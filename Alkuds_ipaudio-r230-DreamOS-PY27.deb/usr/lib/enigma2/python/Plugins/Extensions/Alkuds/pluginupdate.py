# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r229.
"""Download and install the DreamOS update without Screens.Console."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .py2compat import time
from .Task import Job, Task, ReturncodePostcondition
from .xStaticText import MessageBox

BASE = 'https://raw.githubusercontent.com/xximhxx/Alkuds-ipaudio-MAC-Xtreme-Player/main'
INSTALLER = '/tmp/alkuds-installer-dreamos.sh'
PROGRESS_TEXT = u'جارٍ تنزيل تحديث Alkuds وتثبيته...\nقد يستغرق عدة دقائق. لا تفصل الكهرباء عن الرسيفر.'
SUCCESS_TEXT = u'تم تثبيت تحديث Alkuds بنجاح.\n\nيجب إعادة تشغيل واجهة Enigma2 لتفعيل المواقع الجديدة وإصلاح التحديث.\n\nهل تريد إعادة التشغيل الآن؟'
FAILED_TEXT = u'فشل تحديث Alkuds.\n\n%s'

_UPDATE_SCRIPT = u"""#!/bin/sh
URL='%s/installer-dreamos.sh?t=%s'
FILE='%s'
rm -f "$FILE"
if command -v wget >/dev/null 2>&1; then
    wget --no-check-certificate -T 60 -O "$FILE" "$URL" || true
    if [ ! -s "$FILE" ]; then
        rm -f "$FILE"
        wget -T 60 -O "$FILE" "$URL" || true
    fi
fi
if [ ! -s "$FILE" ] && command -v curl >/dev/null 2>&1; then
    curl -kL --connect-timeout 20 --max-time 300 -o "$FILE" "$URL" || true
fi
if [ ! -s "$FILE" ]; then
    echo 'Alkuds update: unable to download installer-dreamos.sh'
    exit 1
fi
sh "$FILE"
rc=$?
rm -f "$FILE"
exit $rc
"""

try:
    text_type = unicode
except NameError:
    text_type = str


class UpdateTask(Task):

    def __init__(self, job, script):
        Task.__init__(self, job, 'Alkuds update')
        self.log = []
        self.postconditions.append(ReturncodePostcondition())
        self.setCmdline('/bin/sh ' + script)

    def processOutputLine(self, line):
        self.log.append(line)
        try:
            print('[Alkuds update] ' + str(line).rstrip())
        except Exception:
            pass


def _error_text(task):
    lines = getattr(task, 'log', None) or []
    values = []
    for line in lines[-12:]:
        try:
            if not isinstance(line, text_type):
                line = line.decode('utf-8', 'replace')
        except Exception:
            line = text_type(line)
        values.append(line)
    text = u''.join(values).strip()
    if not text:
        return u'راجع السجل في /tmp أو أعد المحاولة.'
    return text[-1500:]


def _restart(session, answer):
    if not answer:
        return
    try:
        from Screens import Standby
        Standby.quitMainloop(3)
    except Exception:
        session.open(
            MessageBox,
            u'تعذر إعادة التشغيل تلقائيًا. أعد تشغيل الواجهة من القائمة.',
            MessageBox.TYPE_ERROR, timeout=10)


def start_update(session, owner=None):
    stamp = str(int(time.time()))
    script = '/tmp/alkuds-update-%s.sh' % stamp
    payload = _UPDATE_SCRIPT % (BASE, stamp, INSTALLER)
    try:
        handle = open(script, 'w')
        try:
            handle.write(payload)
        finally:
            handle.close()
        try:
            os.chmod(script, 0o755)
        except OSError:
            pass
    except Exception as error:
        session.open(
            MessageBox, u'تعذر تجهيز التحديث:\n%s' % error,
            MessageBox.TYPE_ERROR, timeout=12)
        return

    progress = session.open(
        MessageBox, PROGRESS_TEXT, MessageBox.TYPE_INFO, timeout=0)
    if owner is not None:
        owner._alkuds_update_progress = progress

    def finished(job, task, problems):
        try:
            progress.close()
        except Exception:
            pass
        if problems:
            session.open(
                MessageBox, FAILED_TEXT % _error_text(task),
                MessageBox.TYPE_ERROR, timeout=20)
            return
        session.openWithCallback(
            lambda answer: _restart(session, answer),
            MessageBox, SUCCESS_TEXT, MessageBox.TYPE_YESNO)

    job = Job('Alkuds update')
    UpdateTask(job, script)
    try:
        job.start(finished)
    except Exception as error:
        try:
            progress.close()
        except Exception:
            pass
        session.open(
            MessageBox, u'تعذر بدء التحديث:\n%s' % error,
            MessageBox.TYPE_ERROR, timeout=12)
