# -*- coding: utf-8 -*-
"""Yacine Android API bootstrap, shared by Python 2.7 and Python 3.

The Android client does not hard-code the API host: it reads it from Firebase
Remote Config (project ycntv-7a08e) and rewrites every request through a host
interceptor.  The plugin follows the same route, but keeps a list of known
endpoints so that a single dead or Cloudflare-blocked host cannot break the
whole provider:

    saved last-good host -> Firebase defaults -> Firebase tv_defaults ->
    built-in hosts -> retired hosts

Only an explicitly configured, *unknown* endpoint bypasses the list.
"""
from __future__ import absolute_import
import json
import os
import re
import time
import threading
import sys
if sys.version_info[0] == 2:
    from .py2compat import requests
else:
    import requests

# Current values published by Firebase Remote Config for the Yacine APK.
# def001.ycnapi.com was retired and its DNS record no longer resolves.
API = 'https://def111.ycnapi.com/api/'
TV_API = 'https://tv.variety-buy.store/api/'
LEGACY_API = 'https://deft.yacinelive.com/api/'  # parked domain, last resort

# Retired hosts are still probed last because a provider may restore them.
RETIRED_APIS = ('https://def001.ycnapi.com/api/',)

_HOST = re.compile(r'^[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}$')
_STORE = '/etc/enigma2/alkuds/yacine-host.json'
_STORE_TTL = 7 * 24 * 3600
_BOOTSTRAP_TTL = 3600
_FETCH = ('https://firebaseremoteconfig.googleapis.com/v1/projects/'
          'ycntv-7a08e/namespaces/firebase:fetch?key='
          'AIzaSyDRKL14PPiXzk7qNUNLgV2IsjasxNpWLeU')

_cache = {'hosts': [], 'until': 0}
_lock = threading.Lock()


def _normalize(base):
    base = str(base or '').strip().rstrip('/')
    return base + '/' if base else ''


def _host_base(host):
    host = str(host or '').strip().lower().strip('.')
    if not _HOST.match(host):
        return ''
    return 'https://' + host + '/api/'


def _hostname(base):
    value = str(base or '').strip()
    return value.split('://', 1)[-1].split('/', 1)[0]


def _bootstrap_hosts():
    """Ask Firebase Remote Config where the Android client points today."""
    response = None
    try:
        response = requests.post(_FETCH, json={
            'app_id': '1:692330584196:android:68ea9f0c920aa17904cad1',
            'package_name': 'ver3.ycntivi.off',
            'app_instance_id': 'x',
        }, timeout=(4, 6))
        response.raise_for_status()
        entries = response.json().get('entries') or {}
    except Exception:
        return []
    finally:
        if response is not None:
            response.close()
    result = []
    for key in ('defaults', 'tv_defaults'):
        base = _host_base(entries.get(key))
        if base and base not in result:
            result.append(base)
    return result


def _bootstrap():
    """Cached Firebase lookup; failures are retried after one minute."""
    with _lock:
        if time.time() < _cache['until']:
            return list(_cache['hosts'])
        hosts = _bootstrap_hosts()
        _cache['hosts'] = list(hosts)
        _cache['until'] = time.time() + (_BOOTSTRAP_TTL if hosts else 60)
        return list(hosts)


def _read_store(ttl=_STORE_TTL):
    try:
        with open(_STORE, 'r') as handle:
            data = json.load(handle)
    except Exception:
        return ''
    base = _normalize(data.get('base'))
    try:
        fresh = time.time() - float(data.get('at') or 0) < ttl
    except (TypeError, ValueError):
        fresh = False
    return base if fresh and _HOST.match(_hostname(base)) else ''


def _write_store(base):
    data = {'base': _normalize(base), 'at': int(time.time())}
    temporary = _STORE + '.tmp'
    try:
        try:
            os.makedirs(os.path.dirname(_STORE))
        except OSError:
            pass
        with open(temporary, 'w') as handle:
            json.dump(data, handle)
        try:
            os.replace(temporary, _STORE)
        except AttributeError:
            if os.path.exists(_STORE):
                os.remove(_STORE)
            os.rename(temporary, _STORE)
    except Exception:
        try:
            os.remove(temporary)
        except Exception:
            pass


def remember(base):
    """Persist the endpoint that just answered, so restarts stay online."""
    base = _normalize(base)
    if not base or _read_store() == base:
        return
    _write_store(base)


def known_bases():
    """Endpoints shipped with the plugin (custom values are not in this list)."""
    result = [_normalize(API), _normalize(TV_API), _normalize(LEGACY_API)]
    result.extend(_normalize(url) for url in RETIRED_APIS)
    return result


def api_bases(configured=None):
    """Ordered API candidates for this request (never empty)."""
    result = []

    def add(base):
        base = _normalize(base)
        if base and base not in result:
            result.append(base)

    configured = _normalize(configured)
    if configured and configured not in known_bases():
        # The owner typed a custom endpoint: respect it and nothing else.
        return [configured]

    add(_read_store())
    # A host that answered within the last day is good enough; asking Firebase
    # on every screen open would add seconds to the receiver's menu.
    if not _read_store(24 * 3600):
        for base in _bootstrap():
            add(base)
    add(TV_API)
    add(API)
    add(LEGACY_API)
    for base in RETIRED_APIS:
        add(base)
    return result


def api_base(configured=None):
    """Backwards-compatible first candidate."""
    return api_bases(configured)[0]


def wire_headers(headers):
    """Send non-ASCII Android header values as UTF-8, without stripping them.

    Keep logical headers as Unicode everywhere else. requests/http.client
    otherwise encode them as Latin-1 and fail before sending the request.
    """
    result = {}
    for key, value in headers.items():
        if isinstance(value, bytes):
            result[key] = value
            continue
        try:
            value.encode('ascii')
        except UnicodeEncodeError:
            value = value.encode('utf-8')
        result[key] = value
    return result
