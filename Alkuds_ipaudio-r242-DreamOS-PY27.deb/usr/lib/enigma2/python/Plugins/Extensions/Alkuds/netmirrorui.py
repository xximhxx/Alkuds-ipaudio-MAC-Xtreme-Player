# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .playbackcache import repeated_catalogue
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import threading
from . import netmirror
from .arabseedui import Alkuds_ArabSeed_Browser
from .fajershowui import Alkuds_FajerShow_Qualities

class Alkuds_NetMirror_Browser(Alkuds_ArabSeed_Browser):
    provider = netmirror
    site_name = 'NetMirror'

    def __init__(self, session, view='platforms', parent=None, page=1):
        self.view = view
        level = 'items' if view in ('titles', 'episodes') else 'groups'
        Alkuds_ArabSeed_Browser.__init__(self, session, 'browse', level, parent, page)
        self['key_yellow'].setText(u'السابق' if level == 'items' else '')
        self['key_blue'].setText(u'التالي' if level == 'items' else u'تحديث')

    def _label(self):
        return self.site_name + (u' — ' + str(self.parent.get('name', '')) if self.parent else '')

    @repeated_catalogue
    def _load_worker(self):
        try:
            if self.view == 'platforms':
                self._result = self.provider.platforms()
            elif self.view == 'navigation':
                self._result = self.provider.navigation(self.parent)
            elif self.view == 'rows':
                self._result = self.provider.sections(self.parent)
            elif self.view == 'seasons':
                self._result = self.provider.seasons(self.parent)
            elif self.view == 'episodes':
                self._result = self.provider.episodes(self.parent, self.page)
            elif self.view == 'titles':
                self._result = self.provider.titles(self.parent, self.page)
            else:
                raise RuntimeError(u'قسم غير معروف')
        except Exception as error:
            self._error = str(error)
        self._done = True

    def open_current(self):
        if self._closed or self._loading:
            return
        index = self._index()
        if not 0 <= index < len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if item.get('action') == 'search':
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(self._search_done, VirtualKeyBoard, title=u'بحث NetMirror', text='')
            return
        if item.get('action') == 'play':
            self._operation, self._loading, self._done = ('resolve', True, False)
            self._result, self._error = (None, '')
            self._update_title(u' — جاري تجهيز الفيديو...')
            task = threading.Thread(target=self._resolve_worker, args=(item,))
            task.daemon = True
            task.start()
            self._timer.start(120, False)
            return
        self.session.open(type(self), item['view'], item, 1)

    def _search_done(self, query):
        if self._closed or not query or (not query.strip()):
            return
        self._operation, self._loading, self._done = ('search', True, False)
        self._result, self._error = (None, '')

        def worker():
            try:
                self._result = self.provider.search(self.parent['ott'], query.strip())
            except Exception as error:
                self._error = str(error)
            self._done = True
        task = threading.Thread(target=worker)
        task.daemon = True
        task.start()
        self._timer.start(120, False)

    def _poll(self):
        if self._operation == 'search' and self._done:
            self._timer.stop()
            self._loading = False
            if self._closed:
                return
            if not self._error:
                self._operation = 'load'
                self.session.open(type(self), 'titles', self._result, 1)
                return
        Alkuds_ArabSeed_Browser._poll(self)

    def _start_resolved(self, item):
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']}, item['name'], 'Series' if item.get('type') == 't' else 'Movie', item.get('show_name', ''), item.get('image', ''), 'netmirror:' + item['ott'] + ':' + item['id'])

    def next_or_refresh(self):
        if self._loading:
            return
        if self.level != 'items':
            self.provider.refresh()
        Alkuds_ArabSeed_Browser.next_or_refresh(self)
