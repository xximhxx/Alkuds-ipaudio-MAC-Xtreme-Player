# -*- coding: utf-8 -*-
"""Short-lived catalogue reuse after two successful visits."""
from collections import OrderedDict
from copy import deepcopy
from functools import wraps
import hashlib
import json
import threading
import time

_LOCK = threading.RLock()
_VISITS = OrderedDict()
_ROWS = OrderedDict()
_TTL = 90


def _key(owner):
    values = [getattr(owner, name, None) for name in (
        "kind", "level", "section", "page", "parent", "topic", "view", "site_name")]
    provider = getattr(owner, "provider", None)
    if isinstance(provider, (str, type(u""))):
        values.append(provider)
    elif provider is not None:
        values.extend((provider.__class__.__name__, getattr(provider, "base", None)))
    payload = json.dumps([owner.__class__.__name__, values], sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(payload.encode("ascii")).hexdigest()


def repeated_catalogue(worker):
    @wraps(worker)
    def load(owner):
        if getattr(owner, "level", None) in ("servers", "detail"):
            return worker(owner)
        try:
            key = _key(owner)
        except (ValueError, TypeError):
            return worker(owner)
        previous = getattr(owner, "_catalogue_cache_key", None)
        owner._catalogue_cache_key = key
        now = time.time()
        with _LOCK:
            cached = _ROWS.pop(key, None)
            if cached and previous != key and now < cached[0]:
                _ROWS[key] = cached
                owner._result = deepcopy(cached[1])
                owner._error = ""
                owner._done = True
                return
        result = worker(owner)
        rows = getattr(owner, "_result", None)
        if getattr(owner, "_error", None) or getattr(owner, "_closed", False) or not rows:
            return result
        if isinstance(rows, dict) and not rows.get("entries"):
            return result
        try:
            if len(json.dumps(rows, ensure_ascii=True)) > 192 * 1024:
                return result
        except (ValueError, TypeError):
            return result
        with _LOCK:
            count, stamp = _VISITS.pop(key, (0, 0))
            if now - stamp > 1800:
                count = 0
            count = min(2, count + 1)
            _VISITS[key] = (count, now)
            if count == 2:
                _ROWS[key] = (time.time() + _TTL, deepcopy(rows))
            while len(_VISITS) > 96:
                _VISITS.popitem(last=False)
            while len(_ROWS) > 16:
                _ROWS.popitem(last=False)
        return result
    return load
