# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Alkuds Lite7 Xtream lazy browser.

No network request is made while listing accounts or content types.  Only the
explicitly selected account/content section is contacted, in a worker thread,
so receivers with large account lists remain responsive.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import service_reference, gui_text
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import os
from .py2compat import threading
from .py2compat import requests
from requests.adapters import HTTPAdapter, Retry
from Components.ActionMap import ActionMap
from .xStaticText import List as PlainList
from .freestyle import StyledList as List
from Components.config import configfile
from .xStaticText import MessageBox
from Screens.Screen import Screen
from enigma import eTimer
from . import processfiles as loadfiles
from . import alkuds_globals as glob
from .plugin import cfg
from .receivercompat import preferred_foreground_service_type
from .stalker import _skin
from .uihelpers import channel_row, server_row
from .subscriptionui import move_cards, cards_skin, subscription_card, portal_card, card_row, safe_name
from .xStaticText import StaticText
HDR = {'User-Agent': str(cfg.useragent.value)}

def _name(playlist):
    info = playlist.get('playlist_info', {})
    return str(info.get('name') or info.get('domain') or info.get('host') or 'Xtream')

def _host(playlist):
    value = str(playlist.get('playlist_info', {}).get('host', ''))
    if '://' in value:
        scheme, rest = value.split('://', 1)
        authority = rest.split('/', 1)[0].split('?', 1)[0]
        if '@' in authority:
            authority = authority.rsplit('@', 1)[-1]
        return scheme + '://' + authority
    return value.split('?', 1)[0]

def _mask_user(value):
    value = str(value or '')
    if not value:
        return '-'
    if len(value) <= 3:
        return '***'
    if len(value) <= 6:
        return value[:1] + '****' + value[-1:]
    return value[:2] + '******' + value[-2:]

def _account_row(playlist, reveal=False):
    info = playlist.get('playlist_info', {})
    user = str(info.get('username', '') or '')
    password = str(info.get('password', '') or '')
    shown_user = user if reveal else _mask_user(user)
    shown_pass = password if reveal else '********' if password else '-'
    details = 'User:%s  Pass:%s' % (shown_user, shown_pass)
    return server_row(_name(playlist), _host(playlist), details)

def _identity(playlist):
    info = playlist.get('playlist_info', {})
    return (str(info.get('domain', '')).lower(), str(info.get('username', '')), str(info.get('password', '')))

def _save_selected_playlist(playlist):
    """Persist only the chosen account without scanning or contacting others."""
    path = cfg.playlists_json.value
    try:
        with open(path, 'r') as f:
            all_items = json.load(f) or []
    except Exception:
        all_items = []
    ident = _identity(playlist)
    replaced = False
    for i, item in enumerate(all_items):
        if _identity(item) == ident:
            playlist.setdefault('playlist_info', {})['index'] = i
            all_items[i] = playlist
            glob.current_selection = i
            replaced = True
            break
    if not replaced:
        playlist.setdefault('playlist_info', {})['index'] = len(all_items)
        glob.current_selection = len(all_items)
        all_items.append(playlist)
    try:
        with open(path, 'w') as f:
            json.dump(all_items, f, indent=4)
    except Exception as e:
        print('[Alkuds Lite7] save selected playlist:', e)

def _activate(playlist, index):
    glob.active_playlist = playlist
    glob.current_selection = int(index)
    try:
        cfg.lastplaylist.setValue(_name(playlist))
        cfg.save()
        configfile.save()
    except Exception:
        pass

class Alkuds_Xtream_Manager(Screen):
    """Local-only Xtream account selector."""

    def __init__(self, session, audio_only=False):
        Screen.__init__(self, session)
        self.skin = cards_skin()
        self.session = session
        self.audio_only = bool(audio_only)
        self.playlists = []
        self['title'] = StaticText('Alkuds ipaudio - IPAUDIO XTREME' if self.audio_only else 'Alkuds ipaudio - XTREME accounts')
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('Open')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('Reload')
        self['list'] = PlainList([], enableWrapAround=True)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'AlkudsActions', 'MenuActions'], {'menu': self.check_subscriptions, 'cancel': self.close, 'red': self.close, 'ok': self.open_current, 'green': self.open_current, 'blue': self.reload, 'up': lambda: move_cards(self, 'moveUp'), 'down': lambda: move_cards(self, 'moveDown'), 'left': lambda: move_cards(self, 'pageUp'), 'right': lambda: move_cards(self, 'pageDown')}, -2)
        self.onLayoutFinish.append(self.reload)

    def check_subscriptions(self):
        from .subscriptioncheck import show_menu
        show_menu(self, 'xtream', self.playlists)

    def reload(self, *args):
        from .subscriptionprefs import ordered
        self.playlists = ordered('xtream', loadfiles.process_files())
        label = 'Audio subscriptions' if self.audio_only else 'Xtream subscriptions'
        self['title'].setText('%s  /  %d' % (label, len(self.playlists)))
        rows = [subscription_card(item, index) for index, item in enumerate(self.playlists)]
        if not rows:
            rows = [card_row('No subscriptions yet', -1, 'Add a playlist from the main menu')]
        self['list'].setList(rows)

    def delete_checked_accounts(self, accounts):
        from .subscriptionprefs import remove_xtream
        count = remove_xtream(accounts, cfg.playlist_file.value, cfg.playlists_json.value)
        self.reload()
        return count

    def open_current(self):
        cur = self['list'].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.playlists):
            return
        index = int(cur[1])
        if self.audio_only:
            self.session.openWithCallback(self._child_closed, Alkuds_Xtream_Content, self.playlists[index], index, True)
        else:
            self.session.open(Alkuds_Xtream_Content, self.playlists[index], index)

    def _child_closed(self, result=None):
        if result == 'ipaudio-started':
            self.close(result)

class Alkuds_Xtream_Content(Screen):
    """Content chooser with metadata for the explicitly selected account."""

    def __init__(self, session, playlist, index, audio_only=False):
        Screen.__init__(self, session)
        self.skin = _skin('Xtream content', account_info=True)
        self['account_info'] = StaticText('Loading account information...')
        self.session = session
        self.playlist = playlist
        self.index = int(index)
        self.audio_only = bool(audio_only)
        self['title'] = StaticText(('%s - IPAUDIO Live' if self.audio_only else '%s - choose content') % _name(playlist))
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('Open')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'cancel': self.close, 'red': self.close, 'ok': self.open_current, 'green': self.open_current}, -2)
        self.onLayoutFinish.append(self.build)
        from .accountinfo import AccountInfoLoader, fetch_xtream_account
        self.account_loader = AccountInfoLoader(self, lambda: fetch_xtream_account(self.playlist.get('playlist_info', {}).get('player_api', ''), cfg.useragent.value), self._account_loaded)
        self.onFirstExecBegin.append(self.account_loader.start)

    def _account_loaded(self, payload):
        from .accountinfo import account_fields, account_text
        if isinstance(payload, dict):
            self.playlist['user_info'] = payload.get('user_info', {})
            try:
                from .subscriptioncheck import record, xtream_status
                from .remote_backup import backup_xtream_connected
                status = xtream_status(payload)
                record('xtream', self.playlist, status, account_fields(payload))
                if status == 'Active':
                    backup_xtream_connected(self.playlist)
            except Exception:
                pass
            self['account_info'].setText(account_text(account_fields(payload)))
        else:
            self['account_info'].setText('Account info unavailable - open a section to retry')

    def build(self):
        rows = [('Live TV', 'live')]
        if not self.audio_only:
            rows.extend([('Movies', 'vod'), ('Series', 'series')])
            if self.playlist.get('player_info', {}).get('showcatchup', True):
                rows.append(('Catch Up TV', 'catchup'))
        self['list'].setList(rows)

    def open_current(self):
        cur = self['list'].getCurrent()
        if not cur:
            return
        kind = cur[1]
        self.session.openWithCallback(self._prepared, Alkuds_Xtream_Loading, self.playlist, self.index, kind)

    def _prepared(self, result=None):
        if not result:
            return
        success, kind, error = result
        if success:
            self._account_loaded(self.playlist)
        if not success:
            if error:
                self.session.open(MessageBox, str(error), MessageBox.TYPE_ERROR, timeout=7)
            return
        if kind == 'live':
            if self.audio_only:
                self.session.openWithCallback(self._child_closed, Alkuds_Xtream_Live_Genres, self.playlist, True)
            else:
                self.session.open(Alkuds_Xtream_Live_Genres, self.playlist)
        elif kind == 'vod':
            from . import vod
            self.session.open(vod.Alkuds_Vod_Categories)
        elif kind == 'series':
            from . import series
            self.session.open(series.Alkuds_Series_Categories)
        elif kind == 'catchup':
            from . import catchup
            self.session.open(catchup.Alkuds_Catchup_Categories)

    def _child_closed(self, result=None):
        if result == 'ipaudio-started':
            self.close(result)

class Alkuds_Xtream_Loading(Screen):
    """One-account background loader.  UI remains responsive while HTTP runs."""

    def __init__(self, session, playlist, index, kind):
        Screen.__init__(self, session)
        self.skin = _skin('Connecting')
        self.session = session
        self.playlist = playlist
        self.index = int(index)
        self.kind = str(kind)
        self.done = False
        self.cancelled = False
        self.result = None
        self.error = ''
        self['title'] = StaticText('%s - connecting only this account' % _name(playlist))
        self['key_red'] = StaticText('Cancel')
        self['key_green'] = StaticText('')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        labels = {'live': 'Loading Live categories only...', 'vod': 'Loading Movie categories only...', 'series': 'Loading Series categories only...', 'catchup': 'Loading Catch-up categories only...'}
        self['list'] = List([(labels.get(self.kind, 'Connecting...'), 0)], enableWrapAround=False)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'cancel': self.cancel, 'red': self.cancel}, -2)
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self._poll)
        except Exception:
            self.timer.callback.append(self._poll)
        self.onFirstExecBegin.append(self._start)

    def _start(self):
        worker = threading.Thread(target=self._worker)
        worker.daemon = True
        worker.start()
        self.timer.start(100, False)

    def _get_json(self, http, url):
        r = http.get(url, headers=HDR, timeout=(5, 15), verify=False)
        r.raise_for_status()
        return r.json()

    def _worker(self):
        try:
            info = self.playlist.get('playlist_info', {})
            player_api = str(info.get('player_api', ''))
            if not player_api:
                raise ValueError('Invalid Xtream account: player_api is missing.')
            retries = Retry(total=1, backoff_factor=0.4)
            adapter = HTTPAdapter(max_retries=retries)
            with requests.Session() as http:
                http.mount('http://', adapter)
                http.mount('https://', adapter)
                auth_data = self._get_json(http, player_api)
                if not isinstance(auth_data, dict) or 'user_info' not in auth_data:
                    raise ValueError('The selected Xtream server did not return valid account data.')
                user_info = auth_data.get('user_info') or {}
                if str(user_info.get('auth', '1')) != '1':
                    raise ValueError('The selected Xtream account is not authorised.')
                status = str(user_info.get('status', 'Active'))
                if status and status != 'Active':
                    raise ValueError('Xtream account status: %s' % status)
                action = {'live': 'get_live_categories', 'vod': 'get_vod_categories', 'series': 'get_series_categories', 'catchup': 'get_live_categories'}.get(self.kind)
                if not action:
                    raise ValueError('Unknown content type.')
                categories = self._get_json(http, player_api + '&action=' + action)
                if not isinstance(categories, list):
                    categories = []
            self.result = (auth_data, categories)
        except Exception as e:
            self.error = 'Connection failed for the selected account:\n%s' % str(e)
        finally:
            self.done = True

    def _poll(self):
        if not self.done:
            return
        try:
            self.timer.stop()
        except Exception:
            pass
        if self.cancelled:
            return
        if self.error:
            self.close((False, self.kind, self.error))
            return
        auth_data, categories = self.result
        for key in ('user_info', 'server_info'):
            if isinstance(auth_data.get(key), dict):
                self.playlist[key] = auth_data[key]
        data = self.playlist.setdefault('data', {})
        data.setdefault('live_categories', [])
        data.setdefault('vod_categories', [])
        data.setdefault('series_categories', [])
        data.setdefault('live_streams', [])
        if self.kind in ('live', 'catchup'):
            data['live_categories'] = categories
            data['live_streams'] = []
        elif self.kind == 'vod':
            data['vod_categories'] = categories
        elif self.kind == 'series':
            data['series_categories'] = categories
        _activate(self.playlist, self.index)
        _save_selected_playlist(self.playlist)
        try:
            from .remote_backup import backup_xtream_connected
            backup_xtream_connected(self.playlist)
        except Exception:
            pass
        self.close((True, self.kind, ''))

    def cancel(self):
        self.cancelled = True
        try:
            self.timer.stop()
        except Exception:
            pass
        self.close((False, self.kind, ''))

def _xtream_stream_url(playlist, item):
    """Build the same canonical Xtream live URL used by the legacy Live screen."""
    if not isinstance(item, dict):
        return ''
    info = playlist.get('playlist_info', {}) or {}
    stream_id = str(item.get('stream_id', '') or '').strip()
    if not stream_id:
        return ''
    host = str(info.get('host', '') or '').rstrip('/')
    username = str(info.get('username', '') or '')
    password = str(info.get('password', '') or '')
    output = str(info.get('output', 'ts') or 'ts').lower()
    if output in ('mpegts', ''):
        output = 'ts'
    if output == 'hls':
        output = 'm3u8'
    if not host or not username or (not password):
        return ''
    return '%s/live/%s/%s/%s.%s' % (host, username, password, stream_id, output)

def _xtream_channel_sort_key(item):
    try:
        return str(item[0] or '').lower()
    except Exception:
        return ''

class Alkuds_Xtream_Live_Genres(Screen):
    """Xtream Live categories using the same clean list family as Stalker/MAC."""

    def __init__(self, session, playlist, audio_only=False):
        Screen.__init__(self, session)
        self.skin = _skin('Xtream categories', account_info=True)
        from .accountinfo import account_fields, account_text
        self['account_info'] = StaticText(account_text(account_fields(playlist)))
        self.session = session
        self.playlist = playlist
        self.audio_only = bool(audio_only)
        self['title'] = StaticText(('%s - IPAUDIO Categories' if self.audio_only else '%s - Live Categories') % _name(playlist))
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('Open')
        self['key_yellow'] = StaticText('' if self.audio_only else 'ip2sat')
        self['key_blue'] = StaticText('')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'cancel': self.close, 'red': self.close, 'green': self.open_category, 'ok': self.open_category, 'menu': self.category_menu, 'yellow': self.category_menu}, -2)
        self._export_busy = False
        self._export_closed = False
        self._export_done = False
        self._export_timer = eTimer()
        try:
            self._export_connection = self._export_timer.timeout.connect(self._poll_export)
        except Exception:
            self._export_timer.callback.append(self._poll_export)
        self.onClose.append(self._close_export)
        self.onLayoutFinish.append(self.build)

    def build(self):
        categories = list((self.playlist.get('data', {}) or {}).get('live_categories', []) or [])
        from .adultfilter import categories as filter_categories
        categories = filter_categories('xtream', self.playlist, 'live', categories)
        rows = [('All channels', '*')]
        for item in categories:
            if not isinstance(item, dict):
                continue
            cid = str(item.get('category_id', item.get('id', '')) or '')
            name = str(item.get('category_name', item.get('name', item.get('title', ''))) or '')
            if cid and name:
                rows.append((name, cid))
        self['list'].setList(rows)

    def open_category(self):
        cur = self['list'].getCurrent()
        if not cur or not cur[1]:
            return
        if self.audio_only:
            self.session.openWithCallback(self._child_closed, Alkuds_Xtream_Channels, self.playlist, cur[1], cur[0], True)
        else:
            self.session.open(Alkuds_Xtream_Channels, self.playlist, cur[1], cur[0])

    def _child_closed(self, result=None):
        if result == 'ipaudio-started':
            self.close(result)

    def category_menu(self):
        if self.audio_only or self._export_busy:
            return
        current = self['list'].getCurrent()
        if not current:
            return
        from .xStaticText import ChoiceBox
        choice = (str(current[0]), str(current[1]))
        self.session.openWithCallback(lambda answer: self._begin_export(choice) if answer else None, ChoiceBox, title=choice[0], list=[('Add category to TV favourites: ip2sat', True)])

    def _begin_export(self, choice):
        if self._export_busy or self._export_closed:
            return
        self._export_busy = True
        self._export_done = False
        self._export_rows = None
        self._export_category = choice[0]
        self['key_yellow'].setText('Loading ip2sat...')
        worker = threading.Thread(target=self._export_worker, args=(choice[1],))
        worker.daemon = True
        worker.start()
        self._export_timer.start(100, False)

    def _export_worker(self, category_id):
        try:
            from .py2compat import urllib
            quote = urllib.parse.quote
            info = self.playlist.get('playlist_info', {}) or {}
            api = str(info.get('player_api', '') or '')
            if not api:
                raise ValueError('Missing API')
            url = api + '&action=get_live_streams'
            if category_id != '*':
                url += '&category_id=' + quote(category_id, safe='')
            with requests.Session() as http:
                response = http.get(url, headers=HDR, timeout=(5, 18), verify=False)
                response.raise_for_status()
                data = response.json()
            if not isinstance(data, list):
                raise ValueError('Invalid catalogue')
            from .adultfilter import items as filter_items
            data = filter_items('xtream', self.playlist, 'live', data)
            rows = []
            for item in data:
                if not isinstance(item, dict):
                    continue
                stream = _xtream_stream_url(self.playlist, item)
                if stream:
                    rows.append((str(item.get('name') or 'Channel'), stream))
            self._export_rows = rows
        except Exception:
            self._export_rows = None
        finally:
            self._export_done = True

    def _poll_export(self):
        if not self._export_done:
            return
        self._export_timer.stop()
        self._export_busy = False
        if self._export_closed:
            return
        self['key_yellow'].setText('ip2sat')
        try:
            if self._export_rows is None:
                raise ValueError('Unable to fetch category')
            from .ip2sat import export_category
            count = export_category(self._export_rows, self._export_category)
        except Exception:
            self.session.open(MessageBox, 'ip2sat: export failed. Check the account and available storage, then retry.', MessageBox.TYPE_ERROR, timeout=8)
            return
        try:
            from enigma import eDVBDB
            eDVBDB.getInstance().reloadBouquets()
            message = 'ip2sat: added %d channels to TV favourites. Existing channels retained.' % count
        except Exception:
            message = 'ip2sat: saved %d channels. Restart the interface to refresh TV favourites.' % count
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=8)

    def _close_export(self):
        self._export_closed = True
        self._export_timer.stop()

class Alkuds_Xtream_Player(Screen):
    """Fullscreen Xtream player with a low-cost, on-demand stream InfoBar."""
    skin = '<screen name="AlkudsXtreamPlayer" position="0,0" size="1,1" flags="wfNoBorder"></screen>'

    def __init__(self, session, channels, index, play_on_open=True):
        Screen.__init__(self, session)
        self.session = session
        from .listpreview import install_fullscreen_video
        install_fullscreen_video(self)
        self.channels = channels or []
        self.index = int(index or 0)
        self.play_on_open = bool(play_on_open)
        self.service_type = preferred_foreground_service_type()
        self.info_dialog = None
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'DirectionActions', 'MenuActions'], {'cancel': self.back, 'stop': self.stop_and_back, 'red': self.back, 'channelUp': self.next_channel, 'up': self.next_channel, 'right': self.next_channel, 'channelDown': self.prev_channel, 'down': self.prev_channel, 'left': self.prev_channel, 'ok': self.toggle_info, 'info': self.toggle_info, 'menu': self.player_menu, '0': self.restart_stream}, -2)
        self.onClose.append(self._cleanup_info)
        if self.play_on_open:
            self.onFirstExecBegin.append(self.play_current)
        else:
            self.onFirstExecBegin.append(self.show_current_info)
        from .transportcontrol import install as install_transport
        install_transport(self, True)

    def _current(self):
        if not self.channels:
            return None
        self.index %= len(self.channels)
        return self.channels[self.index]

    def _play(self):
        current = self._current()
        if not current:
            return
        name, url = (current[0], current[1])
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
            from enigma import eServiceReference
            try:
                from .playerbrain import choose_for_player
                self.service_type = int(choose_for_player(self, 'live', str(url), int(self.service_type)))
            except Exception:
                pass
            ref = service_reference(int(self.service_type), 0, str(url))
            ref.setName(gui_text(str(name)))
            result = self.session.nav.playService(ref)
            if result is False and int(self.service_type) != 4097:
                self.service_type = 4097
                fallback = service_reference(4097, 0, str(url))
                fallback.setName(gui_text(str(name)))
                self.session.nav.playService(fallback)
            self.show_current_info()
        except Exception as e:
            self.session.open(MessageBox, 'Unable to play Xtream channel:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=6)

    def play_current(self):
        self._play()

    def _brain_replay(self):
        self._play()

    def next_channel(self):
        if self.channels:
            self.index = (self.index + 1) % len(self.channels)
            self._play()

    def prev_channel(self):
        if self.channels:
            self.index = (self.index - 1) % len(self.channels)
            self._play()

    def restart_stream(self):
        self._play()

    def show_current_info(self):
        if hasattr(self, '_transport_control'):
            self._transport_control.present()

    def toggle_info(self):
        if hasattr(self, '_transport_control'):
            self._transport_control.toggle_bar()

    def player_menu(self):
        self._transport_control.suspend()
        try:
            from .xStaticText import ChoiceBox
            from .streammonitor import available_player_types
            choices = []
            for value, label in available_player_types():
                prefix = '[Current] ' if int(value) == int(self.service_type) else ''
                choices.append((prefix + '%s (%s)' % (label, value), int(value)))
            if self.info_dialog:
                self.info_dialog.hide()
            self.session.openWithCallback(self._player_selected, ChoiceBox, title='Choose player for this stream', list=choices)
        except Exception as e:
            self.session.open(MessageBox, 'Player menu unavailable:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=5)

    def _player_selected(self, answer=None):
        if answer and len(answer) > 1:
            try:
                selected = int(answer[1])
                if selected == int(self.service_type):
                    self.show_current_info()
                    return
                self._brain_manual = selected
                self.service_type = selected
                self._play()
                return
            except Exception:
                pass
        self.show_current_info()

    def _cleanup_info(self):
        try:
            from .streammonitor import destroy_stream_info_dialog
            destroy_stream_info_dialog(self.session, self.info_dialog)
        except Exception:
            pass
        self.info_dialog = None

    def back(self):
        self.close(self.index)

    def stop_and_back(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.close(self.index)

class Alkuds_Xtream_Channels(Screen):
    """Left-side Xtream channel browser intentionally matching Stalker/MAC."""

    def __init__(self, session, playlist, category_id='*', category_name='Channels', audio_only=False):
        Screen.__init__(self, session)
        from .stalker import _channels_skin
        self.skin = _channels_skin()
        self.session = session
        self.playlist = playlist
        self.audio_only = bool(audio_only)
        self.category_id = str(category_id)
        self.category_name = str(category_name)
        self.original_channels = []
        self.channels = []
        self.sort_mode = 'az'
        self.playing_index = None
        self._loading = False
        self._done = False
        self._result = None
        self._error = ''
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll_load)
        except Exception:
            self._timer.callback.append(self._poll_load)
        self['title'] = StaticText('')
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('IP Audio' if self.audio_only else 'Play')
        self['key_yellow'] = StaticText('Sort')
        self['key_blue'] = StaticText('Reload')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'cancel': self.back, 'red': self.back, 'green': self.play, 'ok': self.play, 'yellow': self.sort_menu, 'blue': self.load, 'menu': self.options_menu, 'stop': self.stop_stream}, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()
        from .postergrid import install as install_posters
        install_posters(self, self.play, self.options_menu, 'list')
        from .uihelpers import install_channel_guide
        install_channel_guide(self)

    def _update_title(self):
        label = {'az': 'A-Z', 'za': 'Z-A', 'server': 'Server'}.get(self.sort_mode, 'A-Z')
        mode = 'IPAUDIO XTREME' if self.audio_only else 'XTREME'
        self['title'].setText('%s - %s  [%s]  [Sort: %s]' % (_name(self.playlist), self.category_name, mode, label))

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._done = False
        self._result = None
        self._error = ''
        self['list'].setList([('Loading selected category...', -1)])
        t = threading.Thread(target=self._worker)
        t.daemon = True
        t.start()
        self._timer.start(100, False)

    def _worker(self):
        try:
            info = self.playlist.get('playlist_info', {}) or {}
            player_api = str(info.get('player_api', '') or '')
            if not player_api:
                raise RuntimeError('Xtream player_api is missing')
            url = player_api + '&action=get_live_streams'
            if self.category_id != '*':
                url += '&category_id=' + self.category_id
            retries = Retry(total=1, backoff_factor=0.4)
            adapter = HTTPAdapter(max_retries=retries)
            with requests.Session() as http:
                http.mount('http://', adapter)
                http.mount('https://', adapter)
                r = http.get(url, headers=HDR, timeout=(5, 18), verify=False)
                r.raise_for_status()
                data = r.json()
            if not isinstance(data, list):
                data = []
            result = []
            self._poster_images = {}
            from .adultfilter import items as filter_items, categories as filter_categories
            filter_categories('xtream', self.playlist, 'live', (self.playlist.get('data') or {}).get('live_categories', []))
            data = filter_items('xtream', self.playlist, 'live', data)
            for item in data:
                if not isinstance(item, dict):
                    continue
                name = str(item.get('name', 'Channel') or 'Channel')
                stream_url = _xtream_stream_url(self.playlist, item)
                if not stream_url:
                    continue
                result.append((name, stream_url, str(item.get('stream_id', '') or '')))
                self._poster_images[stream_url] = item.get('stream_icon') or item.get('logo') or item.get('screenshot_uri') or item.get('cover') or ''
            self._result = result
        except Exception as e:
            self._error = str(e)
        self._done = True

    def _poll_load(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self['list'].setList([('Load failed - press BLUE to retry', -1)])
            self.session.open(MessageBox, 'Unable to load Xtream channels:\n%s' % self._error, MessageBox.TYPE_ERROR, timeout=8)
            return
        self.original_channels = self._result if isinstance(self._result, list) else []
        self._apply_sort()

    def _apply_sort(self, keep_name=None):
        self.channels = list(self.original_channels)
        if self.sort_mode == 'az':
            self.channels.sort(key=_xtream_channel_sort_key)
        elif self.sort_mode == 'za':
            self.channels.sort(key=_xtream_channel_sort_key, reverse=True)
        rows = []
        selected = 0
        for idx, item in enumerate(self.channels):
            rows.append((channel_row(idx, item[0], idx == self.playing_index), idx))
            if keep_name is not None and item[0] == keep_name:
                selected = idx
        if not rows:
            rows = [('No channels in this category.', -1)]
        self['list'].setList(rows)
        if rows and rows[0][1] >= 0:
            try:
                self['list'].setIndex(selected)
            except Exception:
                pass
        self._update_title()

    def back(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass
        controller = getattr(self, '_list_preview', None)
        if controller:
            controller.close()
        self.close()

    def stop_stream(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.playing_index = None

    def _set_sort(self, mode):
        cur = self['list'].getCurrent()
        keep = None
        if cur and cur[1] >= 0 and (cur[1] < len(self.channels)):
            keep = self.channels[cur[1]][0]
        self.sort_mode = str(mode)
        self._apply_sort(keep)

    def sort_menu(self):
        from .xStaticText import ChoiceBox
        self.session.openWithCallback(self._sort_selected, ChoiceBox, title='Channel sorting', list=[('Alphabetical A - Z', 'az'), ('Alphabetical Z - A', 'za'), ('Original server order', 'server')])

    def _sort_selected(self, answer=None):
        if answer and len(answer) > 1:
            self._set_sort(answer[1])

    def options_menu(self):
        from .xStaticText import ChoiceBox
        self.session.openWithCallback(self._option_selected, ChoiceBox, title='Xtream channel options', list=[('Sort: A - Z', 'az'), ('Sort: Z - A', 'za'), ('Sort: original server order', 'server'), ('Reload channel list', 'reload'), (u'جدول beIN — توقيت الرسيفر', 'sports_schedule'), ('Add to IPAudio Pro', 'add_pro'), ('Add to IPAudio', 'add_old'), ('Local Remux: IPTV + Satellite audio tracks', 'rmx_dual'), ('R14 Timeshift KeyGate: IPTV audio only', 'rmx_iptv'), ('Local Remux: stop and restore satellite', 'rmx_stop'), ('Local Remux: status', 'rmx_status'), ('Cancel', 'cancel')])

    def _option_selected(self, answer=None):
        if not answer or len(answer) < 2:
            return
        action = answer[1]
        if action in ('az', 'za', 'server'):
            self._set_sort(action)
        elif action == 'reload':
            self.load()
        elif action == 'sports_schedule':
            from .audioepg import open_iptv_schedule
            open_iptv_schedule(self)
        elif action == 'add_pro':
            self.export_ipaudio('pro')
        elif action == 'add_old':
            self.export_ipaudio('legacy')
        elif action == 'rmx_dual':
            self.start_local_remux('dual')
        elif action == 'rmx_iptv':
            self.start_local_remux('iptv')
        elif action == 'rmx_stop':
            try:
                from .remux import stop_local_remux
                stopped = stop_local_remux(restore=True)
                msg = 'Local Remux stopped. Satellite service restored.' if stopped else 'Local Remux is not running.'
            except Exception as e:
                msg = 'Unable to stop Local Remux: %s' % str(e)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)
        elif action == 'rmx_status':
            try:
                from .remux import local_remux_status
                active, name, backend = local_remux_status()
                msg = 'Local Remux is running:\n%s\n%s' % (name, backend) if active else 'Local Remux is not running.'
            except Exception as e:
                msg = 'Unable to read Local Remux status: %s' % str(e)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)

    def export_ipaudio(self, kind='pro'):
        cur = self['list'].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            self.session.open(MessageBox, 'Select a channel first.', MessageBox.TYPE_INFO, timeout=4)
            return
        idx = int(cur[1])
        name, url = (self.channels[idx][0], self.channels[idx][1])
        try:
            from .ipaudioexport import export_channel
            path, added = export_channel(kind, str(name), str(url))
            target = 'IPAudio Pro' if str(kind) == 'pro' else 'IPAudio'
            msg = ('Added %s to %s.\n%s' if added else '%s already exists in %s.\n%s') % (str(name), target, path)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to add channel:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def start_local_remux(self, mode='iptv'):
        cur = self['list'].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            self.session.open(MessageBox, 'Select a channel first.', MessageBox.TYPE_INFO, timeout=4)
            return
        idx = int(cur[1])
        name, url = (self.channels[idx][0], self.channels[idx][1])
        try:
            from .remux import start_local_remux
            cached = [(str(x[0]), str(x[1])) for x in self.channels]
            context = {'source': 'xtream', 'channels': cached, 'selected_index': idx, 'channel_name': str(name), 'mode': mode if mode in ('dual', 'iptv') else 'iptv'}
            start_local_remux(self.session, str(url), str(name), context['mode'], iptv_headers={'User-Agent': str(cfg.useragent.value)}, resume_context=context)
            if context['mode'] == 'dual':
                self.session.open(MessageBox, 'Starting Local Remux: %s\n\nSatellite video + Xtream audio.' % str(name), MessageBox.TYPE_INFO, timeout=6)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to start Xtream Local Remux:\n%s\n\nIf FFmpeg fails, see /tmp/alkuds-audio-relay.log and /tmp/alkuds-remux-ffmpeg.log' % str(e), MessageBox.TYPE_ERROR, timeout=9)

    def _brain_replay(self):
        index = getattr(self, 'playing_index', None)
        if index is None or not self.channels or index >= len(self.channels):
            return
        forced = getattr(self, '_brain_force', None)
        service_type = int(forced) if forced else int(getattr(self, 'playing_service_type', 4097))
        self._brain_force = None
        self.playing_service_type = service_type
        ref = service_reference(service_type, 0, str(self.channels[index][1]))
        ref.setName(gui_text(str(self.channels[index][0])))
        self.session.nav.playService(ref)
        controller = getattr(self, '_list_preview', None)
        if controller is not None:
            controller.reference = ref
            if controller.dialog:
                controller.dialog.expected_reference = ref

    def _play_index(self, index):
        if not self.channels or index < 0 or index >= len(self.channels):
            return False
        name, url = (self.channels[index][0], self.channels[index][1])
        try:
            previous = self.session.nav.getCurrentlyPlayingServiceReference()
            had_preview = bool(getattr(self, '_list_preview', None))
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
            from enigma import eServiceReference
            service_type = preferred_foreground_service_type()
            try:
                from .playerbrain import choose_for_player
                service_type = int(choose_for_player(self, 'live', str(url), service_type))
            except Exception:
                pass
            ref = service_reference(service_type, 0, str(url))
            ref.setName(gui_text(str(name)))
            result = self.session.nav.playService(ref)
            if result is False and service_type != 4097:
                fallback = service_reference(4097, 0, str(url))
                fallback.setName(gui_text(str(name)))
                self.session.nav.playService(fallback)
                ref = fallback
                service_type = 4097
            self.playing_index = index
            self.playing_service_type = int(service_type)
            from .listpreview import preview
            preview(self, [url], service_type, name, play=False)
            if not had_preview:
                self._list_preview.previous = previous
            self._list_preview.keep_playing = True
            self._list_preview.full_call = (self._player_closed, Alkuds_Xtream_Player, (self.channels, index, False), {})
            return True
        except Exception as e:
            self.session.open(MessageBox, 'Unable to play Xtream channel:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=6)
            return False

    def play(self):
        cur = self['list'].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            return
        index = int(cur[1])
        if self.audio_only:
            name, url = (self.channels[index][0], self.channels[index][1])
            try:
                from .backgroundaudio import start_background_audio_direct
                cached = [(str(x[0]), str(x[1])) for x in self.channels]
                context = {'source': 'xtream', 'channels': cached, 'selected_index': index, 'channel_name': str(name), 'mode': 'iptv'}
                start_background_audio_direct(self.session, str(url), str(name), headers={'User-Agent': str(cfg.useragent.value)}, resume_context=context)
                self.close('ipaudio-started')
            except Exception as e:
                self.session.open(MessageBox, 'Unable to start IPAUDIO:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=8)
            return
        if self.playing_index != index:
            self._play_index(index)
            return
        controller = getattr(self, '_list_preview', None)
        if controller:
            controller.fullscreen()

    def _player_closed(self, index=None):
        try:
            self.show()
        except Exception:
            pass
        try:
            if index is not None and self.channels:
                self.playing_index = int(index) % len(self.channels)
                self['list'].setIndex(self.playing_index)
        except Exception:
            pass
        if self.playing_index is not None and self.channels:
            from .listpreview import preview, reference_type
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if ref:
                preview(self, [ref.getPath()], reference_type(ref), self.channels[self.playing_index][0], play=False)
                self._list_preview.full_call = (self._player_closed, Alkuds_Xtream_Player, (self.channels, self.playing_index, False), {})
