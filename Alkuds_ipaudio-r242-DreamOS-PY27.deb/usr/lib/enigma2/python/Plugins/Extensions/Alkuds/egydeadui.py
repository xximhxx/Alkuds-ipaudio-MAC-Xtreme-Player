# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .playbackcache import repeated_catalogue
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import egydead
from .arabseedui import Alkuds_ArabSeed_Browser

class Alkuds_EgyDead_Browser(Alkuds_ArabSeed_Browser):
    provider = egydead
    site_name = u'إيجي ديد EgyDead'

    @repeated_catalogue
    def _load_worker(self):
        if self.level == 'sections':
            self._result = [{'name': u'بحث في هذا القسم', 'action': 'search'}, {'name': u'الأحدث', 'order': 'latest'}, {'name': u'ترتيب الصفحة أ–ي', 'order': 'az'}, {'name': u'ترتيب الصفحة ي–أ', 'order': 'za'}]
            self._done = True
        else:
            Alkuds_ArabSeed_Browser._load_worker(self)
