# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Small, self-contained player for Free Arabic TV."""
from __future__ import absolute_import, division, print_function
from .py2compat import service_reference, gui_text
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .py2compat import subprocess
from .py2compat import time
try:
    import cPickle as pickle
except ImportError:
    import pickle
from Components.ActionMap import ActionMap
from Components.ServiceEventTracker import ServiceEventTracker
from enigma import eServiceReference, eTimer, getDesktop, iPlayableService, iServiceInformation
from .xStaticText import ChoiceBox
from Screens.Screen import Screen
from .receivercompat import set_selected_free_service_type
from .playerbrain import order as _brain_order, learn_ok as _brain_ok, learn_fail as _brain_fail
from .xStaticText import StaticText
from .streammetrics import TrafficCounter, traffic_text
RESUME_FILE = '/etc/enigma2/alkuds/free_entertainment_resume.pkl'

def _load_resume_points():
    try:
        with open(RESUME_FILE, 'rb') as handle:
            data = pickle.load(handle)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _write_resume_points(points):
    try:
        folder = os.path.dirname(RESUME_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = RESUME_FILE + '.tmp'
        with open(temporary, 'wb') as handle:
            pickle.dump(points, handle, pickle.HIGHEST_PROTOCOL)
        os.rename(temporary, RESUME_FILE)
    except Exception:
        pass

def _player_skin(radio=False):
    size = getDesktop(0).size()
    if radio:
        return '<screen name="AlkudsRadioPlayer" position="0,0" size="%d,%d" backgroundColor="#00000000" flags="wfNoBorder"><widget name="radio_background" position="0,0" size="%d,%d" alphatest="off" /></screen>' % (size.width(), size.height(), size.width(), size.height())
    return '<screen name="AlkudsFreeTVPlayer" position="0,0" size="%d,%d" backgroundColor="#ff000000" flags="wfNoBorder"><widget source="session.VideoPicture" render="Pig" position="0,0" size="%d,%d" backgroundColor="#ff000000" transparent="0" zPosition="0" /></screen>' % (size.width(), size.height(), size.width(), size.height())

class Alkuds_FreeTV_Player(Screen):
    """Plain Screen avoids receiver-specific teardown crashes from PVR mixins."""
    ALLOW_SUSPEND = True

    def __init__(self, session, streamurls, servicetype, name, category='Live', description='', image='', resume_key='', radio=False, subtitles=None, subtitle_search=None, reuse_service=False, keep_playing_on_back=False, playback_scope="", preview_ready=False):
        Screen.__init__(self, session)
        self.reuse_service = bool(reuse_service)
        self.keep_playing_on_back = bool(keep_playing_on_back)
        self.playback_scope = playback_scope
        self.preview_ready = bool(preview_ready)
        self._expected_stop = False
        self._switch_pending = False
        self._switch_reference = None
        self._service_grace_until = 0.0
        self._learned_key = None
        self._confirmed_at = 0.0
        self._reconnects = 0
        self._returning_preview = False
        self.radio = bool(radio)
        self.subtitles = list(subtitles or [])
        self.subtitle_search = subtitle_search or {}
        self.skin = _player_skin(self.radio)
        self._radio_background = None
        if self.radio:
            from .radiobackground import RadioBackground
            self._radio_background = RadioBackground(self)
        if not self.radio:
            from .listpreview import install_fullscreen_video
            install_fullscreen_video(self)
        self._radio_last_position = None
        self.session = session
        self.streamurls = list(streamurls or [])
        self.servicetype = int(servicetype)
        self.name = str(name or 'Channel')
        self.category = str(category or 'Live')
        self.description = str(description or '')
        self.resume_key = str(resume_key or '')
        self.streamurl = self.streamurls[0] if self.streamurls else ''
        self._closed = False
        self._confirmed = False
        self._failed = False
        self._playback_stopped = False
        self._started_attempts = False
        self._attempt_index = -1
        self._attempts = []
        self._bar_visible = True
        self._resume_applied = False
        self._resume_target = 0
        self._speed_mbps = 0.0
        self._traffic = TrafficCounter()
        self._traffic_rate = 0
        self._traffic_total = 0
        self._last_rx = self._network_rx_bytes()
        self._last_rx_time = time.time()
        self._attempt_started_at = 0.0
        self._attempt_data_ticks = 0
        if self.category.lower() != 'live' and self.resume_key:
            try:
                self._resume_target = int((_load_resume_points().get(self.resume_key) or [0])[0])
            except Exception:
                self._resume_target = 0
        # The player is chosen automatically per site (playerbrain): the best
        # remembered player first, other players only after a real failure.
        self._attempts = self._build_attempts()
        self['name'] = StaticText(self.name)
        self['status'] = StaticText('Connecting to stream...')
        self['details'] = StaticText(self._details_text())
        self._attempt_timer = eTimer()
        try:
            self._attempt_timer_conn = self._attempt_timer.timeout.connect(self._attempt_timeout)
        except Exception:
            self._attempt_timer.callback.append(self._attempt_timeout)
        self._resume_timer = eTimer()
        try:
            self._resume_timer_conn = self._resume_timer.timeout.connect(self._resume_tick)
        except Exception:
            self._resume_timer.callback.append(self._resume_tick)
        self._status_timer = eTimer()
        try:
            self._status_timer_conn = self._status_timer.timeout.connect(self._status_tick)
        except Exception:
            self._status_timer.callback.append(self._status_tick)
        self._close_timer = eTimer()
        try:
            self._close_timer_conn = self._close_timer.timeout.connect(self._close_after_stop)
        except Exception:
            self._close_timer.callback.append(self._close_after_stop)
        self._switch_timer = eTimer()
        try:
            self._switch_timer_conn = self._switch_timer.timeout.connect(self._switch_play)
        except Exception:
            self._switch_timer.callback.append(self._switch_play)
        self._pending_result = None

        eventmap = {}
        for event_name, callback in (('evStart', self._service_started), ('evUpdatedInfo', self._service_updated), ('evVideoSizeChanged', self._video_ready), ('evTuneFailed', self._service_failed), ('evEOF', self._service_failed)):
            event = getattr(iPlayableService, event_name, None)
            if event is not None:
                eventmap[event] = callback
        self._service_tracker = ServiceEventTracker(screen=self, eventmap=eventmap)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'DirectionActions', 'InfobarSeekActions'], {'cancel': self.back, 'red': self.back, 'stop': self.stopPlayback, 'menu': self.choose_player, 'ok': self.toggle_info, 'info': self.toggle_info, 'up': self.nextChannel, 'channelUp': self.nextChannel, 'down': self.prevChannel, 'channelDown': self.prevChannel, 'left': self.seek_back, 'right': self.seek_forward, 'seekBack': self.seek_back, 'seekFwd': self.seek_forward, 'seekBackManual': self.seek_back, 'seekFwdManual': self.seek_forward}, -2)
        self.onFirstExecBegin.append(self.playStream)
        self.onFirstExecBegin.append(lambda: self._status_timer.start(1000, False))
        self.onClose.append(self._cleanup)
        from .transportcontrol import install as install_transport
        install_transport(self, self.category.lower() == 'live')

    def choose_player(self):
        from .playerbrain import player_menu
        player_menu(self, self.servicetype, self._player_chosen)

    def _player_chosen(self, choice):
        if not choice or int(choice[1]) == self.servicetype:
            return
        selected = int(choice[1])
        current_url = self.streamurl or self.streamurls[0]
        self._attempts = [(current_url, selected)]
        self._attempt_index = -1
        self._failed = False
        self._confirmed = False
        self.reuse_service = False
        self._learned_key = None
        self._try_next()

    def _build_attempts(self):
        category = "live" if self.category.lower() == "live" else "vod"
        attempts = []
        for position, url in enumerate(self.streamurls):
            types = list(_brain_order(category, url, default=self.servicetype, scope=self.playback_scope))
            if self.reuse_service and position == 0 and self.servicetype in types:
                types.remove(self.servicetype)
                types.insert(0, self.servicetype)
            types = types[:3] if position == 0 else types[:1]
            for service_type in types:
                pair = (url, int(service_type))
                if pair not in attempts:
                    attempts.append(pair)
        if not attempts and self.streamurls:
            attempts = [(self.streamurls[0], self.servicetype)]
        return attempts

    def _probe_timeout(self):
        return 10000 if self.category.lower() == "live" else 15000

    def _make_reference(self):
        reference = service_reference(self.servicetype, 0, self.streamurl)
        reference.setName(gui_text(self.name))
        return reference

    def _kill_exteplayer3(self):
        try:
            with open(os.devnull, "wb") as sink:
                subprocess.call(["killall", "-TERM", "exteplayer3"], stdout=sink, stderr=sink)
        except Exception:
            pass

    def _learn_failure(self):
        try:
            _brain_fail("live" if self.category.lower() == "live" else "vod", self.streamurl, self.servicetype, self.playback_scope)
        except Exception:
            pass

    def _stop_and_play(self, reference, delay=250):
        """Release the decoder first; switching players without this can hang."""
        if self._closed:
            return
        try:
            self._switch_timer.stop()
        except Exception:
            pass
        self._switch_reference = reference
        self._switch_pending = True
        self._expected_stop = True
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        try:
            self._switch_timer.start(max(1, int(delay)), True)
        except Exception:
            self._switch_play()

    def _switch_play(self):
        if self._closed:
            return
        self._switch_pending = False
        reference = self._switch_reference
        self._switch_reference = None
        if reference is None:
            return
        self._attempt_started_at = time.time()
        self._attempt_data_ticks = 0
        self._last_rx = self._network_rx_bytes()
        self._last_rx_time = self._attempt_started_at
        # A stop emits a stale EOF/tune-failed on some images; ignore it.
        self._service_grace_until = self._attempt_started_at + 2.0
        self._expected_stop = False
        self._confirmed = False
        try:
            try:
                result = self.session.nav.playService(reference, forceRestart=True)
            except TypeError:
                result = self.session.nav.playService(reference)
            if result is False or (type(result) is type(0) and result != 0):
                self._service_failed(force=True)
                return
            self._playback_stopped = False
            self._attempt_timer.start(self._probe_timeout(), True)
        except Exception:
            self._service_failed(force=True)


    def _network_rx_bytes(self):
        """Best available live throughput counter on receiver images."""
        total = 0
        try:
            with open('/proc/net/dev', 'r') as handle:
                for line in handle:
                    if ':' not in line:
                        continue
                    interface, values = line.split(':', 1)
                    if interface.strip() == 'lo':
                        continue
                    fields = values.split()
                    if fields:
                        total += int(fields[0])
        except Exception:
            pass
        return total

    def _service_info_value(self, *names):
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if not info:
                return 0
            for name in names:
                key = getattr(iServiceInformation, name, None)
                if key is not None:
                    value = int(info.getInfo(key))
                    if value > 0:
                        return value
        except Exception:
            pass
        return 0

    def _details_text(self):
        clean_url = str(self.streamurl or '').split('#', 1)[0]
        extension = os.path.splitext(clean_url)[-1].split('?', 1)[0].lstrip('.') or 'stream'
        width, height = self._stream_dimensions()
        resolution = '%dx%d' % (width, height) if width and height else 'detecting resolution'
        frame_rate = self._service_info_value('sFrameRate')
        if frame_rate > 1000:
            frame_rate = int(round(frame_rate / 1000.0))
        bitrate = self._service_info_value('sVideoBitrate', 'sBitrate')
        if bitrate > 10000:
            speed = bitrate / 1000000.0
        else:
            speed = self._speed_mbps
        text = '%s | P%s | %s | %s | %s' % (self.category, self.servicetype, extension[:8].upper(), resolution, traffic_text(self._traffic_rate, self._traffic_total))
        if frame_rate:
            text += u'  •  %d fps' % frame_rate
        if self.description:
            text += u'  •  ' + self.description
        return text

    def _status_tick(self):
        if self._closed:
            return
        if self.radio and self._started_attempts and (not self._confirmed):
            try:
                seek = self._seekable()
                result = seek.getPlayPosition() if seek else None
                if result and result[0] == 0:
                    position = int(result[1])
                    if self._radio_last_position is not None and position > self._radio_last_position:
                        self._mark_ready()
                    self._radio_last_position = position
            except Exception:
                pass
        self._traffic_rate, self._traffic_total = self._traffic.sample()
        now = time.time()
        received = self._network_rx_bytes()
        elapsed = max(0.001, now - self._last_rx_time)
        delta = received - self._last_rx if received >= self._last_rx else 0
        if delta >= 0:
            self._speed_mbps = delta * 8.0 / elapsed / 1000000.0
        self._last_rx = received
        self._last_rx_time = now
        if self._started_attempts and (not self._confirmed) and (not self._switch_pending) and (delta >= 8192):
            self._attempt_data_ticks += 1
            self._set_status('Buffering stream... data is being received.')
            if self._attempt_data_ticks >= 3:
                self._mark_ready()
                return
        elif not self._confirmed:
            self._attempt_data_ticks = max(0, self._attempt_data_ticks - 1)
        self['details'].setText(self._details_text())

    def _set_status(self, value):
        if self._closed:
            return
        self['status'].setText(str(value or ''))
        self['details'].setText(self._details_text())

    def _is_current_service(self, current):
        try:
            if current.toString() == service_reference(self.servicetype, 0, self.streamurls[0]).toString():
                return True
        except Exception:
            pass
        try:
            from .listpreview import reference_type
            return int(reference_type(current)) == int(self.servicetype) and current.getPath() == self.streamurls[0]
        except Exception:
            return False

    def playStream(self):
        if self.reuse_service and self.streamurls:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
            if current and self._is_current_service(current):
                self._started_attempts = True
                self._attempt_index = 0
                self._attempt_started_at = time.time()
                self._playback_stopped = False
                self._resume_applied = True
                self._resume_target = 0
                self._confirmed = False
                self.streamurl = self.streamurls[0]
                self._service_grace_until = time.time() + 3.0
                self._set_status('Continuing current stream...')
                if self.preview_ready:
                    self._mark_ready(*self._stream_dimensions())
                else:
                    self._service_updated()
                if not self._confirmed:
                    self._attempt_timer.start(self._probe_timeout(), True)
                return
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
        except Exception:
            pass
        self._started_attempts = True
        self._try_next()

    def _try_next(self):
        if self._closed:
            return
        try:
            self._attempt_timer.stop()
        except Exception:
            pass
        if 0 <= self._attempt_index < len(self._attempts) and not self._confirmed:
            self._learn_failure()
        self._confirmed = False
        self._attempt_index += 1
        self._radio_last_position = None
        if self._attempt_index >= len(self._attempts):
            self._failed = True
            self._set_status("Stream is offline or not responding.")
            self._expected_stop = True
            try:
                self.session.nav.stopService()
                self._playback_stopped = True
            except Exception:
                pass
            self._expected_stop = False
            return
        previous_type = self.servicetype
        self.streamurl, service_type = self._attempts[self._attempt_index]
        self.servicetype = int(service_type)
        if previous_type == 5002 and self._attempt_index > 0:
            self._kill_exteplayer3()
        self._attempt_started_at = time.time()
        self._attempt_data_ticks = 0
        self._last_rx = self._network_rx_bytes()
        self._last_rx_time = self._attempt_started_at
        self._set_status("Connecting to stream (player %d)..." % self.servicetype)
        current = None
        try:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            pass
        self._stop_and_play(self._make_reference(), 250 if current else 1)

    def _service_started(self):
        if self._started_attempts and (not self._confirmed):
            self._set_status('Buffering stream...')

    def _stream_dimensions(self):
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            width = int(info.getInfo(iServiceInformation.sVideoWidth)) if info else 0
            height = int(info.getInfo(iServiceInformation.sVideoHeight)) if info else 0
            return (max(0, width), max(0, height))
        except Exception:
            return (0, 0)

    def _service_updated(self):
        if self._switch_pending:
            return
        width, height = self._stream_dimensions()
        if width > 0:
            self._mark_ready(width, height)

    def _video_ready(self):
        if self._switch_pending:
            return
        width, height = self._stream_dimensions()
        self._mark_ready(width, height)

    def _mark_ready(self, width=0, height=0):
        if self._closed or self._switch_pending:
            return
        first = not self._confirmed
        self._confirmed = True
        self._reconnects = 0 if first else self._reconnects
        if first:
            self._confirmed_at = time.time()
        try:
            self._attempt_timer.stop()
        except Exception:
            pass
        resolution = " %dx%d" % (width, height) if width and height else ""
        self._set_status("Stream is working.%s" % resolution)
        key = (self.streamurl, self.servicetype)
        if self._learned_key != key and (self._attempt_index > 0 or not self.reuse_service):
            self._learned_key = key
            try:
                _brain_ok("live" if self.category.lower() == "live" else "vod", self.streamurl,
                          self.servicetype, max(0.1, time.time() - self._attempt_started_at), self.playback_scope)
            except Exception:
                pass
        self._apply_resume()
        if self.category.lower() != "live":
            try:
                self._resume_timer.start(30000, False)
            except Exception:
                pass

    def _service_failed(self, force=False):
        if not self._started_attempts or self._closed:
            return
        if self._switch_pending or self._expected_stop:
            return
        # The stop that precedes a switch/fullscreen handoff emits EOF on some
        # images; never let that stale event mark the stream offline.
        if not force and time.time() < self._service_grace_until:
            return
        if (self._confirmed and self._confirmed_at and time.time() - self._confirmed_at > 20
                and self._reconnects < 3):
            # A stream that played fine and then dropped: reconnect the same
            # player instead of abandoning it.
            self._reconnects += 1
            self._confirmed = False
            self._set_status("Reconnecting...")
            self._stop_and_play(self._make_reference(), 400)
            return
        self._confirmed = False
        self._attempt_data_ticks = 0
        self._attempt_timer.start(1, True)

    def _attempt_timeout(self):
        if self._closed or self._confirmed:
            return
        if self._switch_pending:
            self._attempt_timer.start(500, True)
            return
        if self._attempt_data_ticks and time.time() - self._attempt_started_at < 45:
            self._set_status("Buffering stream... waiting for video.")
            self._attempt_timer.start(6000, True)
            return
        self._try_next()

    def toggle_info(self):
        if hasattr(self, '_transport_control'):
            self._transport_control.toggle_bar()
            return
        if self._bar_visible:
            self.hide()
        else:
            self.show()
        self._bar_visible = not self._bar_visible

    def nextChannel(self):
        if self.category.lower() == 'live':
            self._finish('next', force_stop=True)

    def prevChannel(self):
        if self.category.lower() == 'live':
            self._finish('prev', force_stop=True)

    def _seekable(self):
        try:
            service = self.session.nav.getCurrentService()
            return service and service.seek()
        except Exception:
            return None

    def _seek_relative(self, direction):
        if hasattr(self, '_transport_control'):
            self._transport_control.queue(direction)
            return
        if self.category.lower() == 'live' or self._closed:
            return
        seekable = self._seekable()
        if not seekable:
            self._set_status('Seeking is not supported by this server.')
            return
        try:
            seekable.seekRelative(1 if direction > 0 else -1, 60 * 90000)
            self._set_status('Forward 60 seconds.' if direction > 0 else 'Back 60 seconds.')
            self._save_resume()
        except Exception:
            self._set_status('Seeking is not supported by this server.')

    def seek_forward(self):
        self._seek_relative(1)

    def seek_back(self):
        self._seek_relative(-1)

    def _apply_resume(self):
        if self._resume_applied or self._resume_target < 30 * 90000:
            return
        seekable = self._seekable()
        if not seekable:
            return
        try:
            seekable.seekTo(self._resume_target)
            self._resume_applied = True
            seconds = self._resume_target // 90000
            self._set_status('Resumed at %02d:%02d:%02d.' % (seconds // 3600, seconds % 3600 // 60, seconds % 60))
        except Exception:
            pass

    def _resume_tick(self):
        if not self._closed:
            self._save_resume()

    def _save_resume(self):
        if self.category.lower() == 'live' or not self.resume_key or self._failed:
            return
        seekable = self._seekable()
        if not seekable:
            return
        try:
            position = seekable.getPlayPosition()
            if not position or position[0] or int(position[1]) < 10 * 90000:
                return
            current = int(position[1])
            length_result = seekable.getLength()
            length = int(length_result[1]) if length_result and (not length_result[0]) else 0
            points = _load_resume_points()
            if length and current >= max(0, length - 90 * 90000):
                points.pop(self.resume_key, None)
            else:
                points[self.resume_key] = [current, length, int(time.time())]
            if len(points) > 300:
                ordered = sorted(points.items(), key=lambda pair: pair[1][2] if len(pair[1]) > 2 else 0)
                points = dict(ordered[-300:])
            _write_resume_points(points)
        except Exception:
            pass

    def stopPlayback(self):
        self._finish('stopped', force_stop=True)

    def back(self):
        action = 'failed' if self._failed else 'back'
        self._returning_preview = self.keep_playing_on_back and action == 'back'
        self._finish(action, force_stop=not self._returning_preview)

    def _finish(self, action, force_stop=False):
        if self._closed:
            return
        self._save_resume()
        result = (str(action), 'working' if self._confirmed else 'offline')
        self._closed = True
        self._cleanup()
        if force_stop and (not self._playback_stopped):
            try:
                self.session.nav.stopService()
                self._playback_stopped = True
            except Exception:
                pass
        if not self._returning_preview and any((service_type == 5002 for _url, service_type in self._attempts)):
            try:
                with open(os.devnull, 'wb') as sink:
                    subprocess.call(['killall', '-TERM', 'exteplayer3'], stdout=sink, stderr=sink)
            except Exception:
                pass
        self._pending_result = result if self.category.lower() == 'live' else None
        try:
            self._close_timer.start(450, True)
        except Exception:
            self._close_after_stop()

    def _close_after_stop(self):
        try:
            self._close_timer.stop()
        except Exception:
            pass
        if self.category.lower() == 'live':
            self.close(self._pending_result)
        else:
            self.close()

    def _cleanup(self):
        if self._radio_background is not None:
            self._radio_background.cleanup()
        if not self._closed:
            self._save_resume()
        try:
            self._attempt_timer.stop()
        except Exception:
            pass
        try:
            self._resume_timer.stop()
        except Exception:
            pass
        try:
            self._status_timer.stop()
        except Exception:
            pass
        for timer_name in ("_switch_timer",):
            try:
                getattr(self, timer_name).stop()
            except Exception:
                pass
        self._switch_pending = False
        if not self._playback_stopped and (not self._returning_preview):
            try:
                self.session.nav.stopService()
                self._playback_stopped = True
            except Exception:
                pass
