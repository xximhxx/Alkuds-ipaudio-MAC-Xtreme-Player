# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .playbackcache import repeated_catalogue
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import threading
from .arabseedui import Alkuds_ArabSeed_Browser
from .sitecatalogue import SitePages

class Alkuds_SiteCatalogue_Browser(Alkuds_ArabSeed_Browser):

    def _label(self):
        title = self.parent.get('series_title') or (u'البحث: ' + self.parent['query'] if self.parent.get('query') else self.parent.get('catalogue_label') or self.provider.SECTION_MAP.get(self.section, (self.parent.get('name') or u'تصفح الموقع', ''))[0])
        labels = self.parent.get('filter_labels') or {}
        detail = u' | '.join((labels[k] for k in ('genre', 'year', 'country') if labels.get(k)))
        return self.site_name + (u' — ' + title if self.level != 'groups' else '') + (u' | ' + detail if detail else '')

    @repeated_catalogue
    def _load_worker(self):
        try:
            if self.level == 'groups':
                self._result = self.provider.groups()
            elif self.level == 'sections':
                self._result = self.provider.sections(self.section, self.parent)
            elif self.level == 'filters':
                self._result = self.provider.filters(self.section, self.parent)
            elif self.level == 'seasons':
                self._result = self.provider.seasons(self.parent)
            elif self.level == 'servers':
                self._result = self.provider.servers(self.parent)
            elif self.parent.get('season'):
                self._result = self.provider.episodes(self.parent, self.page)
            else:
                if not hasattr(self, '_catalogue_pager'):
                    self._catalogue_pager = SitePages(cancelled=lambda: self._closed)
                self._result = self._catalogue_pager.get(self.page, lambda page: self.provider.fetch_items(self.section, page, self.parent.get('query', ''), self.parent.get('order', 'latest'), self.parent))
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        if self.level == 'items' and (not self.parent.get('season')) and (self.parent.get('order') in ('az', 'za')):
            self.entries.sort(key=lambda x: x.get('name', '').lower(), reverse=self.parent['order'] == 'za')
        Alkuds_ArabSeed_Browser._set_rows(self)

    def open_current(self):
        controller = getattr(self, '_list_preview', None)
        if controller and controller.second_ok():
            return
        if self._loading or self._closed:
            return
        index = self._index()
        if not 0 <= index < len(self.entries):
            return
        item = dict(self.entries[index])
        self._selected_index = index
        if item.get('action') == 'search':
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(self._search_done, VirtualKeyBoard, title=u'بحث ' + self.site_name, text='')
            return
        node = item.get('node')
        if node:
            parent = dict(self.parent)
            parent.update(item)
            if item.get('section') and (self.level == 'groups' or item['section'] != self.section):
                parent['catalogue_label'] = item['name']
            self.session.open(type(self), item.get('section', self.section), node, parent, 1)
            return
        if self.level == 'items' and item.get('is_series'):
            self.session.open(type(self), self.section, 'seasons', item, 1)
            return
        if self.level == 'seasons':
            self.session.open(type(self), self.section, 'items', item, 1)
            return
        if self.level != 'servers':
            self.session.open(type(self), self.section, 'servers', item, 1)
            return
        self._operation, self._loading, self._done = ('resolve', True, False)
        self._result, self._error = (None, '')
        self._update_title(u' — جاري تجهيز الفيديو...')
        worker = threading.Thread(target=self._resolve_worker, args=(item,))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _search_done(self, value):
        if self._closed or not value or (not value.strip()):
            return
        parent = dict(self.parent)
        parent.update(query=value.strip(), name=u'البحث: ' + value.strip())
        self.session.open(type(self), self.section, 'items', parent, 1)

    def _poll(self):
        auto = self._done and (not self._closed) and (not self._error) and (self._operation == 'load') and (self.level == 'servers')
        Alkuds_ArabSeed_Browser._poll(self)
        if auto and len(self.entries) == 1:
            self['list'].setIndex(0)
            self.open_current()
