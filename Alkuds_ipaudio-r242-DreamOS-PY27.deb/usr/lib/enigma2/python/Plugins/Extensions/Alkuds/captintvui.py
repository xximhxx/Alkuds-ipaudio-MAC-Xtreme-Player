# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .playbackcache import repeated_catalogue
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import captintv
from .arabseedui import Alkuds_ArabSeed_Browser
from .freechannels import _list_entry
from .fajershowui import Alkuds_FajerShow_Qualities
from .cataloguepages import CataloguePages
from .py2compat import threading

class Alkuds_CaptinTV_Browser(Alkuds_ArabSeed_Browser):
    provider = captintv
    site_name = u'الكابتن — بين سبورت'

    def __init__(self, session, section='channels', level='items', parent=None, page=1):
        section = 'channels'
        if level not in ('items', 'servers'):
            level = 'items'
        Alkuds_ArabSeed_Browser.__init__(self, session, section, level, parent, page)
        self['key_blue'].setText(u'التالي' if level == 'items' else u'تحديث')

    def _label(self):
        return self.site_name + (u' — ' + str(self.parent.get('name', '')) if self.parent else '')

    @repeated_catalogue
    def _load_worker(self):
        try:
            if self.level == 'servers':
                self._result = self.provider.servers(self.parent)
            else:
                if not hasattr(self, '_captin_pages'):
                    self._captin_pages = CataloguePages(cancelled=lambda: self._closed)
                self._result = self._captin_pages.get(self.page, lambda number: self.provider.page(self.parent, number))
        except Exception as error:
            self._error = str(error)
        self._done = True

    def open_current(self):
        if self._loading or self._closed:
            return
        index = self._index()
        if not 0 <= index < len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if item.get('action') == 'play':
            self._operation, self._loading, self._done = ('resolve', True, False)
            self._result, self._error = (None, '')
            self._update_title(u' — جاري تجهيز البث...')
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)
            return
        self.session.open(type(self), 'channels', 'servers', item, 1)

    def _start_resolved(self, item):
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']}, item['name'], 'Live', '', item.get('image', ''), '')

    def next_or_refresh(self):
        if self._loading:
            return
        if self.level != 'items':
            self.provider.refresh()
        Alkuds_ArabSeed_Browser.next_or_refresh(self)
