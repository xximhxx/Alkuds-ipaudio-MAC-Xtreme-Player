# -*- coding: utf-8 -*-
"""5TV (Fivetv) catalogue, watch mirrors and stream resolver.

The site is a WordPress installation whose movie/series/episode pages list
their mirrors directly in the HTML as buttons carrying data-server-url.
Only the non-VIP mirrors are exposed here; the paid /vip/ area is never used.
"""
from .py2compat import json
from .py2compat import re
import time
from .py2compat import requests
try:
    from urllib.parse import urljoin, urlparse, parse_qs
    from html import unescape
except ImportError:
    from urlparse import urljoin, urlparse, parse_qs
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape
from . import arabseed as a
from . import sitecatalogue as c

BASE = 'https://new61.5tv.lol/'
HOSTS = ('new61.5tv.lol', 'www.new61.5tv.lol')

SECTIONS = (
    ('home', u'الرئيسية', ''),
    ('new', u'آخر الإضافات', 'new-rows/'),
    ('movies', u'آخر الأفلام', 'latest-movies/'),
    ('series', u'آخر المسلسلات', 'latest-series/'),
    ('episodes', u'آخر الحلقات', 'latest-episodes/'),
    ('schedule', u'الجدول الأسبوعي', 'schedule/'),
)
SECTION_MAP = dict((key, (name, path)) for key, name, path in SECTIONS)

SCHEDULE_DAYS = (
    ('friday', u'الجمعة'),
    ('saturday', u'السبت'),
    ('sunday', u'الأحد'),
    ('monday', u'الاثنين'),
    ('tuesday', u'الثلاثاء'),
    ('wednesday', u'الأربعاء'),
    ('thursday', u'الخميس'),
)
DAY_MAP = dict(SCHEDULE_DAYS)

# Mirrors whose embed page cannot be resolved with the receiver's HTTP client
# yet.  They stay hidden instead of giving the user a dead server entry.
_UNSUPPORTED = ('hgcloud.to', 'dsvplay.com')

# The site does not publish a +18 area on its public pages, but search can
# still reach anything the site stores.  Keep the same guard used elsewhere.
_BLOCKED = re.compile(
    u'(?<![a-z0-9])(?:xxx|porn(?:o|ography)?|nsfw|18\\s*(?:\\+|plus)|\\+\\s*18)'
    u'(?![a-z0-9])|اباح|إباح|للكبار|سكس|بورن|جنس(?:ية|يه)', re.I)

_DISCOVER = {'time': 0.0, 'items': {}}
_DISCOVER_TTL = 6 * 60 * 60


def _local(value):
    return c.local(BASE, HOSTS, value)


def _get(session, value, referer=BASE, params=None):
    html, final, _mime = c.get(session, _local(value), referer, params)
    return html, final


def _text(value):
    value = re.sub(r'<[^>]+>', ' ', value or '')
    return re.sub(r'\s+', ' ', unescape(value)).strip()


def _attr(tag, name):
    match = re.search(r'\b%s\s*=\s*(["\'])(.*?)\1' % re.escape(name),
                      tag or '', re.S | re.I)
    return unescape(match.group(2)).strip() if match else ''


def _first_tag(value, tag):
    match = re.search(r'<%s\b[^>]*>' % re.escape(tag), value or '', re.S | re.I)
    return match.group(0) if match else ''


def _first_text(value, tag):
    match = re.search(r'<%s\b[^>]*>(.*?)</%s>' %
                      (re.escape(tag), re.escape(tag)), value or '', re.S | re.I)
    return _text(match.group(1)) if match else ''


def _class_text(value, needle):
    match = re.search(r'<[a-z0-9]+\b[^>]*class="[^"]*%s[^"]*"[^>]*>(.*?)</[a-z0-9]+>' %
                      re.escape(needle), value or '', re.S | re.I)
    return _text(match.group(1)) if match else ''


def _image(value, page):
    for attribute in ('data-src', 'data-lazy-src', 'data-echo', 'src'):
        match = re.search(r'\b%s\s*=\s*(["\'])(.*?)\1' % re.escape(attribute),
                          value or '', re.S | re.I)
        if not match:
            continue
        source = unescape(match.group(2)).strip()
        if source and not source.startswith('data:'):
            return urljoin(page, source)
    match = re.search(r'\b(?:data-srcset|srcset)\s*=\s*(["\'])(.*?)\1',
                      value or '', re.S | re.I)
    if match:
        source = unescape(match.group(2)).split(',')[0].strip().split(' ')[0]
        if source and not source.startswith('data:'):
            return urljoin(page, source)
    return ''


def _blocked(row):
    value = u' '.join((row.get('name') or '', row.get('category') or '',
                       row.get('title') or ''))
    return bool(_BLOCKED.search(value))


def _row(href, title, image, page, category='', quality='', is_series=False,
         is_episode=False):
    title = (title or '').strip() or u'عنصر'
    path = urlparse(urljoin(page, href)).path or ''
    if not is_series and '/series/' in path:
        is_series = True
    row = {
        'url': urljoin(page, href),
        'name': title,
        'title': title,
        'image': image,
        'category': category,
        'quality': quality,
        'search_text': title.lower(),
        'catalogue_label': title,
    }
    if is_series:
        row['is_series'] = True
        row['series_title'] = title
    elif is_episode or '/episode/' in path:
        row['is_episode'] = True
    return None if _blocked(row) else row


def _paged(path, page):
    page = max(1, int(page))
    if page <= 1:
        return path
    return path.rstrip('/') + '/page/%d/' % page


def _last_page(html, page):
    values = [max(1, int(page))]
    for match in re.finditer(r'href\s*=\s*(["\'])(.*?)\1', html or '', re.S | re.I):
        value = unescape(match.group(2))
        number = re.search(r'/page/(\d+)/?', value)
        if number:
            values.append(int(number.group(1)))
        query = parse_qs(urlparse(value).query).get('pg')
        if query and query[0].isdigit():
            values.append(int(query[0]))
    return max(values)


def _poster_cards(html, page):
    rows, seen = [], set()
    pattern = re.compile(r'<article\b[^>]*class="[^"]*\bftv-home-poster-card\b[^"]*"[^>]*>'
                         r'(.*?)</article>', re.S | re.I)
    for match in pattern.finditer(html or ''):
        part = match.group(1)
        href = _attr(_first_tag(part, 'a'), 'href')
        if not href or href.startswith('#'):
            continue
        url = urljoin(page, href)
        if url in seen or (urlparse(url).hostname or '') not in HOSTS:
            continue
        seen.add(url)
        title = _class_text(part, 'ftv-home-poster-card__title')
        if not title:
            title = _attr(_first_tag(part, 'img'), 'alt')
        year = _class_text(part, 'ftv-poster-badge--year')
        category = _class_text(part, 'ftv-poster-badge--category') or year
        quality = _class_text(part, 'ftv-poster-badge--quality')
        row = _row(href, title, _image(part, page), page, category, quality)
        if row:
            rows.append(row)
    return rows


def _episode_cards(html, page):
    rows, seen = [], set()
    pattern = re.compile(r'<article\b[^>]*class="[^"]*\bftv-home-episode-card\b[^"]*"[^>]*>'
                         r'(.*?)</article>', re.S | re.I)
    for match in pattern.finditer(html or ''):
        part = match.group(1)
        href = _attr(_first_tag(part, 'a'), 'href')
        if not href or href.startswith('#'):
            continue
        url = urljoin(page, href)
        if url in seen or (urlparse(url).hostname or '') not in HOSTS:
            continue
        seen.add(url)
        title = _class_text(part, 'ftv-home-episode-card__title')
        if not title:
            title = _attr(_first_tag(part, 'img'), 'alt')
        meta = _class_text(part, 'ftv-home-episode-card__meta')
        row = _row(href, title, _image(part, page), page, meta, '', is_episode=True)
        if row:
            rows.append(row)
    return rows


def _tax_cards(html, page):
    rows, seen = [], set()
    pattern = re.compile(r'<article\b[^>]*class="[^"]*\bftv-tax-card\b[^"]*"[^>]*>'
                         r'(.*?)</article>', re.S | re.I)
    for match in pattern.finditer(html or ''):
        part = match.group(1)
        anchor = _first_tag(part, 'a')
        href = _attr(anchor, 'href')
        if not href or href.startswith('#'):
            continue
        url = urljoin(page, href)
        if url in seen or (urlparse(url).hostname or '') not in HOSTS:
            continue
        seen.add(url)
        title = _first_text(part, 'h2') or _attr(anchor, 'aria-label')
        year = _class_text(part, 'ftv-tax-card__year')
        row = _row(href, title, _image(part, page), page, year)
        if row:
            rows.append(row)
    return rows


def _hero_card(part, page):
    anchor = ''
    match = re.search(r'<a\b[^>]*class="[^"]*ftv-hero-slide__title-link[^"]*"[^>]*>',
                      part or '', re.S | re.I)
    if match:
        anchor = match.group(0)
    if not anchor:
        anchor = _first_tag(part, 'a')
    href = _attr(anchor, 'href')
    if not href or href.startswith('#'):
        return None
    title = _text(_first_text(part, 'h2')) or _attr(anchor, 'title')
    badge = _class_text(part, 'ftv-hero-slide__badge')
    kind = _class_text(part, 'ftv-hero-slide__kind')
    category = badge or kind
    return _row(href, title, _image(part, page), page, category)


def _home_cards(html, page):
    rows, seen = [], set()
    pattern = re.compile(r'<article\b[^>]*class="([^"]*)"[^>]*>(.*?)</article>',
                         re.S | re.I)
    for match in pattern.finditer(html or ''):
        classes = match.group(1)
        part = match.group(2)
        row = None
        if 'ftv-hero-slide' in classes:
            row = _hero_card(part, page)
        elif 'ftv-home-poster-card' in classes:
            href = _attr(_first_tag(part, 'a'), 'href')
            if href:
                title = _class_text(part, 'ftv-home-poster-card__title')
                if not title:
                    title = _attr(_first_tag(part, 'img'), 'alt')
                year = _class_text(part, 'ftv-poster-badge--year')
                category = _class_text(part, 'ftv-poster-badge--category') or year
                quality = _class_text(part, 'ftv-poster-badge--quality')
                row = _row(href, title, _image(part, page), page, category, quality)
        elif 'ftv-home-episode-card' in classes:
            href = _attr(_first_tag(part, 'a'), 'href')
            if href:
                title = _class_text(part, 'ftv-home-episode-card__title')
                if not title:
                    title = _attr(_first_tag(part, 'img'), 'alt')
                meta = _class_text(part, 'ftv-home-episode-card__meta')
                row = _row(href, title, _image(part, page), page, meta, '',
                           is_episode=True)
        if not row:
            continue
        if row['url'] in seen or (urlparse(row['url']).hostname or '') not in HOSTS:
            continue
        seen.add(row['url'])
        rows.append(row)
    return rows


def _schedule_cards(html, page, day):
    day = (day or 'friday').lower()
    match = re.search(r'<section\b[^>]*class="[^"]*ftv-schedule-day[^"]*"[^>]*'
                      r'data-schedule-day="%s"[^>]*>' % re.escape(day),
                      html or '', re.S | re.I)
    if not match:
        return []
    start = match.end()
    following = re.search(r'<section\b[^>]*class="[^"]*ftv-schedule-day[^"]*"',
                          html[start:], re.I)
    block = html[start:start + following.start()] if following else html[start:]
    rows, seen = [], set()
    for part in re.compile(r'<div\b[^>]*class="[^"]*ftv-schedule-item[^"]*"[^>]*>', re.I).split(block)[1:]:
        time = _class_text(part, 'ftv-schedule-time')
        card = re.search(r'<article\b[^>]*class="[^"]*ftv-home-poster-card[^"]*"[^>]*>'
                         r'(.*?)</article>', part, re.S | re.I)
        if not card:
            continue
        inner = card.group(1)
        href = _attr(_first_tag(inner, 'a'), 'href')
        if not href or href.startswith('#'):
            continue
        url = urljoin(page, href)
        if url in seen or (urlparse(url).hostname or '') not in HOSTS:
            continue
        seen.add(url)
        title = _class_text(inner, 'ftv-home-poster-card__title')
        if not title:
            title = _attr(_first_tag(inner, 'img'), 'alt')
        year = _class_text(inner, 'ftv-poster-badge--year')
        category = _class_text(inner, 'ftv-poster-badge--category') or year
        name = (time + u' | ' + title) if time else title
        row = _row(href, name, _image(inner, page), page, category)
        if row:
            row['title'] = title
            row['catalogue_label'] = title
            rows.append(row)
    return rows


def _discover_links(body, kind):
    rows, seen = [], set()
    for match in re.finditer(r'<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                             body or '', re.S | re.I):
        href = unescape(match.group(1))
        parsed = urlparse(href)
        if (parsed.hostname or '') not in HOSTS:
            continue
        parts = [item for item in (parsed.path or '').split('/') if item]
        if not parts or parts[0] != kind or parsed.path in seen:
            continue
        inner = match.group(2)
        name = _class_text(inner, 'ftv-discover-category__name')
        if not name:
            name = _text(inner).replace(u'←', '').strip()
            name = re.sub(u'\\s+\\d[\\d\\u066b\\u066c,\\.]*\\s*$', '', name).strip()
        if not name or _BLOCKED.search(name):
            continue
        seen.add(parsed.path)
        rows.append({'name': name, 'url': parsed.path})
    return rows


def _discover():
    now = time.time()
    if _DISCOVER['items'] and now - _DISCOVER['time'] < _DISCOVER_TTL:
        return _DISCOVER['items']
    with requests.Session() as session:
        session.verify = False
        html, _final = _get(session, 'discover/', BASE)
    items = {'category': [], 'genre': [], 'country': [], 'year': []}
    for match in re.finditer(r'<section\b[^>]*class="[^"]*ftv-discover-section[^"]*"'
                             r'[^>]*>(.*?)</section>', html or '', re.S | re.I):
        body = match.group(1)
        heading = _first_text(body, 'h2')
        kind = ''
        if u'التصنيف' in heading:
            kind = 'category'
        elif u'النوع' in heading:
            kind = 'genre'
        elif u'الدولة' in heading:
            kind = 'country'
        elif u'السنة' in heading:
            kind = 'year'
        if kind:
            items[kind] = _discover_links(body, kind)
    if not any(items.values()):
        raise RuntimeError(u'تعذر قراءة أقسام التصفح من الموقع. حاول لاحقاً.')
    _DISCOVER['items'] = items
    _DISCOVER['time'] = now
    return items


def _section_items(name, path, section):
    return {'name': name, 'title': name, 'section': section, 'url': path,
            'node': 'items', 'catalogue_label': name}


def groups():
    return [
        {'name': u'البحث في الموقع', 'section': 'movies', 'action': 'search'},
        {'name': u'الرئيسية', 'section': 'home', 'node': 'items'},
        {'name': u'آخر الإضافات', 'section': 'new', 'node': 'items'},
        {'name': u'آخر الأفلام', 'section': 'movies', 'node': 'items'},
        {'name': u'آخر المسلسلات', 'section': 'series', 'node': 'items'},
        {'name': u'آخر الحلقات', 'section': 'episodes', 'node': 'items'},
        {'name': u'التصنيفات', 'section': 'category', 'node': 'sections'},
        {'name': u'الأنواع', 'section': 'genre', 'node': 'sections'},
        {'name': u'الدول', 'section': 'country', 'node': 'sections'},
        {'name': u'السنوات', 'section': 'year', 'node': 'sections'},
        {'name': u'الجدول الأسبوعي', 'section': 'schedule', 'node': 'sections'},
    ]


def sections(section, parent):
    if section in ('category', 'genre', 'country', 'year'):
        return [_section_items(item['name'], item['url'], section)
                for item in _discover().get(section) or []]
    if section == 'schedule':
        return [{'name': name, 'title': name, 'section': 'schedule',
                 'node': 'items', 'day': key,
                 'catalogue_label': u'الجدول الأسبوعي — ' + name}
                for key, name in SCHEDULE_DAYS]
    return []


def filters(section, parent):
    return []


def fetch_items(section, page=1, query='', order='latest', options=None):
    page = max(1, int(page))
    options = options or {}
    with requests.Session() as session:
        session.verify = False
        if query:
            params = {'q': query.strip()}
            if page > 1:
                params['pg'] = page
            html, final = _get(session, 'search/', BASE, params)
            rows = _poster_cards(html, final)
            last = _last_page(html, page)
        elif section == 'home':
            html, final = _get(session, '', BASE)
            rows = _home_cards(html, final)
            last = 1
        elif section == 'schedule':
            html, final = _get(session, 'schedule/', BASE)
            rows = _schedule_cards(html, final, options.get('day'))
            last = 1
        else:
            path = options.get('url') or SECTION_MAP.get(section, ('', 'new-rows/'))[1]
            html, final = _get(session, _paged(path, page), BASE)
            if section == 'episodes':
                rows = _episode_cards(html, final)
            elif section in ('category', 'genre', 'country', 'year'):
                rows = _tax_cards(html, final)
            elif section == 'new':
                rows = _poster_cards(html, final) + _episode_cards(html, final)
            else:
                rows = _poster_cards(html, final)
            last = _last_page(html, page)
    # A source page can repeat a title across carousels.
    unique, seen = [], set()
    for row in rows:
        if row['url'] in seen:
            continue
        seen.add(row['url'])
        unique.append(row)
    return {'entries': unique, 'page': page, 'last_page': last, 'total': len(unique)}


def _season_label(value, number):
    text = _text(value)
    label = re.sub(r'\s*\d+\s*$', '', text).strip()
    return label or (u'الموسم ' + (number or ''))


def seasons(item):
    url = item.get('url')
    if not url:
        raise RuntimeError(u'تعذر تحديد صفحة المسلسل في الموقع.')
    with requests.Session() as session:
        session.verify = False
        html, final = _get(session, url, url)
    series_title = item.get('series_title') or item.get('name') or u'مسلسل'
    rows = []
    pattern = re.compile(r'<button\b[^>]*class="[^"]*ftv-season-tab\b[^"]*"[^>]*>'
                         r'(.*?)</button>', re.S | re.I)
    for match in pattern.finditer(html or ''):
        tag = _first_tag(match.group(0), 'button')
        number = _attr(tag, 'data-season-tab')
        if not number:
            continue
        label = _season_label(match.group(1), number)
        row = dict(item)
        row.update(url=final, name=label, title=label, season=number,
                   is_series=True, series_title=series_title,
                   catalogue_label=series_title)
        rows.append(row)
    if rows:
        return rows
    if re.search(r'class="[^"]*ftv-series-episode-card', html or '', re.I):
        row = dict(item)
        row.update(url=final, name=u'كل الحلقات', title=u'كل الحلقات',
                   season='all', is_series=True, series_title=series_title,
                   catalogue_label=series_title)
        return [row]
    raise RuntimeError(u'هذا المسلسل لا يعرض مواسماً أو حلقات حالياً.')


def _season_panel(html, season):
    match = re.search(r'<div\b[^>]*class="[^"]*ftv-season-panel[^"]*"[^>]*'
                      r'data-season-panel="%s"[^>]*>' % re.escape(str(season)),
                      html or '', re.I)
    if not match:
        return html or ''
    start = match.end()
    following = re.search(r'<div\b[^>]*class="[^"]*ftv-season-panel[^"]*"',
                          (html or '')[start:], re.I)
    return (html or '')[start:start + following.start()] if following \
        else (html or '')[start:]


def episodes(item, page=1):
    url = item.get('url')
    if not url:
        raise RuntimeError(u'تعذر تحديد صفحة الحلقات في الموقع.')
    with requests.Session() as session:
        session.verify = False
        html, final = _get(session, url, url)
    season = item.get('season')
    block = _season_panel(html, season) if season and season != 'all' else html
    series_title = item.get('series_title') or item.get('name') or u'مسلسل'
    rows, seen = [], set()
    pattern = re.compile(r'<a\b[^>]*class="[^"]*ftv-series-episode-card\b[^"]*"'
                         r'[^>]*>(.*?)</a>', re.S | re.I)
    for match in pattern.finditer(block or ''):
        tag = _first_tag(match.group(0), 'a')
        href = _attr(tag, 'href')
        if not href or href.startswith('#'):
            continue
        target = urljoin(final, href)
        if target in seen or (urlparse(target).hostname or '') not in HOSTS:
            continue
        seen.add(target)
        number = _first_text(match.group(1), 'strong')
        name = number or _attr(tag, 'aria-label') or u'حلقة'
        row = _row(href, name, '', final, '', '', is_episode=True)
        if not row:
            continue
        row.update(season=season, series_title=series_title,
                   catalogue_label=series_title)
        rows.append(row)
    if not rows:
        raise RuntimeError(u'لم يعرض الموقع أي حلقات لهذا الموسم.')
    return rows


def _server_values(html):
    values, seen = [], set()
    pattern = re.compile(r'<button\b[^>]*class="[^"]*ftv-watch-tab\b[^"]*"[^>]*>'
                         r'(.*?)</button>', re.S | re.I)
    for match in pattern.finditer(html or ''):
        tag = _first_tag(match.group(0), 'button')
        url = _attr(tag, 'data-server-url')
        if not url or url in seen:
            continue
        if _attr(tag, 'data-server-vip') == '1':
            continue
        host = (urlparse(url).hostname or '').lower()
        if any(host == blocked or host.endswith('.' + blocked)
               for blocked in _UNSUPPORTED):
            continue
        seen.add(url)
        label = _first_text(match.group(1), 'strong') or host or u'سيرفر'
        quality = _first_text(match.group(1), 'small')
        values.append((u'%d - %s' % (len(values) + 1, label), url, quality))
    return values


def servers(item):
    referer = item.get('url') or BASE
    with requests.Session() as session:
        session.verify = False
        html, final = _get(session, referer, referer)
    values = _server_values(html)
    if not values:
        raise RuntimeError(u'الموقع لم يعرض أي سيرفر مشاهدة مدعوم لهذا المحتوى.')
    return c.server_rows(values, item, final)


def _resolve_71stream(item):
    from .freeproviders import hls_variant_streams
    url = item.get('server_url')
    referer = item.get('referer') or BASE
    with requests.Session() as session:
        session.verify = False
        html, final, _mime = c.get(session, url, referer)
    match = re.search(r'<div\b[^>]*id="app"[^>]*data-page="([^"]+)"',
                      html or '', re.S | re.I)
    if not match:
        raise RuntimeError(u'تعذر قراءة مشغل 71Stream.')
    try:
        data = json.loads(unescape(match.group(1)))
    except ValueError:
        raise RuntimeError(u'تعذر قراءة مشغل 71Stream.')
    props = data.get('props') or {}
    source = (props.get('url') or '').strip()
    if not source:
        raise RuntimeError(u'مشغل 71Stream لم يعرض رابط الفيديو.')
    mediatype = a._media_type(source)
    if not mediatype:
        mime = (props.get('mime') or '').lower()
        mediatype = 'hls' if ('mpegurl' in mime or '.m3u8' in source.lower()) else 'mp4'
    stream = {'url': source, 'mediatype': mediatype, 'quality': 'Original',
              'headers': c.headers(final), 'relay': True}
    streams = hls_variant_streams(stream) if mediatype == 'hls' else [stream]
    if not streams:
        raise RuntimeError(u'مشغل 71Stream لا يعرض رابطاً يدعمه الرسيفر.')
    result = dict(item)
    result.update(name=item.get('title') or item['name'], streams=streams)
    return result


def resolve(item):
    host = (urlparse(item.get('server_url') or '').hostname or '').lower()
    if host == '71stream.one' or host.endswith('.71stream.one'):
        return _resolve_71stream(item)
    return c.resolve(item)
