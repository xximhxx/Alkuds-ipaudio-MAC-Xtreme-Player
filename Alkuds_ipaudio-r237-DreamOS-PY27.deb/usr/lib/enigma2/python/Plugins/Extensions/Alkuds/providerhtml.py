# -*- coding: utf-8 -*-
"""Python 2 parser with Python 3-style decoded text entities."""
from HTMLParser import HTMLParser as NativeParser
class HTMLParser(NativeParser):
    def __init__(self, convert_charrefs=True):
        NativeParser.__init__(self)
        self.convert_charrefs = convert_charrefs
    def handle_entityref(self, name):
        value = '&' + name + ';'
        self.handle_data(self.unescape(value) if self.convert_charrefs else value)
    def handle_charref(self, name):
        value = '&#' + name + ';'
        self.handle_data(self.unescape(value) if self.convert_charrefs else value)
