# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Cricfy 7.1 remote catalogue, independent of Android advertising screens."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
import calendar
from .py2compat import json
from .py2compat import re
from .py2compat import subprocess
from .py2compat import threading
from .py2compat import time
from .py2compat import datetime
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlparse = urllib.parse.urlparse
parse_qsl = urllib.parse.parse_qsl
unquote = urllib.parse.unquote
from .py2compat import requests
UA = 'Mozilla/5.0 CricfyTV/7.1'
BASE = 'https://rtsplays.com/data/'
STARTUP = ('https://s1.crickfy.click/c/7.1/c4-co.json', 'https://s1.crickfy.xyz/c/7.1/c4-co.json')
SECTION_MAP = {'matches': (u'Cricfy TV - الأحداث والقنوات', '')}
_cache = {}
_lock = threading.RLock()
_TOKEN_CODES = (13, 83, 1, 82, 93, 84, 12, 84, 83, 83, 80, 80, 82, 82, 2, 86, 92, 82, 84, 83, 81, 82, 86, 2, 93, 80, 82, 83, 94, 80, 83, 84, 92, 86, 92, 82, 81, 82, 82, 4, 93, 84, 83, 83, 93, 80, 94, 82, 80, 80, 92, 82, 86, 83, 82, 84, 93, 80, 81, 83, 93, 80, 83)

def refresh():
    with _lock:
        compat_clear(_cache)

def _memo(key, load, ttl=45):
    with _lock:
        cached = _cache.get(key)
        if cached and time.time() - cached[0] < ttl:
            return cached[1]
    data = load()
    with _lock:
        _cache[key] = (time.time(), data)
    return data

def _get(url, headers=None):
    if urlparse(url).scheme not in ('http', 'https'):
        raise ValueError('Invalid Cricfy address')
    with requests.get(url, headers=headers or {'User-Agent': UA, 'Accept': 'text/plain, application/json, */*'}, timeout=(7, 18), stream=True) as response:
        response.raise_for_status()
        chunks, size = ([], 0)
        for chunk in response.iter_content(32768):
            size += len(chunk)
            if size > 16 * 1024 * 1024:
                raise RuntimeError('Cricfy response is too large')
            chunks.append(chunk)
        return (b''.join(chunks).decode('utf-8-sig'), response.url)

def _swap_reverse(text):
    chars = list(text)
    for i in range(0, len(chars) - 1, 2):
        chars[i], chars[i + 1] = (chars[i + 1], chars[i])
    return ''.join(chars)[::-1]

def _aes(data):
    key, iv = (b'WT1sdkEvUlR4ckd2', b'Q7sKcm9LR4VaX2pN')
    try:
        from Crypto.Cipher import AES
        plain = AES.new(key, AES.MODE_CBC, iv).decrypt(data)
    except ImportError:
        from .generalaes import AESModeOfOperationCBC
        cipher = AESModeOfOperationCBC(key, iv=iv)
        plain = b''.join((cipher.decrypt(data[n:n + 16]) for n in range(0, len(data), 16)))
    padding = plain[-1] if plain else 0
    if not 1 <= padding <= 16 or plain[-padding:] != bytes([padding]) * padding:
        raise ValueError('Invalid catalogue padding')
    return plain[:-padding]

def decode(text):
    text = text.strip()
    if not text:
        raise RuntimeError(u'خدمة Cricfy أعادت بيانات فارغة؛ جرّب التحديث لاحقاً.')
    if text.lower().startswith('cfj1:'):
        a = (29, 88, 17, 104, 66, 7, 91, 34, 113, 5, 47, 96)
        b = (71, 12, 83, 44, 9, 121, 36, 58, 101, 22, 63)
        c = (6, 39, 95, 14, 74, 52, 117, 27, 68, 3, 86, 41, 109)
        key = [(a[i % 12] ^ (b[(i * 3 + 1) % 11] >> 8 - (i & 7) | b[(i * 3 + 1) % 11] << (i & 7)) & 255 ^ c[(i * 5 + 2) % 13] ^ 90 ^ i) & 255 for i in range(32)]
        raw = base64.b64decode(text[5:])
        text = bytes((v ^ key[i % 32] ^ i * 29 + 71 & 255 for i, v in enumerate(raw)))[::-1].decode('utf8')
    elif not text.startswith(('[', '{')):
        transformed = _swap_reverse(base64.b64decode(text).decode('utf8'))
        if not transformed.endswith('abcdefghijklmnop'):
            raise RuntimeError(u'صيغة بيانات Cricfy تغيرت')
        clear = _aes(base64.b64decode(transformed[:-16])).decode('utf8')
        plain = re.sub('[^A-Za-z0-9+/=]', '', _swap_reverse(clear)).replace('=', '')
        text = base64.b64decode(plain + '=' * (-len(plain) % 4)).decode('utf8')
    return json.loads(text)

def _config():

    def load():
        for url in STARTUP:
            try:
                data = decode(_get(url)[0])
                if data.get('enabled') is False:
                    raise RuntimeError(u'خدمة Cricfy متوقفة من المصدر')
                return data
            except Exception as error:
                last = error
        raise RuntimeError(u'تعذر جلب إعدادات Cricfy: ' + str(last))
    return _memo('config', load, 300)

def _encode(value):
    return byte_hex(bytes((c ^ 90 for c in value.encode('utf8'))))

def _data(path):

    def load():
        config = _config()
        base = config.get('api_url') or BASE
        if path.startswith(('http://', 'https://')):
            raw, final = _get(path)
        else:
            prefix = config.get('getdata_path_prefix') or 'v2/'
            full = path if path.startswith(prefix) else prefix.rstrip('/') + '/' + path.lstrip('/')
            token = config.get('getdata_token') or ''.join((chr(c ^ 53) for c in _TOKEN_CODES))
            params = {'key': _encode(full), 'hmac': _encode(str(int(time.time())) + '|' + token)}
            from .py2compat import urllib
            urlencode = urllib.parse.urlencode
            endpoint = urljoin(config.get('getdata_base_url') or base, config.get('getdata_endpoint') or 'getData.php')
            raw, final = _get(endpoint + '?' + urlencode(params))
        return decode(raw)
    return _memo(('data', path), load)

def _obj(value):
    if isinstance(value, str) and value.strip().startswith(('{', '[')):
        return json.loads(value)
    return value

def _rows(value):
    value = _obj(value)
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        for key in ('items', 'events', 'channels', 'categories', 'data', 'results', 'entries', 'links', 'sources', 'streams'):
            if isinstance(_obj(value.get(key)), list):
                return _obj(value[key])
        return [value]
    return []

def _entry(raw, kind):
    info = _obj(raw.get(kind)) or raw
    if not isinstance(info, dict):
        return {}
    item = dict(info)
    if 'links' in raw:
        item['links'] = _obj(raw['links'])
    item['id'] = str(raw.get('id', item.get('id', '')))
    return item

def _events():
    path = _config().get('events_path') or 'events.txt'
    events = []
    for raw in _rows(_data(path)):
        info = _entry(raw, 'event')
        if not info or info.get('visible') is False:
            continue
        details = info.get('eventDetails') or {}
        a, b = (info.get('teamA'), info.get('teamB'))
        a = a.get('name', '') if isinstance(a, dict) else a or info.get('teamAName', '')
        b = b.get('name', '') if isinstance(b, dict) else b or info.get('teamBName', '')
        name = info.get('eventName2') or ('%s vs %s' % (a, b) if a and b and (a != b) else a or details.get('eventName') or info.get('eventName') or 'Event')
        timestamp = _timestamp(info.get('date'), info.get('time'))
        end = _timestamp(info.get('end_date') or info.get('date'), info.get('end_time'))
        status = u'انتهى' if end and end < time.time() else u'مباشر' if timestamp and timestamp <= time.time() else u'قادم'
        clock = time.strftime('%d/%m %H:%M', time.localtime(timestamp)) if timestamp else ' '.join((info.get('date', ''), info.get('time', '')))
        events.append(dict(info, name=clock + ' | ' + name + ' | ' + status, match_name=name, title=name, category=details.get('category') or info.get('category') or 'Other', image=details.get('eventLogo') or info.get('eventLogo', ''), action='browse', section='matches', kind='servers', timestamp=timestamp or 0, description=clock + ' | ' + status))
    return sorted(events, key=lambda row: (row['timestamp'] < time.time(), row['timestamp'] if row['timestamp'] >= time.time() else -row['timestamp']))

def _timestamp(date, clock):
    if not date or not clock:
        return None
    for fmt in ('%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M', '%Y-%m-%d %H:%M:%S'):
        try:
            return calendar.timegm(datetime.strptime(date + ' ' + clock, fmt).timetuple())
        except ValueError:
            pass
    return None

def groups():
    events = _events()
    groups = [dict(name=u'كل المباريات والأحداث (%d)' % len(events), kind='events', section='matches')]
    for category in dict.fromkeys((event['category'] for event in events)):
        groups.append(dict(name=category, category=category, kind='events', section='matches'))
    groups.append(dict(name=u'القنوات الرياضية', kind='catalogue', path=_config().get('sports_slug_path'), section='channels'))
    for raw in _rows(_data(_config().get('categories_path') or 'categories.txt')):
        cat = _entry(raw, 'cat')
        if cat.get('visible') is False:
            continue
        path = cat.get('api') or cat.get('path') or cat.get('catLink')
        if not path and raw.get('table_name'):
            path = 'channels/' + raw['table_name'] + '.txt'
        groups.append(dict(cat, name=cat.get('name') or cat.get('title') or 'Channels', kind='catalogue', path=path, section='channels', image=cat.get('logo', '')))
    return groups

def split_url(value, headers=None):
    from .streamrequest import split_url as split_stream_url
    url, result = split_stream_url(value, headers)
    result.setdefault('User-Agent', UA)
    return url.strip(), result

def parse_m3u(text, final):
    rows, entry, headers, protected = ([], None, {}, False)
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('#EXTINF:'):
            attrs = dict(re.findall('([\\w-]+)="([^"]*)"', line))
            name = line.rsplit(',', 1)[-1]
            entry = dict(name=name, title=name, match_name=name, image=attrs.get('tvg-logo', ''), category=attrs.get('group-title', ''))
            headers, protected = ({}, False)
        elif entry and line.startswith('#EXTVLCOPT:'):
            key, _, val = line[len('#EXTVLCOPT:'):].partition('=')
            names = {'http-user-agent': 'User-Agent', 'http-referrer': 'Referer', 'http-origin': 'Origin'}
            if key in names:
                headers[names[key]] = val
        elif entry and line.startswith('#KODIPROP:') and ('license_type=' in line or 'license_key=' in line):
            protected = True
            prop, unused, value = line[len('#KODIPROP:'):].partition('=')
            if prop.endswith('license_type'):
                entry['license_type'] = value.strip()
            elif prop.endswith('license_key') and re.fullmatch('[0-9a-fA-F]{32}:[0-9a-fA-F]{32}', value.strip()):
                entry['api'] = value.strip()
        elif entry and line and (not line.startswith('#')):
            url, options = split_url(line, headers)
            entry.update(action='play', url=urljoin(final, url), headers=options, protected=protected, source='cricfy')
            if protected:
                entry['name'] += ' [DRM]'
            rows.append(entry)
            entry = None
    return rows

def _catalogue(parent):
    path = parent.get('path')
    if not path:
        raise RuntimeError(u'هذا التصنيف لا يحتوي رابطاً من المصدر')
    if parent.get('type') == 'm3u' or path.split('|')[0].split('?')[0].endswith(('.m3u', '.m3u8')):
        url, headers = split_url(path)
        raw, final = _get(url, headers)
        return parse_m3u(raw, final)
    rows = []
    for raw in _rows(_data(path)):
        info = _entry(raw, 'channel')
        if not info or info.get('visible') is False:
            continue
        name = info.get('name') or info.get('title') or 'Channel'
        rows.append(dict(info, name=name, title=name, match_name=name, kind='servers', action='browse', section='channels', image=info.get('logo', '')))
    return rows

def _servers(parent):
    links = _obj(parent.get('links'))
    if isinstance(links, str):
        links = _data(links)
    rows = []
    for number, row in enumerate(_rows(links)):
        if isinstance(row, str):
            row = {'link': row}
        if not isinstance(row, dict):
            continue
        name = row.get('name') or row.get('title') or 'Server %d' % (number+1)
        from .streamrequest import headers as merge_headers
        url, headers = split_url(row.get('link') or row.get('url') or '', merge_headers(parent.get('headers'), row.get('headers')))
        if urlparse(url).scheme not in ('http', 'https') and not (row.get('tokenApi') or row.get('token_api')):
            continue
        protected = bool(row.get('api') or row.get('license') or row.get('drm'))
        rows.append(dict(row, name=name+(' [DRM]' if protected else ''), action='play',
                         url=url, headers=headers, protected=protected, server_key=str(number),
                         match_name=parent.get('match_name') or parent.get('name', ''),
                         description=parent.get('description', ''), image=parent.get('image', ''), source='cricfy'))
    return rows

def page(parent, page=1):
    kind = parent.get('kind')
    if kind == 'events':
        rows = [row for row in _events() if not parent.get('category') or row['category'] == parent['category']]
    elif kind == 'catalogue':
        rows = _memo(('catalogue', parent.get('path')), lambda: _catalogue(parent), 45)
    else:
        rows = _servers(parent)
    return {'entries': rows[(page - 1) * 24:page * 24], 'page': page, 'total': len(rows), 'last_page': max(1, (len(rows) + 23) // 24)}

def resolve(item):
    from .cricfyplayback import resolve as resolve_player
    return resolve_player(item)
