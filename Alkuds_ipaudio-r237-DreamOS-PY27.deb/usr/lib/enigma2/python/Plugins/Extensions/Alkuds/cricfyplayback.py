# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Bounded Cricfy playback preparation. Runs in the existing browser worker."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import html
from .py2compat import json
from .py2compat import re
from .py2compat import time
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlparse = urllib.parse.urlparse
from .py2compat import requests
from .cricfy import UA, split_url, _obj
from .matchqualities import qualities

class Playback(object):

    def __init__(self):
        self.session = requests.Session()
        self.deadline = time.monotonic() + 28
        self.visited = set()
        self.requests = 0

    def fetch(self,url,headers,sample=False):
        if urlparse(url).scheme not in ('http','https'):
            raise RuntimeError('عنوان المشغّل غير صالح')
        remaining=self.deadline-time.monotonic()
        self.requests+=1
        if remaining<=0 or self.requests>12:
            raise RuntimeError('انتهت مهلة تجهيز السيرفر؛ جرّب سيرفرًا آخر')
        with self.session.get(url,headers=headers,timeout=(min(4,remaining),min(8,remaining)),stream=True) as response:
            response.raise_for_status()
            data=bytearray()
            # Do not wait for a full 64 KiB chunk from a slow live TS source.
            for chunk in response.iter_content(188*16):
                data.extend(chunk)
                if self.is_video(data) or (sample and len(data)>=188*3):break
                if len(data)>512*1024:raise RuntimeError('استجابة المشغّل أكبر من الحد المسموح')
                if time.monotonic()>self.deadline:raise RuntimeError('انتهت مهلة تجهيز السيرفر')
            return bytes(data),response.url

    def stream_headers(self,url,headers):
        from .streamrequest import cookie_headers
        return cookie_headers(self.session,url,headers)

    def media(self,url,headers,depth=0):
        if depth>3:raise RuntimeError('قائمة الجودات متداخلة أكثر من اللازم')
        raw,final=self.fetch(url,headers)
        text=raw.decode('utf-8-sig','replace').lstrip()
        if text.startswith('#EXTM3U'):
            links=[line.strip() for line in text.splitlines() if line.strip() and not line.startswith('#')]
            if not links:raise RuntimeError('السيرفر أعاد قائمة فيديو فارغة')
            if '#EXT-X-STREAM-INF:' in text:
                failure=None
                for link in links[:4]:
                    try:return self.media(urljoin(final,link),headers,depth+1)
                    except Exception as error:failure=error
                raise failure
            sequence=re.search(r'(?m)^#EXT-X-MEDIA-SEQUENCE:\s*(\d+)',text)
            sequence=int(sequence.group(1)) if sequence else 0
            current=None
            segments=[]
            for raw_line in text.splitlines():
                line=raw_line.strip()
                if line.startswith('#EXT-X-KEY:'):
                    current={key: value.strip('"') for key,value in re.findall(r'([A-Za-z0-9-]+)=("[^"]*"|[^,]*)',line.split(':',1)[1])}
                    if current.get('METHOD')=='NONE':current=None
                    elif current.get('METHOD')!='AES-128' or current.get('KEYFORMAT','identity')!='identity':
                        raise RuntimeError('هذا السيرفر يحتاج مشغّل تشفير خاص؛ اختر سيرفرًا مباشرًا')
                    elif not current.get('URI'):raise RuntimeError('مفتاح HLS غير موجود في قائمة البث')
                elif line and not line.startswith('#'):
                    segments.append((urljoin(final,line),current,sequence))
                    sequence+=1
            keys={}
            # Probe decrypted media, including rotations and METHOD=NONE.
            for segment, encryption, number in segments[-2:]:
                data,_=self.fetch(segment,headers,sample=True)
                if encryption:
                    import binascii
                    key_url=urljoin(final,encryption['URI'])
                    if key_url not in keys:
                        if key_url.startswith('data:'):
                            from .streamproxy import _decode_data_uri
                            keys[key_url]=_decode_data_uri(key_url)
                        else:keys[key_url]=self.fetch(key_url,headers)[0]
                    key=keys[key_url]
                    if not key or len(key)!=16:raise RuntimeError('مفتاح HLS غير صالح')
                    iv=encryption.get('IV')
                    if iv:
                        if not re.match(r'^0[xX][0-9a-fA-F]{1,32}\Z',iv):raise RuntimeError('قيمة IV غير صالحة')
                        number=int(iv[2:],16)
                    iv=binascii.unhexlify(('%032x'%number).encode('ascii'))
                    data=self._decrypt_sample(data,key,iv)
                if not self.is_video(data):
                    raise RuntimeError('مقاطع السيرفر ليست فيديو قابلاً للتشغيل')
            return True
        if not self.is_video(raw):raise RuntimeError('السيرفر أعاد صفحة ويب بدل الفيديو')
        return True

    @staticmethod
    def is_video(data):
        return len(data) >= 188 * 3 and data[0] == data[188] == data[376] == 71 or b'ftyp' in data[:32] or (len(data) > 8 and data[4:8] in (b'styp', b'moof'))

    def walk(self,url,headers,depth=0):
        if depth>3 or url in self.visited:raise RuntimeError('لم يظهر رابط فيديو مباشر داخل المشغّل')
        self.visited.add(url)
        raw,final=self.fetch(url,headers)
        stream=dict(url=final,headers=self.stream_headers(final,headers),source='cricfy',quality='Auto',relay=True,relay_options={'live':True,'livehd':True})
        text=raw.decode('utf-8-sig','replace').lstrip()
        if text.startswith('#EXTM3U'):
            self.media(final,headers)
            stream['headers']=self.stream_headers(final,headers)
            from .streamrequest import cookie_state
            stream['relay_options']['cookies']=cookie_state(self.session)
            return qualities(text,dict(stream,mediatype='hls'))
        if self.is_video(raw):return [dict(stream,mediatype='ts' if raw[:1]==b'G' else 'mp4')]
        text=raw.decode('utf-8-sig','replace')
        from .sirfbs import media_candidates
        candidates=media_candidates(text,final)
        # Follow only actual player iframes, never scripts, popups or ad links.
        candidates+=re.findall(r'<iframe\b[^>]*\bsrc\s*=\s*["\']([^"\']+)',text,re.I)
        errors=[]
        for candidate in list(dict.fromkeys(candidates))[:4]:
            target=urljoin(final,html.unescape(candidate))
            child_headers={key:value for key,value in headers.items() if key.lower()!='cookie'}
            child_headers['Referer']=final
            try:return self.walk(target,child_headers,depth+1)
            except Exception as error:errors.append(error)
        if re.search(r'WebAssembly\s*\.|["\'][^"\']+\.wasm(?:[?"\'])|Wasm\s+decryptor',text,re.I):
            raise RuntimeError('هذا المشغّل يحتاج تهيئة Wasm داخل المتصفح؛ مساره غير مدعوم بعد')
        if errors:raise errors[-1]
        raise RuntimeError('هذا السيرفر يحتاج تهيئة داخل تطبيقه ولم يُرجع رابط فيديو مباشرًا')

    def _decrypt_sample(self,data,key,iv):
        import binascii
        length=min(len(data)//16*16,576)
        if not length:raise RuntimeError('مقطع HLS المشفر فارغ أو غير صالح')
        # The legacy AES module iterates native byte strings on Python 2;
        # future.newbytes instead yields integers. Normalize this boundary.
        data=binascii.unhexlify(binascii.hexlify(data[:length]))
        key=binascii.unhexlify(binascii.hexlify(key))
        iv=binascii.unhexlify(binascii.hexlify(iv))
        try:
            from Crypto.Cipher import AES
            clear=AES.new(key,AES.MODE_CBC,iv).decrypt(data)
        except ImportError:
            from .generalaes import AESModeOfOperationCBC
            cipher=AESModeOfOperationCBC(key,iv=iv)
            clear=b''.join(cipher.decrypt(data[n:n+16]) for n in range(0,len(data),16))
        return bytes(clear)

def resolve(item):
    player = Playback()
    try:
        if item.get('protected'):
            from .cricfyclearkey import prepare
            return prepare(item, player)
        url, headers = split_url(item.get('url'), item.get('headers'))
        token = _obj(item.get('tokenApi') or item.get('token_api'))
        if token:
            if not isinstance(token, dict) or token.get('request_type', 'get').lower() != 'get':
                raise RuntimeError(u'طريقة تهيئة هذا السيرفر غير مدعومة بعد')
            target = token.get('api') or token.get('url')
            raw, final = player.fetch(target, headers)
            try:
                payload = json.loads(raw.decode('utf-8-sig'))
                resolved = payload.get(token.get('link_key') or 'url') if isinstance(payload, dict) else None
            except (ValueError, UnicodeError):
                resolved = None
            if resolved:
                url, headers = split_url(resolved, headers)
            elif token.get('type') in ('embed', 'web'):
                url = final
            else:
                raise RuntimeError(u'خدمة تهيئة السيرفر لم تُرجع رابط فيديو')
        if '/promo/' in urlparse(url).path.lower():
            raise RuntimeError(u'لم يُنشر رابط المباراة بعد؛ المصدر يعرض رابطًا ترويجيًا')
        streams = player.walk(url, headers)
        return dict(item, name=item.get('match_name') or item['name'], url=streams[0]['url'], streams=streams, variants=streams)
    except requests.HTTPError as error:
        status = error.response.status_code if error.response is not None else '?'
        raise RuntimeError(u'السيرفر غير متاح الآن (HTTP %s)؛ جرّب سيرفرًا آخر' % status)
    except requests.RequestException:
        raise RuntimeError(u'تعذر الاتصال بسيرفر البث؛ جرّب سيرفرًا آخر')
    finally:
        player.session.close()
