# -*- coding: utf-8 -*-
"""QFilm movies (PHP Melody) catalogue, player servers and HLS resolver."""
from .py2compat import json
from .py2compat import re
from .py2compat import requests
try:
    from urllib.parse import urljoin, urlparse
except ImportError:
    from urlparse import urljoin, urlparse
from . import arabseed as a
from . import sitecatalogue as c

BASE = 'https://a.qfilm.tv/'
HOSTS = ('a.qfilm.tv', 'www.qfilm.tv', 'qfilm.tv')
try:
    string_types = (basestring,)
except NameError:
    string_types = (str,)

# The +18 section is intentionally not exposed.
CATEGORIES = (
    ('2026-movies', u'أفلام 2026'),
    ('arabic-movies', u'أفلام عربي'),
    ('egyptian-movies', u'أفلام مصرية'),
    ('foreign-movies', u'أفلام أجنبية'),
    ('indian-movies', u'أفلام هندية'),
    ('asian-movies', u'أفلام آسيوية'),
    ('turkish-movies', u'أفلام تركية'),
    ('anime-movies', u'أفلام أنيميشن'),
    ('dubbed-movies', u'أفلام مدبلجة'),
    ('action-movies', u'أكشن'),
    ('comedy-movies', u'كوميدي'),
    ('drama-movies', u'دراما'),
    ('romance-movies', u'رومانسي'),
    ('horror-movies', u'رعب'),
    ('thriller-movies', u'تشويق وإثارة'),
    ('adventure-movies', u'مغامرات'),
    ('crime-movies', u'جريمة'),
    ('mystery-movies', u'غموض'),
    ('sci-fi-movies', u'خيال علمي'),
    ('fantasy-movies', u'فانتازيا'),
    ('war-movies', u'حروب'),
    ('documentary-movies', u'وثائقي'),
    ('family-movies', u'عائلي'),
    ('biography-movies', u'سيرة ذاتية'),
    ('musical-movies', u'موسيقي وغنائي'),
    ('historical-movies', u'تاريخي'),
    ('coming-soon', u'يعرض قريباً'),
)

SECTIONS = (
    ('browse', u'تصفح الموقع', 'newvideos.php'),
    ('new', u'جديد الموقع', 'newvideos.php'),
    ('movies', u'الأفلام', 'category.php?cat=2026-movies'),
) + tuple((key, name, 'category.php?cat=' + key) for key, name in CATEGORIES)

SECTION_MAP = dict((key, (name, path)) for key, name, path in SECTIONS)

_LABELS = (
    ('liiivideo', 'Liiivideo'),
    ('vidmoly', 'Vidmoly'),
    ('mp4plus', 'MP4Plus'),
    ('vidspeed', 'VidSpeed'),
    ('anafast', 'AnaFast'),
    ('vidoba', 'Vidoba'),
    ('uqload', 'UQload'),
    ('vidaraa', 'Vidaraa'),
    ('abyssplayer', 'AbyssPlayer'),
    ('ok.ru', 'OK.ru'),
    ('dailymotion', 'Dailymotion'),
    ('streamwish', 'StreamWish'),
    ('filemoon', 'FileMoon'),
    ('mixdrop', 'MixDrop'),
    ('streamtape', 'StreamTape'),
    ('dood', 'DoodStream'),
    ('vidhide', 'VidHide'),
    ('voe', 'VOE'),
)

# Fast providers first; the first one is the direct HLS player used by QFilm.
_PRIORITY = ('liiivideo', 'vidmoly', 'mp4plus', 'vidspeed', 'anafast', 'vidoba',
             'uqload', 'vidaraa', 'ok.ru', 'abyssplayer')
_BROWSER_HOSTS = ('ok.ru', 'abyssplayer.', 'vidaraa.')


def _local(value):
    return c.local(BASE, HOSTS, value)


def _get(session, value, params=None, referer=BASE):
    html, final, mime = c.get(session, _local(value), referer, params)
    _local(final)
    return html, final


def groups():
    return [{'name': u'البحث في الموقع', 'section': 'new', 'action': 'search'},
            {'name': u'جديد الموقع', 'section': 'new', 'node': 'items'},
            {'name': u'الأفلام', 'section': 'movies', 'node': 'sections'}]


def sections(section, parent):
    if section == 'movies':
        return [{'name': name, 'section': key, 'node': 'items'} for key, name in CATEGORIES]
    return [{'name': u'عرض النتائج', 'node': 'items'},
            {'name': u'ترتيب أبجدي أ–ي', 'node': 'items', 'order': 'az'},
            {'name': u'ترتيب أبجدي ي–أ', 'node': 'items', 'order': 'za'}]


def filters(section, parent):
    return []


def _vid(value):
    match = re.search(r'watch\.php\?vid=([0-9A-Za-z]+)', value or '')
    return match.group(1) if match else ''


def _text(nodes):
    return nodes[0].text() if nodes else ''


def _rows(root, page, section):
    rows, seen = [], set()
    lists = root.find('ul', 'pm-ul-browse-videos')
    nodes = []
    for block in lists:
        nodes.extend(block.find('li'))
    if not nodes:
        nodes = root.find('li')
    for node in nodes:
        anchor = None
        for candidate in node.find('a'):
            if 'watch.php?vid=' in candidate.attrs.get('href', ''):
                anchor = candidate
                break
        if anchor is None:
            continue
        vid = _vid(anchor.attrs.get('href', ''))
        if not vid or vid in seen:
            continue
        seen.add(vid)
        title = _text(node.find('h3', 'caption')) or anchor.attrs.get('title') or u'فيلم'
        image = ''
        pictures = node.find('img')
        if pictures:
            image = pictures[0].attrs.get('data-echo') or pictures[0].attrs.get('src') or ''
            if not image:
                image = pictures[0].attrs.get('data-src') or ''
        duration = _text(node.find('span', 'pm-label-duration'))
        rows.append({'id': vid, 'url': urljoin(page, anchor.attrs.get('href', '')),
                     'name': title, 'title': title,
                     'image': urljoin(page, image) if image else '',
                     'duration': duration,
                     'quality': '',
                     'category': u'فيلم' + (u' | ' + duration if duration else ''),
                     'search_text': title.lower()})
    return rows


def fetch_items(section, page=1, query='', order='latest', options=None):
    page = max(1, int(page))
    if section not in SECTION_MAP:
        section = 'new'
    with requests.Session() as session:
        session.verify = False
        if query:
            html, final = _get(session, 'search.php', {'keywords': query, 'page': page})
        else:
            html, final = _get(session, SECTION_MAP[section][1], {'page': page})
        root = a.Document(html).root
        rows = _rows(root, final, section)
        last = c.last_page(root, page)
    return {'entries': rows, 'page': page, 'last_page': last, 'total': len(rows)}


def _server_label(url):
    low = url.lower()
    for key, name in _LABELS:
        if key in low:
            return name
    host = (urlparse(url).hostname or '').replace('www.', '')
    return host.split('.')[0].capitalize() or u'سيرفر'


def _browser_hint(url):
    low = url.lower()
    return u' (قد يحتاج متصفحاً)' if any(host in low for host in _BROWSER_HOSTS) else ''


def _priority(url):
    low = url.lower()
    for index, key in enumerate(_PRIORITY):
        if key in low:
            return index
    return 50


def _labelled(values):
    values = [(url, quality) for url, quality in values if url]
    values.sort(key=lambda pair: _priority(pair[0]))
    result, seen = [], set()
    for url, quality in values:
        if url in seen:
            continue
        seen.add(url)
        index = len(result) + 1
        result.append((u'%d - %s%s' % (index, _server_label(url), _browser_hint(url)), url, quality))
    return result


def _server_values(html, page):
    match = re.search(r'var\s+servers\s*=\s*(\[.*?\])\s*;', html, re.S)
    values, seen = [], set()
    if not match:
        return values
    raw = match.group(1)
    blocks = []
    try:
        parsed = json.loads(raw)
        blocks = [value for value in parsed if isinstance(value, string_types)]
    except (TypeError, ValueError):
        blocks = [value.replace('\\/', '/').replace('\\"', '"')
                  for value in re.findall(r'"((?:\\.|[^"\\])*)"', raw)]
    for block in blocks:
        source = ''
        quoted = re.search(r'src\s*=\s*["\']([^"\']+)["\']', block)
        if quoted:
            source = quoted.group(1)
        else:
            direct = re.search(r'https?://[^\s"\'<>]+', block)
            if direct:
                source = direct.group(0)
        source = source.replace('\\/', '/').replace('&amp;', '&').strip()
        if not source:
            continue
        url = urljoin(page, source)
        if urlparse(url).scheme not in ('http', 'https') or url in seen:
            continue
        seen.add(url)
        values.append((url, ''))
    return _labelled(values)


def _watch_values(html, page):
    root = a.Document(html).root
    values, seen = [], set()
    candidates = []
    for meta in root.find('meta'):
        if (meta.attrs.get('itemprop') or '').lower() == 'contenturl':
            candidates.append(meta.attrs.get('content') or '')
    for frame in root.find('iframe'):
        candidates.append(frame.attrs.get('src') or frame.attrs.get('data-src') or '')
    for match in re.finditer(r'["\'](https?://[^"\']+\.(?:m3u8|mp4)(?:\?[^"\']*)?)["\']', html, re.I):
        candidates.append(match.group(1))
    for value in candidates:
        value = (value or '').replace('\\/', '/').replace('&amp;', '&').strip()
        if not value:
            continue
        url = urljoin(page, value)
        if urlparse(url).scheme not in ('http', 'https') or url in seen:
            continue
        seen.add(url)
        values.append((url, ''))
    return _labelled(values)


def servers(item):
    vid = item.get('id') or _vid(item.get('url'))
    if not vid:
        raise RuntimeError(u'تعذر تحديد صفحة الفيديو في الموقع.')
    referer = item.get('url') or BASE
    with requests.Session() as session:
        session.verify = False
        html, final = _get(session, 'play.php', {'vid': vid}, referer)
    values = _server_values(html, final)
    if not values:
        with requests.Session() as session:
            session.verify = False
            html, final = _get(session, referer, referer=referer)
        values = _watch_values(html, final)
    if not values:
        raise RuntimeError(u'الموقع لم يعرض أي سيرفر مشاهدة لهذا الفيلم.')
    return c.server_rows(values, item, final)


def seasons(item):
    raise RuntimeError(u'هذا القسم يعرض الأفلام فقط.')


def episodes(item, page=1):
    raise RuntimeError(u'هذا القسم يعرض الأفلام فقط.')


resolve = c.resolve
