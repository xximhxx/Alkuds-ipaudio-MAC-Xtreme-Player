# -*- coding: utf-8 -*-
from . import fivetv
from .sitecatalogueui import Alkuds_SiteCatalogue_Browser


class Alkuds_5TV_Browser(Alkuds_SiteCatalogue_Browser):
    provider = fivetv
    site_name = u'فايف تي في 5TV'

    def __init__(self, session, section='home', level='groups', parent=None, page=1):
        Alkuds_SiteCatalogue_Browser.__init__(self, session, section, level, parent, page)
