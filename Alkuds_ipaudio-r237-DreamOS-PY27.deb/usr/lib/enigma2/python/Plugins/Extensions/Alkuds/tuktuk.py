# -*- coding: utf-8 -*-
"""TukTukCinema catalogue, player mirrors and HLS resolver.

The site is a WordPress installation whose movie/episode posts embed an
Inertia.js player at megatuktuk.store.  The player exposes its mirrors through
a partial Inertia request, which is what servers() uses.
"""
import base64
from .py2compat import json
from .py2compat import re
from .py2compat import requests
try:
    from urllib.parse import urljoin, urlparse, parse_qs, quote
    from html import unescape
except ImportError:
    from urlparse import urljoin, urlparse, parse_qs
    from urllib import quote
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape
from . import arabseed as a
from . import sitecatalogue as c

BASE = 'https://tuk.tuktukarab.store/'
HOSTS = ('tuk.tuktukarab.store', 'www.tuk.tuktukarab.store')

SECTIONS = (
    ('home', u'الرئيسية', 'main/'),
    ('recent', u'المضاف حديثاً', 'recent/'),
    ('movies', u'الأفلام', 'category/movies-2/'),
    ('series', u'المسلسلات', 'channel/full-series-1/'),
    ('episodes', u'الحلقات', 'category/series-1/'),
    ('most', u'الأكثر مشاهدة', 'most-viewed/'),
    ('popular', u'أفلام شائعة', 'popular-movies/'),
    ('schedule', u'الجدول الأسبوعي', 'page-schedule/'),
)
SECTION_MAP = dict((key, (name, path)) for key, name, path in SECTIONS)

# The +18 section is deliberately not exposed.
MOVIE_SECTIONS = (
    (u'جميع الأفلام', 'category/movies-2/'),
    (u'أفلام أجنبي', 'category/movies-2/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a/'),
    (u'أفلام هندي', 'category/movies-2/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%87%d9%86%d8%af%d9%89/'),
    (u'أفلام آسيوي', 'category/movies-2/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d8%b3%d9%8a%d9%88%d9%8a/'),
    (u'أفلام أنمي', 'category/anime-6/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%a7%d9%86%d9%85%d9%8a/'),
    (u'أفلام تركي', 'category/movies-2/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d8%aa%d8%b1%d9%83%d9%8a/'),
    (u'أفلام مدبلجة', 'category/movies-2/%d8%a7%d9%81%d9%84%d8%a7%d9%85-%d9%85%d8%af%d8%a8%d9%84%d8%ac%d8%a9/'),
    (u'أفلام نتفليكس', 'channel/film-netflix-1/'),
)

SERIES_SECTIONS = (
    (u'مسلسلات أجنبي', 'sercat/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a/'),
    (u'مسلسلات تركي', 'sercat/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%aa%d8%b1%d9%83%d9%8a/'),
    (u'مسلسلات آسيوي', 'sercat/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a3%d8%b3%d9%8a%d9%88%d9%8a/'),
    (u'مسلسلات هندي', 'sercat/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d9%87%d9%86%d8%af%d9%8a/'),
    (u'مسلسلات أنمي', 'sercat/%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d9%84%d8%a7%d9%86%d9%85%d9%8a/'),
    (u'برامج تلفزيونية', 'sercat/%d8%a8%d8%b1%d8%a7%d9%85%d8%ac-%d8%aa%d9%84%d9%81%d8%b2%d9%8a%d9%88%d9%86%d9%8a%d8%a9/'),
    (u'مسلسلات نتفليكس', 'channel/series-netflix-2/'),
    (u'مسلسلات كاملة', 'channel/full-series-1/'),
)

EPISODE_SECTIONS = (
    (u'جميع الحلقات', 'category/series-1/'),
    (u'حلقات أجنبي', 'category/series-1/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a7%d8%ac%d9%86%d8%a8%d9%8a/'),
    (u'حلقات تركي', 'category/series-1/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%aa%d8%b1%d9%83%d9%8a/'),
    (u'حلقات آسيوي', 'category/series-1/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d8%a3%d8%b3%d9%8a%d9%88%d9%8a/'),
    (u'حلقات هندي', 'category/series-1/%d9%85%d8%b3%d9%84%d8%b3%d9%84%d8%a7%d8%aa-%d9%87%d9%86%d8%af%d9%8a/'),
    (u'حلقات أنمي', 'category/anime-6/%d8%a7%d9%86%d9%85%d9%8a-%d9%85%d8%aa%d8%b1%d8%ac%d9%85/'),
)

SCHEDULE_DAYS = (
    ('friday', u'الجمعة'),
    ('saturday', u'السبت'),
    ('sunday', u'الأحد'),
    ('monday', u'الاثنين'),
    ('tuesday', u'الثلاثاء'),
    ('wednesday', u'الأربعاء'),
    ('thursday', u'الخميس'),
)
DAY_MAP = dict(SCHEDULE_DAYS)

# The site's own priority: TukTukVIP (earnvids) first, then the other mirrors
# that returned a playable HLS/MP4 link during testing.
_WORKING_DRIVERS = ('earnvids', 'streamruby', 'lulustream', 'mixdrop')
_BROWSER_DRIVERS = ('firestream', 'vidara', 'doodstream', 'byse', 'mp4upload')
_DRIVER_LABELS = {
    'earnvids': 'TukTukVIP',
    'streamruby': 'StreamRuby',
    'lulustream': 'LuluStream',
    'mixdrop': 'MixDrop',
    'firestream': 'Firestream',
    'vidara': 'Vidara',
    'doodstream': 'DoodStream',
    'byse': 'Byse',
    'mp4upload': 'MP4Upload',
}


def _local(value):
    return c.local(BASE, HOSTS, value)


def _get(session, value, referer=BASE, params=None):
    html, final, _mime = c.get(session, _local(value), referer, params)
    return html, final


def _quote(value):
    if not isinstance(value, bytes):
        value = value.encode('utf-8')
    return quote(value, '')


def _text(value):
    value = re.sub(r'<[^>]+>', ' ', value or '')
    return re.sub(r'\s+', ' ', unescape(value)).strip()


def _attr(tag, name):
    match = re.search(r'\b%s\s*=\s*(["\'])(.*?)\1' % re.escape(name), tag or '', re.S | re.I)
    return unescape(match.group(2)).strip() if match else ''


def _first_tag(value, tag):
    match = re.search(r'<%s\b[^>]*>' % re.escape(tag), value or '', re.S | re.I)
    return match.group(0) if match else ''


def _first_text(value, tag):
    match = re.search(r'<%s\b[^>]*>(.*?)</%s>' % (re.escape(tag), re.escape(tag)),
                      value or '', re.S | re.I)
    return _text(match.group(1)) if match else ''


def _class_text(value, needle):
    match = re.search(r'<[a-z0-9]+\b[^>]*class="[^"]*%s[^"]*"[^>]*>(.*?)</[a-z0-9]+>' %
                      re.escape(needle), value or '', re.S | re.I)
    return _text(match.group(1)) if match else ''


def _image(value, page):
    for attribute in ('data-src', 'data-lazy-src', 'data-echo', 'src'):
        match = re.search(r'\b%s\s*=\s*(["\'])(.*?)\1' % re.escape(attribute),
                          value or '', re.S | re.I)
        if not match:
            continue
        source = unescape(match.group(2)).strip()
        if source and not source.startswith('data:'):
            return urljoin(page, source)
    match = re.search(r'\b(?:data-srcset|srcset)\s*=\s*(["\'])(.*?)\1', value or '', re.S | re.I)
    if match:
        source = unescape(match.group(2)).split(',')[0].strip().split(' ')[0]
        if source and not source.startswith('data:'):
            return urljoin(page, source)
    return ''


def _genres(value):
    match = re.search(r'<ul\b[^>]*class="[^"]*\b(?:Genres|liList)\b[^"]*"[^>]*>(.*?)</ul>',
                      value or '', re.S | re.I)
    if not match:
        return []
    return [_text(item) for item in re.findall(r'<li\b[^>]*>(.*?)</li>', match.group(1), re.S | re.I)
            if _text(item)]


def _episode_tag(url):
    match = re.search(r'-s(\d+)-e(\d+)', url or '', re.I)
    if not match:
        return ''
    return u'موسم %d | حلقة %d' % (int(match.group(1)), int(match.group(2)))


def _fix_schedule_url(url):
    return re.sub(r'^https?://(?:www\.)?tuktukcinemas\.com', BASE.rstrip('/'), url or '',
                  flags=re.I)


def _row(href, title, image, page, category='', quality='', is_series=False):
    title = title.strip() or u'عنصر'
    row = {
        'url': urljoin(page, href),
        'name': title,
        'title': title,
        'image': image,
        'category': category,
        'quality': quality,
        'search_text': title.lower(),
        'catalogue_label': title,
    }
    if is_series:
        row['is_series'] = True
        row['series_title'] = title
    return row


def _block_cards(html, page):
    rows, seen = [], set()
    parts = re.compile(r'<div\b[^>]*class="[^"]*\bBlock--Item\b[^"]*"[^>]*>', re.I).split(html or '')
    for part in parts[1:]:
        if 'Poster--Block' not in part and not re.search(r'<h[23]\b', part, re.I):
            continue
        anchor = _first_tag(part, 'a')
        if not anchor:
            continue
        href = _attr(anchor, 'href')
        if not href or href.startswith('#'):
            continue
        url = urljoin(page, href)
        if url in seen or (urlparse(url).hostname or '') not in HOSTS:
            continue
        seen.add(url)
        title = _attr(anchor, 'title') or _first_text(part, 'h2') or _first_text(part, 'h3')
        genres = _genres(part)
        category = u', '.join(genres)
        is_series = '/series/' in (urlparse(url).path or '')
        if not is_series:
            tag = _episode_tag(url)
            if tag:
                category = tag + (u' | ' + category if category else '')
        rows.append(_row(href, title, _image(part, page), page, category,
                         _class_text(part, 'quality'), is_series))
    return rows


def _view_cards(html, page):
    rows, seen = [], set()
    for match in re.finditer(r'<article\b[^>]*class="[^"]*\bview-card\b[^"]*"[^>]*>(.*?)</article>',
                             html or '', re.S | re.I):
        part = match.group(1)
        anchor = _first_tag(part, 'a')
        if not anchor:
            continue
        href = _attr(anchor, 'href')
        if not href or href.startswith('#'):
            continue
        url = urljoin(page, href)
        if url in seen or (urlparse(url).hostname or '') not in HOSTS:
            continue
        seen.add(url)
        title = _first_text(part, 'h2') or _attr(anchor, 'title')
        views = _class_text(part, 'card-views-count')
        is_series = '/series/' in (urlparse(url).path or '')
        rows.append(_row(href, title, _image(part, page), page, views, '', is_series))
    return rows


def _ftv_cards(html, page):
    rows, seen = [], set()
    pattern = re.compile(r'(<a\b[^>]*class="[^"]*\bftv-card\b[^"]*"[^>]*>)(.*?)(</a>)',
                         re.S | re.I)
    for match in pattern.finditer(html or ''):
        anchor, inner = match.group(1), match.group(2)
        href = _fix_schedule_url(_attr(anchor, 'href'))
        if not href or href.startswith('#'):
            continue
        url = urljoin(page, href)
        if url in seen or (urlparse(url).hostname or '') not in HOSTS:
            continue
        seen.add(url)
        title = _first_text(inner, 'h2') or _attr(anchor, 'title')
        if not title:
            image_tag = _first_tag(inner, 'img')
            title = _attr(image_tag, 'alt')
        quality = _class_text(inner, 'ftv-badge-quality')
        badge = _class_text(inner, 'ftv-badge')
        is_series = '/series/' in (urlparse(url).path or '')
        rows.append(_row(href, title, _image(inner, page), page, badge, quality, is_series))
    return rows


def _schedule_cards(html, page, day):
    day = (day or 'friday').lower()
    match = re.search(r'<div\b[^>]*id="tab-%s"[^>]*>' % re.escape(day), html or '', re.I)
    if not match:
        return []
    start = match.end()
    following = re.search(r'<div\b[^>]*class="[^"]*ftv-tab-content', html[start:], re.I)
    block = html[start:start + following.start()] if following else html[start:]
    return _ftv_cards(block, page)


def _home_cards(html, page):
    """The front page mixes three card layouts; merge them without repeats."""
    rows, seen = [], set()

    def add(card_rows):
        for row in card_rows:
            if row['url'] in seen:
                continue
            seen.add(row['url'])
            rows.append(row)

    add(_block_cards(html, page))
    pattern = re.compile(r'<li\b[^>]*class="[^"]*\b(?:Small--Box|AsidePost)\b[^"]*"[^>]*>(.*?)</li>',
                         re.S | re.I)
    extra = []
    for match in pattern.finditer(html or ''):
        part = match.group(1)
        anchor = _first_tag(part, 'a')
        if not anchor:
            continue
        href = _attr(anchor, 'href')
        if not href or href.startswith('#'):
            continue
        url = urljoin(page, href)
        if (urlparse(url).hostname or '') not in HOSTS:
            continue
        title = _attr(anchor, 'title') or _first_text(part, 'h3') or _first_text(part, 'h2')
        if not title:
            title = _attr(_first_tag(part, 'img'), 'alt')
        genres = _genres(part)
        category = u', '.join(genres)
        is_series = '/series/' in (urlparse(url).path or '')
        if not is_series:
            tag = _episode_tag(url)
            if tag:
                category = tag + (u' | ' + category if category else '')
        extra.append(_row(href, title, _image(part, page), page, category, '', is_series))
    add(extra)
    return rows


def _last_page(html, page):
    values = [max(1, int(page))]
    for href in re.findall(r'href\s*=\s*(["\'])(.*?)\1', html or '', re.S | re.I):
        value = unescape(href[1])
        match = re.search(r'/page/(\d+)', value)
        if match:
            values.append(int(match.group(1)))
        query = parse_qs(urlparse(value).query).get('page')
        if query and query[0].isdigit():
            values.append(int(query[0]))
    return max(values)


def _section_items(name, path, section):
    return {'name': name, 'title': name, 'section': section, 'url': path,
            'node': 'items', 'catalogue_label': name}


def groups():
    return [
        {'name': u'البحث في الموقع', 'section': 'recent', 'action': 'search'},
        {'name': u'الرئيسية', 'section': 'home', 'node': 'items'},
        {'name': u'المضاف حديثاً', 'section': 'recent', 'node': 'items'},
        {'name': u'الأفلام', 'section': 'movies', 'node': 'sections'},
        {'name': u'المسلسلات', 'section': 'series', 'node': 'sections'},
        {'name': u'الحلقات', 'section': 'episodes', 'node': 'sections'},
        {'name': u'الأكثر مشاهدة', 'section': 'most', 'node': 'items'},
        {'name': u'أفلام شائعة ويعرض في السينما', 'section': 'popular', 'node': 'items'},
        {'name': u'الجدول الأسبوعي', 'section': 'schedule', 'node': 'sections'},
    ]


def sections(section, parent):
    if section == 'movies':
        return [_section_items(name, path, 'movies') for name, path in MOVIE_SECTIONS]
    if section == 'series':
        return [_section_items(name, path, 'series') for name, path in SERIES_SECTIONS]
    if section == 'episodes':
        return [_section_items(name, path, 'episodes') for name, path in EPISODE_SECTIONS]
    if section == 'schedule':
        return [{'name': name, 'title': name, 'section': 'schedule', 'node': 'items',
                 'day': key, 'catalogue_label': u'الجدول الأسبوعي — ' + name}
                for key, name in SCHEDULE_DAYS]
    return []


def filters(section, parent):
    return []


def fetch_items(section, page=1, query='', order='latest', options=None):
    page = max(1, int(page))
    options = options or {}
    if section not in SECTION_MAP and not options.get('url'):
        section = 'recent'
    url = options.get('url') or SECTION_MAP.get(section, ('', 'recent/'))[1]
    with requests.Session() as session:
        session.verify = False
        if query:
            params = {'page': page} if page > 1 else None
            html, final = _get(session, 'search/%s/' % _quote(query.strip()), BASE, params)
        else:
            params = {'page': page} if page > 1 and section not in \
                ('home', 'recent', 'most', 'popular', 'schedule') else None
            html, final = _get(session, url, BASE, params)
    if section == 'most':
        rows = _view_cards(html, final)
    elif section == 'popular':
        rows = _ftv_cards(html, final)
    elif section == 'schedule':
        rows = _schedule_cards(html, final, options.get('day'))
    elif section == 'home':
        rows = _home_cards(html, final)
    else:
        rows = _block_cards(html, final)
    if query:
        last = _last_page(html, page)
    elif section in ('home', 'recent', 'most', 'popular', 'schedule'):
        last = 1
    else:
        last = _last_page(html, page)
    return {'entries': rows, 'page': page, 'last_page': last, 'total': len(rows)}


def _section_content(html, name):
    match = re.search(r'<section\b[^>]*class="[^"]*\b%s\b[^"]*"[^>]*>' % re.escape(name),
                      html or '', re.I)
    if not match:
        return ''
    start = match.end()
    end = (html or '').lower().find('</section>', start)
    return (html or '')[start:end] if end > start else (html or '')[start:]


def _season_number(row):
    match = re.search(r'(\d+)', row.get('name') or '')
    return int(match.group(1)) if match else 9999


def seasons(item):
    url = item.get('url')
    if not url:
        raise RuntimeError(u'تعذر تحديد صفحة المسلسل في الموقع.')
    with requests.Session() as session:
        session.verify = False
        html, final = _get(session, url, url)
    rows = _block_cards(_section_content(html, 'SeriesSeasons'), final)
    series_title = item.get('series_title') or item.get('name') or u'مسلسل'
    if rows:
        rows.sort(key=_season_number)
        for row in rows:
            row.update(season=row['name'], is_series=True, series_title=series_title,
                       catalogue_label=series_title)
        return rows
    # Some pages publish the current season directly without a seasons tab.
    if re.search(r'class="[^"]*SeriesEpisodeCard', html, re.I):
        row = dict(item)
        row.update(name=u'كل الحلقات', title=u'كل الحلقات', url=final, season=u'كل الحلقات',
                   is_series=True, series_title=series_title, catalogue_label=series_title)
        return [row]
    raise RuntimeError(u'هذا المسلسل لا يعرض مواسم أو حلقات حالياً.')


def _episode_cards(html, page, item):
    rows, seen = [], set()
    pattern = re.compile(r'<a\b[^>]*class="[^"]*\bSeriesEpisodeCard\b[^"]*"[^>]*>(.*?)</a>',
                         re.S | re.I)
    series_title = item.get('series_title') or item.get('name') or u'مسلسل'
    for match in pattern.finditer(html or ''):
        anchor = _first_tag(match.group(0), 'a')
        href = _attr(anchor, 'href')
        if not href or href.startswith('#'):
            continue
        url = urljoin(page, href)
        if url in seen or (urlparse(url).hostname or '') not in HOSTS:
            continue
        seen.add(url)
        title = _attr(anchor, 'title') or _first_text(match.group(1), 'h2') or u'حلقة'
        image = _image(match.group(1), page)
        number = _first_text(match.group(1), 'strong')
        category = u'حلقة ' + number if number else _episode_tag(url)
        row = _row(href, title, image, page, category)
        row.update(season=item.get('season'), series_title=series_title,
                   catalogue_label=series_title)
        rows.append(row)
    return rows


def episodes(item, page=1):
    url = item.get('url')
    if not url:
        raise RuntimeError(u'تعذر تحديد صفحة الحلقات في الموقع.')
    with requests.Session() as session:
        session.verify = False
        html, final = _get(session, url, url)
    rows = _episode_cards(html, final, item)
    if not rows:
        raise RuntimeError(u'لم يعرض الموقع أي حلقات لهذا الموسم.')
    return rows


def _decode(value):
    value = ''.join((value or '').split())
    if not value:
        return ''
    for decoder in (base64.b64decode, base64.urlsafe_b64decode):
        try:
            text = decoder(value + '=' * (-len(value) % 4)).decode('utf-8')
        except Exception:
            continue
        if text.startswith(('http://', 'https://')):
            return text
    return ''


def _player_url(html, page):
    for match in re.finditer(r'<iframe\b[^>]*>', html or '', re.S | re.I):
        tag = match.group(0)
        if 'main-video-frame' not in tag and 'data-crypt=' not in tag:
            continue
        value = _decode(_attr(tag, 'data-crypt'))
        if value:
            return urljoin(page, value)
        source = _attr(tag, 'src')
        if source and not source.startswith('about:'):
            return urljoin(page, source)
    return ''


def _page_json(html):
    match = re.search(r'<script\b[^>]*data-page="app"[^>]*>(.*?)</script>',
                      html or '', re.S | re.I)
    if not match:
        raise RuntimeError(u'تعذر قراءة مشغل الموقع.')
    raw = match.group(1)
    try:
        return json.loads(raw)
    except ValueError:
        return json.loads(unescape(raw))


def _player_headers(referer):
    return {
        'User-Agent': a.UA,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8',
        'Referer': referer,
        'X-Requested-With': 'XMLHttpRequest',
        'X-Inertia': 'true',
        'X-Inertia-Partial-Component': 'files/mirror/video',
        'X-Inertia-Partial-Data': 'streams',
    }


def _streams_payload(session, iframe_url, version, item_page):
    headers = _player_headers(iframe_url)
    if version:
        headers['X-Inertia-Version'] = version
    response = session.get(iframe_url, headers=headers, timeout=(8, 25))
    if response.status_code == 409:
        response.close()
        html, _final, _mime = c.get(session, iframe_url, item_page)
        data = _page_json(html)
        headers['X-Inertia-Version'] = data.get('version') or ''
        response = session.get(iframe_url, headers=headers, timeout=(8, 25))
    try:
        response.raise_for_status()
        return json.loads(response.content.decode('utf-8', 'replace'))
    finally:
        response.close()


def _mirrors(payload, iframe_url):
    streams = ((payload.get('props') or {}).get('streams') or {})
    qualities = streams.get('data') or []
    result = []
    for quality_index, quality in enumerate(qualities):
        label = _text(quality.get('label') or '')
        for mirror in quality.get('mirrors') or []:
            link = (mirror.get('link') or '').strip()
            if not link:
                continue
            if link.startswith('//'):
                link = 'https:' + link
            url = urljoin(iframe_url, link)
            if (urlparse(url).hostname or '') == '':
                continue
            driver = (mirror.get('driver') or mirror.get('symbol') or u'سيرفر').strip()
            key = driver.lower()
            symbol = _text(mirror.get('symbol') or '')
            name = _DRIVER_LABELS.get(key) or (symbol or driver.title())
            if symbol and symbol.lower() not in name.lower():
                name = symbol + u' — ' + name
            hint = u' (قد يحتاج متصفحاً)' if key in _BROWSER_DRIVERS else ''
            result.append({'key': key, 'label': name, 'hint': hint, 'url': url,
                           'quality': label, 'quality_index': quality_index})
    unique, seen = [], set()
    for item in result:
        if item['url'] in seen:
            continue
        seen.add(item['url'])
        unique.append(item)
    return unique


def _server_values(mirrors):
    known = [item for item in mirrors if item['key'] in _WORKING_DRIVERS]
    if known:
        mirrors = known
    order = dict((key, index) for index, key in enumerate(_WORKING_DRIVERS))
    mirrors.sort(key=lambda item: (item['quality_index'], order.get(item['key'], 50)))
    values = []
    for index, item in enumerate(mirrors[:24]):
        label = u'%d - %s%s' % (index + 1, item['label'], item['hint'])
        values.append((label, item['url'], item['quality']))
    return values


def servers(item):
    referer = item.get('url') or BASE
    with requests.Session() as session:
        session.verify = False
        html, final = _get(session, referer, referer)
        player = _player_url(html, final)
        if not player:
            raise RuntimeError(u'صفحة الفيلم لا تحتوي على مشغل صالح.')
        player_html, iframe_url, _mime = c.get(session, player, final)
        data = _page_json(player_html)
        version = data.get('version') or ''
        payload = _streams_payload(session, iframe_url, version, final)
    mirrors = _mirrors(payload, iframe_url)
    values = _server_values(mirrors)
    if not values:
        raise RuntimeError(u'الموقع لم يعرض أي سيرفر مشاهدة لهذا المحتوى.')
    return c.server_rows(values, item, iframe_url)


resolve = c.resolve
