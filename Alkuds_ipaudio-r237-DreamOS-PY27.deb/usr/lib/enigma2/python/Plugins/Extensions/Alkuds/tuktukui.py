# -*- coding: utf-8 -*-
from . import tuktuk
from .sitecatalogueui import Alkuds_SiteCatalogue_Browser


class Alkuds_TukTuk_Browser(Alkuds_SiteCatalogue_Browser):
    provider = tuktuk
    site_name = u'توك توك سينما TukTuk'

    def __init__(self, session, section='recent', level='groups', parent=None, page=1):
        Alkuds_SiteCatalogue_Browser.__init__(self, session, section, level, parent, page)
