# -*- coding: utf-8 -*-
from . import alooytv
from .sitecatalogueui import Alkuds_SiteCatalogue_Browser


class Alkuds_AlooYTV_Browser(Alkuds_SiteCatalogue_Browser):
    provider = alooytv
    site_name = u'AlooYTV — الوي تي في'
