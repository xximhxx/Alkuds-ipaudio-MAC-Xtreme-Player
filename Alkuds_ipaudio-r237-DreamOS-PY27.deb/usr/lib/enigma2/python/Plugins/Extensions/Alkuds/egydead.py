# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r228.
"""EgyDead catalogue and MegaMax public player choices, Python 2/3."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import re
from .py2compat import requests
from . import arabseed as a
try:
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
    urlencode = urllib.parse.urlencode
    parse_qs = urllib.parse.parse_qs
except ImportError:
    from urlparse import urljoin, urlparse, parse_qs
    from urllib import urlencode

BASE = 'https://a1.egydead.media/'
TRUSTED_SUFFIXES = ('egydead.media', 'egydead.live')
SECTIONS = [
    ('browse', u'تصفح الموقع', 'h3/'),
    ('foreign_movies', u'أفلام أجنبية', 'category/english-movies/'),
    ('arabic_movies', u'أفلام عربية', u'category/افلام-عربي/'),
    ('turkish_movies', u'أفلام تركية', u'category/افلام-تركية/'),
    ('indian_movies', u'أفلام هندية', 'category/hindi-movies/'),
    ('asian_movies', u'أفلام آسيوية', u'category/افلام-اسيوية/'),
    ('cartoon_movies', u'أفلام كرتون', u'category/افلام-كرتون/'),
    ('anime_movies', u'أفلام أنمي', u'category/افلام-انمي/'),
    ('documentary_movies', u'أفلام وثائقية', u'category/افلام-وثائقية/'),
    ('dubbed_movies', u'أفلام أجنبية مدبلجة', 'category/english-movies/english-movies-dubbed/'),
    ('egyptian_cartoon_movies', u'كرتون باللهجة المصرية', u'category/افلام-كرتون/افلام-كرتون-ديزني-باللهجة-المصرية/'),
    ('translated_movies', u'أفلام إسلام الجيزاوي', 'category/eslamgizawy-movies/'),
    ('all_series', u'المسلسلات الكاملة', 'Series/'),
    ('foreign_series', u'مسلسلات أجنبية', 'series-category/english-series/'),
    ('arabic_series', u'مسلسلات عربية', 'series-category/arabic-series/'),
    ('turkish_series', u'مسلسلات تركية', 'series-category/turkish-series/'),
    ('indian_series', u'مسلسلات هندية', 'series-category/indian-series/'),
    ('asian_series', u'مسلسلات آسيوية', 'series-category/asian-series/'),
    ('latino_series', u'مسلسلات لاتينية', 'series-category/latino-series/'),
    ('african_series', u'مسلسلات إفريقية', 'series-category/african-series/'),
    ('documentary_series', u'مسلسلات وثائقية', 'series-category/documentary-series/'),
    ('cartoon_series', u'مسلسلات كرتون', 'series-category/cartoon-series/'),
    ('anime_series', u'مسلسلات أنمي', 'series-category/anime-series/'),
    ('dubbed_anime_series', u'أنمي مدبلج', 'series-category/anime-series-dubbed/'),
    ('chinese_series', u'أنميات صينية', 'series-category/chinese-anime/'),
    ('korean_series', u'أنميات كورية', 'series-category/korean-anime/'),
    ('dubbed_foreign_series', u'مسلسلات أجنبية مدبلجة', 'series-category/english-series-dubbed/'),
    ('dubbed_turkish_series', u'مسلسلات تركية مدبلجة', 'series-category/turkish-series-dubbed/'),
    ('dubbed_cartoon_series', u'كرتون مدبلج', 'series-category/cartoon-series-dubbed/'),
    ('dubbed_latino_series', u'مسلسلات لاتينية مدبلجة', 'series-category/latino-series-dubbed/'),
    ('programs', u'برامج تلفزيونية', 'series-category/tv-shows/'),
    ('shows', u'ستاند أب وحفلات', u'category/عروض-وحفلات/'),
    ('sports', u'رياضة', u'category/رياضة/')]
SECTION_MAP = dict((key, (name, path)) for key, name, path in SECTIONS)

SERIES_PATHS = ('/Series/', '/seasons/', '/episodes/')
SEASON_WORDS = {
    u'الاول': 1, u'الأول': 1, u'الثاني': 2, u'الثالث': 3, u'الرابع': 4,
    u'الخامس': 5, u'السادس': 6, u'السابع': 7, u'الثامن': 8, u'التاسع': 9,
    u'العاشر': 10, u'الحادي عشر': 11, u'الثاني عشر': 12,
}


def _trusted_host(host):
    host = (host or '').lower().rstrip('.')
    return any(host == suffix or host.endswith('.' + suffix) for suffix in TRUSTED_SUFFIXES)


def _local(url):
    url = urljoin(BASE, url)
    parsed = urlparse(url)
    if parsed.scheme not in ('https', 'http') or not _trusted_host(parsed.hostname):
        raise ValueError('Unexpected EgyDead catalogue address')
    value = urljoin(BASE, parsed.path.lstrip('/') + ('?' + parsed.query if parsed.query else ''))
    return requests.utils.requote_uri(value)


def _accept_redirect(url):
    global BASE
    parsed = urlparse(url)
    host = (parsed.hostname or '').lower()
    if parsed.scheme in ('https', 'http') and _trusted_host(host):
        if host != (urlparse(BASE).hostname or '').lower():
            BASE = '%s://%s/' % (parsed.scheme, parsed.netloc)


def _get(session, url, referer=BASE):
    response = session.get(_local(url), headers=a._headers(referer), timeout=(6, 18), stream=True)
    try:
        raw = bytearray()
        for chunk in response.iter_content(32768):
            raw.extend(chunk)
            if len(raw) > 5 * 1024 * 1024:
                raise RuntimeError(u'صفحة إيجي ديد أكبر من الحجم المدعوم.')
        text = bytes(raw).decode('utf8', 'replace')
        if ('cf-chl-' in text or '_cf_chl_opt' in text) and 'movieItem' not in text:
            raise RuntimeError(u'إيجي ديد يطلب تحقق Cloudflare من المتصفح (403). طلبات الرسيفر محجوبة حالياً؛ أعد المحاولة لاحقاً أو جرّب شبكة أخرى.')
        if response.status_code == 403:
            raise RuntimeError(u'إيجي ديد رفض الوصول إلى المحتوى (403). القائمة المحلية قد تظهر رغم حجب صفحات الموقع.')
        response.raise_for_status()
        _accept_redirect(response.url)
        return text, response.url
    finally:
        response.close()


def groups():
    return [{'name': name, 'section': key} for key, name, path in SECTIONS]


def _series_title(title):
    title = re.split(u'\\s*(?:الموسم|الجزء|الحلقة|حلقه|حلقة)\\s*', title, 1)[0]
    title = re.sub(u'\\s+(?:مترجم|مترجمة|مدبلج|مدبلجة|كامل|كاملة|جميع المواسم|مواسم).*$', '', title, flags=re.I).strip()
    title = re.sub(u'^جميع مواسم\\s+', '', title)
    title = re.sub(u'^مواسم\\s+', '', title)
    # Complete-series cards append the production year; season cards don't.
    # Use the same grouping name for both while retaining the actual URL.
    return re.sub(r'\s+(?:19|20)\d{2}$', '', title).strip()


def _is_series_url(url):
    path = urlparse(url).path
    return any(path.startswith(prefix) for prefix in SERIES_PATHS)


def _cards(root, section, container='posts-list'):
    holders = root.find(css=container)
    result, seen = [], set()
    for holder in holders:
        for block in holder.find(css='movieItem'):
            links = block.find('a')
            if not links:
                continue
            link = links[0]
            try:
                url = _local(link.attrs.get('href', ''))
            except ValueError:
                continue
            if url in seen:
                continue
            seen.add(url)
            title = link.attrs.get('title') or a._first_text(block, 'BottomTitle') or link.text()
            if not title:
                continue
            result.append({'url': url, 'name': title, 'image': a._image(block),
                'category': a._first_text(block, 'cat_name'), 'section': section,
                'is_series': _is_series_url(url)})
    return result


def _sort_key(item):
    title = re.sub(u'^(?:مشاهدة\\s+)?(?:فيلم|مسلسل|انمي|أنمي|برنامج)\\s+', '', item['name'])
    return title.lower()


def _page_url(path, page):
    url = _local(path)
    page = max(1, int(page or 1))
    if page == 1:
        return url
    parsed = urlparse(url)
    return requests.utils.requote_uri('%s://%s%s/page/%d/' % (
        parsed.scheme, parsed.netloc, parsed.path.rstrip('/'), page))


def fetch_items(section, page=1, query='', order='latest'):
    name, path = SECTION_MAP[section]
    if query:
        if section == 'browse':
            path = ''
        url = _local(path) if path else _local('')
        separator = '&' if '?' in url else '?'
        url += separator + urlencode({'s': query.encode('utf-8')})
        if int(page) > 1:
            separator = '&' if '?' in url else '?'
            url += separator + 'page=%d' % int(page)
    else:
        url = _page_url(path, page)
    session = requests.Session()
    try:
        html, page_url = _get(session, url)
    finally:
        session.close()
    root = a.Document(html).root
    entries = _cards(root, section)
    if not entries:
        # Home page has separate movie/episode/season panels.
        entries = _cards(root, section, 'container')
    if section.endswith('_movies'):
        entries = [x for x in entries if not x['is_series']]
    elif section.endswith('_series'):
        entries = [x for x in entries if x['is_series']]
    grouped, positions = [], {}
    for item in entries:
        if item['is_series']:
            item['name'] = _series_title(item['name'])
            key = item['name'].lower()
            if key in positions:
                # Prefer the complete-series page so every season is listed.
                current = grouped[positions[key]]
                if '/Series/' in urlparse(item['url']).path and '/Series/' not in urlparse(current['url']).path:
                    grouped[positions[key]] = item
                continue
            positions[key] = len(grouped)
        grouped.append(item)
    entries = grouped
    if order in ('az', 'za'):
        entries.sort(key=_sort_key, reverse=order == 'za')
    pages = [int(page)]
    for link in root.find('a', 'page-numbers'):
        params = parse_qs(urlparse(link.attrs.get('href', '')).query)
        match = re.match(r'(\d+)', params.get('page', [''])[0])
        if not match:
            match = re.search(r'/page/(\d+)', link.attrs.get('href', ''))
        if match:
            pages.append(int(match.group(1)))
    return {'entries': entries, 'page': int(page), 'last_page': max(pages), 'total': len(entries)}


def _breadcrumb(root, prefixes):
    if not isinstance(prefixes, (list, tuple)):
        prefixes = (prefixes,)
    holders = [x for x in root.find('ul') if x.attrs.get('id') == 'breadcrumbs']
    for holder in holders:
        for link in holder.find('a'):
            path = urlparse(link.attrs.get('href', '')).path
            if any(path.startswith(prefix) for prefix in prefixes):
                return _local(link.attrs['href'])
    return ''


def _season_number(title, url=''):
    match = re.search(u'(?:الموسم|الجزء)\\s+([^\\s]+)', title or '')
    if match:
        word = match.group(1)
        if word.isdigit():
            return int(word)
        if word in SEASON_WORDS:
            return SEASON_WORDS[word]
    match = re.search(r'-s(\d+)(?:/|$)', urlparse(url or '').path, re.I)
    return int(match.group(1)) if match else 0


def _find_series_page(session, item):
    """Locate the complete-series page for a season card when one exists."""
    title = _series_title(item.get('name', ''))
    if not title:
        return ''
    try:
        html, page_url = _get(session, _local('') + '?' + urlencode({'s': title.encode('utf-8')}))
        root = a.Document(html).root
        for card in _cards(root, item.get('section', 'all_series')):
            if '/Series/' not in urlparse(card['url']).path:
                continue
            if _series_title(card['name']).lower() == title.lower():
                return card['url']
    except Exception:
        pass
    return ''


def seasons(item):
    session = requests.Session()
    try:
        html, url = _get(session, item['url'])
        root = a.Document(html).root
        path = urlparse(url).path
        if path.startswith('/episodes/'):
            season_url = _breadcrumb(root, ('/seasons/',))
            if not season_url:
                raise RuntimeError('EgyDead did not return the episode season')
            html, url = _get(session, season_url, item['url'])
            root = a.Document(html).root
            path = urlparse(url).path
        if path.startswith('/seasons/'):
            series_url = _find_series_page(session, item)
            if series_url:
                html, url = _get(session, series_url, url)
                root = a.Document(html).root
                path = urlparse(url).path
        result = []
        if path.startswith('/Series/'):
            result = _cards(root, item['section'], 'seasons-list')
        if not result and (path.startswith('/seasons/') or path.startswith('/Series/')):
            result = [dict(item, url=url, name=item['name'])]
        for row in result:
            row.update(season=row['url'], series_title=item['name'], is_series=False)
            number = _season_number(row['name'], row['url'])
            if number:
                row['name'] = u'الموسم %d' % number
                row['season_number'] = number
            else:
                row['season_number'] = 0
        if not result:
            raise RuntimeError('EgyDead did not return seasons for this series')
        result.sort(key=lambda row: row.get('season_number') or 0)
        return result
    finally:
        session.close()


def episodes(item, page=1):
    session = requests.Session()
    try:
        html, url = _get(session, item['url'])
    finally:
        session.close()
    root = a.Document(html).root
    result, seen = [], set()
    for holder in root.find(css='EpsList'):
        for link in holder.find('a'):
            href = link.attrs.get('href', '')
            if not urlparse(href).path.startswith('/episodes/'):
                continue
            href = _local(href)
            if href in seen:
                continue
            seen.add(href)
            row = dict(item)
            label = link.text() or link.attrs.get('title') or u'حلقة'
            number = re.search(r'\d+', label)
            if not number:
                number = re.search(r'(\d+)', link.attrs.get('title', ''))
            row.update(url=href, name=u'الحلقة %d' % int(number.group()) if number else label,
                       description=link.attrs.get('title', ''),
                       episode_number=int(number.group()) if number else 0)
            result.append(row)
    result.sort(key=lambda x: x['episode_number'])
    return {'entries': result, 'page': 1, 'last_page': 1, 'total': len(result)}


def _inertia_servers(session, url, referer):
    """Expand Inertia players such as MegaMax into their public mirrors."""
    html, final_url = a._get(session, url, referer)
    scripts = a.Document(html).root.find('script')
    page = None
    for node in scripts:
        if 'data-page' in node.attrs:
            try:
                page = json.loads(node.text())
            except Exception:
                page = None
            break
    if not page or 'mirror/video' not in page.get('component', ''):
        return []
    headers = a._headers(final_url)
    headers.update({'X-Inertia': 'true', 'X-Inertia-Version': page.get('version', ''),
        'X-Inertia-Partial-Component': page['component'], 'X-Inertia-Partial-Data': 'streams',
        'X-Requested-With': 'XMLHttpRequest'})
    response = session.get(final_url, headers=headers, timeout=(8, 20))
    try:
        response.raise_for_status()
        streams = response.json().get('props', {}).get('streams', {})
    finally:
        response.close()
    if streams.get('status') != 'success':
        raise RuntimeError(streams.get('msg') or 'MegaMax video is unavailable')
    result = []
    for quality in streams.get('data', []):
        for mirror in quality.get('mirrors', []):
            link = urljoin(final_url, mirror.get('link', ''))
            if urlparse(link).scheme not in ('http', 'https'):
                continue
            result.append({'server_url': link, 'name': '%s | %s' % (mirror.get('driver', 'Player'), quality.get('label', 'Original')),
                           'quality': quality.get('label', 'Original'), 'referer': final_url})
    return result


def servers(item):
    session = requests.Session()
    try:
        url = _local(item['url'])
        if urlparse(url).path.rstrip('/').endswith('/watch'):
            detail_url, root = url, None
        else:
            html, detail_url = _get(session, url)
            root = a.Document(html).root
        watch_url = ''
        if root is not None:
            for link in root.find('a'):
                href = link.attrs.get('href', '')
                if urlparse(href).path.rstrip('/').endswith('/watch'):
                    watch_url = _local(urljoin(detail_url, href))
                    break
        if not watch_url:
            watch_url = _local(detail_url.rstrip('/') + '/watch/')
        watch_html, watch_final = _get(session, watch_url, detail_url)
        watch = a.Document(watch_html).root
        choices = []
        for holder in watch.find(css='serversList'):
            for node in holder.find('li'):
                href = node.attrs.get('data-link')
                if not href:
                    continue
                href = urljoin(watch_final, href)
                if urlparse(href).scheme not in ('http', 'https'):
                    continue
                label = node.text() or u'مشغل'
                try:
                    expanded = _inertia_servers(session, href, watch_final)
                except Exception:
                    expanded = []
                if expanded:
                    choices.extend(expanded)
                else:
                    choices.append({'name': label, 'server_url': href, 'referer': watch_final})
        if not choices:
            for frame in watch.find('iframe'):
                href = frame.attrs.get('src') or frame.attrs.get('data-src')
                if href:
                    choices.append({'name': u'المشغل الرئيسي', 'server_url': urljoin(watch_final, href), 'referer': watch_final})
        result = []
        for choice in choices:
            row = dict(item)
            row.update(choice)
            row['title'] = item.get('series_title', '') + u' - ' + item['name'] if item.get('series_title') else item['name']
            result.append(row)
        if not result:
            raise RuntimeError('EgyDead did not return any available players')
        return result
    finally:
        session.close()


def resolve(item):
    from .freeproviders import hls_variant_streams, _unpack_egybest_script
    session = requests.Session()
    try:
        media = a._resolve_page(session, item['server_url'], item['referer'])
        if not media:
            html, final_url = a._get(session, item['server_url'], item['referer'])
            html = (_unpack_egybest_script(html) or '') + '\n' + html
            html = html.replace('\\/', '/')
            # Mixdrop and Uqload use protocol-relative media links or arrays.
            for value in re.findall(r'["\']((?:https?:)?//[^"\']+\.(?:mp4|m3u8)(?:\?[^"\']*)?)["\']', html, re.I):
                media.append({'url': urljoin(final_url, value), 'referer': final_url, 'mediatype': a._media_type(value)})
        variants, seen = [], set()
        for stream in media:
            candidate = {'url': stream['url'], 'relay': True, 'mediatype': stream['mediatype'], 'subtitles': stream.get('subtitles') or [],
                'quality': stream.get('quality') or item.get('quality', 'Original'),
                'headers': {'User-Agent': a.UA, 'Referer': a._referer(stream['referer'])}}
            for variant in hls_variant_streams(candidate):
                if variant['url'] not in seen:
                    seen.add(variant['url'])
                    variants.append(variant)
        if not variants:
            raise RuntimeError('This player did not expose a supported video link. Choose another player.')
        result = dict(item)
        result.update(name=item.get('title', item['name']), streams=variants)
        return result
    finally:
        session.close()
