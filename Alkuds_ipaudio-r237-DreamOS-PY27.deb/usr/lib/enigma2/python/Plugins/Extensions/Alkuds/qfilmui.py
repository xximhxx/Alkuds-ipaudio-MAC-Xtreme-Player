# -*- coding: utf-8 -*-
from . import qfilm
from .sitecatalogueui import Alkuds_SiteCatalogue_Browser


class Alkuds_QFilm_Browser(Alkuds_SiteCatalogue_Browser):
    provider = qfilm
    site_name = u'كيو فيلم QFilm'

    def __init__(self, session, section='new', level='groups', parent=None, page=1):
        Alkuds_SiteCatalogue_Browser.__init__(self, session, section, level, parent, page)
