# -*- coding: utf-8 -*-
"""Yacine Android API bootstrap, shared by Python 2.7 and Python 3."""
from __future__ import absolute_import
import re
import time
import threading
import sys
if sys.version_info[0] == 2:
    from .py2compat import requests
else:
    import requests

API = 'https://def001.ycnapi.com/api/'
LEGACY_API = 'https://deft.yacinelive.com/api/'
_cache = {'base': API, 'until': 0}
_lock = threading.Lock()
_FETCH = ('https://firebaseremoteconfig.googleapis.com/v1/projects/'
          'ycntv-7a08e/namespaces/firebase:fetch?key='
          'AIzaSyDRKL14PPiXzk7qNUNLgV2IsjasxNpWLeU')


def api_base(configured):
    """Follow the APK's defaults key; preserve explicit custom endpoints."""
    base = (configured or API).strip().rstrip('/') + '/'
    if base not in (API, LEGACY_API):
        return base
    with _lock:
        if time.time() < _cache['until']:
            return _cache['base']
        response = None
        try:
            response = requests.post(_FETCH, json={
                'app_id': '1:692330584196:android:68ea9f0c920aa17904cad1',
                'package_name': 'ver3.ycntivi.off',
                'app_instance_id': 'x',
            }, timeout=(5, 8))
            response.raise_for_status()
            host = response.json().get('entries', {}).get('defaults', '')
            if not re.match(r'^[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}$', host):
                raise ValueError('Invalid Yacine bootstrap host')
            _cache.update(base='https://' + host + '/api/', until=time.time() + 3600)
        except Exception:
            # Last known public API, not the retired parked domain.
            _cache['until'] = time.time() + 60
        finally:
            if response is not None:
                response.close()
        return _cache['base']


def wire_headers(headers):
    """Send non-ASCII Android header values as UTF-8, without stripping them.

    Keep logical headers as Unicode everywhere else. requests/http.client
    otherwise encode them as Latin-1 and fail before sending the request.
    """
    result = {}
    for key, value in headers.items():
        if isinstance(value, bytes):
            result[key] = value
            continue
        try:
            value.encode('ascii')
        except UnicodeEncodeError:
            value = value.encode('utf-8')
        result[key] = value
    return result
