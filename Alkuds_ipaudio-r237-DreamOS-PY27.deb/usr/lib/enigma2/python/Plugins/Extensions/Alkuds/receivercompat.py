# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Receiver-specific compatibility helpers for Alkuds IPAUDIO (R31P7).

Vu+ 4K receivers use Broadcom vendor audio drivers whose DVB audio decoder is
paused together with native Timeshift. Detect Vu+ using both procfs and
Enigma2's own boxbranding/BoxInfo APIs, then select the audio-only Enigma2
handoff plus the independent ALSA renderer. The main DVB video service and
native Timeshift remain untouched; Local Remux is never selected here.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .py2compat import re

def is_dreambox_arm():
    """DM900/DM920 require the image's GStreamer audio renderer first."""
    return bool(re.search('(?<![a-z0-9])dm(?:900|920)(?![a-z0-9])', receiver_signature().lower()))
FREE_PLAYER_FILE = '/etc/enigma2/alkuds/free_player_type'

def _read_text(path):
    try:
        with open(path, 'rb') as f:
            data = f.read(2048)
        if not isinstance(data, str):
            data = data.decode('utf-8', 'ignore')
        return str(data or '').replace('\x00', ' ').strip()
    except Exception:
        return ''

def _safe_call(module_name, names):
    values = []
    try:
        mod = __import__(module_name, fromlist=list(names))
        for name in names:
            try:
                fn = getattr(mod, name, None)
                if callable(fn):
                    value = fn()
                    if value is not None and str(value).strip():
                        values.append('%s=%s' % (name, str(value).strip()))
            except Exception:
                pass
    except Exception:
        pass
    return values

def _boxinfo_values():
    values = []
    try:
        from Components.SystemInfo import BoxInfo
        for key in ('brand', 'model', 'boxtype', 'machinebuild', 'machinename', 'machinebrand', 'oem'):
            try:
                value = BoxInfo.getItem(key)
                if value is not None and str(value).strip():
                    values.append('BoxInfo.%s=%s' % (key, str(value).strip()))
            except Exception:
                pass
    except Exception:
        pass
    try:
        from Tools.HardwareInfo import HardwareInfo
        hw = HardwareInfo()
        for name in ('get_device_model', 'get_device_name', 'get_vu_device_name'):
            try:
                fn = getattr(hw, name, None)
                if callable(fn):
                    value = fn()
                    if value is not None and str(value).strip():
                        values.append('HardwareInfo.%s=%s' % (name, str(value).strip()))
            except Exception:
                pass
    except Exception:
        pass
    return values

def receiver_signature():
    values = []
    for path in ('/proc/stb/info/brand', '/proc/stb/info/model', '/proc/stb/info/boxtype', '/proc/stb/info/boxmodel', '/proc/stb/info/vumodel', '/proc/stb/info/machinebuild', '/proc/stb/info/chipset', '/proc/device-tree/model', '/sys/firmware/devicetree/base/model', '/etc/hostname'):
        value = _read_text(path)
        if value:
            values.append('%s=%s' % (path, value))
    values.extend(_safe_call('boxbranding', ('getBoxType', 'getMachineBuild', 'getMachineBrand', 'getMachineName', 'getBrandOEM', 'getMachineMake', 'getModel')))
    values.extend(_boxinfo_values())
    return ' | '.join(values)

def _normalise(value):
    return ''.join((ch for ch in str(value or '').lower() if ch.isalnum() or ch == '+'))

def is_octagon():
    """Use physical/branding identity; Egami's dm800se/vumodel are aliases."""
    signature = receiver_signature()
    for field in str(signature).split('|'):
        key, sep, value = field.strip().partition('=')
        value = _normalise(value)
        if not sep:
            continue
        if key in ('/proc/stb/info/brand', 'getMachineBrand', 'getBrandOEM', 'BoxInfo.brand', 'BoxInfo.machinebrand') and value == 'octagon':
            return True
        if key in ('/proc/stb/info/model', '/proc/stb/info/boxtype', 'getBoxType', 'getMachineBuild', 'BoxInfo.model') and value in ('sf4008', 'sf8008', 'sf8008m', 'sf8008mini', 'sf8008supreme', 'sf8008combo', 'sf8008single', 'sfx6008'):
            return True
    return False

def is_octagon_egami():
    if not is_octagon():
        return False
    image = ' '.join((_read_text(path) for path in ('/etc/image-version', '/etc/issue', '/etc/egami-version')))
    image += ' ' + ' '.join(_safe_call('boxbranding', ('getImageDistro', 'getImageVersion')))
    return 'egami' in image.lower()

def is_vuplus():
    signature = receiver_signature()
    ident = _normalise(signature)
    if not ident:
        return False
    physical = {}
    for field in str(signature).split('|'):
        key, sep, value = field.strip().partition('=')
        if sep and key.startswith('/proc/stb/info/'):
            physical[key.rsplit('/', 1)[-1]] = _normalise(value)
    octagon_models = {'sf4008', 'sf8008', 'sf8008m', 'sf8008mini', 'sf8008supreme', 'sf8008combo', 'sf8008single', 'sfx6008'}
    if physical.get('brand') == 'octagon' or any((physical.get(key) in octagon_models for key in ('model', 'boxtype', 'boxmodel'))):
        return False
    if not physical.get('vumodel') and physical.get('brand') not in ('vu+', 'vuplus', 'vu'):
        for field in str(signature).split('|'):
            key, sep, value = field.strip().partition('=')
            if sep and key in ('getMachineBrand', 'getBrandOEM', 'BoxInfo.brand', 'BoxInfo.machinebrand') and (_normalise(value) == 'octagon'):
                return False
    legacy = {'solo', 'solo2', 'solose', 'solosev2', 'uno', 'duo', 'duo2', 'ultimo', 'zero'}
    for field in str(signature).split('|'):
        key, separator, value = field.strip().partition('=')
        value = _normalise(value)
        if separator and key == '/proc/stb/info/vumodel' and (value in legacy):
            return True
        if separator and key in ('getBoxType', 'getMachineBuild', 'getMachineMake', 'BoxInfo.model', 'BoxInfo.machinebuild') and value.startswith('vu') and (value[2:] in legacy):
            return True
    markers = ('vu+', 'vuplus', 'vusolo4k', 'solo4k', 'vuuno4k', 'uno4k', 'vuuno4kse', 'uno4kse', 'vuultimo4k', 'ultimo4k', 'vuduo4k', 'duo4k', 'vuduo4kse', 'duo4kse', 'vuzero4k', 'zero4k')
    if any((_normalise(marker) in ident for marker in markers)):
        return True
    vu_brand = any((x in ident for x in ('machinebrandvu', 'brandvu', 'oemvu', 'brandvutplus', 'vuplus')))
    vu_4k_model = any((x in ident for x in ('solo4k', 'uno4k', 'ultimo4k', 'duo4k', 'zero4k')))
    return bool(vu_brand and vu_4k_model)

def needs_single_service_audio():
    """Compatibility flag for legacy/remux callers on Vu+ hardware."""
    return is_vuplus()

def preferred_local_service_type():
    """Prefer ExtePlayer3 on Vu+ when installed; otherwise native 4097."""
    if is_vuplus() and os.path.isfile('/usr/bin/exteplayer3') and os.access('/usr/bin/exteplayer3', os.X_OK):
        return 5002
    return 4097

def preferred_foreground_service_type():
    """Use ServiceApp/ExtePlayer3 for normal IPTV whenever it is installed."""
    for path in ('/usr/bin/exteplayer3', '/usr/bin/exteplayer3.sh'):
        try:
            if os.path.isfile(path) and os.access(path, os.X_OK):
                return 5002
        except Exception:
            pass
    return 4097

def available_free_service_types():
    available = []
    for kind, paths in ((5002, ('/usr/bin/exteplayer3', '/usr/bin/exteplayer3.sh')),
                        (5001, ('/usr/bin/gstplayer', '/usr/bin/gstplayer2', '/usr/bin/gstplayer_gst-1.0'))):
        if not any(os.path.isfile(path) and os.access(path, os.X_OK) for path in paths):
            continue
        try:
            from enigma import eServiceCenter, eServiceReference
            if eServiceCenter.getInstance().info(eServiceReference(kind, 0, 'http://127.0.0.1/alkuds-check.ts')) is None:
                continue
        except Exception:
            pass
        available.append(kind)
    return tuple(available + [4097])

def selected_free_service_type():
    """Persistent manual player choice for every Free Arabic TV screen."""
    try:
        with open(FREE_PLAYER_FILE, "r") as handle:
            value = int(str(handle.read() or "").strip())
        if value in available_free_service_types():
            return value
    except Exception:
        pass
    preferred = preferred_foreground_service_type()
    return preferred if preferred in available_free_service_types() else 4097

def set_selected_free_service_type(value):
    value = int(value)
    if value not in (5002, 5001, 4097):
        raise ValueError("Unsupported IPTV player")
    if value not in available_free_service_types():
        raise ValueError('The selected IPTV player is not installed or registered; restart the GUI after installation')
    folder = os.path.dirname(FREE_PLAYER_FILE)
    if not os.path.isdir(folder):
        os.makedirs(folder)
    temporary = FREE_PLAYER_FILE + ".tmp"
    with open(temporary, "w") as handle:
        handle.write(str(value))
    os.rename(temporary, FREE_PLAYER_FILE)
    return value
