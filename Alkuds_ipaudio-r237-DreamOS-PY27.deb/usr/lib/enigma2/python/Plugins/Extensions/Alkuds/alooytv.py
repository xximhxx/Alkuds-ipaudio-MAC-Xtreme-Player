# -*- coding: utf-8 -*-
"""AlooYTV catalogue (alooytvapp.com / alooytv16.com).

The public alooytvapp.com page is only an SEO landing page.  The real
catalogue lives on alooytv16.com: HTML cards, one watch page per title and
one ?key= page per episode.  The episode page exposes a plain MP4 URL on a
separate CDN; it requires a browser User-Agent and a Referer, so the player
uses the local relay with those headers.
"""
from .py2compat import re

from .py2compat import requests

try:
    from urllib.parse import urljoin, urlparse
except ImportError:
    from urlparse import urljoin, urlparse

from . import arabseed as a
from . import sitecatalogue as c

BASE = 'https://alooytv16.com/'
HOSTS = ('alooytv16.com', 'www.alooytv16.com', 'g.alooytv16.com')
SEARCH_PER_PAGE = 24
CATALOGUE_PER_PAGE = 24
GENRE_PER_PAGE = 50

# key -> (Arabic label, genre slug or 'all')
GENRES = [
    ('arabic', u'عربي', 'arabic'),
    ('kleeji', u'خليجي', 'kleeji'),
    ('turki', u'تركي', 'turki'),
    ('ramadan-arabi-2026', u'رمضان عربي 2026', 'ramadan-arabi-2026'),
    ('ramadan-kleeji-2026', u'رمضان خليجي 2026', 'ramadan-kleeji-2026'),
    ('ramadan-arabi-2025', u'رمضان عربي 2025', 'ramadan-arabi-2025'),
    ('ramadan-kleeji-2025', u'رمضان خليجي 2025', 'ramadan-kleeji-2025'),
    ('ramadan-arabi-2024', u'رمضان عربي 2024', 'ramadan-arabi-2024'),
    ('ramadan-kleeji-2024', u'رمضان خليجي 2024', 'ramadan-kleeji-2024'),
    ('ramadan-arabi', u'رمضان عربي 2023', 'ramadan-arabi'),
    ('ramadan-kleeji', u'رمضان خليجي 2023', 'ramadan-kleeji'),
    ('farisi', u'فارسي', 'farisi'),
    ('anmi', u'أنمي', 'anmi'),
    ('foreign-movies', u'أفلام أجنبية', 'foreign-movies'),
    ('Korean-movies', u'أفلام كورية', 'Korean-movies'),
    ('Foreign-series', u'مسلسلات أجنبية', 'Foreign-series'),
    ('Korean-series', u'مسلسلات كورية', 'Korean-series'),
    ('asia-series', u'مسلسلات آسيوية', 'asia-series'),
    ('arabic-movies', u'أفلام عربية', 'arabic-movies'),
    ('masrahiyat', u'مسرحيات', 'masrahiyat'),
]

SECTION_MAP = {
    'browse': (u'كل الأقسام', 'all'),
    'all': (u'كل المسلسلات والأفلام', 'all'),
    'latest': (u'أحدث الإضافات', 'all'),
}
SECTION_MAP.update((key, (name, slug)) for key, name, slug in GENRES)

_GENRE_BY_KEY = dict((key, slug) for key, _name, slug in GENRES)
_GENRE_NAMES = dict((key, name) for key, name, _slug in GENRES)


def _local(value):
    return c.local(BASE, HOSTS, value)


def _genre_slug(section):
    return _GENRE_BY_KEY.get(section)


def _page_url(section, page):
    page = max(1, int(page))
    if section in ('browse', 'all', 'latest'):
        if page == 1:
            return BASE + 'tv-series.html'
        return BASE + 'tvseries/home/%d.html' % ((page - 1) * CATALOGUE_PER_PAGE)
    slug = _genre_slug(section)
    if not slug:
        raise ValueError('قسم غير معروف: %s' % section)
    if page == 1:
        return BASE + 'genre/%s.html' % slug
    return BASE + 'genre/%s/%d.html' % (slug, (page - 1) * GENRE_PER_PAGE)


def _last_page(root, page):
    values = [max(1, int(page))]
    for node in root.find('a'):
        number = str(node.attrs.get('data-ci-pagination-page') or '').strip()
        if number.isdigit():
            values.append(int(number))
    return max(values)


def _card_rows(root, page_url, section):
    rows, seen = [], set()
    for card in root.find('div', 'latest-movie-img-container'):
        links = [node.attrs.get('href', '') for node in card.find('a')
                 if '/watch/' in node.attrs.get('href', '')]
        if not links:
            continue
        url = _local(links[0])
        if url in seen:
            continue
        seen.add(url)
        title_node = card.find('div', 'movie-title')
        title = title_node[0].text() if title_node else ''
        if not title:
            image_node = card.find('img')
            title = image_node[0].attrs.get('alt', '') if image_node else ''
        count_match = re.search(u'(\d+)\s*عدد\s*الحلقات', card.text())
        count = int(count_match.group(1)) if count_match else -1
        # A zero count means the site has no playable episode yet (the watch
        # page only contains https://vidN.0 placeholders).  Hide those cards.
        if count == 0:
            continue
        is_series = count > 1
        rows.append({
            'id': url, 'url': url, 'name': title, 'title': title,
            'is_series': is_series, 'series_key': url, 'section': section,
            'image': c.image(card, page_url), 'quality': '',
            'category': (u'مسلسل' if is_series else u'فيلم') +
                        (u' | %d حلقة' % count if count > 0 else ''),
            'search_text': card.text().lower(),
            'episode_count': count if count > 0 else 0,
        })
    return rows


def groups():
    result = [
        {'name': u'البحث في كل الأقسام', 'section': 'browse', 'action': 'search'},
        {'name': u'أحدث الإضافات', 'section': 'latest', 'node': 'items'},
        {'name': u'كل التصنيفات', 'section': 'browse', 'node': 'sections'},
    ]
    # A few shortcuts before the full list.
    for key in ('arabic', 'kleeji', 'turki', 'ramadan-arabi-2026', 'ramadan-kleeji-2026'):
        result.append({'name': _GENRE_NAMES[key], 'section': key, 'node': 'items'})
    return result


def sections(section, parent):
    result = [{'name': u'البحث في هذا القسم', 'action': 'search'}]
    if section in ('browse', 'all', 'latest'):
        result += [{'name': name, 'section': key, 'node': 'items'}
                   for key, name, _slug in GENRES]
    else:
        result += [
            {'name': u'عرض النتائج', 'node': 'items'},
            {'name': u'ترتيب العناوين أ–ي', 'node': 'items', 'order': 'az'},
            {'name': u'ترتيب العناوين ي–أ', 'node': 'items', 'order': 'za'},
        ]
    return result


def filters(section, parent):
    return []


def fetch_items(section, page=1, query='', order='latest', options=None):
    page = max(1, int(page))
    with requests.Session() as session:
        session.verify = False
        if query:
            params = {'q': query}
            if page > 1:
                params['per_page'] = (page - 1) * SEARCH_PER_PAGE
            html, final, _mime = c.get(session, BASE + 'search', BASE, params)
        else:
            html, final, _mime = c.get(session, _local(_page_url(section, page)), BASE)
    root = a.Document(html).root
    rows = _card_rows(root, final, section)
    return {'entries': rows, 'page': page, 'last_page': _last_page(root, page),
            'total': len(rows)}


def seasons(item):
    # The site lists every episode on the title page; there is no season tree.
    row = dict(item)
    row.update(name=u'كل الحلقات', season=True, season_url=item['url'],
               season_number=1, series_title=item['name'], is_series=False)
    return [row]


def _episode_number(text, fallback):
    match = re.search(r'Ep\s*#?\s*(\d+)', text or '', re.I)
    if match:
        return int(match.group(1))
    match = re.search(r'(\d+)', text or '')
    return int(match.group(1)) if match else fallback


def episodes(item, page=1):
    with requests.Session() as session:
        session.verify = False
        html, final, _mime = c.get(session, item['season_url'], BASE)
    root = a.Document(html).root
    rows, seen = [], set()
    for node in root.find('a'):
        href = node.attrs.get('href', '')
        if '/watch/' not in href or 'key=' not in href:
            continue
        url = _local(href)
        if url in seen:
            continue
        seen.add(url)
        number = _episode_number(node.text(), len(rows) + 1)
        series_title = item.get('series_title') or item.get('name') or u''
        label = u'%s — الحلقة %d' % (series_title, number) if series_title else u'الحلقة %d' % number
        row = dict(item)
        row.update(name=label, episode=number, url=url, title=label,
                   quality='', category='', is_series=False, season=False,
                   episode_query=False)
        rows.append(row)
    rows.sort(key=lambda value: value['episode'])
    if not rows:
        raise RuntimeError(u'الموقع لم يعرض حلقات هذا المسلسل حالياً.')
    return {'entries': rows, 'page': 1, 'last_page': 1, 'total': len(rows)}


def _first_key(root):
    for node in root.find('a'):
        href = node.attrs.get('href', '')
        if '/watch/' in href and 'key=' in href:
            return _local(href)
    return ''


def _media_url(value):
    value = str(value or '').strip()
    if not value:
        return ''
    url = urljoin(BASE, value)
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https'):
        return ''
    host = parsed.hostname or ''
    if not host or '.' not in host:
        return ''
    # The site uses https://vid1.0 as a placeholder when no key is supplied.
    if re.match(r'^vid\d+\.0$', host, re.I):
        return ''
    return url


def servers(item):
    page_url = item['url']
    with requests.Session() as session:
        session.verify = False
        html, final, _mime = c.get(session, page_url, BASE)
        root = a.Document(html).root
        # An episode row already points at its own ?key= page.  Only a plain
        # title page needs the first episode key; never replace a selected
        # episode with the first one in the page's episode list.
        if 'key=' not in page_url:
            key_url = _first_key(root)
            if key_url and key_url != final:
                html, final, _mime = c.get(session, key_url, final)
                root = a.Document(html).root
    values, seen = [], set()
    for node in root.find('source') + root.find('video'):
        url = _media_url(node.attrs.get('src', ''))
        if not url or url in seen:
            continue
        seen.add(url)
        quality = '1080p' if '1080' in url else ('720p' if '720' in url else 'MP4')
        values.append((u'مشاهدة مباشرة', url, quality))
    if not values:
        raise RuntimeError(u'هذا العنوان لا يعرض رابط فيديو مباشراً حالياً.')
    return c.server_rows(values, item, final)


def resolve(item):
    result = c.resolve(item)
    for stream in result.get('streams') or []:
        url = str(stream.get('url') or '').lower().split('?', 1)[0]
        if stream.get('mediatype') == 'mp4' or url.endswith('.mp4'):
            options = dict(stream.get('relay_options') or {})
            options['media_type'] = 'mp4'
            stream['relay_options'] = options
            stream.setdefault('quality', 'MP4')
    return result
