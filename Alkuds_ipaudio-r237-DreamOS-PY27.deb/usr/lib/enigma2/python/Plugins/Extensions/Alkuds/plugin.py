# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .py2compat import shutil
import sys
from .py2compat import time
import glob as glob_module
import twisted.python.runtime
from . import _
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigDirectory, ConfigYesNo, ConfigSelectionNumber, ConfigClock, ConfigPIN, ConfigInteger, configfile, ConfigText
from enigma import eTimer, getDesktop, addFont
from Plugins.Plugin import PluginDescriptor
from os.path import isdir
pythonFull = (sys.version_info.major, sys.version_info.minor)
pythonVer = sys.version_info.major
isDreambox = os.path.exists('/usr/bin/apt-get')
debugs = False
try:
    from multiprocessing.pool import ThreadPool
    hasMultiprocessing = True
except ImportError:
    hasMultiprocessing = False
try:
    from .py2compat import futures
    ThreadPoolExecutor = futures.ThreadPoolExecutor
    if twisted.python.runtime.platform.supportsThreads():
        hasConcurrent = True
    else:
        hasConcurrent = False
except ImportError:
    hasConcurrent = False
dir_etc = '/etc/enigma2/alkuds/'
dir_tmp = '/etc/enigma2/alkuds/tmp/'
dir_plugins = '/usr/lib/enigma2/python/Plugins/Extensions/Alkuds/'
dir_videos = '/usr/lib/enigma2/python/Plugins/Extensions/Alkuds/video/'
version = ''
try:
    with open(os.path.join(dir_plugins, 'version.txt'), 'r') as f:
        version = f.readline().strip()
except:
    version = ''
screenwidth = getDesktop(0).size()
if screenwidth.width() == 2560:
    skin_directory = os.path.join(dir_plugins, 'skin/uhd/')
elif screenwidth.width() > 1280:
    skin_directory = os.path.join(dir_plugins, 'skin/fhd/')
else:
    skin_directory = os.path.join(dir_plugins, 'skin/hd/')
try:
    folders = [x for x in os.listdir(skin_directory) if x != 'common']
except:
    folders = ['default']
try:
    files = os.listdir(dir_videos)
except OSError:
    files = []
video_extensions = ('.mp4', '.avi', '.mkv')
video_files = [file for file in files if file.endswith(video_extensions)]
video_list = [(os.path.join(dir_videos, file), file) for file in video_files]
languages = [('', 'English'), ('de-DE', 'Deutsch'), ('es-ES', u'Espaأ±ol'), ('fr-FR', u'Franأ§ais'), ('it-IT', 'Italiano'), ('nl-NL', 'Nederlands'), ('tr-TR', u'Tأ¼rkأ§e'), ('cs-CZ', u'ؤŒeskأ½'), ('da-DK', 'Dansk'), ('hr-HR', 'Hrvatski'), ('hu-HU', 'Magyar'), ('no-NO', 'Norsk'), ('pl-PL', 'Polski'), ('pt-PT', u'Portuguأھs'), ('ro-RO', u'Romأ¢nؤƒ'), ('ru-RU', u'Pرƒرپرپذ؛ذ¸ذ¹'), ('sh-SH', 'Srpski'), ('sk-SK', u'Slovenؤچina'), ('fi-FI', 'suomi'), ('sv-SE', 'svenska'), ('uk-UA', u'ذ£ذ؛ر€ذ°ر—ذ½رپرŒذ؛ذ¸ذ¹'), ('ar-SA', u'ط§ظ„ط¹ط±ط¨ظٹط©'), ('bg-BG', u'ذ±رٹذ»ذ³ذ°ر€رپذ؛ذ¸ ذµذ·ذ¸ذ؛'), ('el-GR', u'خµخ»خ»خ·خ½خ¹خ؛خ¬'), ('sq-AL', 'shqip'), ('zh-CN', u'ن¸\xadو–‡')]
useragents = [('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 'Chrome 145 - Windows'), ('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', 'Firefox 147'), ('Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36', 'Android')]
config.plugins.Alkuds = ConfigSubsection()
cfg = config.plugins.Alkuds
live_streamtype_choices = [('1', 'DVB(1)'), ('4097', 'IPTV(4097)')]
vod_streamtype_choices = [('4097', 'IPTV(4097)')]
if os.path.exists('/usr/bin/gstplayer'):
    live_streamtype_choices.append(('5001', 'GStreamer(5001)'))
    vod_streamtype_choices.append(('5001', 'GStreamer(5001)'))
if os.path.exists('/usr/bin/exteplayer3'):
    live_streamtype_choices.append(('5002', 'ExtePlayer(5002)'))
    vod_streamtype_choices.append(('5002', 'ExtePlayer(5002)'))
if isDreambox:
    live_streamtype_choices.append(('8193', 'DreamOS GStreamer(8193)'))
    vod_streamtype_choices.append(('8193', 'DreamOS GStreamer(8193)'))
default_streamtype = '5002' if any((x[0] == '5002' for x in live_streamtype_choices)) else '4097'
default_vodtype = '5002' if any((x[0] == '5002' for x in vod_streamtype_choices)) else '4097'
cfg.livetype = ConfigSelection(default=default_streamtype, choices=live_streamtype_choices)
cfg.vodtype = ConfigSelection(default=default_vodtype, choices=vod_streamtype_choices)
cfg.ar_id_player = ConfigSelection(default='6', choices=[('0', _('4:3 Letterbox')), ('1', _('4:3 PanScan')), ('2', _('16:9')), ('3', _('16:9 Always')), ('4', _('16:10 Letterbox')), ('5', _('16:10 PanScan')), ('6', _('16:9 Letterbox'))])
result = cfg.downloadlocation.value if hasattr(cfg, 'downloadlocation') else ''
if not result:
    try:
        if isdir('/media/hdd/movie/'):
            result = '/media/hdd/movie/'
        elif isdir('/media/usb/movie/'):
            result = '/media/usb/movie/'
        elif config.usage.instantrec_path.value:
            result = config.usage.instantrec_path.value
        elif config.movielist.last_videodir.value:
            result = config.movielist.last_videodir.value
        else:
            result = '/media/'
    except Exception as e:
        print(e)
        result = '/media/'
cfg.downloadlocation = ConfigDirectory(default=result)
epg_base = '/etc/enigma2/'
try:
    if hasattr(config, 'misc') and hasattr(config.misc, 'epgcachepath'):
        epgcachepath = config.misc.epgcachepath.value
        if epgcachepath:
            epg_base = epgcachepath
except:
    pass
cfg.epglocation = ConfigDirectory(default=epg_base)
cfg.location = ConfigDirectory(default=dir_etc)
cfg.main = ConfigYesNo(default=True)
cfg.livepreview = ConfigYesNo(default=False)
cfg.freepreview = ConfigYesNo(default=True)
cfg.stopstream = ConfigYesNo(default=False)
cfg.skin = ConfigSelection(default='violet' if 'violet' in folders else 'alkuds', choices=folders)
try:
    _theme_marker = os.path.join(dir_etc, '.theme_violet')
    if 'violet' in folders and (not os.path.exists(_theme_marker)):
        if cfg.skin.value != 'violet':
            cfg.skin.value = 'violet'
            cfg.skin.save()
            try:
                from Components.config import configfile
                configfile.save()
            except Exception:
                pass
        open(_theme_marker, 'w').close()
except Exception:
    pass
cfg.timeout = ConfigSelectionNumber(1, 20, 1, default=20, wraparound=True)
cfg.TMDB = ConfigYesNo(default=False)
cfg.TMDBLanguage2 = ConfigSelection(default='', choices=languages)
cfg.catchupstart = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
cfg.catchupend = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
cfg.subs = ConfigYesNo(default=False)
cfg.wakeup = ConfigClock(default=(9 * 60 + 30) * 60)
cfg.adult = ConfigYesNo(default=False)
cfg.adultpin = ConfigPIN(default=0)
cfg.retries = ConfigSubsection()
cfg.retries.adultpin = ConfigSubsection()
cfg.retries.adultpin.tries = ConfigInteger(default=3)
cfg.retries.adultpin.time = ConfigInteger(default=3)
cfg.location_valid = ConfigYesNo(default=True)
cfg.channelpicons = ConfigYesNo(default=False)
cfg.infobarpicons = ConfigYesNo(default=False)
cfg.channelcovers = ConfigYesNo(default=False)
cfg.yacine_api = ConfigText(default='https://def001.ycnapi.com/api/', fixed_size=False)
cfg.yacine_useragent = ConfigText(default='', fixed_size=False)
cfg.infobarcovers = ConfigYesNo(default=False)
cfg.introvideo = ConfigYesNo(default=False)
cfg.introloop = ConfigYesNo(default=False)
cfg.introvideoselection = ConfigSelection(choices=video_list or [('', '-')])
cfg.speedtest = ConfigYesNo(default=False)
cfg.startmenuplaylists = ConfigYesNo(default=True)
cfg.manageplaylists = ConfigYesNo(default=True)
cfg.sidemenumanageplaylists = ConfigYesNo(default=True)
cfg.sidemenuaccountinfo = ConfigYesNo(default=True)
cfg.boot = ConfigYesNo(default=False)
cfg.useragent = ConfigSelection(default='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', choices=useragents)
cfg.lastplaylist = ConfigText()
cfg.remuxquickreturn = ConfigYesNo(default=True)
cfg.remuxvideohold = ConfigYesNo(default=True)
cfg.remuxvideoholddelay = ConfigSelectionNumber(1, 10, 1, default=2, wraparound=True)
cfg.ipaudiodelayms = ConfigSelectionNumber(0, 120000, 250, default=0, wraparound=False)
cfg.ipaudiovideodelayms = ConfigInteger(default=4500, limits=(0, 120000))
cfg.vodcategoryorder = ConfigSelection(default=_('Sort: Original'), choices=[(_('Sort: A-Z'), 'A-Z'), (_('Sort: Z-A'), 'Z-A'), (_('Sort: Original'), _('Original'))])
cfg.vodstreamorder = ConfigSelection(default=_('Sort: Original'), choices=[(_('Sort: A-Z'), 'A-Z'), (_('Sort: Z-A'), 'Z-A'), (_('Sort: Added'), _('Added')), (_('Sort: Year'), _('Year')), (_('Sort: Original'), _('Original'))])
cfg.seriescategoryorder = ConfigSelection(default=_('Sort: Original'), choices=[(_('Sort: A-Z'), 'A-Z'), (_('Sort: Z-A'), 'Z-A'), (_('Sort: Original'), _('Original'))])
cfg.seriesorder = ConfigSelection(default=_('Sort: Original'), choices=[(_('Sort: A-Z'), 'A-Z'), (_('Sort: Z-A'), 'Z-A'), (_('Sort: Added'), _('Added')), (_('Sort: Year'), _('Year')), (_('Sort: Original'), _('Original'))])
playlist_file = os.path.join(dir_etc, 'playlists.txt')
playlists_json = os.path.join(dir_etc, 'x-playlists.json')
downloads_json = os.path.join(dir_etc, 'downloads2.json')
skin_path = os.path.join(skin_directory, cfg.skin.value)
common_path = os.path.join(skin_directory, 'common/')
location = cfg.location.value
if location:
    if os.path.exists(location):
        playlist_file = os.path.join(cfg.location.value, 'playlists.txt')
        cfg.location_valid.setValue(True)
    else:
        os.makedirs(location)
        playlist_file = os.path.join(location, 'playlists.txt')
        cfg.location_valid.setValue(True)
else:
    cfg.location.setValue(dir_etc)
    cfg.location_valid.setValue(False)
cfg.playlist_file = ConfigText(playlist_file)
cfg.playlists_json = ConfigText(playlists_json)
cfg.downloads_json = ConfigText(downloads_json)
cfg.save()
configfile.save()
if os.path.isdir('/usr/lib/enigma2/python/Plugins/Extensions/InternetSpeedTest'):
    InternetSpeedTest_installed = True
else:
    InternetSpeedTest_installed = False
if os.path.isdir('/usr/lib/enigma2/python/Plugins/Extensions/NetSpeedTest'):
    NetSpeedTest_installed = True
else:
    NetSpeedTest_installed = False
if not os.path.exists(dir_etc):
    os.makedirs(dir_etc)
if not os.path.exists(dir_tmp):
    os.makedirs(dir_tmp)
if not os.path.isfile(cfg.playlist_file.value):
    with open(cfg.playlist_file.value, 'a') as f:
        f.close()
if not os.path.isfile(cfg.playlists_json.value):
    with open(cfg.playlists_json.value, 'a') as f:
        f.close()
if not os.path.isfile(cfg.downloads_json.value):
    with open(cfg.downloads_json.value, 'a') as f:
        f.close()
font_folder = os.path.join(dir_plugins, 'fonts/')
for font, name in [('AlkudsUnicode.ttf', 'AlkudsUnicode'), ('AlkudsUnicode.ttf', 'alkudsregular'), ('AlkudsUnicode.ttf', 'alkudsbold'), ('AlkudsUnicode.ttf', 'slykregular'), ('AlkudsUnicode.ttf', 'slykbold'), ('classfont2.ttf', 'klass')]:
    try:
        addFont(os.path.join(font_folder, font), name, 100, 0)
    except:
        pass
hdr = {'User-Agent': str(cfg.useragent.value)}
_menu_housekeeping_done = False

def _module_loaded(name):
    """True when a sibling module was already imported in this process.

    backgroundaudio/remux keep their state only in memory, so a module that has
    not been imported cannot have anything running. Checking sys.modules avoids
    importing ~6000 lines just to learn that nothing is active.
    """
    return __name__.rpartition('.')[0] + '.' + name in sys.modules

def _ipaudio_menu_closed(session, result=None):
    if result == 'ipaudio-started':
        from .videodelay import request_panel_after_audio_start
        request_panel_after_audio_start(session)

def main(session, **kwargs):
    try:
        from .remote_backup import flush_pending_async
        flush_pending_async()
    except Exception:
        pass
    try:
        if _module_loaded('backgroundaudio'):
            from .backgroundaudio import background_audio_status, get_resume_context
            active, _name, _backend = background_audio_status()
            context = get_resume_context() if active else {}
            if active and context and context.get('channels'):
                from . import audioquickreturn
                session.openWithCallback(lambda result=None: _ipaudio_menu_closed(session, result), audioquickreturn.Alkuds_Audio_QuickReturn)
                return
    except Exception as e:
        print('[Alkuds R26] IPAUDIO quick return:', e)
    try:
        if cfg.remuxquickreturn.value and _module_loaded('remux'):
            from .remux import is_local_remux_active, get_resume_context
            context = get_resume_context() if is_local_remux_active() else {}
            if context and context.get('channels'):
                from . import remuxreturn
                session.open(remuxreturn.Alkuds_Remux_Return)
                return
    except Exception as e:
        print('[Alkuds Lite16] smart return:', e)
    global _menu_housekeeping_done
    if not _menu_housekeeping_done:
        if not os.path.isdir(dir_tmp):
            os.makedirs(dir_tmp)
        _menu_housekeeping_done = True
    elif not os.path.isdir(dir_tmp):
        os.makedirs(dir_tmp)
    from . import startmenu
    session.openWithCallback(lambda result=None: _ipaudio_menu_closed(session, result), startmenu.Alkuds_MainMenu)

def mainmenu(menu_id, **kwargs):
    if menu_id == 'mainmenu':
        return [(_('Alkuds ipaudio'), main, 'Alkuds', 0)]
    return []

class XCAutoStartTimer(object):

    def __init__(self, session):
        self.session = session
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.onTimer)
        except:
            self.timer.callback.append(self.onTimer)
        self.update()

    def getWakeTime(self):
        clock = cfg.wakeup.value
        nowt = time.time()
        now = time.localtime(nowt)
        return int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, clock[0], clock[1], 0, now.tm_wday, now.tm_yday, now.tm_isdst)))

    def update(self, atLeast=0):
        self.timer.stop()
        wake = self.getWakeTime()
        now = int(time.time())
        if wake < now + atLeast:
            wake += 86400
        self.timer.startLongTimer(max(60, min(3600, wake - now)))

    def onTimer(self):
        self.timer.stop()
        now = int(time.time())
        wake = self.getWakeTime()
        atLeast = 0
        if abs(wake - now) < 60:
            self.runUpdate()
            atLeast = 60
        self.update(atLeast)

    def runUpdate(self):
        print('\n *********** Updating Alkuds EPG ************ \n')
        from . import update
        update.Alkuds_Update(self.session)
xcAutoStartTimer = None

def autostart(reason, session=None, **kwargs):
    global xcAutoStartTimer
    if reason == 0 and session:

        def start_web():
            try:
                from .audio_web import start
                start()
            except Exception:
                pass
        from .py2compat import threading
        threading.Thread(target=start_web, name='AlkudsWebStart', daemon=True).start()
    if reason == 0 and session and (xcAutoStartTimer is None):
        xcAutoStartTimer = XCAutoStartTimer(session)
    elif reason == 1:
        try:
            from .audio_web import stop
            stop()
            from .remote_backup import shutdown as stop_backups
            stop_backups()
        except Exception:
            pass
        try:
            from .flashbackpvr import shutdown
            shutdown()
        except Exception:
            pass
        try:
            from .backgroundaudio import stop_background_audio
            stop_background_audio()
        except Exception:
            pass
        try:
            from .remux import stop_local_remux
            stop_local_remux(restore=False)
        except Exception:
            pass

def stop_bg_audio_menu(session, **kwargs):
    try:
        from .backgroundaudio import stop_background_audio, background_audio_status
        active, name, backend = background_audio_status()
        if active:
            stop_background_audio()
            text = _('Alkuds background audio stopped: %s') % name
        else:
            text = _('Alkuds background audio is not running.')
    except Exception as e:
        text = _('Unable to control Alkuds background audio: %s') % str(e)
    from .xStaticText import MessageBox
    session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=5)

def stop_ipaudio_timeshift_menu(session, **kwargs):
    try:
        from .backgroundaudio import stop_ipaudio_and_timeshift
        had_audio, stopped_timeshift, _closed = stop_ipaudio_and_timeshift(session=session, close_plugin=False)
        if had_audio or stopped_timeshift:
            text = _('Alkuds ipaudio audio and native Timeshift stopped. Satellite audio restored.')
        else:
            text = _('Alkuds ipaudio audio / Timeshift is not running.')
    except Exception as e:
        text = _('Unable to stop Alkuds ipaudio / Timeshift: %s') % str(e)
    from .xStaticText import MessageBox
    session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=5)

def stop_local_remux_menu(session, **kwargs):
    try:
        from .remux import stop_local_remux, local_remux_status
        active, name, backend = local_remux_status()
        if active:
            stop_local_remux(restore=True)
            text = _('Alkuds Local Remux stopped. Satellite service restored.')
        else:
            text = _('Alkuds Local Remux is not running.')
    except Exception as e:
        text = _('Unable to control Alkuds Local Remux: %s') % str(e)
    from .xStaticText import MessageBox
    session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=5)
glb_session = None
glb_startDelay = None

class StartDelay(object):

    def __init__(self):
        self.timerboot = eTimer()

    def start(self):
        delay = 2000
        try:
            self.timer_conn = self.timerboot.timeout.connect(self.query)
        except:
            self.timerboot.callback.append(self.query)
        self.timerboot.start(delay, True)

    def query(self):
        from . import startmenu
        glb_session.openWithCallback(lambda result=None: _ipaudio_menu_closed(glb_session, result), startmenu.Alkuds_MainMenu)
        return

def bootstart(reason, **kwargs):
    print('*** bootstart ***')
    global glb_session
    global glb_startDelay
    if reason == 0 and 'session' in kwargs:
        glb_session = kwargs['session']
        glb_startDelay = StartDelay()
        glb_startDelay.start()

def Plugins(**kwargs):
    iconFile = 'icons/plugin-icon_sd.png'
    if screenwidth.width() > 1280:
        iconFile = 'icons/plugin-icon.png'
    description = _('MAC & XTREME player')
    pluginname = _('Alkuds ipaudio')
    main_menu = PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_MENU, fnc=mainmenu, needsRestart=True)
    extensions_menu = PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main, needsRestart=True)
    boot_start = PluginDescriptor(name=pluginname, description=description, where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=bootstart, needsRestart=True)
    result = [PluginDescriptor(name=pluginname, description=description, where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart), PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_PLUGINMENU, icon=iconFile, fnc=main)]
    result.append(extensions_menu)
    result.append(PluginDescriptor(name=_('Alkuds ipaudio - STOP Audio + Timeshift'), description=_('Stop Alkuds ipaudio audio/timeshift and restore satellite'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=stop_ipaudio_timeshift_menu, needsRestart=False))
    if cfg.main.value:
        result.append(main_menu)
    if cfg.boot.value:
        result.append(boot_start)
    return result
