# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Sportacity's public fixture cards and ordinary Soccer Live Player streams."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
from .py2compat import json
from .py2compat import re
from .providerhtml import HTMLParser
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlparse = urllib.parse.urlparse
from .livehd import _get_html, _iframe_urls, _media_urls
BASE = 'https://sportacity.com/'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
SECTION_MAP = {'matches': (u'جدول المباريات', '')}

class _Node(object):

    def __init__(self, tag='', attrs=()):
        self.tag, self.attrs, self.children = (tag, dict(attrs), [])

    def walk(self):
        yield self
        for child in self.children:
            if isinstance(child, _Node):
                for node in child.walk():
                    yield node

    def text(self):
        if self.tag in ('script', 'style'):
            return ''
        return ' '.join((c.text() if isinstance(c, _Node) else c for c in self.children))

    def has(self, name):
        return name in self.attrs.get('class', '').split()

class _Document(HTMLParser):

    def __init__(self, html):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.root = _Node()
        self.stack = [self.root]
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        node = _Node(tag, attrs)
        self.stack[-1].children.append(node)
        if tag not in ('area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'):
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if self.stack[-1].tag == tag:
            self.stack.pop()

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                del self.stack[index:]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)

def _text(node):
    return ' '.join(node.text().split())

def parse_matches(html, day, final_url=BASE):
    entries, seen = ([], set())
    for card in _Document(html).root.walk():
        if not card.has('mc'):
            continue
        nodes = list(card.walk())
        teams = [_text(n) for n in nodes if n.has('mt-name')]
        if len(teams) != 2:
            continue
        identity = card.attrs.get('id') or '|'.join(teams + [card.attrs.get('data-start', '')])
        if identity in seen:
            continue
        seen.add(identity)
        score = [_text(n) for n in nodes if n.has('ms-score')]
        state = card.attrs.get('data-status-initial', '')
        status = next((_text(n) for n in nodes if n.has('ms-badge')), '')
        when = card.attrs.get('data-naive', '')
        kickoff = when[11:16] if len(when) >= 16 else next((_text(n) for n in nodes if n.has('mt-kick')), '')
        details = [_text(n) for n in nodes if n.has('font-medium') and n.has('break-words')]
        channel, commentator, league = (details + ['', '', ''])[:3]
        link = next((n.attrs.get('href', '') for n in nodes if n.tag == 'a' and n.attrs.get('aria-label')), '')
        link = urljoin(final_url, link) if link else ''
        parsed = urlparse(link)
        if parsed.scheme not in ('http', 'https') or (parsed.netloc == urlparse(BASE).netloc and parsed.path in ('', '/')):
            link = ''
        result = ' - '.join(score) if len(score) == 2 and state != 'not_started' else u'ضد'
        name = u'%s | %s %s %s | %s' % (kickoff or '--:--', teams[0], result, teams[1], status)
        description = u' | '.join((x for x in (when[:10], kickoff + u' بتوقيت القاهرة' if kickoff else '', status, channel, commentator, league) if x))
        image = next((n.attrs.get('data-src') or n.attrs.get('src', '') for n in nodes if n.tag == 'img'), '')
        entries.append(dict(id=day + ':' + identity, name=name, title=name, day=day, home=teams[0], away=teams[1], score=result, status=status, state=state, time=kickoff, when=when, channel=channel, league=league, description=description, category=channel or league, image=image, url=link, action='play', source='sportacity', is_live=True))
    return entries

def groups():
    return [{'name': label, 'title': label, 'day': day, 'section': 'matches'} for day, label in [('today', u'مباريات اليوم'), ('yesterday', u'مباريات الأمس'), ('tomorrow', u'مباريات الغد')]]

def refresh():
    pass

def fetch_day(day):
    if day not in ('yesterday', 'today', 'tomorrow'):
        raise RuntimeError(u'جدول مباريات غير صحيح.')
    html, final = _get_html(urljoin(BASE, 'matches-' + day + '/'), UA, BASE)
    entries = parse_matches(html, day, final)
    if not entries and re.search('cf-chl-|challenge-platform', html, re.I):
        raise RuntimeError(u'الموقع يطلب تحقق متصفح؛ لم يتم تحميل الجدول.')
    return entries

def page(parent, number):
    entries = fetch_day(parent.get('day', 'today'))
    start = (max(1, int(number)) - 1) * 24
    return {'entries': entries[start:start + 24], 'last_page': max(1, (len(entries) + 23) // 24)}

def player_config(html):
    match = re.search('SoccerLivePlayer\\s*=\\s*JSON\\.parse\\(\\s*atob\\(\\s*["\\\']([A-Za-z0-9+/=]+)["\\\']\\s*\\)\\s*\\)', html)
    if not match:
        return {}
    value = json.loads(base64.b64decode(match.group(1)).decode('utf-8'))
    return value if isinstance(value, dict) else {}

def _players(url, referer, visited=None, depth=0):
    visited = set() if visited is None else visited
    if depth > 4 or url in visited:
        return []
    visited.add(url)
    html, final = _get_html(url, UA, referer)
    config = player_config(html)
    streams = []
    for index, server in enumerate(config.get('servers') or []):
        if not isinstance(server, dict):
            continue
        if server.get('clappr_license_key') or server.get('clappr_license_type'):
            continue
        target = urljoin(final, str(server.get('code_url') or ''))
        if server.get('source_mode') == 'api' and server.get('code_url'):
            try:
                body, api_final = _get_html(target, UA, final)
                value = json.loads(body)
                for key in str(server.get('api_json_key') or '').split('.'):
                    if key:
                        value = value.get(key) if isinstance(value, dict) else None
                target = urljoin(api_final, value) if isinstance(value, str) and value else ''
            except Exception:
                continue
        elif server.get('source_mode', 'direct') != 'direct':
            continue
        if server.get('type') == 'iframe_url':
            try:
                streams.extend(_players(target, final, visited, depth + 1))
            except Exception:
                pass
            continue
        if server.get('code_url') and urlparse(target).scheme in ('http', 'https'):
            streams.append(dict(url=target, name=server.get('name') or u'سيرفر %d' % (index + 1), quality=server.get('quality') or 'Auto', mediatype='hls' if server.get('clappr_protocol') == 'hls' else 'direct', headers={'User-Agent': UA, 'Referer': final}, relay=True, relay_options={'live': True, 'livehd': True}, source='sportacity'))
    for target in _media_urls(html, final):
        if target not in [s['url'] for s in streams]:
            streams.append(dict(url=target, name=u'سيرفر %d' % (len(streams) + 1), quality='Auto', headers={'User-Agent': UA, 'Referer': final}, mediatype='hls', relay=True, relay_options={'live': True, 'livehd': True}, source='sportacity'))
    if not streams:
        for target in _iframe_urls(html, final)[:16]:
            try:
                streams.extend(_players(target, final, visited, depth + 1))
            except Exception:
                continue
    return streams

def resolve(item):
    if not item.get('url'):
        raise RuntimeError(u'هذه المباراة للجدول والنتيجة فقط؛ الموقع لا يوفر لها بثاً حالياً.')
    from .plasmatv import _hls_qualities
    from .py2compat import requests
    variants, seen = ([], set())
    for stream in _players(item['url'], BASE):
        if stream['url'] in seen:
            continue
        seen.add(stream['url'])
        try:
            with requests.get(stream['url'], headers=stream['headers'], timeout=(7, 18), stream=True) as response:
                response.raise_for_status()
                chunks, total = ([], 0)
                for chunk in response.iter_content(16384):
                    chunks.append(chunk)
                    total += len(chunk)
                    if total >= 65536:
                        break
                raw = b''.join(chunks)
                stream['url'] = response.url
            if raw.lstrip().startswith(b'#EXTM3U'):
                text = raw.decode('utf-8-sig', 'replace')
                if 'SAMPLE-AES' in text or re.search('KEYFORMAT="(?!identity")', text):
                    continue
                stream['mediatype'] = 'hls'
                variants.extend(_hls_qualities(text, stream))
            elif raw[:1] == b'G':
                variants.append(dict(stream, mediatype='ts', relay=False))
        except Exception:
            continue
    if not variants:
        raise RuntimeError(u'البث غير متاح الآن؛ حدّث الجدول أو جرّب مباراة أخرى.')
    return dict(item, url=variants[0]['url'], streams=variants, variants=variants)
