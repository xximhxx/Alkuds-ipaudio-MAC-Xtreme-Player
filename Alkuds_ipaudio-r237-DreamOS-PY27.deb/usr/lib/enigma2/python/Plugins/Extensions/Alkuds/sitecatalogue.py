# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Shared helpers used only by the MySeed and Zaflam integrations."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .py2compat import requests
try:
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
    parse_qs = urllib.parse.parse_qs
    urlencode = urllib.parse.urlencode
    unquote = urllib.parse.unquote
    from .py2compat import html
    unescape = html.unescape
except ImportError:
    from urlparse import urljoin, urlparse, parse_qs
    from urllib import urlencode, unquote
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape
from . import arabseed as a
from .cataloguepages import CataloguePages

class SitePages(CataloguePages):

    def _key(self, item):
        return ('series', item['series_key']) if item.get('is_series') and item.get('series_key') else ('item', item.get('url') or item.get('id'))

def local(base, hosts, value):
    url = urljoin(base, value)
    p = urlparse(url)
    if p.scheme not in ('http', 'https') or p.hostname not in hosts:
        raise ValueError('Unexpected catalogue address')
    return requests.utils.requote_uri(url)

def headers(referer):
    return {'User-Agent': a.UA, 'Referer': a._referer(referer), 'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8'}

def get(session, url, referer, params=None):
    response = session.get(requests.utils.requote_uri(url), params=params, headers=headers(referer), timeout=(5, 18), stream=True)
    try:
        response.raise_for_status()
        mime = response.headers.get('Content-Type', '').lower()
        if mime.startswith(('video/', 'audio/')) and 'mpegurl' not in mime:
            return ('', response.url, mime)
        raw = bytearray()
        for chunk in response.iter_content(32768):
            raw.extend(chunk)
            if len(raw) > 4 * 1024 * 1024:
                raise RuntimeError('Catalogue/player page too large')
        try:
            html = bytes(raw).decode('utf-8-sig')
        except UnicodeDecodeError:
            html = bytes(raw).decode('cp1256', 'replace')
        if 'cf-chl-' in html or 'cf-chl-widget' in html:
            raise RuntimeError(u'المصدر يطلب تحقق المتصفح. جرّب مصدراً آخر أو أعد المحاولة لاحقاً.')
        return (html, response.url, mime)
    finally:
        response.close()

def text(node, css):
    found = node.find(css=css)
    return found[0].text() if found else ''

def image(node, page):
    found = node.find('img')
    return urljoin(page, found[0].attrs.get('data-src') or found[0].attrs.get('src') or '') if found else ''

def page_url(url, number, wordpress=False):
    number = max(1, int(number))
    p = urlparse(url)
    if wordpress:
        path = re.sub('/page/\\d+/?$', '/', p.path).rstrip('/')
        return '%s://%s%s%s%s' % (p.scheme, p.netloc, path, '/page/%d/' % number if number > 1 else '/', '?' + p.query if p.query else '')
    values = parse_qs(p.query)
    values['page'] = [str(number)]
    return '%s://%s%s?%s' % (p.scheme, p.netloc, p.path, urlencode([(k, v) for k, vs in values.items() for v in vs]))

def last_page(root, page):
    values = [int(page)]
    for link in root.find('a'):
        url = link.attrs.get('href', '')
        m = re.search('/page/(\\d+)/?', url)
        n = parse_qs(urlparse(url).query).get('page', [''])[0]
        if m:
            values.append(int(m.group(1)))
        elif n.isdigit():
            values.append(int(n))
    return max(values)

def series_name(title):
    return re.compile(u'\\s*(?:الموسم|موسم|الحلقة|حلقة|الجزء|Season|Episode)\\s*', re.I).split(title, 1)[0].strip()

def server_rows(values, item, page):
    result, seen = ([], set())
    for label, url, quality in values:
        url = urljoin(page, unescape(url))
        if urlparse(url).scheme not in ('http', 'https') or url in seen:
            continue
        seen.add(url)
        row = dict(item)
        row.pop('node', None)
        row.pop('action', None)
        browser_hint = u' (قد يحتاج متصفحاً)' if c_browser_player(url) else ''
        row.update(name=(label or u'مشغل') + (u' | ' + quality if quality else '') + browser_hint, title=item.get('title') or item['name'], server_url=url, referer=page)
        result.append(row)
    if not result:
        raise RuntimeError(u'المصدر لم يعرض أي سيرفر مشاهدة لهذا المحتوى.')
    return result

def c_browser_player(url):
    host = urlparse(url).hostname or ''
    return host.endswith('.embedseek.com') or host.endswith('.4meplayer.com')

def literal_expression(expression):
    """Parse only quoted strings, +, parentheses and numeric substring calls."""
    tokens = []
    pattern = re.compile('\\s*(?:([\'"])((?:\\\\.|(?!\\1).)*?)\\1|(\\+|\\(|\\))|\\.substring\\((\\d+)\\))', re.S)
    pos = 0
    while pos < len(expression):
        match = pattern.match(expression, pos)
        if not match:
            if not expression[pos:].strip():
                break
            return ''
        tokens.append(('str', re.sub('\\\\([\\\\\\x22\\x27/])', '\\1', match.group(2))) if match.group(1) else ('cut', int(match.group(4))) if match.group(4) is not None else (match.group(3), None))
        pos = match.end()
    index = [0]

    def factor():
        if index[0] >= len(tokens):
            raise ValueError('Missing string')
        token, value = tokens[index[0]]
        index[0] += 1
        if token == '(':
            value = sequence()
            if index[0] >= len(tokens) or tokens[index[0]][0] != ')':
                raise ValueError('Missing parenthesis')
            index[0] += 1
        elif token != 'str':
            raise ValueError('Unsupported expression')
        while index[0] < len(tokens) and tokens[index[0]][0] == 'cut':
            value = value[tokens[index[0]][1]:]
            index[0] += 1
        return value

    def sequence():
        value = factor()
        while index[0] < len(tokens) and tokens[index[0]][0] == '+':
            index[0] += 1
            value += factor()
        return value
    try:
        value = sequence()
        return value if index[0] == len(tokens) else ''
    except (ValueError, IndexError):
        return ''

def media_sources(session, url, referer, depth=0, seen=None):
    if depth > 4:
        return []
    seen = seen if seen is not None else set()
    if url in seen:
        return []
    seen.add(url)
    if a._media_type(url):
        return [{'url': url, 'mediatype': a._media_type(url), 'headers': headers(referer)}]
    html, final, mime = get(session, url, referer)
    if not html and mime.startswith(('video/', 'audio/')):
        return [{'url': final, 'mediatype': 'mp4', 'headers': headers(referer)}]
    if html.lstrip().startswith('#EXTM3U'):
        return [{'url': final, 'mediatype': 'hls', 'headers': headers(referer)}]
    from .freeproviders import _unpack_egybest_script
    unpacked = _unpack_egybest_script(html)
    if unpacked:
        html += '\n' + unpacked
    html = html.replace('\\/', '/')
    from .subtitledata import extract
    tracks = extract(html, final, headers(final))
    root = a.Document(html).root
    candidates = []
    for node in root.find('source') + root.find('video'):
        value = node.attrs.get('src')
        if value:
            kind = 'hls' if 'mpegurl' in node.attrs.get('type', '') else a._media_type(value) or 'mp4'
            candidates.append((value, node.attrs.get('label') or node.attrs.get('res') or 'Original', kind))
    for block in re.findall('\\{[^{}]*\\bfile\\s*:[^{}]*\\}', html, re.I):
        media = re.search('\\bfile\\s*:\\s*["\\\']([^"\\\']+)', block, re.I)
        quality = re.search('\\blabel\\s*:\\s*["\\\']([^"\\\']+)', block, re.I)
        if media and a._media_type(media.group(1)):
            candidates.append((media.group(1), quality.group(1) if quality else 'Original', a._media_type(media.group(1))))
    for value in re.findall('["\\\']((?:https?:)?//[^"\\\']+\\.(?:m3u8|mp4)(?:\\?[^"\\\']*)?)["\\\']', html, re.I):
        candidates.append((value, 'Original', a._media_type(value)))
    for expression in re.findall('getElementById\\([\'\\"](?:robotlink|norobotlink)[\'\\"]\\)\\.innerHTML\\s*=\\s*([^;]+)', html):
        value = literal_expression(expression)
        if '/get_video?' in value:
            candidates.append((value, 'Original', 'mp4'))
    result, unique = ([], set())
    for value, quality, kind in candidates:
        target = urljoin(final, unescape(value))
        if urlparse(target).scheme not in ('http', 'https') or target in unique:
            continue
        unique.add(target)
        result.append({'url': target, 'quality': quality, 'mediatype': kind, 'headers': headers(final), 'subtitles': tracks})
    if not result:
        for node in root.find('iframe'):
            value = node.attrs.get('src') or node.attrs.get('data-src')
            if value:
                try:
                    result.extend(media_sources(session, urljoin(final, value), final, depth + 1, seen))
                except requests.RequestException:
                    continue
    return result

def resolve(item):
    from .freeproviders import hls_variant_streams
    with requests.Session() as session:
        session.verify = False
        found = media_sources(session, item['server_url'], item['referer'])
    streams = []
    for stream in found:
        stream.update(relay=True)
        streams.extend(hls_variant_streams(stream) if stream.get('mediatype') == 'hls' else [stream])
    if not streams:
        raise RuntimeError(u'هذا السيرفر لا يعرض رابطاً يدعمه الرسيفر أو يحتاج متصفحاً. اختر سيرفراً آخر.')
    result = dict(item)
    result.update(name=item.get('title') or item['name'], streams=streams)
    return result
