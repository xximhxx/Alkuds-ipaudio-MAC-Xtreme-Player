# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Embedded service subtitles and optional public SRT/VTT files."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import threading
import gzip
from .py2compat import io_module as io
from .py2compat import requests
from Components.ActionMap import ActionMap
from .xStaticText import Label
from .xStaticText import StaticText
from Screens.Screen import Screen
from .xStaticText import MessageBox
from enigma import eTimer, getDesktop
from .subtitledata import CueTimeline, parse_cues, recalled
from .freestyle import FONT, StyledList


class AlkudsOptionBox(Screen):
    """DreamOS-safe alternative to the system ChoiceBox.

    DreamOS OE2.5 can draw the numeric ChoiceBox keys while dropping UTF-8
    labels from tuple rows.  Alkuds' own list renderer already handles Arabic
    correctly, so keep the original choice payload but render it here.
    """

    def __init__(self, session, title='', list=None):
        size = getDesktop(0).size()
        width, height = size.width(), size.height()
        panel_w = min(int(width * 0.72), 1180)
        panel_h = min(int(height * 0.72), 760)
        left = (width - panel_w) // 2
        top = (height - panel_h) // 2
        title_h = 86 if height >= 900 else 66
        keys_h = 70 if height >= 900 else 54
        font = 38 if width >= 1920 else 30 if width >= 1280 else 24
        item_h = 82 if height >= 900 else 64
        template = ('{"template":[MultiContentEntryText(pos=(24,0),'
                    'size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,'
                    'text=0,color=0xffffff,color_sel=0xffffff,'
                    'backcolor=0xff000004,backcolor_sel=0x6d3fc4)],'
                    '"fonts":[gFont("%s",%d)],"itemHeight":%d}' %
                    (panel_w - 48, item_h, FONT, font, item_h))
        self.skin = (
            '<screen name="AlkudsOptionBox" position="%d,%d" size="%d,%d" '
            'backgroundColor="#160c2a" flags="wfNoBorder">'
            '<widget source="title" render="Label" position="20,8" size="%d,%d" '
            'font="%s;%d" foregroundColor="#ffffff" backgroundColor="#160c2a" '
            'halign="center" valign="center" />'
            '<widget source="list" render="Listbox" position="20,%d" size="%d,%d" '
            'backgroundColor="#160c2a" backgroundColorSelected="#6d3fc4" '
            'scrollbarMode="showOnDemand" enableWrapAround="1">'
            '<convert type="TemplatedMultiContent">%s</convert></widget>'
            '<widget source="key_red" render="Label" position="20,%d" size="%d,%d" '
            'font="%s;%d" foregroundColor="#ff9292" backgroundColor="#160c2a" '
            'halign="center" valign="center" />'
            '<widget source="key_green" render="Label" position="%d,%d" size="%d,%d" '
            'font="%s;%d" foregroundColor="#8de3ba" backgroundColor="#160c2a" '
            'halign="center" valign="center" /></screen>' %
            (left, top, panel_w, panel_h, panel_w - 40, title_h,
             FONT, font + 4, title_h, panel_w - 40,
             panel_h - title_h - keys_h - 12, template,
             panel_h - keys_h, (panel_w - 40) // 2, keys_h,
             FONT, max(22, font - 4), 20 + (panel_w - 40) // 2,
             panel_h - keys_h, (panel_w - 40) // 2, keys_h,
             FONT, max(22, font - 4)))
        Screen.__init__(self, session)
        self._choices = list or []
        rows = []
        for choice in self._choices:
            label = choice[0] if isinstance(choice, (tuple, type([]))) and choice else choice
            rows.append((label, choice, u'', 0xffffff))
        self['title'] = StaticText(title or u'خيارات التشغيل')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'اختيار')
        self['list'] = StyledList(rows, enableWrapAround=True)
        self['actions'] = ActionMap(
            ['AlkudsActions', 'OkCancelActions', 'ColorActions', 'DirectionActions'],
            {'cancel': self.cancel, 'red': self.cancel,
             'ok': self.accept, 'green': self.accept,
             'up': self.up, 'down': self.down}, -2)

    def _move(self, direction):
        try:
            instance = self['list'].master.master.instance
            instance.moveSelection(getattr(instance, direction))
        except Exception:
            pass

    def up(self):
        self._move('moveUp')

    def down(self):
        self._move('moveDown')

    def accept(self):
        current = self['list'].getCurrent()
        self.close(current[1] if current else None)

    def cancel(self):
        self.close(None)

class CaptionOverlay(Screen):

    def __init__(self, session):
        size = getDesktop(0).size()
        w, h = (size.width(), size.height())
        self.skin = '<screen position="0,0" size="%d,%d" flags="wfNoBorder" backgroundColor="#ff000000" zPosition="7"><widget name="caption" position="%d,%d" size="%d,%d" font="%s;%d" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#80000000" shadowColor="#000000" shadowOffset="2,2" /></screen>' % (w, h, int(w * 0.07), int(h * 0.75), int(w * 0.86), int(h * 0.19), FONT, max(24, int(h * 0.045)))
        Screen.__init__(self, session)
        self['caption'] = Label('')

class SubtitleControl(object):

    def __init__(self, screen):
        self.screen, self.closed = (screen, False)
        self.overlay = self.native_window = None
        self.timeline, self.result = (None, None)
        self.search_result = None
        self.generation, self.reference, self.loading = (0, None, False)
        self.links = []
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.tick)
        except Exception:
            self.timer.callback.append(self.tick)
        actions = getattr(screen.get('actions') if hasattr(screen, 'get') else screen['actions'], 'actions', {})
        self.old_menu = actions.get('menu')
        screen['alkuds_subtitle_actions'] = ActionMap(['AlkudsActions', 'InfobarSubtitleSelectionActions'], {'menu': self.menu, 'subtitleSelection': self.choose}, -35)
        screen.onClose.append(self.close)

    def ref(self):
        value = self.screen.session.nav.getCurrentlyPlayingServiceReference()
        return value.toString() if value else ''

    def interface(self):
        service = self.screen.session.nav.getCurrentService()
        return service.subtitle() if service else None

    def message(self, text):
        if not self.closed:
            self.screen.session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=6)

    def menu(self):
        choices = [(u'اختيار الترجمة / إيقافها', self.choose)]
        if self.old_menu:
            choices.append((u'خيارات المشغل', self.old_menu))
        audio = getattr(self.screen, 'audioSelection', None)
        if audio:
            choices.append((u'اختيار الصوت', audio))
        self.screen.session.openWithCallback(self.menu_chosen, AlkudsOptionBox, title=u'خيارات التشغيل', list=choices)

    def menu_chosen(self, choice):
        if choice and (not self.closed):
            choice[1]()

    def choose(self):
        self.links = list(getattr(self.screen, 'subtitles', []) or recalled(getattr(self.screen, 'streamurl', '')))
        rows = [(u'إيقاف الترجمة', ('off', None))]
        try:
            interface = self.interface()
            for index, track in enumerate(interface.getSubtitleList() if interface else []):
                lang = str(track[4]) if len(track) > 4 else ''
                lang = {'ara': u'العربية', 'ar': u'العربية', 'eng': 'English', 'en': 'English', 'fra': u'الفرنسية', 'fre': u'الفرنسية', 'fr': u'الفرنسية', 'tur': u'التركية', 'tr': u'التركية'}.get(lang.lower(), lang)
                rows.append((u'ترجمة مدمجة %d  |  %s' % (index + 1, lang), ('native', track)))
        except Exception:
            pass
        rows.extend(((u'ترجمة الموقع  |  ' + str(track.get('name') or 'Subtitle'), ('external', track)) for track in self.links))
        if getattr(self.screen, 'subtitle_search', {}).get('imdb'):
            rows.append((u'البحث عن ترجمات حسب اللغة (مثل الموقع)', ('search', None)))
        if len(rows) == 1:
            self.message(u'لا توجد ترجمات اختيارية متاحة من هذا المصدر أو المشغل. الترجمة المطبوعة داخل الصورة لا يمكن تغييرها.')
            return
        self.screen.session.openWithCallback(self.chosen, AlkudsOptionBox, title=u'اختيار الترجمة', list=rows)

    def off(self):
        self.generation += 1
        self.loading, self.timeline, self.result = (False, None, None)
        self.search_result = None
        self.timer.stop()
        if self.overlay:
            self.overlay.hide()
            self.overlay['caption'].setText('')
        try:
            if hasattr(self.screen, 'enableSubtitle'):
                self.screen.enableSubtitle(None)
            else:
                interface = self.interface()
                if interface and self.native_window:
                    interface.disableSubtitles(self.native_window.instance)
                if self.native_window:
                    self.native_window.hide()
        except Exception:
            pass

    def chosen(self, choice):
        if not choice or self.closed:
            return
        kind, value = choice[1]
        if kind == 'search':
            languages = [(u'العربية', 'ara'), (u'English', 'eng'), (u'الفرنسية', 'fre'), (u'التركية', 'tur'), (u'الإسبانية', 'spa'), (u'كل اللغات', 'all')]
            self.screen.session.openWithCallback(self.search_chosen, AlkudsOptionBox, title=u'لغة الترجمة', list=languages)
            return
        self.off()
        self.reference = self.ref()
        if kind == 'off':
            return
        if kind == 'native':
            try:
                if hasattr(self.screen, 'enableSubtitle'):
                    self.screen.enableSubtitle(value)
                else:
                    from Screens.InfoBarGenerics import SubtitleDisplay
                    if not self.native_window:
                        self.native_window = self.screen.session.instantiateDialog(SubtitleDisplay)
                    self.interface().enableSubtitles(self.native_window.instance, value)
                    self.native_window.show()
                self.timer.start(250, False)
            except Exception:
                self.message(u'هذا المشغل لا يدعم تفعيل الترجمة المختارة؛ جرّب مشغلاً آخر.')
            return
        self.loading = True
        worker = threading.Thread(target=self.download, args=(self.generation, value))
        worker.daemon = True
        worker.start()
        self.timer.start(250, False)

    def download(self, generation, track):
        try:
            if track.get('hls_subtitle'):
                from .netmirror import subtitle_bytes
                raw = subtitle_bytes(track, lambda: self.closed or generation != self.generation)
            else:
                with requests.get(track['url'], headers=track.get('headers') or {}, timeout=(5, 12), stream=True) as response:
                    response.raise_for_status()
                    raw = bytearray()
                    for chunk in response.iter_content(32768):
                        if self.closed or generation != self.generation:
                            return
                        raw.extend(chunk)
                        if len(raw) > 4 * 1024 * 1024:
                            raise ValueError('subtitle too large')
                raw = bytes(raw)
            if raw.startswith(b'\x1f\x8b'):
                raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read(4 * 1024 * 1024 + 1)
                if len(raw) > 4 * 1024 * 1024:
                    raise ValueError('subtitle too large')
            cues = parse_cues(raw, track.get('encoding') or 'utf-8-sig')
            if not cues:
                raise ValueError('not SRT/WebVTT')
            result = (generation, CueTimeline(cues), '')
        except Exception:
            result = (generation, None, u'تعذر تحميل الترجمة. هذا الخيار يدعم ملفات SRT وVTT؛ اختر ترجمة أو مشغلاً آخر.')
        if not self.closed and generation == self.generation:
            self.result = result

    def search_chosen(self, choice):
        if not choice or self.closed:
            return
        self.reference = self.ref()
        worker = threading.Thread(target=self.search, args=(self.generation, choice[1], dict(self.screen.subtitle_search)))
        worker.daemon = True
        worker.start()
        self.timer.start(250, False)

    def search(self, generation, language, context):
        try:
            url = 'https://rest.opensubtitles.org/search'
            if context.get('season') and context.get('episode'):
                url += '/episode-%s/imdbid-%s/season-%s' % (context['episode'], context['imdb'], context['season'])
            else:
                url += '/imdbid-' + context['imdb']
            url += '/sublanguageid-' + language
            response = requests.get(url, headers={'X-User-Agent': 'trailers.to-UA'}, timeout=(5, 12))
            response.raise_for_status()
            rows = []
            for value in response.json()[:150]:
                link = value.get('SubDownloadLink') or ''
                if link.startswith(('https://', 'http://')):
                    track = {'url': link, 'name': value.get('LanguageName') or language, 'encoding': value.get('SubEncoding') or 'utf-8-sig', 'headers': {}}
                    rows.append((str(value.get('SubFileName') or track['name']), ('external', track)))
            result = (generation, rows)
        except Exception:
            result = (generation, [])
        if not self.closed and generation == self.generation:
            self.search_result = result

    def tick(self):
        if self.closed:
            return
        try:
            if self.reference != self.ref():
                self.off()
                return
            if self.search_result:
                generation, rows = self.search_result
                self.search_result = None
                if generation == self.generation:
                    if rows:
                        self.screen.session.openWithCallback(self.chosen, AlkudsOptionBox, title=u'ترجمات الموقع — اختر نسخة الفيلم المناسبة', list=rows)
                    else:
                        self.message(u'لا توجد نتائج متاحة بهذه اللغة حالياً، أو خدمة الترجمة لا تستجيب.')
            if self.result:
                generation, timeline, error = self.result
                self.result = None
                if generation == self.generation:
                    self.loading, self.timeline = (False, timeline)
                    if error:
                        self.timer.stop()
                        self.message(error)
            if not self.timeline:
                return
            service = self.screen.session.nav.getCurrentService()
            seek = service.seek() if service else None
            position = seek.getPlayPosition() if seek else None
            text = self.timeline.at(position[1] / 90000.0) if position and position[0] == 0 else ''
            if text:
                if not self.overlay:
                    self.overlay = self.screen.session.instantiateDialog(CaptionOverlay)
                self.overlay['caption'].setText(text)
                self.overlay.show()
            elif self.overlay:
                self.overlay.hide()
        except Exception:
            if self.overlay:
                self.overlay.hide()

    def close(self):
        self.off()
        self.closed = True
        for dialog in (self.overlay, self.native_window):
            if dialog:
                try:
                    self.screen.session.deleteDialog(dialog)
                except Exception:
                    pass
        self.overlay = self.native_window = None

def install(screen):
    if not hasattr(screen, '_alkuds_subtitles'):
        screen._alkuds_subtitles = SubtitleControl(screen)
