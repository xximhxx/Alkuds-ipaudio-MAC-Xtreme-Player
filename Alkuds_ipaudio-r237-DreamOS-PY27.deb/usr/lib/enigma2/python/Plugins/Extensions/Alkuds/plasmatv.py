# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Plasma public web catalogue; only ordinary, non-DRM media servers."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import re
from .py2compat import threading
from .py2compat import time
from .providerhtml import HTMLParser
from .py2compat import urllib
urlparse = urllib.parse.urlparse
urljoin = urllib.parse.urljoin
from .py2compat import requests
BASE = 'plasmatv'
SECTION_MAP = {'browse': (u'بلازما Plasma 4K', '')}
CATALOGUE = 'https://app-plasma-4k.web.app/'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
_cache = (0, None)
_lock = threading.RLock()

class _Cards(HTMLParser):

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.groups, self.cards = ([], [])
        self.section, self.card, self.capture = ('', None, None)

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        classes = a.get('class', '').split()
        if tag == 'button' and 'section-btn' in classes:
            self.capture = ('group', {'id': a.get('data-section', ''), 'name': ''})
        if 'section-container' in classes:
            self.section = a.get('id', '')
        if 'channel-card' in classes:
            self.card = {'id': a.get('data-channel', ''), 'group': self.section, 'name': '', 'image': ''}
            self.cards.append(self.card)
        if tag == 'img' and self.card is not None:
            self.card['image'] = a.get('src', '')
        if tag == 'h3' and self.card is not None:
            self.capture = ('card', self.card)

    def handle_data(self, data):
        if self.capture:
            self.capture[1]['name'] += data

    def handle_endtag(self, tag):
        if self.capture and (tag == 'button' and self.capture[0] == 'group' or (tag == 'h3' and self.capture[0] == 'card')):
            if self.capture[0] == 'group':
                self.groups.append(self.capture[1])
            self.capture = None
        if tag == 'h3':
            self.card = None

def _clear_server(server):
    if not isinstance(server, dict) or server.get('drmKey') or server.get('license') or server.get('licenseUrl'):
        return None
    if str(server.get('scheme', 'clear')).lower() not in ('', 'clear', 'none'):
        return None
    url = str(server.get('url') or '').strip()
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        return None
    if not parsed.path.lower().endswith(('.m3u8', '.ts', '.mp4', '.mp3', '.aac')):
        return None
    headers = {'User-Agent': str(server.get('userAgent') or UA)}
    for key, field in [('Referer', 'refer'), ('Origin', 'origin')]:
        value = str(server.get(field) or '')
        if value:
            headers[key] = value
    if any(('\r' in v or '\n' in v for v in headers.values())):
        return None
    return {'name': str(server.get('name') or 'Server'), 'url': url, 'headers': headers}

def parse_catalogue(content):
    match = re.search('const\\s+staticChannelLinks\\s*=\\s*', content)
    end = content.find('let channelLinks', match.end()) if match else -1
    if not match or end < 0:
        raise RuntimeError(u'تغيرت بنية صفحة بلازما؛ تعذر قراءة الباقات.')
    literal = content[match.end():end].strip().rstrip(';').strip()
    literal = re.sub(',\\s*([}\\]])', '\\1', literal)
    links = json.loads(literal)
    parser = _Cards()
    parser.feed(content[:match.start()])
    groups, cards = ([], [])
    for group in parser.groups:
        group = dict(group, name=group['name'].strip(), section='channels')
        seen = set()
        for original in parser.cards:
            if original['group'] != group['id'] or original['id'] in seen:
                continue
            data = links.get(original['id']) or {}
            servers = []
            for raw in data.get('servers', [data]):
                server = _clear_server(raw)
                if server and (not any((x['url'] == server['url'] and x['headers'] == server['headers'] for x in servers))):
                    servers.append(server)
            if servers:
                seen.add(original['id'])
                cards.append(dict(original, name=original['name'].strip(), servers=servers, section='channels', category=group['name']))
        count = sum((1 for card in cards if card['group'] == group['id']))
        if count:
            groups.append(dict(group, name=group['name'] + ' (%d)' % count))
    if not cards:
        raise RuntimeError(u'لا توجد روابط مباشرة غير محمية متاحة في بلازما حالياً.')
    return (groups, cards)

def catalogue():
    global _cache
    with _lock:
        if _cache[1] is not None and time.time() - _cache[0] < 180:
            return _cache[1]
        with requests.get(CATALOGUE, headers={'User-Agent': UA}, timeout=(6, 12), stream=True) as reply:
            reply.raise_for_status()
            raw = reply.raw.read(2097153, decode_content=True)
            if len(raw) > 2097152:
                raise RuntimeError(u'صفحة بلازما أكبر من الحد المسموح.')
            parsed = parse_catalogue(raw.decode('utf-8-sig'))
        _cache = (time.time(), parsed)
        return parsed

def refresh():
    global _cache
    with _lock:
        _cache = (0, None)

def groups():
    return [dict(x) for x in catalogue()[0]]

def page(parent, number):
    cards = catalogue()[1]
    if parent.get('channel_id'):
        channel = next((x for x in cards if x['id'] == parent['channel_id']), None)
        if not channel:
            raise RuntimeError(u'القناة لم تعد متاحة؛ حدث قائمة بلازما.')
        rows = [dict(channel, id='%s:%d' % (channel['id'], index), channel_id=channel['id'], server_index=index, server_key=str(index), server=server, name=channel['name'] + ' | ' + server['name'], url=server['url'], action='play') for index, server in enumerate(channel['servers'])]
    else:
        rows = [dict(x, channel_id=x['id']) for x in cards if x['group'] == parent.get('id')]
    start = (max(1, int(number)) - 1) * 24
    return {'entries': rows[start:start + 24], 'page': max(1, int(number)), 'last_page': max(1, (len(rows) + 23) // 24), 'total': len(rows)}

def resolve(item):
    channel = next((x for x in catalogue()[1] if x['id'] == item.get('channel_id')), None)
    index = item.get('server_index')
    if not channel or not isinstance(index, int) or (not 0 <= index < len(channel['servers'])):
        raise RuntimeError(u'المشغل لم يعد متاحاً؛ حدث قائمة المشغلات.')
    server = channel['servers'][index]
    with requests.get(server['url'], headers=server['headers'], timeout=(5, 12), stream=True) as reply:
        reply.raise_for_status()
        raw = reply.raw.read(65536, decode_content=True)
        final = reply.url
    hls = raw.lstrip().startswith(b'#EXTM3U')
    if hls:
        text = raw.decode('utf-8-sig')
        if 'SAMPLE-AES' in text or re.search('KEYFORMAT="(?!identity")', text):
            raise RuntimeError(u'هذا المشغل محمي ولا يدعمه هذا القسم.')
        kind = 'hls'
    elif raw[:1] == b'G':
        kind = 'ts'
    elif b'ftyp' in raw[:32]:
        kind = 'mp4'
    elif urlparse(final).path.lower().endswith(('.mp3', '.aac')) and raw:
        kind = 'audio'
    else:
        raise RuntimeError(u'المشغل لم يرجع بثاً صالحاً؛ اختر سيرفراً آخر.')
    stream = {'url': final, 'headers': server['headers'], 'mediatype': kind, 'quality': server['name'], 'relay': True, 'relay_options': {'livehd': True}}
    variants = _hls_qualities(text, stream) if hls else [stream]
    return dict(channel, name=channel['name'] + ' | ' + server['name'], url=final, streams=variants)

def _hls_qualities(text, stream):
    if any(('TYPE=AUDIO' in line and 'URI=' in line for line in text.splitlines() if line.startswith('#EXT-X-MEDIA:'))):
        return [dict(stream, quality='Auto')]
    variants, pending = ([], None)
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('#EXT-X-STREAM-INF:'):
            pending = line
        elif line and (not line.startswith('#')) and pending:
            target = urljoin(stream['url'], line)
            if urlparse(target).scheme in ('http', 'https'):
                resolution = re.search('RESOLUTION=\\d+x(\\d+)', pending)
                bandwidth = re.search('BANDWIDTH=(\\d+)', pending)
                quality = resolution.group(1) + 'p' if resolution else '%d kbps' % (int(bandwidth.group(1)) // 1000) if bandwidth else 'Original'
                if not any((x['url'] == target for x in variants)):
                    variants.append(dict(stream, url=target, quality=quality))
            pending = None
    return variants or [stream]
