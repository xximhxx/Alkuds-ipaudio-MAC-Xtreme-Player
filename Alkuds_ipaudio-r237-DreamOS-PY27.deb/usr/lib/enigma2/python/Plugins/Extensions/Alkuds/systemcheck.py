# -*- coding: utf-8 -*-
"""Alkuds r233 unified operation assurance.

Read-only capability probes plus the safe, small writes needed to relocate the
timeshift buffer. This module never imports Enigma2 components at module level
and performs no UI calls, so every probe is safe to run from a worker thread.

The three probes address the three guarantees requested for the plugin:

1. timeshift storage   -> probe_timeshift_storage() / resolve_timeshift_dir()
2. players + codecs    -> probe_players()
3. Dream/Open integrity -> probe_plugin_integrity()

Python 2.7 and Python 3 are both supported by this file using only constructs
available on both runtimes.
"""
from __future__ import absolute_import, division, print_function

import json
import os
import re
import stat
import subprocess
import time

PLUGIN_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/Alkuds"
TIMESHIFT_PREF = "/etc/enigma2/alkuds/timeshift_storage.json"
MIN_TIMESHIFT_FREE = 128 * 1024 * 1024  # 128 MiB, matching remux's existing floor

_BLOCKED_FS = (
    "tmpfs", "ramfs", "autofs", "proc", "sysfs", "devtmpfs", "devpts",
    "cgroup", "cgroup2", "securityfs", "debugfs", "tracefs", "pstore",
    "squashfs", "jffs2", "ubifs", "overlay", "rootfs", "mtd", "nfs",
)
_SYSTEM_PREFIXES = ("/proc", "/sys", "/dev", "/boot", "/usr", "/etc", "/var/log")


def _which(name):
    """Locate an executable on PATH without shutil.which (absent on Python 2.7)."""
    for folder in os.environ.get("PATH", "").split(os.pathsep):
        if not folder:
            continue
        candidate = os.path.join(folder, name)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _read_text(path, limit=2048):
    try:
        with open(path, "rb") as stream:
            data = stream.read(limit)
        if isinstance(data, bytes):
            data = data.decode("utf-8", "ignore")
        return str(data or "").replace("\x00", " ").strip()
    except Exception:
        return ""


def _mount_table():
    entries = []
    try:
        with open("/proc/mounts") as stream:
            for line in stream:
                fields = line.split()
                if len(fields) >= 4:
                    path = fields[1].replace("\\040", " ").replace("\\011", "\t").replace("\\134", "\\")
                    entries.append((os.path.realpath(path), fields[2], fields[3].split(",")))
    except Exception:
        pass
    return entries


def _filesystem_for(path, entries):
    path = os.path.realpath(path)
    matches = [entry for entry in entries if path == entry[0] or path.startswith(entry[0].rstrip("/") + "/")]
    if not matches:
        return None
    return max(matches, key=lambda entry: len(entry[0]))


def _free_bytes(path):
    try:
        st = os.statvfs(path)
        return int(st.f_bavail) * int(st.f_frsize)
    except (OSError, AttributeError):
        return 0


def _fullmatch(pattern, value):
    """re.fullmatch equivalent for Python 2.7 (which lacks the method)."""
    match = re.match(pattern, value)
    return match is not None and match.end() == len(value)


def _real_disk_device(device):
    device = os.path.realpath(device)
    return bool(_fullmatch(
        r"/dev/(?:sd[a-z]+[0-9]*|hd[a-z]+[0-9]*|vd[a-z]+[0-9]*|mmcblk[0-9]+(?:p[0-9]+)?|nvme[0-9]+n[0-9]+(?:p[0-9]+)?)",
        device))


def _is_external_disk_mount(mountpoint, entries):
    """True when a mountpoint's kernel source device is a real SATA/USB/NVMe/SD.

    A separately exposed disk may also host the root image, so the kernel mount
    source is trusted over the /media directory name alone.
    """
    try:
        with open("/proc/mounts") as stream:
            for line in stream:
                fields = line.split()
                if len(fields) < 2:
                    continue
                mount = fields[1].replace("\\040", " ").replace("\\011", "\t").replace("\\134", "\\")
                if os.path.realpath(mount) == os.path.realpath(mountpoint):
                    return _real_disk_device(fields[0])
    except Exception:
        pass
    return False


def _candidate_volumes():
    """Return an ordered, de-duplicated list of candidate directories."""
    candidates = []
    try:
        if os.path.isdir("/media/hdd"):
            candidates.append("/media/hdd/timeshift")
            candidates.append("/media/hdd")
        if os.path.isdir("/media/usb"):
            candidates.append("/media/usb/timeshift")
            candidates.append("/media/usb")
    except Exception:
        pass
    try:
        names = sorted(os.listdir("/media")) if os.path.isdir("/media") else []
        for name in names:
            if name in ("net", "autofs"):
                continue
            base = os.path.join("/media", name)
            if os.path.isdir(base):
                candidates.append(os.path.join(base, "timeshift"))
                candidates.append(base)
    except Exception:
        pass
    for mount, _fstype, _opts in _mount_table():
        if mount and mount != "/" and os.path.isdir(mount):
            candidates.append(os.path.join(mount, "timeshift"))
            candidates.append(mount)
    seen = []
    result = []
    for candidate in candidates:
        try:
            real = os.path.realpath(candidate)
        except Exception:
            continue
        if real in seen:
            continue
        seen.append(real)
        result.append(candidate)
    return result


def _ram_available():
    """Best-effort available RAM in bytes, read from /proc/meminfo."""
    try:
        values = {}
        with open("/proc/meminfo") as stream:
            for line in stream:
                if ":" in line:
                    parts = line.split()
                    values[parts[0].rstrip(":")] = int(parts[1]) * 1024
        return values.get("MemAvailable", values.get("MemFree", 0) + values.get("Cached", 0) + values.get("Buffers", 0))
    except Exception:
        return 0


def probe_timeshift_storage(min_free=MIN_TIMESHIFT_FREE):
    """Classify every candidate volume for the disk-backed satellite timeshift.

    Returns a dict with ``volumes`` (sorted best-first) and ``ram`` (a RAM
    buffer assessment used by the independent FLASHBACK raw recorder).
    """
    entries = _mount_table()
    root_dev = None
    try:
        root_dev = os.stat("/").st_dev
    except Exception:
        root_dev = None

    volumes = []
    for candidate in _candidate_volumes():
        try:
            real = os.path.realpath(candidate)
            ancestor = real
            while not os.path.isdir(ancestor) and ancestor != "/":
                ancestor = os.path.dirname(ancestor)
            entries = _mount_table()
            filesystem = _filesystem_for(ancestor, entries)
            info = {
                "path": real,
                "filesystem": filesystem[1] if filesystem else "",
                "free": 0,
                "suitable": False,
                "reason": "",
            }
            system_path = any(real == prefix or real.startswith(prefix + "/") for prefix in _SYSTEM_PREFIXES)
            shares_root = False
            try:
                shares_root = os.stat(ancestor).st_dev == root_dev
            except Exception:
                pass
            on_external_disk = bool(filesystem and filesystem[0] != "/" and _is_external_disk_mount(filesystem[0], entries))
            if system_path:
                info["reason"] = "system/flash path"
            elif not filesystem or filesystem[0] == "/" or filesystem[1].lower() in _BLOCKED_FS:
                info["reason"] = "unmounted or blocked filesystem"
            elif shares_root and not on_external_disk:
                info["reason"] = "shares root flash device"
            elif "ro" in filesystem[2]:
                info["reason"] = "read-only volume"
            else:
                free = _free_bytes(ancestor)
                info["free"] = free
                if free < min_free:
                    info["reason"] = "insufficient free space"
                else:
                    info["suitable"] = True
                    info["reason"] = "ok"
            volumes.append(info)
        except Exception as error:
            volumes.append({
                "path": candidate,
                "filesystem": "",
                "free": 0,
                "suitable": False,
                "reason": "%s: %s" % (type(error).__name__, error),
            })

    def score(vol):
        # Prefer a real HDD, then USB, then any other writable volume; largest free first.
        path = vol["path"]
        base = 0
        if path.startswith("/media/hdd"):
            base = 3000
        elif path.startswith("/media/usb"):
            base = 2000
        elif path.startswith("/media/"):
            base = 1000
        if not vol["suitable"]:
            base -= 100000
        return base + (vol["free"] // (1024 * 1024))

    volumes.sort(key=score, reverse=True)

    ram = {"available": _ram_available(), "usable": False, "reason": ""}
    ram["usable"] = ram["available"] >= 32 * 1024 * 1024
    ram["reason"] = "ok" if ram["usable"] else "less than 32 MiB available RAM"

    return {"volumes": volumes, "ram": ram, "min_free": min_free}


def load_timeshift_pref():
    """Return the persisted timeshift directory, or an empty string."""
    try:
        with open(TIMESHIFT_PREF, "r") as stream:
            data = json.loads(stream.read(4097))
        if isinstance(data, dict):
            value = data.get("path", "")
            if isinstance(value, str) and value:
                return value
    except Exception:
        pass
    return ""


def save_timeshift_pref(path):
    """Persist the chosen timeshift directory (safe atomic write)."""
    path = os.path.realpath(str(path or ""))
    if not path:
        raise ValueError("empty timeshift path")
    parent = os.path.dirname(TIMESHIFT_PREF)
    try:
        if not os.path.isdir(parent):
            os.makedirs(parent)
    except OSError:
        if not os.path.isdir(parent):
            raise
    temporary = TIMESHIFT_PREF + ".tmp"
    try:
        with open(temporary, "w") as stream:
            json.dump({"path": path}, stream, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        os.rename(temporary, TIMESHIFT_PREF)
    finally:
        if os.path.exists(temporary):
            try:
                os.unlink(temporary)
            except OSError:
                pass
    return path


def _validated_timeshift_dir(path, min_free=MIN_TIMESHIFT_FREE):
    path = os.path.realpath(path)
    if path in ("", "/") or any(path == prefix or path.startswith(prefix + "/") for prefix in _SYSTEM_PREFIXES):
        return ""
    if not os.path.isdir(path) or not os.access(path, os.W_OK):
        return ""
    if _free_bytes(path) < min_free:
        return ""
    entries = _mount_table()
    filesystem = _filesystem_for(path, entries)
    if filesystem and filesystem[1].lower() in _BLOCKED_FS:
        return ""
    return path


def resolve_timeshift_dir(prefer_pref=True):
    """Return a usable, writable directory for the satellite timeshift buffer.

    Order: persisted preference (validated), then the best auto-detected volume
    (HDD/USB/other), then the legacy /media/hdd fallback. Empty string = none.
    """
    if prefer_pref:
        pref = load_timeshift_pref()
        if pref:
            validated = _validated_timeshift_dir(pref)
            if validated:
                return validated
    report = probe_timeshift_storage()
    for volume in report.get("volumes", []):
        if volume.get("suitable"):
            path = volume["path"]
            try:
                if not os.path.isdir(path):
                    os.makedirs(path)
                if os.path.isdir(path) and os.access(path, os.W_OK):
                    return os.path.realpath(path)
            except Exception:
                continue
    # Legacy fallback identical to the previous remux behaviour.
    for base in ("/media/hdd/timeshift", "/media/hdd"):
        try:
            if os.path.isdir(base) and os.access(base, os.W_OK) and _free_bytes(base) >= MIN_TIMESHIFT_FREE:
                return base
        except Exception:
            continue
    return ""


def _run_ok(argv, timeout=8):
    """Run a command discarding output; True only when it exits 0 in time."""
    try:
        proc = subprocess.Popen(
            argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, close_fds=True)
    except Exception:
        return False
    try:
        proc.stdin.close()
    except Exception:
        pass
    deadline = time.time() + timeout
    while proc.poll() is None and time.time() < deadline:
        time.sleep(0.05)
    if proc.poll() is None:
        try:
            proc.kill()
        except Exception:
            pass
        try:
            proc.communicate()
        except Exception:
            pass
        return False
    try:
        proc.communicate()
    except Exception:
        pass
    return proc.returncode == 0


def _gst_has(element):
    gst_inspect = _which("gst-inspect-1.0")
    if not gst_inspect:
        return False
    return _run_ok([gst_inspect, element], timeout=8)


def probe_players():
    """Check the three IPTV players plus the supporting codecs/tools.

    Player codes follow the Enigma2 convention used by the plugin: 4097 is the
    built-in Enigma2/GStreamer service, 5001 is ServiceApp GstPlayer and 5002
    is ServiceApp ExtePlayer3. DreamOS images additionally expose 8193.
    """
    dreamos = os.path.exists("/usr/bin/apt-get") or os.path.exists("/var/lib/dpkg/status")
    players = [
        {
            "code": 4097,
            "name": "Enigma2 / GStreamer",
            "available": True,
            "detail": "built-in service player",
        },
        {
            "code": 5001,
            "name": "GstPlayer",
            "available": bool(_which("gstplayer") or _which("gstplayer_gst-1.0")),
            "detail": _which("gstplayer") or _which("gstplayer_gst-1.0") or "missing",
        },
        {
            "code": 5002,
            "name": "ExtePlayer3",
            "available": bool(_which("exteplayer3") or _which("exteplayer3.sh")),
            "detail": _which("exteplayer3") or _which("exteplayer3.sh") or "missing",
        },
    ]
    if dreamos:
        players.append({
            "code": 8193,
            "name": "DreamOS GStreamer",
            "available": True,
            "detail": "built-in DreamOS service player",
        })

    tools = {}
    for name in ("ffmpeg", "gst-launch-1.0", "gst-inspect-1.0", "aplay", "curl", "wget", "openssl"):
        tools[name] = bool(_which(name))

    codecs = {}
    for element in ("alsasink", "tsdemux", "aacparse", "mpegaudioparse", "rawaudioparse",
                    "audioconvert", "audioresample", "playbin", "udpsrc", "souphttpsrc",
                    "qtdemux", "hlsdemux", "avdec_aac", "avdec_aac_fixed", "faad", "fdkaacdec"):
        codecs[element] = _gst_has(element)

    return {"players": players, "tools": tools, "codecs": codecs, "dreamos": dreamos}


def _iter_plugin_py():
    for base, dirs, names in os.walk(PLUGIN_DIR):
        dirs[:] = [d for d in dirs if not d.startswith("__pycache__") and d != "_vendor"]
        for name in sorted(names):
            if name.endswith(".py"):
                yield os.path.join(base, name)


def probe_plugin_integrity():
    """Syntax-compile every plugin .py file and report platform basics.

    This is a grammar/compile check only; it does not import Enigma2 modules,
    so it is safe on a worker thread and detects the Dream/Open porting faults
    (Python 2 vs Python 3 syntax) that would crash the plugin at startup.
    """
    python_major = 0
    try:
        import sys
        python_major = sys.version_info[0]
    except Exception:
        pass

    total = 0
    failed = []
    for path in _iter_plugin_py():
        total += 1
        try:
            with open(path, "rb") as stream:
                source = stream.read()
            compile(source, path, "exec")
        except Exception as error:
            failed.append({"path": path.replace(PLUGIN_DIR + os.sep, ""), "error": str(error)})

    version = _read_text(os.path.join(PLUGIN_DIR, "version.txt"))
    dreamos = os.path.exists("/usr/bin/apt-get") or os.path.exists("/var/lib/dpkg/status")
    pkg_manager = "apt/dpkg (DreamOS)" if dreamos else ("opkg (Open image)" if _which("opkg") else "unknown")
    key_files = {}
    for name in ("__init__.py", "plugin.py", "version.txt", "dependencies.sh"):
        path = os.path.join(PLUGIN_DIR, name)
        key_files[name] = os.path.isfile(path)

    deps_executable = False
    try:
        deps_executable = os.access(os.path.join(PLUGIN_DIR, "dependencies.sh"), os.X_OK)
    except Exception:
        pass

    return {
        "plugin_dir": PLUGIN_DIR,
        "version": version,
        "python_major": python_major,
        "dreamos": dreamos,
        "package_manager": pkg_manager,
        "files_scanned": total,
        "failed": failed,
        "ok": total > 0 and not failed,
        "key_files": key_files,
        "dependencies_executable": deps_executable,
    }


def format_report(check):
    """Render a combined human-readable Arabic report."""
    lines = []

    storage = check.get("storage") or {}
    lines.append("1) ذاكرة التايم شيفت")
    volumes = storage.get("volumes") or []
    suitable = [v for v in volumes if v.get("suitable")]
    if suitable:
        for v in suitable[:5]:
            lines.append("  ✓ %s (%d MiB متاح، %s)" % (
                v["path"], v["free"] // (1024 * 1024), v["filesystem"] or "?"))
    else:
        lines.append("  ✗ لا يوجد قرص مناسب؛ سيُرفض تسجيل التايم شيفت")
    rejected = [v for v in volumes if not v.get("suitable") and v.get("reason") not in ("", "ok")]
    for v in rejected[:4]:
        lines.append("  – %s: %s" % (v["path"], v["reason"]))
    ram = storage.get("ram") or {}
    lines.append("  RAM buffer: %s (%d MiB)" % ("متاح" if ram.get("usable") else "غير كافٍ", (ram.get("available") or 0) // (1024 * 1024)))

    players = check.get("players") or {}
    lines.append("")
    lines.append("2) المشغلات الثلاثة والمكملات")
    for p in players.get("players", []):
        lines.append("  %s %s (%d): %s" % ("✓" if p.get("available") else "✗", p.get("name"), p.get("code"), p.get("detail")))
    tools = players.get("tools") or {}
    missing_tools = [name for name, ok in tools.items() if not ok]
    lines.append("  أدوات ناقصة: %s" % (", ".join(missing_tools) if missing_tools else "لا شيء"))
    codecs = players.get("codecs") or {}
    missing_codecs = [name for name, ok in codecs.items() if not ok]
    lines.append("  مكمّلات GStreamer ناقصة: %s" % (", ".join(missing_codecs) if missing_codecs else "لا شيء"))

    integrity = check.get("integrity") or {}
    lines.append("")
    lines.append("3) سلامة البلجن (دريم/أوبن)")
    lines.append("  الإصدار: %s | بايثون %s | %s" % (
        integrity.get("version") or "?", integrity.get("python_major") or "?", integrity.get("package_manager") or "?"))
    if integrity.get("ok"):
        lines.append("  ✓ %d ملف بايثون سليمة الصياغة" % integrity.get("files_scanned"))
    else:
        lines.append("  ✗ فشل صياغة %d ملف:" % len(integrity.get("failed", [])))
        for f in integrity.get("failed", [])[:6]:
            lines.append("    – %s: %s" % (f.get("path"), f.get("error")))

    return "\n".join(lines)


def full_check():
    """Run all three probes and return {'storage':..., 'players':..., 'integrity':...}."""
    return {
        "storage": probe_timeshift_storage(),
        "players": probe_players(),
        "integrity": probe_plugin_integrity(),
    }
