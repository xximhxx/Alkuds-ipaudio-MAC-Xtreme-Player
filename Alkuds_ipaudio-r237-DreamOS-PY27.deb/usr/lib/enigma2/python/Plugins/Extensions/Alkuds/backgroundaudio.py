# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Persistent IPTV background audio for Alkuds (R31P7 Vu+ independent ALSA).

Design goal:
* keep the Enigma2 DVB service as the main service, so satellite video and
  native timeshift continue to work;
* keep satellite video and native Enigma2 timeshift owned by Enigma2;
* on Vu+ ask the current Enigma2 service itself to release ONLY its audio PID
  via setQpipMode(False, audio=False), which cleanly closes the satellite audio
  decoder without putting the main service in QPiP mode;
* keep the proven FFmpeg MP2/MPEG-TS local bridge, but render its audio through
  an explicit ALSA GStreamer sink on Vu+.  Unlike dvbaudiosink, this PCM path is
  not paused by the Broadcom DVB decoder when native Timeshift changes state;
* keep the previous generic backends for non-Vu+ receivers.

This separation is important on receivers where AUDIO_SET_MUTE also silences
PCM produced by GStreamer/ServiceApp.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .py2compat import re
import glob
import fcntl
from .py2compat import shutil
from .py2compat import socket
import struct
import array
import errno
from .py2compat import subprocess
from .py2compat import threading
from .py2compat import time
from enigma import eTimer
try:
    from enigma import eActionMap
except Exception:
    eActionMap = None
_LOCK = threading.RLock()
_BACKEND_LOCK = threading.Lock()
_DEVNULL_R = None
_DEVNULL_W = None
_TIMER = None
_TIMER_CONN = None
_KEY_TIMER = None
_KEY_TIMER_CONN = None
_KEY_BOUND = False
_KEY_SLOT = None
_NAMED_KEY_BOUND = False
_VU_HANDOFF_TIMER = None
_VU_HANDOFF_TIMER_CONN = None
_STOP_TIMER = None
_STOP_TIMER_CONN = None
_LOG = '/tmp/alkuds-backgroundaudio.log'
_STATE = {'wanted': False, 'session': None, 'name': '', 'url': '', 'backend': '', 'procs': [], 'dvb_stopped': False, 'dvb_devices': [], 'last_service': '', 'restart_due': 0.0, 'restarting': False, 'error': '', 'error_reported': False, 'headers': {}, 'retry_resolver': None, 'bridge_port': 0, 'e2_audio_disabled': False, 'resume_context': {}, 'sink_retry_count': 0, 'sink_handoff_until': 0.0, 'vu_handoff_phase': '', 'vu_handoff_action': '', 'vu_handoff_started': 0.0, 'vu_video_paused': False, 'status_error': '', 'status_error_until': 0.0, 'status_name': ''}

def _log(message):
    try:
        with open(_LOG, 'a') as f:
            f.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), str(message)))
    except Exception:
        pass

def _find_executable(names):
    for name in names:
        try:
            path = shutil.which(name)
        except Exception:
            path = None
        if path and os.path.isfile(path) and os.access(path, os.X_OK):
            return path
        for base in ('/usr/bin', '/bin', '/usr/local/bin'):
            candidate = os.path.join(base, name)
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                return candidate
    return ''

def configured_audio_delay_ms():
    """Return the persisted IPAUDIO delay, clamped for old-image safety."""
    try:
        from .plugin import cfg
        value = int(getattr(cfg, 'ipaudiodelayms').value)
    except Exception:
        value = 0
    return max(0, min(120000, value))

def apply_audio_delay(milliseconds):
    """Persist the overlay setting and rebuild active audio only when changed."""
    from .plugin import cfg
    from Components.config import configfile
    value = max(0, min(120000, int(milliseconds)))
    if value == configured_audio_delay_ms():
        return False
    cfg.ipaudiodelayms.setValue(value)
    cfg.ipaudiodelayms.save()
    configfile.save()
    _schedule_restart(0.05)
    _log('R167 Audio Delay changed to %d ms; audio-only rebuild scheduled' % value)
    return True

def _audio_filter_chain(include_resample=False):
    """Build a FFmpeg 4.4-compatible audio filter chain.

    adelay inserts real silence instead of only shifting timestamps.  That is
    important for a live UDP bridge because a timestamp-only offset can be
    normalised away when GStreamer establishes its clock.
    """
    filters = []
    delay_ms = configured_audio_delay_ms()
    if delay_ms > 0:
        # The FFmpeg 3 adelay filter has no all= option. Delay both PCM channels.
        filters.append('aformat=channel_layouts=stereo')
        filters.append('adelay=delays=%d|%d' % (delay_ms, delay_ms))
    if include_resample:
        filters.append('aresample=async=1:first_pts=0')
    return ','.join(filters)

def _append_audio_filter(args, include_resample=False):
    chain = _audio_filter_chain(include_resample=include_resample)
    if chain:
        args += ['-af', chain]
    return args

def _devnull(read=False):
    global _DEVNULL_R, _DEVNULL_W
    if read:
        if _DEVNULL_R is None or getattr(_DEVNULL_R, 'closed', False):
            _DEVNULL_R = open(os.devnull, 'rb')
        return _DEVNULL_R
    if _DEVNULL_W is None or getattr(_DEVNULL_W, 'closed', False):
        _DEVNULL_W = open(os.devnull, 'wb')
    return _DEVNULL_W

def clean_stream_url(command):
    value = str(command or '').strip()
    if not value:
        return ''
    match = re.search('(?:https?|rtsp|rtmp|rtp|udp)://[^\\s\\"\\\']+', value, re.I)
    if match:
        return match.group(0).strip()
    for prefix in ('ffmpeg ', 'ffrt ', 'auto '):
        if value.lower().startswith(prefix):
            value = value[len(prefix):].strip()
            break
    return value
AUDIO_STOP = 28417
AUDIO_PLAY = 28418
AUDIO_PAUSE = 28419
AUDIO_CONTINUE = 28420
AUDIO_SET_MUTE = 28422
AUDIO_SET_AV_SYNC = 28423
AUDIO_GET_STATUS = 2149609226
AUDIO_GET_PTS = 2148036371

def _dreambox_primary_audio_device():
    for path in ('/dev/dvb/adapter0/audio0', '/dev/dvb/card0/audio0'):
        if os.path.exists(path):
            return path
    return ''

def _read_dvb_audio_status(fd):
    data = array.array('B', [0] * 32)
    fcntl.ioctl(fd, AUDIO_GET_STATUS, data, True)
    values = struct.unpack('=6i2I', data)
    return dict(zip(('av_sync', 'mute', 'play', 'source', 'channel', 'bypass', 'left', 'right'), values))

def _prepare_dreambox_audio_output():
    """Temporarily free audio from the unrelated satellite PCR/PTS clock."""
    path = _dreambox_primary_audio_device()
    if not path:
        _log('R135 Dreambox driver preparation: primary audio device missing')
        return
    fd = None
    try:
        fd = os.open(path, os.O_RDWR | getattr(os, 'O_NONBLOCK', 0))
        before = _read_dvb_audio_status(fd)
        _log('R135 Dreambox driver before: %s' % before)
        for key, request in (('av_sync', AUDIO_SET_AV_SYNC), ('mute', AUDIO_SET_MUTE)):
            if before[key] not in (0, 1):
                _log('R135 Dreambox driver %s has unexpected value; left unchanged' % key)
                continue
            if before[key] == 1:
                try:
                    fcntl.ioctl(fd, request, 0)
                    with _LOCK:
                        saved = _STATE.setdefault('dream_audio_controls', {}).setdefault(path, {})
                        saved.setdefault(key, int(before[key]))
                    _log('R135 Dreambox driver %s disabled for external audio' % key)
                except Exception as e:
                    _log('R135 Dreambox driver %s control unsupported: %s' % (key, e))
        _log('R135 Dreambox driver prepared: %s' % _read_dvb_audio_status(fd))
    except Exception as e:
        _log('R135 Dreambox driver preparation unavailable (no blind control writes): %s' % e)
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except Exception:
                pass

def _restore_dreambox_audio_controls():
    with _LOCK:
        saved = dict(_STATE.get('dream_audio_controls') or {})
        _STATE['dream_audio_controls'] = {}
    for path, values in saved.items():
        fd = None
        try:
            fd = os.open(path, os.O_RDWR | getattr(os, 'O_NONBLOCK', 0))
            for key, request in (('av_sync', AUDIO_SET_AV_SYNC), ('mute', AUDIO_SET_MUTE)):
                value = int(values.get(key, -1))
                if value in (0, 1):
                    try:
                        fcntl.ioctl(fd, request, value)
                    except Exception as e:
                        _log('R135 Dreambox driver %s restore failed: %s' % (key, e))
            _log('R135 Dreambox driver controls restored on %s' % path)
        except Exception as e:
            _log('R135 Dreambox driver control restore failed: %s' % e)
        finally:
            if fd is not None:
                try:
                    os.close(fd)
                except Exception:
                    pass

def _log_dreambox_audio_driver(stage):
    """Read decoder state and PTS while the sink owns its write descriptor."""
    fd = None
    try:
        path = _dreambox_primary_audio_device()
        if not path:
            return
        fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NONBLOCK', 0))
        status = _read_dvb_audio_status(fd)
        _log('R135 Dreambox driver %s: %s' % (stage, status))
        try:
            pts = array.array('B', [0] * 8)
            fcntl.ioctl(fd, AUDIO_GET_PTS, pts, True)
            _log('R135 Dreambox decoder PTS %s=%d' % (stage, struct.unpack('=Q', pts)[0]))
        except Exception as e:
            _log('R135 Dreambox decoder PTS read unsupported: %s' % e)
    except Exception as e:
        _log('R135 Dreambox driver read-only diagnostics unavailable: %s' % e)
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except Exception:
                pass

def _dvb_audio_devices():
    devices = []
    for pattern in ('/dev/dvb/adapter*/audio*', '/dev/dvb/card*/audio*'):
        for path in sorted(glob.glob(pattern)):
            if os.path.exists(path) and path not in devices:
                devices.append(path)
    return devices

def _ioctl_audio(path, request, arg=None):
    fd = None
    try:
        fd = os.open(path, os.O_RDWR | getattr(os, 'O_NONBLOCK', 0))
        if arg is None:
            fcntl.ioctl(fd, request)
        else:
            fcntl.ioctl(fd, request, arg)
        return True
    except Exception as e:
        _log('DVB ioctl failed %s 0x%x: %s' % (path, int(request), e))
        return False
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except Exception:
                pass
_NOVALER_HISI_PROFILE = None

def _novaler_profile_signature(signature):
    ident = re.sub('[^a-z0-9]', '', str(signature).lower())
    return 'novaler' in ident and any((chip in ident for chip in ('hi3798', 'hi3796', 'hisilicon')))

def _is_novaler_hisi_receiver():
    global _NOVALER_HISI_PROFILE
    if _NOVALER_HISI_PROFILE is None:
        try:
            from .receivercompat import receiver_signature
            _NOVALER_HISI_PROFILE = _novaler_profile_signature(receiver_signature())
        except Exception:
            _NOVALER_HISI_PROFILE = None
    return bool(_NOVALER_HISI_PROFILE)

def _novaler_request_active(epoch):
    with _LOCK:
        return bool(_STATE.get('wanted')) and _STATE.get('novaler_epoch', 0) == epoch

def _novaler_track(procs, epoch):
    with _LOCK:
        accepted = bool(_STATE.get('wanted')) and _STATE.get('novaler_epoch', 0) == epoch
        if accepted:
            _STATE['procs'] = list(procs)
    if not accepted:
        _terminate_procs(procs)
        raise RuntimeError('Novaler audio request cancelled')

def _set_dvb_decoder_stopped(stopped):
    """Stop/play only DVB audio decoding; never touch the global mixer."""
    if _is_novaler_hisi_receiver():
        _log('NOVALER1 raw DVB audio ioctl bypassed; service-level handoff only')
        return False
    devices = _dvb_audio_devices()
    success = False
    primary = next((path for path in devices if path.endswith('/audio0')), devices[0] if devices else None)
    for path in devices:
        if stopped:
            _ioctl_audio(path, AUDIO_SET_MUTE, 0)
            stopped_ok = _ioctl_audio(path, AUDIO_STOP)
            if path == primary:
                success = bool(stopped_ok)
        else:
            played_ok = _ioctl_audio(path, AUDIO_PLAY)
            if path == primary:
                success = bool(played_ok)
            _ioctl_audio(path, AUDIO_SET_MUTE, 0)
    with _LOCK:
        _STATE['dvb_stopped'] = bool(stopped and success)
        _STATE['dvb_devices'] = devices
    if devices:
        _log('DVB audio %s on %s' % ('STOP' if stopped else 'PLAY', ','.join(devices)))
    else:
        _log('No DVB audio device nodes found')
    return success

def _audio_preferences():
    with _LOCK:
        options = _STATE.get('audio_options')
    if isinstance(options, dict):
        return dict(options)
    try:
        from .playbacksettings import load_preferences
        return load_preferences()
    except ImportError:
        return {'audio_mode': 'auto', 'alsa_device': ''}

def _alsa_playback_devices(ignore_preference=False):
    """Return ALSA PCM candidates discovered from both procfs and aplay -L.

    OpenATV/ARM images do not always expose /proc/asound/pcm even when named
    ALSA routes exist. R15 therefore tried only 'default' on the test box and
    immediately fell back to the Enigma2/GStreamer sink. R16 probes the image's
    own ALSA names before giving up, which is the best chance for a truly
    independent PCM path that keeps playing while native Timeshift pauses DVB.
    """
    candidates = ['plughw:0,0', 'hw:0,0']
    try:
        data = open('/proc/asound/pcm', 'r').read().splitlines()
        for line in data:
            m = re.match('\\s*(\\d+)-(\\d+):.*\\bplayback\\s+\\d+', line, re.I)
            if not m:
                continue
            card = int(m.group(1))
            dev = int(m.group(2))
            for value in ('plughw:%d,%d' % (card, dev), 'hw:%d,%d' % (card, dev)):
                if value not in candidates:
                    candidates.append(value)
    except Exception as e:
        _log('Unable to read /proc/asound/pcm: %s' % e)
    aplay = _find_executable(('aplay',))
    if aplay:
        try:
            proc = subprocess.Popen([aplay, '-L'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)
            try:
                out, _err = proc.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                _terminate_procs([proc])
                raise RuntimeError('ALSA device enumeration timed out')
            try:
                if not isinstance(out, str):
                    out = out.decode('utf-8', 'ignore')
            except Exception:
                out = str(out or '')
            named = []
            for line in str(out or '').splitlines():
                if not line or line[:1].isspace():
                    continue
                name = line.strip()
                low = name.lower()
                if not name or low == 'null':
                    continue
                if any((low.startswith(x) for x in ('hdmi', 'iec958', 'sysdefault', 'default', 'front', 'dmix', 'plug'))):
                    named.append(name)
            named.sort(key=lambda x: (0 if x.lower().startswith(('hdmi', 'iec958', 'sysdefault')) else 1, 1 if x.lower() == 'default' else 0, x))
            for name in named[:16]:
                if name not in candidates:
                    candidates.append(name)
        except Exception as e:
            _log('aplay -L probe failed: %s' % e)
    if 'default' not in candidates:
        candidates.append('default')
    _log('R31P7 ALSA candidates: %s' % (', '.join(candidates) if candidates else 'none'))
    if not ignore_preference:
        selected = _audio_preferences().get('alsa_device')
        if selected:
            return [selected]
    return candidates

def _is_independent_audio_backend(backend=None):
    """True only when IPTV sound is outside the DVB decoder ownership chain."""
    if backend is None:
        with _LOCK:
            backend = str(_STATE.get('backend') or '')
    return 'ALSA-independent' in str(backend or '')

def _release_enigma_alsa_output():
    """Release Enigma2's optional ALSA singleton before opening our PCM sink.

    Some OpenATV/Vu+ builds export eAlsaOutput even though normal DVB playback
    uses dvbaudiosink.  IPAudio 7.4 closes this singleton before starting its
    ALSA renderer.  Do the same when available, without stopping or retuning
    the current DVB service.
    """
    try:
        from enigma import eAlsaOutput
        output = eAlsaOutput.getInstance()
        if output is None:
            return False
        for name in ('stop', 'close'):
            method = getattr(output, name, None)
            if callable(method):
                method()
        _log('R31P7 released Enigma2 eAlsaOutput without service retune')
        return True
    except Exception as e:
        _log('R31P7 eAlsaOutput release unavailable: %s' % e)
        return False

def _current_service_string(session):
    try:
        ref = session.nav.getCurrentlyPlayingServiceReference() if session else None
        return ref.toString() if ref else ''
    except Exception:
        return ''

def _native_timeshift_enabled(session):
    """Read native Enigma2 Timeshift state without changing playback.

    OpenATV keeps the authoritative controller on InfoBar.  Older Enigma2
    images expose only iTimeshift on the current service, so retain that
    read-only fallback for the same IPK/Python source.
    """
    try:
        from Screens.InfoBar import InfoBar
        infobar = getattr(InfoBar, 'instance', None)
        if infobar is not None:
            # r223-py27: DreamOS / OpenPLi keep the flag in timeshift_enabled,
            # OpenATV uses timeshiftEnabled()/ptsGetTimeshiftStatus().
            for name in ('timeshiftEnabled', 'ptsGetTimeshiftStatus', 'timeshift_enabled', 'isTimeshiftEnabled'):
                value = getattr(infobar, name, None)
                if callable(value):
                    value = value()
                if isinstance(value, (list, tuple)):
                    value = value[-1] if value else False
                if value:
                    return True
    except Exception:
        pass
    try:
        service = session.nav.getCurrentService() if session and getattr(session, 'nav', None) else None
        getter = getattr(service, 'timeshift', None)
        timeshift = getter() if callable(getter) else None
        if timeshift is None:
            return False
        for name in ('isTimeshiftEnabled', 'isTimeshiftActive'):
            enabled = getattr(timeshift, name, None)
            if enabled is None:
                continue
            if bool(enabled() if callable(enabled) else enabled):
                return True
        return False
    except Exception:
        return False

def _infobar_pause_state():
    """Return True/False for InfoBar Pause/Play, or None when unavailable."""
    try:
        from Screens.InfoBar import InfoBar
        infobar = getattr(InfoBar, 'instance', None)
        if infobar is None:
            return None
        seekstate = getattr(infobar, 'seekstate', None)
        pause_state = getattr(infobar, 'SEEK_STATE_PAUSE', None)
        play_state = getattr(infobar, 'SEEK_STATE_PLAY', None)
        if pause_state is not None and seekstate == pause_state:
            return True
        if play_state is not None and seekstate == play_state:
            return False
        if isinstance(seekstate, (list, tuple)) and seekstate:
            marker = str(seekstate[-1])
            if marker == '||':
                return True
            if marker == '>':
                return False
    except Exception:
        pass
    return None

def _is_dvb_service_string(service_ref):
    """Return True only for native Enigma2 DVB services.

    IPAudio is designed to sit beside a native satellite service (type 1).
    Streaming/file players use service types such as 4097/5001/5002 and need
    exclusive access to their own A/V pipeline.
    """
    value = str(service_ref or '').strip()
    if not value or ':' not in value:
        return False
    try:
        return int(value.split(':', 1)[0]) == 1
    except Exception:
        return False

def _terminate_procs(procs):
    for proc in reversed(list(procs or [])):
        try:
            if proc.poll() is None:
                proc.terminate()
        except Exception:
            pass
    for proc in reversed(list(procs or [])):
        try:
            if proc.poll() is None:
                proc.kill()
        except Exception:
            pass

def _stop_processes_only():
    with _LOCK:
        procs = list(_STATE.get('procs', []))
        _STATE['procs'] = []
        _STATE['backend'] = ''
        _STATE['bridge_port'] = 0
        _STATE['sink_retry_count'] = 0
        _STATE['sink_handoff_until'] = 0.0
        _STATE['vu_handoff_phase'] = ''
        _STATE['vu_handoff_action'] = ''
        _STATE['vu_handoff_started'] = 0.0
    _terminate_procs(procs)

def _alive_procs():
    with _LOCK:
        old = list(_STATE.get('procs', []))
        wanted = bool(_STATE.get('wanted'))
        backend = str(_STATE.get('backend') or '')
        sink_handoff_until = float(_STATE.get('sink_handoff_until') or 0.0)
    if not old:
        return []
    if ('DVB-verified' in backend or 'PCM-verified' in backend or 'ALSA-verified' in backend) and len(old) == 2:
        with _LOCK:
            isolated = bool(_STATE.get('e2_audio_disabled'))
        with _LOCK:
            dreamos_stop = bool(_STATE.get('dreamos_audio_stop'))
        if isolated and dreamos_stop:
            isolated = _dreamos_audio_stop_verified()
        flow = getattr(old[0], '_alkuds_audio_progress', {})
        stalled = bool(('MP2 parsed' in backend or 'PCM-verified' in backend or 'Octagon DVB-verified' in backend) and (not _audio_output_ready(old[0]) or time.time() - float(flow.get('last') or 0.0) > 15.0))
        ownership = _process_alsa_pcm_ownership(old[1]) if 'PCM-verified' in backend or 'ALSA-verified' in backend else _process_dvb_audio_ownership(old[1])
        if not isolated or stalled or ownership is not True:
            if wanted and dreamos_stop and not isolated and not stalled and ownership is True and len(_alive_list(old)) == 2:
                from .flashbackpvr import audio_handoff_pending
                with _LOCK:
                    session = _STATE.get('session')
                if audio_handoff_pending(session):
                    # The controller still requires STOP acknowledgement before
                    # seeking. Preserve healthy PCM processes during that wait.
                    return old
            if wanted and 'Octagon DVB-verified' in backend and (not stalled) and (sink_handoff_until > time.time()) and (old[0].poll() is None):
                return _alive_list(old)
            _log('R133 Dreambox audio output lost: isolation=%s; stopping unverified chain' % isolated)
            _terminate_procs(old)
            with _LOCK:
                _STATE['procs'] = []
                _STATE['status_error'] = 'Dreambox audio input stopped producing output' if stalled else 'Dreambox audio output is not acquired'
                _STATE['status_error_until'] = time.time() + 10.0
            return []
    alive = []
    dead = []
    for index, proc in enumerate(old):
        try:
            exit_code = proc.poll()
            if exit_code is None:
                alive.append(proc)
            else:
                dead.append(proc)
                role = 'input' if index == 0 and len(old) > 1 else 'renderer'
                _log('R132 audio process exited: role=%s index=%d code=%s' % (role, index, exit_code))
        except Exception:
            dead.append(proc)
            _log('R132 audio process status unavailable: index=%d' % index)
    if dead and len(old) > 1:
        provider = old[0]
        if wanted and any((proc is provider for proc in dead)):
            _record_provider_failure(provider)
        provider_alive = any((proc is provider for proc in alive))
        provider_dead = any((proc is provider for proc in dead))
        vu_sink_grace = bool(wanted and 'local MP2 TS' in backend and (sink_handoff_until > time.time()) and provider_alive and (not provider_dead))
        if vu_sink_grace:
            _terminate_procs([proc for proc in alive if proc is not provider])
            alive = [provider]
            _log('R31P6 Vu+ late sink exit during native Timeshift; provider preserved, sink retry armed')
            _arm_pause_key_timer(420)
        else:
            _log('R19 audio pipeline member exited; restarting whole bridge')
            _terminate_procs(alive)
            alive = []
    with _LOCK:
        _STATE['procs'] = alive
    return alive

def _is_mac_portal_audio():
    """Return True for the Stalker/MAC IPAUDIO path.

    MAC streams carry portal headers/cookies.  Xtream does not.  The distinction
    matters on the OpenATV 8 ARM test receiver: R17 AUDIO_CONTINUE keeps Xtream
    audio alive during native Timeshift, but on MAC it re-enables the original
    satellite audio decoder.  R19 therefore preserves the proven Xtream path
    and gives MAC a sink-only handoff with no DVB audio ioctl after Pause/Play.
    """
    with _LOCK:
        headers = dict(_STATE.get('headers') or {})
    keys = set([str(x) for x in headers.keys()])
    return bool(keys.intersection(set(['Cookie', 'X-User-Agent', 'Authorization'])))

def _continue_xtream_audio_after_pause():
    """Preserve the R17 behavior that was proven working for Xtream."""
    with _LOCK:
        wanted = bool(_STATE.get('wanted'))
        backend = str(_STATE.get('backend') or '')
    if not wanted:
        return
    if 'GStreamer' not in backend and 'FFplay' not in backend:
        return
    ok = False
    for path in _dvb_audio_devices():
        if _ioctl_audio(path, AUDIO_CONTINUE):
            ok = True
    _log('R19 Xtream Timeshift isolation: AUDIO_CONTINUE %s (backend=%s)' % ('applied' if ok else 'not-supported', backend))

def _process_dvb_audio_ownership(proc):
    """Return whether *proc* really owns a DVB audio fd, or None if unknown.

    Vu+'s dvbaudiosink returns a live GStreamer process even when opening
    audio0 failed with EBUSY.  Process liveness therefore cannot prove that
    sound was recovered.  Reading the process fd table is non-invasive and is
    available on the root-run Enigma2 images; retain an unknown result for old
    images that restrict procfs so their previous behavior remains intact.
    """
    try:
        pid = int(getattr(proc, 'pid', 0) or 0)
    except Exception:
        pid = 0
    devices = set([os.path.realpath(path) for path in _dvb_audio_devices()])
    if pid <= 0 or not devices:
        return None
    fd_dir = '/proc/%d/fd' % pid
    try:
        entries = os.listdir(fd_dir)
    except Exception:
        return None
    for entry in entries:
        try:
            target = os.path.realpath(os.path.join(fd_dir, entry))
            if target in devices:
                return True
        except Exception:
            pass
    return False

def _wait_for_dvb_audio_ownership(proc, attempts=12, delay=0.12):
    """Wait briefly for dvbaudiosink to open audio0 after parsing the TS."""
    last = None
    for _index in range(max(1, int(attempts))):
        try:
            if proc.poll() is not None:
                return False
        except Exception:
            return False
        last = _process_dvb_audio_ownership(proc)
        if last is True or last is None:
            return last
        time.sleep(float(delay))
    return False

def _alsa_pcm_nodes():
    nodes = []
    for path in sorted(glob.glob('/dev/snd/pcmC*D*p')):
        try:
            real = os.path.realpath(path)
        except Exception:
            real = path
        if real not in nodes:
            nodes.append(real)
    return nodes

def _process_alsa_pcm_ownership(proc):
    """Return whether *proc* owns an ALSA playback PCM, or None if unknown."""
    try:
        pid = int(getattr(proc, 'pid', 0) or 0)
    except Exception:
        pid = 0
    devices = set(_alsa_pcm_nodes())
    if pid <= 0 or not devices:
        return None
    fd_dir = '/proc/%d/fd' % pid
    try:
        entries = os.listdir(fd_dir)
    except Exception:
        return None
    for entry in entries:
        try:
            target = os.path.realpath(os.path.join(fd_dir, entry))
            if target in devices:
                return True
        except Exception:
            pass
    return False

def _wait_for_alsa_pcm_ownership(sink, provider=None, attempts=32, delay=0.1):
    """Wait until alsasink has decoded the local TS and opened a PCM node.

    When old images hide /proc fd information the result remains unknown, but
    the full probe window still verifies that both processes stay alive.
    """
    last = None
    for _index in range(max(1, int(attempts))):
        for proc in (provider, sink):
            if proc is None:
                continue
            try:
                if proc.poll() is not None:
                    return False
            except Exception:
                return False
        last = _process_alsa_pcm_ownership(sink)
        if last is True:
            return True
        time.sleep(float(delay))
    return last

def _is_local_dvb_bridge(backend):
    return 'local MP2 TS' in str(backend or '') or 'Octagon DVB-verified' in str(backend or '')

def mark_video_audio_transition():
    with _LOCK:
        if _STATE.get('wanted') and 'Octagon DVB-verified' in str(_STATE.get('backend') or ''):
            _STATE['sink_handoff_until'] = time.time() + 5.0

def _queue_octagon_sink_recovery():
    with _LOCK:
        if not _STATE.get('wanted') or 'Octagon DVB-verified' not in str(_STATE.get('backend') or ''):
            return False
        epoch = _STATE.get('audio_epoch', 0)
        if _STATE.get('sink_recovery_epoch') == epoch and _STATE.get('sink_recovery_pending'):
            return True
        _STATE.update(sink_recovery_pending=True, sink_recovery_epoch=epoch, sink_handoff_until=time.time() + 5.0)

    def recover():
        try:
            with _BACKEND_LOCK:
                for attempt in range(3):
                    if not _audio_request_current(epoch):
                        return
                    if _restart_local_gstreamer_sink(worker_recovery=True):
                        with _LOCK:
                            if _STATE.get('audio_epoch', 0) == epoch:
                                _STATE.update(error='', status_error='', status_error_until=0.0, sink_handoff_until=0.0)
                        return
                    time.sleep(0.25)
                if _audio_request_current(epoch):
                    with _LOCK:
                        _STATE['error'] = 'Audio output recovery failed; select Automatic or retry audio'
                        _STATE['status_error'] = _STATE['error']
                        _STATE['status_error_until'] = time.time() + 15.0
        except Exception as error:
            if _audio_request_current(epoch):
                with _LOCK:
                    _STATE['error'] = 'Local audio renderer recovery failed: ' + type(error).__name__
                    _STATE['status_error'] = _STATE['error']
                    _STATE['status_error_until'] = time.time() + 15.0
            _log('FIX9 local renderer recovery worker failed: ' + type(error).__name__)
        finally:
            with _LOCK:
                if _STATE.get('sink_recovery_epoch') == epoch:
                    _STATE['sink_recovery_pending'] = False
    worker = threading.Thread(target=recover)
    worker.daemon = True
    worker.start()
    _log('FIX9 queued local AAC/DVB sink recovery; provider and recording retained')
    return True

def _restart_local_gstreamer_sink(worker_recovery=False):
    """Restart only the local GStreamer audio sink after native Timeshift.

    The provider-side FFmpeg process and the Stalker/MAC create_link connection
    stay open.  This is intentionally NOT a full audio restart: reopening the
    provider can consume/invalidate a session-bound MAC URL.  On Vu+ R25/R31,
    Enigma2 has already released its audio PID and GStreamer owns audio0.  A
    native Pause can pause that hardware decoder, while a second-process ioctl
    is rejected with EBUSY.  Recreating only playbin makes dvbaudiosink issue
    its own PLAY transition through the descriptor it owns.  This works for
    Xtream/direct feeds as well as MAC, and never touches the DVB video graph.
    """
    gst = _find_executable(('gst-launch-1.0',))
    if not gst:
        _log('R31P6 local sink handoff skipped: gst-launch-1.0 missing')
        return False
    with _LOCK:
        wanted = bool(_STATE.get('wanted'))
        backend = str(_STATE.get('backend') or '')
        port = int(_STATE.get('bridge_port') or 0)
        procs = list(_STATE.get('procs', []))
    if not wanted:
        return False
    if not _is_local_dvb_bridge(backend) or port <= 0 or len(procs) < 1:
        _log('R31P6 local sink handoff unavailable backend=%s port=%s procs=%s' % (backend, port, len(procs)))
        return False
    provider = procs[0]
    old_sink = procs[1] if len(procs) > 1 else None
    try:
        if provider.poll() is not None:
            _log('R31P6 local sink handoff aborted: provider already exited=%s' % provider.poll())
            _schedule_restart(0.05)
            return False
    except Exception:
        _schedule_restart(0.05)
        return False
    with _LOCK:
        current = list(_STATE.get('procs', []))
        if not current or current[0] is not provider:
            _log('R31P6 local sink handoff cancelled: audio pipeline changed')
            return False
        _STATE['procs'] = [provider]
    if old_sink is not None:
        _terminate_procs([old_sink])
    if _is_dreambox_arm_receiver():
        _prepare_dreambox_audio_output()
    null_in = _devnull(read=True)
    null_out = _devnull(read=False)
    logfh = _spawn_log_handle()
    new_sink = None
    try:
        args = [gst, '-q', 'playbin', 'uri=udp://127.0.0.1:%d' % port, 'flags=2']
        dreambox = _is_dreambox_arm_receiver()
        octagon = _is_octagon_egami_receiver()
        if octagon:
            args += ['audio-sink=dvbaudiosink sync=false']
        if dreambox:
            args = _dreambox_gstreamer_args(gst, port)
        new_sink = subprocess.Popen(args, stdin=null_in, stdout=null_out, stderr=logfh, close_fds=True)
        time.sleep(0.22)
        if new_sink.poll() is not None:
            raise RuntimeError('replacement GStreamer exited %s' % new_sink.poll())
        audio_owned = None
        if _is_vuplus_receiver() or dreambox or octagon:
            audio_owned = _wait_for_dvb_audio_ownership(new_sink)
            if audio_owned is False or ((dreambox or octagon) and audio_owned is not True):
                raise RuntimeError('replacement GStreamer is alive but did not acquire DVB audio0')
        with _LOCK:
            if not _STATE.get('wanted'):
                discard = True
            else:
                current = list(_STATE.get('procs', []))
                discard = not current or current[0] is not provider
                if not discard:
                    _STATE['procs'] = [provider, new_sink]
                    _STATE['sink_retry_count'] = 0
        if discard:
            _terminate_procs([new_sink])
            return False
        _log('R31P6 native Timeshift: local GStreamer sink reacquired audio0_owned=%s; provider connection preserved' % audio_owned)
        return True
    except Exception as e:
        _terminate_procs([new_sink] if new_sink is not None else [])
        with _LOCK:
            retries = int(_STATE.get('sink_retry_count') or 0) + 1
            _STATE['sink_retry_count'] = retries
        _log('R31P6 local sink handoff failed attempt=%s: %s' % (retries, e))
        if retries <= 3 and (not worker_recovery):
            _arm_pause_key_timer(450 + retries * 180)
        else:
            _log('R31P6 local sink retry limit reached; provider connection remains open')
        return False
    finally:
        try:
            if logfh is not None and logfh is not _DEVNULL_W:
                logfh.close()
        except Exception:
            pass
_restart_mac_local_gstreamer_sink = _restart_local_gstreamer_sink

def prepare_video_delay_transition():
    """Guard programmatic timeshift without destroying the provider connection."""
    with _LOCK:
        wanted, session = (bool(_STATE.get('wanted')), _STATE.get('session'))
    if not wanted:
        return
    mark_video_audio_transition()
    _set_enigma_service_audio(session, False)
    if _is_vuplus_receiver() and (not _is_independent_audio_backend()):
        _named_timeshift_action('InfobarSeekActions', 'playpauseService')

def recover_video_delay_audio(recover_sink=False):
    """Scoped post-timeshift recovery; ordinary remote Pause behavior unchanged."""
    with _LOCK:
        wanted = bool(_STATE.get('wanted'))
        session = _STATE.get('session')
        backend = str(_STATE.get('backend') or '')
    if not wanted:
        return
    isolated = _set_enigma_service_audio(session, False)
    if recover_sink and 'Octagon DVB-verified' in backend:
        _queue_octagon_sink_recovery()
        return
    if _is_independent_audio_backend(backend):
        _release_enigma_alsa_output()
        if _is_dreambox_arm_receiver():
            from .flashbackpvr import video_only_service
            if not video_only_service(session):
                _prepare_dreambox_audio_output()
        _log('R165 Video Delay: PCM provider/sink preserved; isolation=%s' % bool(isolated))
    elif recover_sink:
        if 'local MP2 TS' in backend:
            _restart_local_gstreamer_sink()
        elif not _is_vuplus_receiver():
            _continue_xtream_audio_after_pause()

def _pause_key_timer_fire():
    try:
        if _is_dreambox_arm_receiver():
            with _LOCK:
                session = _STATE.get('session')
            if _set_enigma_service_audio(session, False):
                if _is_independent_audio_backend():
                    _log('R136 Dreambox Pause/Play: independent PCM output kept open')
                else:
                    _restart_local_gstreamer_sink()
            else:
                _log('R133 Dreambox Pause/Play: satellite audio release failed')
                _stop_processes_only()
                report_start_error('Dreambox satellite audio could not be released')
            return
        if _is_independent_audio_backend():
            with _LOCK:
                session = _STATE.get('session')
            isolated = _set_enigma_service_audio(session, False)
            _log('R31P7 Pause/Play: independent ALSA untouched; DVB audio isolation=%s' % bool(isolated))
            return
        if _is_vuplus_receiver():
            _restart_local_gstreamer_sink()
        elif _is_mac_portal_audio():
            _restart_local_gstreamer_sink()
        else:
            _continue_xtream_audio_after_pause()
    except Exception as e:
        _log('R31P7 pause-isolation timer failed: %s' % e)

def _arm_pause_key_timer(delay_ms=180):
    global _KEY_TIMER, _KEY_TIMER_CONN
    if _KEY_TIMER is None:
        _KEY_TIMER = eTimer()
        try:
            _KEY_TIMER_CONN = _KEY_TIMER.timeout.connect(_pause_key_timer_fire)
        except Exception:
            _KEY_TIMER.callback.append(_pause_key_timer_fire)
    try:
        _KEY_TIMER.stop()
    except Exception:
        pass
    try:
        _KEY_TIMER.start(int(delay_ms), True)
    except Exception:
        pass

def _arm_vu_handoff_timer(delay_ms):
    """Schedule the next non-blocking stage of the Vu+ decoder handoff."""
    global _VU_HANDOFF_TIMER, _VU_HANDOFF_TIMER_CONN
    if _VU_HANDOFF_TIMER is None:
        _VU_HANDOFF_TIMER = eTimer()
        try:
            _VU_HANDOFF_TIMER_CONN = _VU_HANDOFF_TIMER.timeout.connect(_vu_handoff_timer_fire)
        except Exception:
            _VU_HANDOFF_TIMER.callback.append(_vu_handoff_timer_fire)
    try:
        _VU_HANDOFF_TIMER.stop()
    except Exception:
        pass
    try:
        _VU_HANDOFF_TIMER.start(int(delay_ms), True)
    except Exception as e:
        _log('R31P6 Vu+ handoff timer failed: %s' % e)

def _begin_vu_native_timeshift_handoff(action=''):
    """Release only playbin before OpenATV handles the original key.

    Solo 4K exposes one Broadcom audio decoder node.  If native Timeshift is
    activated while GStreamer's dvbaudiosink owns audio0, the driver pauses
    that audio descriptor but fails to switch the video decoder.  Preserve the
    provider FFmpeg/MAC session, close only playbin, then let InfoBar switch the
    native video graph before the local sink is reacquired.
    """
    current_pause = _infobar_pause_state()
    if action == 'pauseService':
        expected_pause = True
    elif action == 'playpauseService' and current_pause is not None:
        expected_pause = not current_pause
    else:
        expected_pause = None
    with _LOCK:
        wanted = bool(_STATE.get('wanted'))
        backend = str(_STATE.get('backend') or '')
        procs = list(_STATE.get('procs', []))
        pending = str(_STATE.get('vu_handoff_phase') or '')
    if _is_independent_audio_backend(backend):
        _log('R31P7 Vu+ native Timeshift: no sink handoff for independent ALSA')
        return False
    if not wanted or 'local MP2 TS' not in backend or (not procs):
        return False
    if pending:
        _log('R31P6 Vu+ additional Pause/Play passed through during handoff phase=%s' % pending)
        return True
    provider = procs[0]
    try:
        if provider.poll() is not None:
            _log('R31P6 Vu+ pre-handoff aborted: provider exited=%s' % provider.poll())
            _schedule_restart(0.05)
            return False
    except Exception:
        _schedule_restart(0.05)
        return False
    sinks = procs[1:]
    with _LOCK:
        current = list(_STATE.get('procs', []))
        if not current or current[0] is not provider:
            return False
        _STATE['procs'] = [provider]
        _STATE['sink_retry_count'] = 0
        _STATE['sink_handoff_until'] = time.time() + 12.0
        _STATE['vu_handoff_phase'] = 'wait-native'
        _STATE['vu_handoff_action'] = str(action or '')
        _STATE['vu_handoff_started'] = time.time()
        _STATE['vu_video_paused'] = expected_pause
    _terminate_procs(sinks)
    _log('R31P6 Vu+ pre-handoff: local sink released; provider preserved; original key continues to OpenATV')
    _arm_vu_handoff_timer(350)
    return True

def _vu_handoff_timer_fire():
    """Wait for OpenATV's native transition, then recover local audio."""
    with _LOCK:
        wanted = bool(_STATE.get('wanted'))
        phase = str(_STATE.get('vu_handoff_phase') or '')
        session = _STATE.get('session')
    if not wanted or not phase:
        with _LOCK:
            _STATE['vu_handoff_phase'] = ''
            _STATE['vu_handoff_action'] = ''
            _STATE['vu_handoff_started'] = 0.0
        return
    if phase == 'wait-native':
        with _LOCK:
            started = float(_STATE.get('vu_handoff_started') or 0.0)
            action_name = str(_STATE.get('vu_handoff_action') or '')
            expected_pause = _STATE.get('vu_video_paused')
        elapsed = max(0.0, time.time() - started) if started else 99.0
        native_enabled = _native_timeshift_enabled(session)
        pause_state = _infobar_pause_state()
        transition_ready = bool(native_enabled and (expected_pause is None or pause_state is None or pause_state == expected_pause))
        if not transition_ready and elapsed < 4.2:
            _log('R31P6 Vu+ waiting for OpenATV transition action=%s enabled=%s pause=%s expected=%s elapsed=%.1fs' % (action_name, bool(native_enabled), pause_state, expected_pause, elapsed))
            _arm_vu_handoff_timer(350)
            return
        isolated = _set_enigma_service_audio(session, False)
        with _LOCK:
            if _STATE.get('vu_handoff_phase') == 'wait-native':
                _STATE['vu_handoff_phase'] = 'sink'
        _log('R31P6 Vu+ OpenATV transition ready=%s action=%s enabled=%s pause=%s expected=%s elapsed=%.1fs; audio-only isolation=%s' % (bool(transition_ready), action_name, bool(native_enabled), pause_state, expected_pause, elapsed, bool(isolated)))
        _arm_vu_handoff_timer(220)
        return
    if phase == 'sink':
        recovered = _restart_local_gstreamer_sink()
        with _LOCK:
            _STATE['vu_handoff_phase'] = ''
            _STATE['vu_handoff_action'] = ''
            _STATE['vu_handoff_started'] = 0.0
            _STATE['vu_video_paused'] = False
        _log('R31P6 Vu+ handoff complete sink_recovered=%s provider_preserved=True' % bool(recovered))
        return
    _log('R31P6 Vu+ unknown handoff phase=%s; clearing' % phase)
    with _LOCK:
        _STATE['vu_handoff_phase'] = ''
        _STATE['vu_handoff_action'] = ''
        _STATE['vu_handoff_started'] = 0.0

def _named_timeshift_action(context, action):
    """R185: native Timeshift keys belong exclusively to Enigma2."""
    return 0

def _stop_key_timer_fire():
    try:
        stop_background_audio(restore_main=True)
    except Exception as error:
        _log('R186 audio STOP failed: %s' % error)

def _arm_stop_key_timer(delay_ms=40):
    global _STOP_TIMER, _STOP_TIMER_CONN
    if _STOP_TIMER is None:
        _STOP_TIMER = eTimer()
        try:
            _STOP_TIMER_CONN = _STOP_TIMER.timeout.connect(_stop_key_timer_fire)
        except Exception:
            _STOP_TIMER.callback.append(_stop_key_timer_fire)
    try:
        _STOP_TIMER.stop()
    except Exception:
        pass
    try:
        _STOP_TIMER.start(int(delay_ms), True)
    except Exception:
        pass

def _raw_timeshift_key(key, flag):
    if key in (128, 166) and flag == 0:
        with _LOCK:
            wanted = bool(_STATE.get('wanted'))
        if wanted:
            _arm_stop_key_timer()
            return 1
    return 0

def _bind_pause_isolation():
    global _KEY_BOUND, _KEY_SLOT
    if eActionMap is not None and (not _KEY_BOUND):
        try:
            _KEY_SLOT = eActionMap.getInstance().bindAction('', -2147483646, _raw_timeshift_key)
            _KEY_BOUND = True
        except Exception as error:
            _log('R186 audio STOP bind failed: %s' % error)

def _unbind_pause_isolation():
    global _KEY_BOUND, _NAMED_KEY_BOUND, _KEY_SLOT
    _KEY_SLOT = None
    if eActionMap is None:
        _KEY_BOUND = False
        _NAMED_KEY_BOUND = False
        return
    if _KEY_BOUND:
        try:
            eActionMap.getInstance().unbindAction('', _raw_timeshift_key)
        except Exception:
            pass
    if _NAMED_KEY_BOUND:
        try:
            eActionMap.getInstance().unbindAction('InfobarSeekActions', _named_timeshift_action)
        except Exception:
            pass
    _KEY_BOUND = False
    _NAMED_KEY_BOUND = False

def _ensure_timer():
    global _TIMER, _TIMER_CONN
    if _TIMER is None:
        _TIMER = eTimer()
        try:
            _TIMER_CONN = _TIMER.timeout.connect(_watchdog_tick)
        except Exception:
            _TIMER.callback.append(_watchdog_tick)
    try:
        _TIMER.start(350, False)
    except Exception:
        pass

def _stop_timer():
    if _TIMER is not None:
        try:
            _TIMER.stop()
        except Exception:
            pass

def arm_background_audio(session, channel_name='IPTV', headers=None, resume_context=None, retry_resolver=None, preserve_delay_controller=False):
    from .playbacksettings import load_preferences
    audio_options = load_preferences()
    current_service = _current_service_string(session)
    native_timeshift = _native_timeshift_enabled(session)
    if current_service and (not _is_dvb_service_string(current_service)) and (not native_timeshift):
        raise RuntimeError('Tune a satellite DVB channel before starting IPAUDIO')
    _stop_processes_only()
    try:
        with open(_LOG, 'w') as log_file:
            log_file.write('')
    except Exception:
        pass
    global _NOVALER_HISI_PROFILE
    _NOVALER_HISI_PROFILE = None
    novaler = _is_novaler_hisi_receiver()
    try:
        with open(os.path.join(os.path.dirname(__file__), 'version.txt')) as stream:
            build = stream.read(128).strip()
    except Exception:
        build = 'r194'
    _log('Alkuds build=%s novaler_hisi=%s; restart GUI after package updates' % (build, novaler))
    with _LOCK:
        _STATE['audio_epoch'] = _STATE.get('audio_epoch', 0) + 1
        if novaler:
            _STATE['novaler_epoch'] = _STATE.get('novaler_epoch', 0) + 1
        _STATE['wanted'] = True
        _STATE['audio_options'] = dict(audio_options)
        _STATE['sink_recovery_pending'] = False
        _STATE['sink_recovery_epoch'] = None
        _STATE['settings_restart_epoch'] = None
        _STATE['settings_restart_failed'] = False
        _STATE['session'] = session
        _STATE['name'] = str(channel_name or 'IPTV')
        _STATE['url'] = ''
        _STATE['pending_url'] = ''
        _STATE['backend'] = ''
        _STATE['dvb_stopped'] = False
        _STATE['dvb_devices'] = []
        _STATE['last_service'] = _current_service_string(session)
        _STATE['restart_due'] = 0.0
        _STATE['provider_failures'] = []
        _STATE['restarting'] = True
        _STATE['error'] = ''
        _STATE['error_reported'] = False
        _STATE['headers'] = dict(headers or {})
        _STATE['retry_resolver'] = retry_resolver if callable(retry_resolver) else None
        _STATE['bridge_port'] = 0
        _STATE['e2_audio_disabled'] = False
        _STATE['resume_context'] = dict(resume_context or {})
        _STATE['sink_retry_count'] = 0
        _STATE['sink_handoff_until'] = 0.0
        _STATE['vu_handoff_phase'] = ''
        _STATE['vu_handoff_action'] = ''
        _STATE['vu_handoff_started'] = 0.0
        _STATE['vu_video_paused'] = False
        _STATE['status_error'] = ''
        _STATE['status_error_until'] = 0.0
        _STATE['status_name'] = str(channel_name or 'IPTV')
    try:
        from .streammonitor import show_ipaudio_status
        show_ipaudio_status(session)
    except Exception as e:
        _log('IPAudio status badge unavailable: %s' % e)
    try:
        from .receivercompat import receiver_signature, is_vuplus
        _log('R31P7 receiver profile vuplus=%s signature=%s' % (bool(is_vuplus()), receiver_signature() or '<unknown>'))
    except Exception:
        _log('R31P7 receiver profile unavailable')
    _log('Arming background audio for %s native_timeshift=%s' % (channel_name, bool(native_timeshift)))
    _log('FIX7 Octagon/Egami native audio route=%s' % _is_octagon_egami_receiver())
    isolated = _release_main_audio_for_ipaudio(session, preserve_timeshift=native_timeshift)
    if (_is_vuplus_receiver() or _is_octagon_egami_receiver() or _is_xconn_receiver() or (audio_options['audio_mode'] != 'auto')) and (not isolated):
        with _LOCK:
            _STATE['wanted'] = False
            _STATE['restarting'] = False
        _log('R194 FIX2 cannot isolate satellite audio on Vu+; refusing mixed playback')
        raise RuntimeError('This image could not release satellite audio. External audio was not started to avoid mixing both sounds.')
    if _is_dreambox_arm_receiver() and (not isolated):
        stop_background_audio(keep_status=True)
        raise RuntimeError('Dreambox satellite audio could not be released through Enigma2')
    if _is_vuplus_receiver() or _is_dreambox_arm_receiver() or _is_xconn_receiver() or (audio_options['audio_mode'] in ('alsa', 'pcm')):
        _release_enigma_alsa_output()
    _bind_pause_isolation()
    _ensure_timer()
    try:
        from .videodelay import arm
        if not preserve_delay_controller:
            arm(session)
    except Exception as error:
        _log('Video delay UI unavailable: %s' % error)

def _ffmpeg_audio_input_args(stream_url, ffmpeg, headers=None):
    args = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin']
    hdrs = dict(headers or {})
    hdrs.pop('_AudioFeedHeaders', None)
    if str(stream_url).lower().startswith(('http://', 'https://')):
        ua = str(hdrs.pop('User-Agent', '') or '').strip()
        if ua:
            args += ['-user_agent', ua]
        extra = []
        for hkey in ('X-User-Agent', 'Cookie', 'Referer', 'Authorization'):
            hval = str(hdrs.get(hkey, '') or '').replace('\r', ' ').replace('\n', ' ').strip()
            if hval:
                extra.append('%s: %s\r\n' % (hkey, hval))
        for hkey, hval in hdrs.items():
            if hkey in ('X-User-Agent', 'Cookie', 'Referer', 'Authorization'):
                continue
            key = str(hkey or '').replace('\r', ' ').replace('\n', ' ').strip()
            val = str(hval or '').replace('\r', ' ').replace('\n', ' ').strip()
            if key and val:
                extra.append('%s: %s\r\n' % (key, val))
        if extra:
            args += ['-headers', ''.join(extra)]
        args += ['-probesize', '262144', '-analyzeduration', '1500000']
    args += ['-i', stream_url]
    return args

def _free_udp_port():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind(('127.0.0.1', 0))
        return int(sock.getsockname()[1])
    finally:
        try:
            sock.close()
        except Exception:
            pass

def _r9_provider_input_args(stream_url, ffmpeg, headers=None):
    """R9-proven provider input profile used by the old audio relay/remux.

    R16's small probe window and forwarding of arbitrary/Authorization headers
    was too fragile on the OpenATV 8 ARM test box.  This intentionally mirrors
    the conservative provider side that already worked in R9/R12: larger
    probing, queueing, and only the Stalker headers known to be safe for the
    resolved media host.
    """
    if str(stream_url).lower().startswith('https://') and _is_dreambox_arm_receiver():
        # DreamOS FFmpeg 3 may have no TLS protocol. Keep TLS in Python and
        # expose the existing bounded localhost relay, including HLS children.
        from .streamproxy import prepare_hls_relay
        stream_url = prepare_hls_relay(stream_url, headers or {}, options={'audio_bridge': True})
        headers = {}
    args = [ffmpeg, '-nostdin', '-hide_banner', '-loglevel', 'warning', '-fflags', '+discardcorrupt+genpts', '-probesize', '4194304', '-analyzeduration', '2000000', '-thread_queue_size', '1024']
    hdrs = dict(headers or {})
    if str(stream_url).lower().startswith(('http://', 'https://')):
        ua = str(hdrs.pop('User-Agent', '') or '').strip()
        if ua:
            args += ['-user_agent', ua]
        extra = []
        explicit_feed = bool(hdrs.pop('_AudioFeedHeaders', False))
        permitted = ('X-User-Agent', 'Cookie', 'Referer')
        if explicit_feed:
            permitted += ('Origin', 'Authorization', 'Accept')
        for hkey in permitted:
            hval = str(hdrs.get(hkey, '') or '').replace('\r', ' ').replace('\n', ' ').strip()
            if hval:
                extra.append('%s: %s\r\n' % (hkey, hval))
        if extra:
            args += ['-headers', ''.join(extra)]
    args += ['-i', stream_url]
    return args

def _record_provider_failure(provider):
    """No video operations: stop rejected sources or back off transient input exits."""
    offset = getattr(provider, '_alkuds_provider_log_offset', None)
    reason = _provider_failure_reason(offset)
    rejected = any((code in reason for code in ('HTTP 401', 'HTTP 403', 'HTTP 404', 'HTTP 410', 'lacks the required audio encoder', 'does not support a requested option')))
    now = time.time()
    with _LOCK:
        history = [stamp for stamp in _STATE.get('provider_failures', []) if 0 <= now - stamp < 60.0]
        history.append(now)
        _STATE['provider_failures'] = history
        terminal = rejected or len(history) >= 3
        if terminal:
            message = reason if rejected else 'Audio input repeatedly stopped. Select the source again to retry.'
            _STATE.update(url='', restart_due=0.0, restarting=False, error=message, status_error=message, status_error_until=now + 10.0)
        else:
            _STATE['restart_due'] = now + min(8.0, 2.0 ** len(history))
    _log('AUDIOFIX2 provider input stopped: retry=%s attempt=%d reason=%s' % ('disabled' if terminal else 'delayed', len(history), reason))

def _provider_failure_reason(offset):
    """Classify only this attempt; never show raw output containing credentials."""
    if offset is None:
        return 'See the current background audio log for the provider error.'
    try:
        with open(_LOG, 'rb') as stream:
            stream.seek(0, 2)
            stream.seek(max(int(offset), stream.tell() - 12288))
            text = stream.read(12288).decode('utf-8', 'replace').lower()
        for needles, reason in ((('401 unauthorized', 'http error 401'), 'Source rejected authentication (HTTP 401).'), (('403 forbidden', 'http error 403'), 'Source denied this request (HTTP 403).'), (('404 not found', 'http error 404'), 'Source stream address was not found (HTTP 404).'), (('410 gone', 'http error 410'), 'Source stream address expired (HTTP 410).'), (('unrecognized option', 'option not found'), 'Installed FFmpeg does not support a requested option.'), (('unknown encoder', 'encoder not found'), 'Installed FFmpeg lacks the required audio encoder.'), (('invalid data found', 'could not find codec parameters'), 'Source did not provide decodable audio.'), (('connection timed out', 'connection refused', 'failed to resolve'), 'Could not connect to the audio source.')):
            if any((needle in text for needle in needles)):
                return reason
    except Exception:
        pass
    return 'See the current background audio log for the provider error.'

def _spawn_log_handle():
    try:
        return open(_LOG, 'a')
    except Exception:
        return _devnull(read=False)

def _gst_has_element(element):
    """Return True when the receiver image exposes a GStreamer element."""
    inspector = _find_executable(('gst-inspect-1.0',))
    if not inspector:
        return False
    try:
        proc = subprocess.Popen([inspector, element], stdin=_devnull(read=True), stdout=_devnull(read=False), stderr=_devnull(read=False), close_fds=True)
        try:
            return proc.wait(timeout=3) == 0
        except subprocess.TimeoutExpired:
            _terminate_procs([proc])
            return False
    except Exception as e:
        _log('gst-inspect failed for %s: %s' % (element, e))
        return False

def _is_vuplus_receiver():
    try:
        from .receivercompat import is_vuplus
        return bool(is_vuplus())
    except Exception as e:
        _log('Vu+ detection failed: %s' % e)
        return False

def _is_octagon_egami_receiver():
    try:
        from .receivercompat import is_octagon_egami
        return bool(is_octagon_egami())
    except Exception:
        return False

def _is_dreambox_arm_receiver():
    try:
        from .receivercompat import is_dreambox_arm
        return bool(is_dreambox_arm())
    except Exception:
        return False

def _is_xconn_receiver():
    try:
        from .receivercompat import receiver_signature
        return bool(re.search('(?:^|\\|)\\s*/(?:proc/device-tree/model|sys/firmware/devicetree/base/model)=xconn\\s*(?:\\||$)', receiver_signature().lower()))
    except Exception:
        return False

def _dreamos_borrow_audio_fd():
    """Duplicate the main decoder fd already owned by this Enigma2 process."""
    devices = ('/dev/dvb/adapter0/audio0', '/dev/dvb/card0/audio0')
    for name in os.listdir('/proc/self/fd'):
        if not name.isdigit():
            continue
        descriptor = None
        try:
            if os.readlink('/proc/self/fd/' + name) not in devices:
                continue
            descriptor = os.dup(int(name))
            if os.readlink('/proc/self/fd/%d' % descriptor) in devices:
                result, descriptor = descriptor, None
                return result
        except OSError:
            continue
        finally:
            if descriptor is not None:
                try:os.close(descriptor)
                except OSError:pass
    raise RuntimeError('DreamOS main audio descriptor was not found')


def _dreamos_audio_status(descriptor):
    try:
        return _read_dvb_audio_status(descriptor)
    except OSError as error:
        if getattr(error, 'errno', None) in (errno.EOPNOTSUPP, errno.ENOTTY):
            return None
        raise


def _dreamos_audio_command(descriptor, command, label):
    try:
        result = fcntl.ioctl(descriptor, command)
    except OSError as error:
        raise RuntimeError('DreamOS %s rejected: %s' % (label, error))
    if result != 0:
        raise RuntimeError('DreamOS %s returned %r' % (label, result))


def _dreamos_audio_stop_verified():
    from .flashbackpvr import video_only_service
    with _LOCK:
        session = _STATE.get('session')
    if video_only_service(session):
        return True
    descriptor = None
    try:
        descriptor = _dreamos_borrow_audio_fd()
        status = _dreamos_audio_status(descriptor)
        if status is not None:
            return status.get('play') == 0
        # A driver acknowledgement is weaker than readable playback telemetry.
        with _LOCK:
            saved = dict(_STATE.get('dreamos_audio_stop') or {})
            session = _STATE.get('session')
        return (saved.get('confirmation') == 'driver-ack' and
                saved.get('service') == _current_service_string(session))
    except Exception:
        return False
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _dreamos_audio_handoff(session, enabled):
    """Stop native audio; require STOP success even if GET_STATUS is absent."""
    descriptor = None
    changed = False
    before = None
    service_key = _current_service_string(session)
    if not service_key:
        return False
    with _LOCK:
        saved = dict(_STATE.get('dreamos_audio_stop') or {})
    try:
        if enabled and not saved:
            return False
        descriptor = _dreamos_borrow_audio_fd()
        before = _dreamos_audio_status(descriptor)
        if before is not None:
            if before.get('play') not in (0, 1, 2) or before.get('source') not in (0, 1):
                raise RuntimeError('DreamOS decoder status is not recognised')
        else:
            _log('DREAMOS13 GET_STATUS unsupported; STOP/PLAY must acknowledge success')
            play_state = 1
            try:
                from enigma import iPlayableService
                native = session.nav.getCurrentService().playState()
                if native == iPlayableService.statePause:
                    play_state = 2
                elif native == iPlayableService.stateStop:
                    play_state = 0
            except Exception:
                pass
            before = {'play': play_state}
        if enabled:
            play_state = saved.get('play', 1) if saved.get('service') == service_key else 1
            if play_state:
                _dreamos_audio_command(descriptor, AUDIO_PLAY, 'AUDIO_PLAY')
                if play_state == 2:
                    _dreamos_audio_command(descriptor, AUDIO_PAUSE, 'AUDIO_PAUSE')
            after = _dreamos_audio_status(descriptor)
            if after is not None and after.get('play') != play_state:
                raise RuntimeError('DreamOS native audio restoration was not confirmed')
            with _LOCK:
                _STATE.pop('dreamos_audio_stop', None)
                _STATE['e2_audio_disabled'] = False
                _STATE['dvb_stopped'] = False
            _log('DREAMOS13 native audio restore accepted; play=%s status_readable=%s' % (play_state, after is not None))
            return True
        # Repeat STOP rather than assuming state when the driver cannot report it.
        _dreamos_audio_command(descriptor, AUDIO_STOP, 'AUDIO_STOP')
        changed = True
        after = _dreamos_audio_status(descriptor)
        if after is not None and after.get('play') != 0:
            raise RuntimeError('DreamOS audio STOP was not confirmed by driver')
        if not saved or saved.get('service') != service_key:
            saved = {'service': service_key, 'play': before['play']}
        saved['confirmation'] = 'status' if after is not None else 'driver-ack'
        with _LOCK:
            _STATE['dreamos_audio_stop'] = saved
            _STATE['e2_audio_disabled'] = True
            _STATE['dvb_stopped'] = True
        _log('DREAMOS13 AUDIO_STOP accepted; confirmation=%s' % saved['confirmation'])
        return True
    except Exception as error:
        if changed and before is not None and before.get('play') in (1, 2):
            try:
                _dreamos_audio_command(descriptor, AUDIO_PLAY, 'rollback AUDIO_PLAY')
                if before['play'] == 2:
                    _dreamos_audio_command(descriptor, AUDIO_PAUSE, 'rollback AUDIO_PAUSE')
            except Exception:
                _log('DREAMOS13 rollback could not restore decoder audio')
        _log('DREAMOS13 audio handoff failed enabled=%s: %s' % (enabled, error))
        return False
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _set_enigma_service_audio(session, enabled):
    """Enable/disable audio on the CURRENT DVB service through Enigma2 itself.

    On OpenATV/eDVBServicePlay, setQpipMode(False, audio=False) sets the current
    audio PID to -1 and reapplies the decoder.  That destroys Enigma2's eDVBAudio
    object and releases /dev/dvb/adapter0/audio0 while leaving video/timeshift
    untouched.  This is the key Vu+ fix: opening audio0 from a second process
    while Enigma2 owns it returns EBUSY.
    """
    try:
        if session is None or getattr(session, 'nav', None) is None:
            return False
        service = session.nav.getCurrentService()
        if service is None:
            _log('R31P6 E2 audio handoff: no current service')
            return False
        if _is_dreambox_arm_receiver():
            from .flashbackpvr import video_only_service
            if video_only_service(session):
                with _LOCK:
                    _STATE['e2_audio_disabled'] = not bool(enabled)
                    _STATE['dvb_stopped'] = not bool(enabled)
                    if enabled:
                        _STATE.pop('dreamos_audio_stop', None)
                    else:
                        _STATE['dreamos_audio_stop'] = {'service': _current_service_string(session), 'play': 1, 'confirmation': 'video-only-pmt'}
                return True
        setter = getattr(service, 'setQpipMode', None)
        if not callable(setter):
            if _is_dreambox_arm_receiver():
                return _dreamos_audio_handoff(session, bool(enabled))
            _log('E2 audio handoff: current service has no setQpipMode')
            return False
        setter(False, bool(enabled))
        with _LOCK:
            _STATE['e2_audio_disabled'] = not bool(enabled)
            _STATE['dvb_stopped'] = not bool(enabled)
            _STATE['dvb_devices'] = _dvb_audio_devices()
        _log('R31P7 E2 service audio %s via setQpipMode(qpip=False,audio=%s)' % ('RESTORED' if enabled else 'RELEASED', bool(enabled)))
        return True
    except Exception as e:
        _log('R31P6 E2 audio handoff failed enabled=%s: %s' % (enabled, e))
        return False

def _release_main_audio_for_ipaudio(session, preserve_timeshift=False):
    """Release the satellite audio decoder without touching satellite video."""
    if _is_novaler_hisi_receiver():
        released = _set_enigma_service_audio(session, False)
        if released:
            _release_enigma_alsa_output()
        _log('NOVALER1 service audio handoff=%s; video service retained' % released)
        return released
    if _audio_preferences().get('audio_mode') in ('alsa', 'pcm'):
        return _set_enigma_service_audio(session, False)
    if _is_dreambox_arm_receiver() or _is_xconn_receiver():
        if _set_enigma_service_audio(session, False):
            time.sleep(0.08)
            return True
        _log('R133 Dreambox: Enigma2 audio release unavailable; refusing false isolation')
        return False
    if _is_vuplus_receiver() or _is_octagon_egami_receiver():
        if preserve_timeshift:
            _log('R31P6 active native Timeshift: one-time Enigma2 audio-only handoff')
        if _set_enigma_service_audio(session, False):
            time.sleep(0.08)
            return True
        _log('R194 FIX2 Vu+: service audio release unavailable; external audio not started')
        return False
    return _set_dvb_decoder_stopped(True)

def _restore_main_audio_after_ipaudio(session):
    """Re-enable current DVB/PVR audio and reapply its selected track, no retune."""
    restored = _set_enigma_service_audio(session, True)
    try:
        service = session.nav.getCurrentService() if session is not None else None
        getter = getattr(service, 'audioTracks', None)
        tracks = getter() if callable(getter) else None
        if tracks is not None:
            count = tracks.getNumberOfTracks()
            selected = tracks.getCurrentTrack()
            if count > 0:
                selected = selected if 0 <= selected < count else 0
                result = tracks.selectTrack(selected)
                restored = result in (None, 0) or restored
                _log('R187 restored native audio track index=%s result=%s' % (selected, result))
    except Exception as error:
        _log('R187 native audio track restore unavailable: %s' % error)
    if not restored:
        restored = _set_dvb_decoder_stopped(False)
    _restore_dreambox_audio_controls()
    return restored

def _local_audio_route(ffmpeg):
    """Choose from actual image capabilities before opening any subscription."""
    caps = _ffmpeg_audio_capabilities(ffmpeg)
    if 'mpegts' in caps['muxers']:
        for encoder in ('mp2', 'mp2fixed'):
            if encoder in caps['encoders']:
                return encoder
    if 's16le' in caps['muxers'] and 'pcm_s16le' in caps['encoders']:
        return 'pcm'
    if 'mpegts' in caps['muxers'] and 'aac' in caps['encoders']:
        return 'aac'
    raise RuntimeError('Installed FFmpeg lacks supported MP2/PCM/AAC audio output. Install an image-compatible FFmpeg build.')

def _aac_software_decoder():
    missing = [name for name in ('tsdemux', 'queue', 'aacparse', 'audioconvert', 'audioresample', 'alsasink') if not _gst_has_element(name)]
    if missing:
        raise RuntimeError('AAC audio requires GStreamer elements: %s' % ', '.join(missing))
    decoder = next((name for name in ('avdec_aac', 'avdec_aac_fixed', 'faad', 'fdkaacdec') if _gst_has_element(name)), None)
    if not decoder:
        raise RuntimeError('AAC audio requires a software decoder: install the image-compatible GStreamer libav or faad plugin.')
    return decoder

def _aac_alsa_args(gst, port, device, decoder):
    return [gst, '-q', 'udpsrc', 'address=127.0.0.1', 'port=%d' % port, 'caps=video/mpegts,systemstream=(boolean)true,packetsize=(int)188', '!', 'tsdemux', '!', 'queue', '!', 'aacparse', '!', decoder, '!', 'audioconvert', '!', 'audioresample', '!', 'alsasink', 'device=' + device, 'sync=false', 'async=false']

def _start_ffmpeg_local_ts_alsa_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers=None, strict_alsa=False, request_epoch=None):
    """Vu+ single-open bridge with audio rendered outside the DVB decoder.

    FFmpeg owns the provider/MAC connection exactly once and continuously sends
    the R19 MP2 transport stream to loopback.  Only local GStreamer sinks are
    probed.  Native Pause/Play can therefore operate on the DVB video/timeshift
    graph without pausing this independent ALSA PCM stream.
    """
    if not _gst_has_element('alsasink'):
        raise RuntimeError('GStreamer element alsasink is not installed')
    manual_alsa = _audio_preferences().get('audio_mode') == 'alsa'
    with _LOCK:
        manual_epoch = _STATE.get('audio_epoch', 0)
    route = _local_audio_route(ffmpeg)
    if route == 'pcm':
        if strict_alsa:
            raise RuntimeError('This Novaler FFmpeg build lacks the MP2 encoder required by its verified bridge.')
        _log('R194 FIX3 local MP2 encoder unavailable; using verified raw PCM ALSA bridge')
        procs, backend = _start_dreambox_pcm_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers)
        return (procs, backend.replace('Dreambox PCM-verified', 'PCM-verified'))
    if route == 'aac' and strict_alsa:
        raise RuntimeError('This Novaler image needs its verified MP2 bridge; AAC fallback is scoped to non-strict ALSA.')
    decoder = _aac_software_decoder() if route == 'aac' else None
    _log('R194 FIX4 local audio encoder selected: %s decoder=%s' % (route, decoder or 'playbin'))
    port = _free_udp_port()
    ffproc = None
    gstproc = None
    fflog = None
    gstlog = None
    sink_errors = []
    try:
        ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
        ffargs += ['-map', '0:a:0', '-vn', '-sn', '-dn']
        _append_audio_filter(ffargs, include_resample=True)
        ffargs += ['-c:a', route, '-b:a', '160k', '-ar', '48000', '-ac', '2', '-muxdelay', '0', '-muxpreload', '0', '-mpegts_flags', '+resend_headers', '-f', 'mpegts', 'udp://127.0.0.1:%d?pkt_size=1316' % port]
        fflog = _spawn_log_handle()
        provider_log_offset = None
        try:
            fflog.seek(0, 2)
            provider_log_offset = fflog.tell()
        except Exception:
            pass
        ffproc = subprocess.Popen(ffargs, stdin=null_in, stdout=null_out, stderr=fflog, close_fds=True)
        ffproc._alkuds_provider_log_offset = provider_log_offset
        if strict_alsa:
            _novaler_track([ffproc], request_epoch)
        candidates = []
        for device in _alsa_playback_devices():
            value = str(device or '').strip()
            if value and value not in candidates:
                candidates.append(value)
            if len(candidates) >= 12:
                break
        if strict_alsa:
            named = [d for d in candidates if 'HISIAIAO' in d.upper()]
            candidates = list(dict.fromkeys(named + ['default']))[:2]
        for device in candidates:
            if manual_alsa and (not _audio_request_current(manual_epoch)):
                raise RuntimeError('Manual audio start cancelled by newer settings')
            if strict_alsa and (not _novaler_request_active(request_epoch)):
                raise RuntimeError('Novaler audio request cancelled')
            gstproc = None
            try:
                gstargs = [gst, '-q', 'playbin', 'uri=udp://127.0.0.1:%d' % port, 'flags=2', 'audio-sink=alsasink device=%s sync=false' % device]
                if route == 'aac':
                    gstargs = _aac_alsa_args(gst, port, device, decoder)
                gstlog = _spawn_log_handle()
                gstproc = subprocess.Popen(gstargs, stdin=null_in, stdout=null_out, stderr=gstlog, close_fds=True)
                if strict_alsa:
                    _novaler_track([ffproc, gstproc], request_epoch)
                    owned = _wait_for_alsa_pcm_ownership(gstproc, ffproc, attempts=24, delay=0.1)
                else:
                    owned = _wait_for_alsa_pcm_ownership(gstproc, ffproc)
                if strict_alsa and (not _novaler_request_active(request_epoch)):
                    raise RuntimeError('Novaler audio request cancelled')
                if manual_alsa and owned is not True:
                    raise RuntimeError('Selected ALSA device was not acquired')
                if gstproc.poll() is None and ffproc.poll() is None and (owned is True if strict_alsa or route == 'aac' else owned is not False):
                    with _LOCK:
                        _STATE['bridge_port'] = int(port)
                    _log(('NOVALER1' if strict_alsa else 'R31P7 Vu+') + ' independent ALSA bridge ready port=%d device=%s pcm_owned=%s' % (port, device, owned))
                    return ([ffproc, gstproc], 'FFmpeg R9-input -> local %s TS -> GStreamer ALSA-independent (%s)' % ('AAC' if route == 'aac' else 'MP2', device) + (' ALSA-verified' if manual_alsa else ''))
                sink_errors.append('%s owned=%s gst=%s' % (device, owned, gstproc.poll()))
            except Exception as e:
                sink_errors.append('%s: %s' % (device, e))
            finally:
                try:
                    if gstlog is not None and gstlog is not _DEVNULL_W:
                        gstlog.close()
                except Exception:
                    pass
                gstlog = None
            _terminate_procs([gstproc] if gstproc is not None else [])
            gstproc = None
            try:
                if ffproc.poll() is not None:
                    raise RuntimeError('provider FFmpeg exited %s: %s' % (ffproc.poll(), _provider_failure_reason(provider_log_offset)))
            except AttributeError:
                raise RuntimeError('provider FFmpeg state is unavailable')
        if manual_alsa:
            raise RuntimeError('Selected ALSA output could not be confirmed; choose Automatic or another device')
        if route == 'aac':
            raise RuntimeError('AAC ALSA output could not be confirmed; DVB/automatic fallback disabled')
        if strict_alsa:
            raise RuntimeError('Novaler ALSA output unavailable; DVB/automatic sink fallback disabled')
        _log('R31P7 ALSA sink unavailable (%s); reusing provider with DVB playbin fallback' % ('; '.join(sink_errors[-4:]) or 'no candidates'))
        gstargs = [gst, '-q', 'playbin', 'uri=udp://127.0.0.1:%d' % port, 'flags=2']
        gstlog = _spawn_log_handle()
        gstproc = subprocess.Popen(gstargs, stdin=null_in, stdout=null_out, stderr=gstlog, close_fds=True)
        end = time.time() + 3.2
        while time.time() < end:
            if gstproc.poll() is not None or ffproc.poll() is not None:
                break
            time.sleep(0.1)
        if gstproc.poll() is None and ffproc.poll() is None:
            with _LOCK:
                _STATE['bridge_port'] = int(port)
            return ([ffproc, gstproc], 'FFmpeg R9-input -> local MP2 TS -> GStreamer playbin DVB-fallback')
        raise RuntimeError('local bridge exited after ALSA probes (ffmpeg=%s gst=%s)' % (ffproc.poll(), gstproc.poll()))
    except Exception:
        _terminate_procs([x for x in (ffproc, gstproc) if x is not None])
        raise
    finally:
        for fh in (fflog, gstlog):
            try:
                if fh is not None and fh is not _DEVNULL_W:
                    fh.close()
            except Exception:
                pass

def _dreambox_gstreamer_args(gst, port):
    """Known MP2 input: parse encoded audio explicitly, without playbin decoding."""
    return [gst, '-m', 'udpsrc', 'address=127.0.0.1', 'port=%d' % int(port), 'buffer-size=262144', 'caps=video/mpegts,systemstream=(boolean)true,packetsize=(int)188', '!', 'tsdemux', 'latency=0', '!', 'queue', '!', 'mpegaudioparse', '!', 'dvbaudiosink', 'sync=false', 'async=false']

def _audio_output_ready(proc):
    flow = getattr(proc, '_alkuds_audio_progress', {})
    return bool(int(flow.get('bytes') or 0) > 0 and int(flow.get('time_us') or 0) > 0)

def _read_ffmpeg_audio_progress(proc):
    """Read numeric progress from its own pipe (legacy backends use stdout)."""
    block = {}
    confirmed = False
    progress_stream = getattr(proc, '_alkuds_progress_stream', None)
    if progress_stream is None:
        progress_stream = proc.stdout
    try:
        while True:
            raw = progress_stream.readline()
            if not raw:
                break
            line = raw.decode('ascii', 'ignore') if not isinstance(raw, str) else raw
            key, sep, value = line.strip().partition('=')
            if key in ('total_size', 'out_time_us', 'out_time_ms') and sep:
                try:
                    block[key] = max(0, int(value))
                except (ValueError, TypeError):
                    pass
            elif key == 'progress':
                old = getattr(proc, '_alkuds_audio_progress', {})
                size = int(block.get('total_size') or 0)
                stamp = int(block.get('out_time_us', block.get('out_time_ms', 0)) or 0)
                if size > int(old.get('bytes') or 0) or stamp > int(old.get('time_us') or 0):
                    proc._alkuds_audio_progress = {'bytes': size, 'time_us': stamp, 'last': time.time()}
                if not confirmed and _audio_output_ready(proc):
                    _log('R134 FFmpeg audio output confirmed bytes=%d time_us=%d' % (size, stamp))
                    confirmed = True
                block = {}
    except Exception:
        _log('R134 FFmpeg numeric progress reader stopped')
    finally:
        try:
            progress_stream.close()
        except Exception:
            pass

def _ffmpeg_audio_capabilities(ffmpeg):
    """Read modern or FFmpeg 3-era capability tables; no provider is opened."""
    found = {}
    for kind, options in (('muxers', ('-muxers', '-formats')), ('encoders', ('-encoders', '-codecs'))):
        failures = []
        for option in options:
            try:
                result = subprocess.run([ffmpeg, '-hide_banner', option], stdin=_devnull(read=True), stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=3.0, check=False)
                output = (result.stdout or b'') + b'\n' + (result.stderr or b'')
                text = output.decode('utf-8', 'replace')
                if result.returncode != 0:
                    failures.append('%s exit=%s: %s' % (option, result.returncode, ' '.join(text.split())[:180]))
                    continue
                names = set()
                for line in text.splitlines():
                    fields = line.split()
                    if len(fields) < 2:
                        continue
                    flags, name = fields[:2]
                    if name == '=':
                        continue
                    if kind == 'muxers':
                        valid = len(flags) <= 2 and 'E' in flags and all(c in 'DE.' for c in flags)
                    elif option == '-codecs':
                        valid = len(flags) >= 3 and flags[1] == 'E' and flags[2] == 'A'
                    else:
                        valid = len(flags) == 6 and flags.startswith('A')
                    if valid:
                        names.update(name.split(','))
                if names:
                    found[kind] = names
                    _log('DREAMOS14 FFmpeg %s table accepted via %s' % (kind, option))
                    break
                failures.append('%s returned no supported entries' % option)
            except Exception as error:
                failures.append('%s: %s' % (option, type(error).__name__))
        if kind not in found:
            detail = '; '.join(failures)
            _log('DREAMOS14 FFmpeg capability failure: %s' % detail)
            raise RuntimeError('Cannot inspect FFmpeg %s: %s' % (kind, detail))
    return found


def _dreambox_pcm_profile(ffmpeg):
    caps = _ffmpeg_audio_capabilities(ffmpeg)
    muxers, encoders = (caps['muxers'], caps['encoders'])
    _log('R137 Dreambox build: raw_s16le=%s pcm_encoder=%s mpegts=%s mp2_encoder=%s' % ('s16le' in muxers, 'pcm_s16le' in encoders, 'mpegts' in muxers, 'mp2' in encoders))
    if 's16le' in muxers and 'pcm_s16le' in encoders and _gst_has_element('rawaudioparse'):
        return (['-acodec', 'pcm_s16le', '-ac', '2', '-ar', '48000', '-f', 's16le'], ['rawaudioparse', 'use-sink-caps=false', 'format=pcm', 'pcm-format=s16le', 'sample-rate=48000', 'num-channels=2'], 'raw PCM')
    if 'mpegts' in muxers and 'mp2' in encoders:
        missing = [name for name in ('tsdemux', 'queue', 'mpegaudioparse') if not _gst_has_element(name)]
        if missing:
            raise RuntimeError('Missing GStreamer TS elements: %s' % ', '.join(missing))
        decoder = next((name for name in ('avdec_mp2float', 'avdec_mp2', 'mpg123audiodec', 'mad') if _gst_has_element(name)), None)
        if not decoder:
            raise RuntimeError('No software MP2 decoder; install gstreamer1.0-libav or mpg123 plugin')
        _log('R137 Dreambox supported MPEG-TS bridge; software decoder=%s' % decoder)
        return (['-c:a', 'mp2', '-b:a', '160k', '-ar', '48000', '-ac', '2', '-muxdelay', '0', '-muxpreload', '0', '-mpegts_flags', '+resend_headers', '-f', 'mpegts'], ['tsdemux', '!', 'queue', '!', 'mpegaudioparse', '!', decoder], 'MP2 TS -> software PCM')
    raise RuntimeError('FFmpeg build has neither raw PCM output nor MP2/MPEG-TS output')

def _start_dreambox_pcm_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers=None):
    """One provider connection, supported format, software PCM and ALSA output."""
    provider = None
    sink = None
    read_fd = write_fd = None
    progress_stream = None
    reader_started = False
    started = time.time()
    manual_pcm = _audio_preferences().get('audio_mode') == 'pcm'
    with _LOCK:
        manual_epoch = _STATE.get('audio_epoch', 0)
    try:
        output_args, parser_args, profile = _dreambox_pcm_profile(ffmpeg)
        devices = _alsa_playback_devices()
        preferred = [d for d in devices if d.startswith('sysdefault:')]
        preferred += [d for d in devices if d == 'default']
        devices = list(dict.fromkeys(preferred + devices))[:6]
        read_fd, write_fd = os.pipe()
        args = _r9_provider_input_args(stream_url, ffmpeg, headers)
        args += ['-vn', '-sn', '-dn']
        _append_audio_filter(args)
        args += output_args
        args += ['-progress', 'pipe:%d' % write_fd, '-nostats', 'pipe:1']
        try:
            provider_log_offset = os.path.getsize(_LOG)
        except OSError:
            provider_log_offset = None
        provider = subprocess.Popen(args, stdin=null_in, stdout=subprocess.PIPE, stderr=_spawn_log_handle(), close_fds=True, pass_fds=(write_fd,))
        provider._alkuds_provider_log_offset = provider_log_offset
        os.close(write_fd)
        write_fd = None
        progress_stream = os.fdopen(read_fd, 'rb')
        read_fd = None
        provider._alkuds_progress_stream = progress_stream
        reader = threading.Thread(target=_read_ffmpeg_audio_progress, args=(provider,))
        reader.daemon = True
        reader.start()
        reader_started = True
        for device in devices:
            args = [gst, '-q', 'fdsrc', 'fd=0', 'blocksize=4096', '!']
            args += parser_args
            args += ['!', 'audioconvert', '!', 'audioresample', '!', 'alsasink', 'device=' + device, 'sync=false', 'async=false']
            _log('R137 Dreambox PCM local device probe: %s' % device)
            try:
                sink = subprocess.Popen(args, stdin=provider.stdout, stdout=null_out, stderr=_spawn_log_handle(), close_fds=True)
            except Exception as e:
                _log('R137 PCM local sink could not start: %s' % type(e).__name__)
                continue
            deadline = time.time() + 8.0
            ownership_deadline = time.time() + 3.0
            owned = None
            while time.time() < deadline:
                if manual_pcm and (not _audio_request_current(manual_epoch)):
                    raise RuntimeError('Manual PCM start cancelled by newer settings')
                if provider.poll() is not None:
                    raise RuntimeError(_provider_failure_reason(provider_log_offset))
                if sink.poll() is not None:
                    break
                with _LOCK:
                    wanted = bool(_STATE.get('wanted'))
                if not wanted:
                    raise RuntimeError('Dreambox PCM start cancelled')
                owned = _process_alsa_pcm_ownership(sink)
                if _audio_output_ready(provider) and owned is not True and (time.time() >= ownership_deadline):
                    break
                if owned is True and _audio_output_ready(provider):
                    time.sleep(0.25)
                    if sink.poll() is None and provider.poll() is None and (_process_alsa_pcm_ownership(sink) is True):
                        provider.stdout.close()
                        _log('R137 Dreambox PCM acquired device=%s startup_seconds=%.2f' % (device, time.time() - started))
                        return ([provider, sink], 'FFmpeg %s -> ALSA-independent -> Dreambox PCM-verified' % profile)
                    break
                time.sleep(0.1)
            _terminate_procs([sink])
            sink = None
            if not _audio_output_ready(provider) and time.time() >= deadline:
                raise RuntimeError('Dreambox PCM input produced no decoded audio within 8 seconds')
            _log('R137 PCM local device rejected: ownership=%s' % owned)
        raise RuntimeError('Dreambox PCM output unavailable on tested ALSA devices')
    except Exception:
        _terminate_procs([p for p in (provider, sink) if p is not None])
        if provider is not None:
            try:
                provider.stdout.close()
            except Exception:
                pass
        if progress_stream is not None and (not reader_started):
            progress_stream.close()
        raise
    finally:
        for fd in (read_fd, write_fd):
            if fd is not None:
                try:
                    os.close(fd)
                except Exception:
                    pass

def _start_ffmpeg_local_ts_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers=None):
    """Single-open bridge: provider -> FFmpeg -> local MPEG-TS -> playbin.

    The OpenATV ARM box already proved that GStreamer playbin can reach the
    receiver audio output.  R19 keeps the R17-proven design where FFmpeg do only the fragile part
    (provider auth/network/codec normalisation) and gives playbin a local TS.

    For Stalker/MAC this function deliberately opens the provider exactly once.
    Reusing a create_link URL after a failed output probe can invalidate a
    one-shot/session-bound portal stream.
    """
    octagon = _is_octagon_egami_receiver()
    codec = 'mp2'
    if octagon:
        caps = _ffmpeg_audio_capabilities(ffmpeg)
        if 'mpegts' not in caps['muxers']:
            raise RuntimeError('Octagon image FFmpeg lacks MPEG-TS output')
        codec = next((name for name in ('mp2', 'aac') if name in caps['encoders']), None)
        if codec is None:
            raise RuntimeError('Octagon image FFmpeg needs an MP2 or AAC encoder')
        if not _gst_has_element('dvbaudiosink'):
            raise RuntimeError('Octagon requires image GStreamer dvbaudiosink')
        _log('FIX7 Octagon native audio bridge codec=%s; output verification required' % codec)
    verify_output = octagon or _is_dreambox_arm_receiver()
    port = _free_udp_port()
    gstproc = None
    ffproc = None
    gstlog = None
    fflog = None
    try:
        gstargs = [gst, '-q', 'playbin', 'uri=udp://127.0.0.1:%d' % port, 'flags=2']
        dreambox = _is_dreambox_arm_receiver()
        if octagon:
            gstargs += ['audio-sink=dvbaudiosink sync=false']
        if dreambox:
            _prepare_dreambox_audio_output()
            gstargs = _dreambox_gstreamer_args(gst, port)
        gstlog = _spawn_log_handle()
        gstproc = subprocess.Popen(gstargs, stdin=null_in, stdout=gstlog if dreambox else null_out, stderr=gstlog, close_fds=True)
        time.sleep(0.3)
        if gstproc.poll() is not None:
            raise RuntimeError('local GStreamer sink exited %s before provider open' % gstproc.poll())
        ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
        if verify_output:
            ffargs += ['-nostats', '-progress', 'pipe:1']
        ffargs += ['-map', '0:a:0', '-vn', '-sn', '-dn']
        _append_audio_filter(ffargs, include_resample=True)
        ffargs += ['-c:a', codec, '-b:a', '160k', '-ar', '48000', '-ac', '2', '-muxdelay', '0', '-muxpreload', '0', '-mpegts_flags', '+resend_headers', '-f', 'mpegts', 'udp://127.0.0.1:%d?pkt_size=1316' % port]
        fflog = _spawn_log_handle()
        ffproc = subprocess.Popen(ffargs, stdin=null_in, stdout=subprocess.PIPE if verify_output else null_out, stderr=fflog, close_fds=True)
        if verify_output:
            ffproc._alkuds_audio_progress = {}
            progress_thread = threading.Thread(target=_read_ffmpeg_audio_progress, args=(ffproc,))
            progress_thread.daemon = True
            progress_thread.start()
        end = time.time() + (8.0 if verify_output else 3.2)
        while time.time() < end:
            if gstproc.poll() is not None or ffproc.poll() is not None:
                break
            if verify_output and _audio_output_ready(ffproc) and (_process_dvb_audio_ownership(gstproc) is True):
                break
            time.sleep(0.1)
        if gstproc.poll() is None and ffproc.poll() is None:
            if octagon:
                if not _audio_output_ready(ffproc):
                    raise RuntimeError('Octagon FFmpeg has no confirmed audio output')
                if _wait_for_dvb_audio_ownership(gstproc) is not True:
                    raise RuntimeError('Octagon renderer has not acquired DVB audio output')
                with _LOCK:
                    _STATE['bridge_port'] = int(port)
                return ([ffproc, gstproc], 'FFmpeg %s TS -> Octagon DVB-verified' % codec.upper())
            if dreambox:
                if not _audio_output_ready(ffproc):
                    raise RuntimeError('Dreambox FFmpeg produced no confirmed audio output within 8 seconds')
                owned = _wait_for_dvb_audio_ownership(gstproc)
                _log('R133 Dreambox DVB renderer ownership=%s' % owned)
                if owned is not True:
                    raise RuntimeError('Dreambox renderer did not acquire DVB audio output (ownership=%s)' % owned)
                _log_dreambox_audio_driver('playing')
                time.sleep(0.4)
                _log_dreambox_audio_driver('playing+0.4s')
            _log('R19 single-open local audio bridge ready port=%d' % port)
            with _LOCK:
                _STATE['bridge_port'] = int(port)
            label = 'FFmpeg R9-input -> local MP2 TS -> GStreamer playbin'
            if dreambox:
                label = 'FFmpeg R9-input -> local MP2 TS -> MP2 parsed -> Dreambox DVB-verified'
            return ([ffproc, gstproc], label)
        raise RuntimeError('local bridge exited (ffmpeg=%s gst=%s)' % (ffproc.poll(), gstproc.poll()))
    except Exception:
        _terminate_procs([x for x in (ffproc, gstproc) if x is not None])
        raise
    finally:
        for fh in (gstlog, fflog):
            try:
                if fh is not None and fh is not _DEVNULL_W:
                    fh.close()
            except Exception:
                pass

def _copy_audio_ts_args(stream_url, ffmpeg, port, headers=None):
    args = _r9_provider_input_args(stream_url, ffmpeg, headers)
    return args + ['-nostats', '-progress', 'pipe:1', '-map', '0:a:0', '-vn', '-sn', '-dn', '-c:a', 'copy', '-muxdelay', '0', '-muxpreload', '0', '-mpegts_flags', '+resend_headers', '-f', 'mpegts', 'udp://127.0.0.1:%d?pkt_size=1316' % port]

def _start_xconn_copy_audio(stream_url, ffmpeg, gst, null_in, null_out, headers=None, request_epoch=None):
    """Single provider connection; image GStreamer decodes copied compressed audio."""
    with _LOCK:
        epoch = _STATE.get('audio_epoch', 0) if request_epoch is None else request_epoch
    missing = [name for name in ('playbin', 'udpsrc', 'tsdemux', 'audioconvert', 'audioresample', 'alsasink') if not _gst_has_element(name)]
    if missing:
        raise RuntimeError('XCONN audio requires GStreamer: ' + ', '.join(missing))
    port = _free_udp_port()
    provider = None
    sink = None
    handles = []
    try:
        if not _audio_request_current(epoch):
            raise RuntimeError('XCONN audio start cancelled')
        log = _spawn_log_handle()
        handles.append(log)
        provider = subprocess.Popen(_copy_audio_ts_args(stream_url, ffmpeg, port, headers), stdin=null_in, stdout=subprocess.PIPE, stderr=log, close_fds=True)
        provider._alkuds_audio_progress = {}
        reader = threading.Thread(target=_read_ffmpeg_audio_progress, args=(provider,))
        reader.daemon = True
        reader.start()
        candidates = list(dict.fromkeys(_alsa_playback_devices()))[:12]
        errors = []
        for device in candidates:
            if not _audio_request_current(epoch):
                raise RuntimeError('XCONN audio start cancelled')
            if not re.match('^[a-zA-Z0-9_:.,=+\\-]+$', str(device)):
                continue
            delay_ns = max(0, int(configured_audio_delay_ms())) * 1000000
            args = [gst, '-q', 'playbin', 'uri=udp://127.0.0.1:%d' % port, 'flags=2', 'audio-sink=alsasink device=%s sync=true ts-offset=%d' % (device, delay_ns)]
            log = _spawn_log_handle()
            handles.append(log)
            sink = subprocess.Popen(args, stdin=null_in, stdout=null_out, stderr=log, close_fds=True)
            owned = _wait_for_alsa_pcm_ownership(sink, provider, attempts=24, delay=0.1)
            end = time.time() + 2.0
            while owned is True and (not _audio_output_ready(provider)) and (sink.poll() is None) and (provider.poll() is None) and (time.time() < end):
                if not _audio_request_current(epoch):
                    raise RuntimeError('XCONN audio start cancelled')
                time.sleep(0.1)
            if not _audio_request_current(epoch):
                raise RuntimeError('XCONN audio start cancelled')
            if owned is True and _audio_output_ready(provider) and (sink.poll() is None) and (provider.poll() is None):
                with _LOCK:
                    _STATE['bridge_port'] = port
                _log('XCONN copied audio confirmed: FFmpeg output and ALSA PCM acquired device=%s' % device)
                return ([provider, sink], 'XCONN copied audio -> GStreamer ALSA-verified (%s)' % device)
            errors.append('%s owned=%s provider=%s renderer=%s' % (device, owned, provider.poll(), sink.poll()))
            _terminate_procs([sink])
            sink = None
            if provider.poll() is not None:
                break
        raise RuntimeError('XCONN copied audio failed: ' + ('; '.join(errors[-3:]) or 'no ALSA device'))
    except Exception:
        _terminate_procs([p for p in (provider, sink) if p is not None])
        raise
    finally:
        for log in handles:
            try:
                if log is not _DEVNULL_W:
                    log.close()
            except Exception:
                pass

def _start_ffmpeg_aplay(stream_url, ffmpeg, aplay, null_in, null_out, headers=None):
    last_error = ''
    for device in _alsa_playback_devices():
        dec = None
        out = None
        try:
            _log('Trying ALSA device %s' % device)
            ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
            ffargs += ['-map', '0:a:0?', '-vn', '-sn', '-dn']
            _append_audio_filter(ffargs)
            ffargs += ['-ac', '2', '-ar', '48000', '-f', 's16le', 'pipe:1']
            dec = subprocess.Popen(ffargs, stdin=null_in, stdout=subprocess.PIPE, stderr=null_out, close_fds=True)
            out = subprocess.Popen([aplay, '-q', '-D', device, '-t', 'raw', '-f', 'S16_LE', '-c', '2', '-r', '48000'], stdin=dec.stdout, stdout=null_out, stderr=null_out, close_fds=True)
            try:
                dec.stdout.close()
            except Exception:
                pass
            time.sleep(0.45)
            if out.poll() is None and dec.poll() is None:
                return ([dec, out], 'FFmpeg -> ALSA PCM (%s)' % device)
            last_error = 'ALSA device %s exited (ffmpeg=%s aplay=%s)' % (device, dec.poll(), out.poll())
        except Exception as e:
            last_error = '%s: %s' % (device, e)
        _terminate_procs([p for p in (dec, out) if p is not None])
    raise RuntimeError(last_error or 'No usable ALSA playback device')

def _start_ffmpeg_dvbaudiosink_pcm(stream_url, ffmpeg, gst, null_in, null_out, headers=None):
    """Vu+ path: FFmpeg provider/auth -> raw PCM -> GStreamer dvbaudiosink.

    Vu+ 4K boxes are well known for an unusable ALSA path while their native
    DVB audio sink still works.  This backend keeps Enigma2's satellite VIDEO
    service and native timeshift untouched, opens the IPTV provider only once
    (important for MAC/Stalker), and hands already-decoded S16LE PCM directly
    to the receiver's DVB audio sink.  No Local Remux is involved.
    """
    if not _gst_has_element('dvbaudiosink'):
        raise RuntimeError('GStreamer element dvbaudiosink is not installed')
    dec = None
    out = None
    try:
        ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
        ffargs += ['-map', '0:a:0', '-vn', '-sn', '-dn']
        _append_audio_filter(ffargs)
        ffargs += ['-ac', '2', '-ar', '48000', '-f', 's16le', 'pipe:1']
        fflog = _spawn_log_handle()
        gstlog = _spawn_log_handle()
        try:
            dec = subprocess.Popen(ffargs, stdin=null_in, stdout=subprocess.PIPE, stderr=fflog, close_fds=True)
            gstargs = [gst, '-q', 'fdsrc', 'fd=0', '!', 'audio/x-raw,format=S16LE,channels=2,layout=interleaved,rate=48000', '!', 'dvbaudiosink']
            out = subprocess.Popen(gstargs, stdin=dec.stdout, stdout=null_out, stderr=gstlog, close_fds=True)
            try:
                dec.stdout.close()
            except Exception:
                pass
            end = time.time() + 3.2
            while time.time() < end:
                if dec.poll() is not None or out.poll() is not None:
                    break
                time.sleep(0.1)
            if dec.poll() is None and out.poll() is None:
                _log('R24 Vu+ dvbaudiosink backend ready')
                return ([dec, out], 'FFmpeg -> Vu+ DVB audio sink')
            raise RuntimeError('dvbaudiosink exited (ffmpeg=%s gst=%s)' % (dec.poll(), out.poll()))
        finally:
            for fh in (fflog, gstlog):
                try:
                    if fh is not None and fh is not _DEVNULL_W:
                        fh.close()
                except Exception:
                    pass
    except Exception:
        _terminate_procs([x for x in (dec, out) if x is not None])
        raise

def _start_ffmpeg_gstreamer_pcm(stream_url, ffmpeg, gst, null_in, null_out, headers=None):
    """Use FFmpeg for network/auth, GStreamer only as the PCM output sink.

    This fixes the R15 MAC failure mode where playbin did not receive Stalker
    headers. It also gives explicit ALSA a chance before autoaudiosink.
    """
    last_error = ''
    sink_specs = ['alsasink sync=false', 'autoaudiosink sync=false']
    for sink_spec in sink_specs:
        dec = None
        out = None
        try:
            ffargs = _r9_provider_input_args(stream_url, ffmpeg, headers)
            ffargs += ['-map', '0:a:0?', '-vn', '-sn', '-dn']
            _append_audio_filter(ffargs)
            ffargs += ['-ac', '2', '-ar', '48000', '-f', 's16le', 'pipe:1']
            dec = subprocess.Popen(ffargs, stdin=null_in, stdout=subprocess.PIPE, stderr=null_out, close_fds=True)
            gstargs = [gst, '-q', 'fdsrc', 'fd=0', '!', 'audio/x-raw,format=S16LE,channels=2,rate=48000,layout=interleaved', '!', 'audioconvert', '!', 'audioresample', '!']
            gstargs += sink_spec.split()
            out = subprocess.Popen(gstargs, stdin=dec.stdout, stdout=null_out, stderr=null_out, close_fds=True)
            try:
                dec.stdout.close()
            except Exception:
                pass
            time.sleep(0.65)
            if dec.poll() is None and out.poll() is None:
                return ([dec, out], 'FFmpeg -> GStreamer PCM (%s)' % sink_spec.split()[0])
            last_error = '%s exited (ffmpeg=%s gst=%s)' % (sink_spec, dec.poll(), out.poll())
        except Exception as e:
            last_error = '%s: %s' % (sink_spec, e)
        _terminate_procs([x for x in (dec, out) if x is not None])
    raise RuntimeError(last_error or 'No FFmpeg/GStreamer PCM sink')

def _start_novaler_audio_backend(stream_url, channel_name, headers):
    with _LOCK:
        epoch = _STATE.get('novaler_epoch', 0)
        released = bool(_STATE.get('e2_audio_disabled'))
    if not _novaler_request_active(epoch):
        return ''
    if not released:
        raise RuntimeError('Novaler satellite audio release failed; unsafe output fallback disabled')
    ffmpeg = _find_executable(('ffmpeg',))
    gst = _find_executable(('gst-launch-1.0',))
    if not ffmpeg or not gst:
        raise RuntimeError('Novaler requires FFmpeg and GStreamer ALSA')
    _stop_processes_only()
    try:
        procs, backend = _start_ffmpeg_local_ts_alsa_gstreamer(stream_url, ffmpeg, gst, _devnull(read=True), _devnull(read=False), headers, strict_alsa=True, request_epoch=epoch)
    except Exception:
        if not _novaler_request_active(epoch):
            return ''
        raise
    backend = 'NOVALER1 ' + backend
    delay_ms = configured_audio_delay_ms()
    if delay_ms > 0:
        backend += ' | delay %.2fs' % (delay_ms / 1000.0)
    with _LOCK:
        accepted = bool(_STATE.get('wanted')) and _STATE.get('novaler_epoch', 0) == epoch
        if accepted:
            _STATE.update(procs=procs, name=str(channel_name or 'IPTV'), backend=backend, url=stream_url, restarting=False, error='', headers=dict(headers or {}), status_error='', status_error_until=0.0, status_name=str(channel_name or 'IPTV'))
    if not accepted:
        _terminate_procs(procs)
        return ''
    _log('NOVALER1 ALSA-only bridge active; no automatic/DVB renderer fallback')
    return backend

def _audio_request_current(epoch):
    with _LOCK:
        return bool(_STATE.get('wanted')) and _STATE.get('audio_epoch', 0) == epoch

def start_audio_backend(stream_url, channel_name='IPTV', restart=False, headers=None, request_epoch=None):
    if request_epoch is None:
        with _LOCK:
            request_epoch = _STATE.get('audio_epoch', 0)
    with _BACKEND_LOCK:
        if not _audio_request_current(request_epoch):
            return ''
        result = _start_audio_backend_unlocked(stream_url, channel_name, restart, headers)
        if not _audio_request_current(request_epoch):
            _stop_processes_only()
            with _LOCK:
                _STATE['url'] = ''
            return ''
        return result

def _start_audio_backend_unlocked(stream_url, channel_name='IPTV', restart=False, headers=None):
    """Start IPTV audio while Enigma2 keeps ownership of satellite video/timeshift."""
    stream_url = clean_stream_url(stream_url)
    if not stream_url:
        raise RuntimeError('No playable stream URL')
    if _is_novaler_hisi_receiver():
        if _audio_preferences().get('audio_mode') not in ('auto', 'alsa'):
            raise RuntimeError('This receiver supports Automatic or verified ALSA; reset audio options')
        return _start_novaler_audio_backend(stream_url, channel_name, headers)
    with _LOCK:
        startup_epoch = _STATE.get('audio_epoch', 0)
    _stop_processes_only()
    null_in = _devnull(read=True)
    null_out = _devnull(read=False)
    procs = []
    backend = ''
    errors = []
    ffmpeg = _find_executable(('ffmpeg',))
    aplay = _find_executable(('aplay',))
    ffplay = _find_executable(('ffplay',))
    gst = _find_executable(('gst-launch-1.0',))
    hdrkeys = set([str(x) for x in dict(headers or {}).keys()])
    portal_headers = bool(hdrkeys.intersection(set(['Cookie', 'X-User-Agent', 'Authorization'])))
    vuplus = _is_vuplus_receiver()
    dreambox = bool(not vuplus and _is_dreambox_arm_receiver())
    dream_bridge_attempted = False
    has_alsa_sink = bool(gst and _gst_has_element('alsasink'))
    has_dvb_sink = bool(gst and _gst_has_element('dvbaudiosink'))
    with _LOCK:
        e2_audio_disabled = bool(_STATE.get('e2_audio_disabled'))
        dvb_audio_stopped = bool(_STATE.get('dvb_stopped'))
    audio_released = bool(e2_audio_disabled or dvb_audio_stopped)
    _log('R132 backend probe vuplus=%s dreambox_arm=%s ffmpeg=%s gst=%s aplay=%s portal_headers=%s alsasink=%s dvbaudiosink=%s audio_released=%s' % (vuplus, dreambox, bool(ffmpeg), bool(gst), bool(aplay), portal_headers, has_alsa_sink, has_dvb_sink, audio_released))
    mode = _audio_preferences().get('audio_mode', 'auto')
    if mode != 'auto':
        if not audio_released or not ffmpeg or (not gst):
            raise RuntimeError('Manual audio needs released service audio, FFmpeg and GStreamer')
        _log('FIX8 explicit audio mode=%s' % mode)
        if mode == 'alsa':
            procs, backend = _start_ffmpeg_local_ts_alsa_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers)
        elif mode == 'pcm':
            procs, backend = _start_dreambox_pcm_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers)
            backend = backend.replace('Dreambox PCM-verified', 'PCM-verified')
        elif mode == 'native' and _is_octagon_egami_receiver():
            procs, backend = _start_ffmpeg_local_ts_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers)
        else:
            raise RuntimeError('Selected audio mode is not supported on this receiver; select Automatic')
    else:
        if vuplus and ffmpeg and gst:
            if not audio_released:
                errors.append('DVBaudio=not released')
                _log('R31P6 Vu+ backend warning: audio handoff state is not active')
            if not audio_released:
                raise RuntimeError('Vu+ satellite audio was not released; refusing mixed playback')
            if has_alsa_sink:
                try:
                    procs, backend = _start_ffmpeg_local_ts_alsa_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers)
                    release = 'R25 E2-audio-release' if e2_audio_disabled else 'R19 Timeshift release'
                    backend = release + ' -> ' + backend
                except Exception as e:
                    errors.append('Vu+ALSA-GSTlocal=%s' % e)
                    _log('R31P7 Vu+ single-open ALSA/local bridge failed: %s' % e)
            else:
                try:
                    procs, backend = _start_ffmpeg_local_ts_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers)
                    release = 'R25 E2-audio-release' if e2_audio_disabled else 'R19 Timeshift release'
                    backend = release + ' -> ' + backend + ' DVB-fallback'
                except Exception as e:
                    errors.append('Vu+GSTfallback=%s' % e)
                    _log('R31P7 Vu+ DVB playbin fallback failed: %s' % e)
        if dreambox and ffmpeg and gst:
            dream_bridge_attempted = True
            try:
                if not e2_audio_disabled:
                    raise RuntimeError('Enigma2 satellite audio PID is not released')
                if not has_alsa_sink:
                    raise RuntimeError('GStreamer alsasink is not installed')
                missing = [element for element in ('fdsrc', 'audioconvert', 'audioresample') if not _gst_has_element(element)]
                if missing:
                    raise RuntimeError('Missing GStreamer PCM elements: %s' % ', '.join(missing))
                procs, backend = _start_dreambox_pcm_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers)
            except Exception as e:
                errors.append('DreamPCM=%s' % e)
                _log('R137 Dreambox independent PCM output failed: %s' % e)
        if _is_octagon_egami_receiver():
            if not audio_released:
                raise RuntimeError('Octagon satellite audio release failed')
            if not ffmpeg or not gst:
                raise RuntimeError('Octagon requires image FFmpeg and GStreamer')
            procs, backend = _start_ffmpeg_local_ts_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers)
        if not procs and (not vuplus) and (not dreambox) and ffmpeg and (aplay or _is_xconn_receiver()):
            try:
                if _is_xconn_receiver():
                    caps = _ffmpeg_audio_capabilities(ffmpeg)
                    raw_pcm = 's16le' in caps['muxers'] and 'pcm_s16le' in caps['encoders']
                    if not raw_pcm:
                        if not gst or not has_alsa_sink or 'mpegts' not in caps['muxers']:
                            raise RuntimeError('XCONN needs GStreamer ALSA and FFmpeg MPEG-TS when raw PCM is unavailable')
                        _log('XCONN FFmpeg raw PCM unavailable; using copied compressed audio with GStreamer decoding')
                        procs, backend = _start_xconn_copy_audio(stream_url, ffmpeg, gst, null_in, null_out, headers, request_epoch=startup_epoch)
                    else:
                        procs, backend = _start_ffmpeg_aplay(stream_url, ffmpeg, aplay, null_in, null_out, headers)
                else:
                    procs, backend = _start_ffmpeg_aplay(stream_url, ffmpeg, aplay, null_in, null_out, headers)
            except Exception as e:
                errors.append('ALSA=%s' % e)
                _log('FFmpeg+ALSA failed: %s' % e)
                if _is_xconn_receiver():
                    raise
        if not procs and ffmpeg and gst and (not vuplus) and (not dreambox) and (not dream_bridge_attempted):
            try:
                procs, backend = _start_ffmpeg_local_ts_gstreamer(stream_url, ffmpeg, gst, null_in, null_out, headers)
            except Exception as e:
                errors.append('GSTlocal=%s' % e)
                _log('R25 buffered local audio bridge failed: %s' % e)
        if not procs and ffmpeg and gst and (not portal_headers) and (not vuplus) and (not dreambox):
            try:
                procs, backend = _start_ffmpeg_gstreamer_pcm(stream_url, ffmpeg, gst, null_in, null_out, headers)
            except Exception as e:
                errors.append('GSTpcm=%s' % e)
                _log('FFmpeg+GStreamer PCM failed: %s' % e)
        if not procs and ffplay and (not portal_headers) and (not vuplus) and (not dreambox):
            cmd = [ffplay, '-nodisp', '-vn', '-loglevel', 'error', '-nostats']
            _append_audio_filter(cmd)
            cmd.append(stream_url)
            procs = [subprocess.Popen(cmd, stdin=null_in, stdout=null_out, stderr=null_out, close_fds=True)]
            backend = 'FFplay direct audio'
            time.sleep(0.35)
            if not _alive_list(procs):
                errors.append('FFplay=exited')
                _terminate_procs(procs)
                procs = []
                backend = ''
        if not procs and gst and (not portal_headers) and (not vuplus) and (not dreambox):
            if configured_audio_delay_ms() > 0:
                _log('R31 warning: direct GStreamer fallback cannot apply configured audio delay')
            cmd = [gst, '-q', 'playbin', 'uri=' + stream_url, 'flags=2']
            procs = [subprocess.Popen(cmd, stdin=null_in, stdout=null_out, stderr=null_out, close_fds=True)]
            backend = 'GStreamer audio-only (fallback)'
            time.sleep(0.35)
            if not _alive_list(procs):
                errors.append('GSTdirect=exited')
                _terminate_procs(procs)
                procs = []
                backend = ''
    if not procs:
        short = '; '.join(errors[-3:])
        if dreambox:
            raise RuntimeError('Dreambox verified PCM audio backend failed. %s. See /tmp/alkuds-backgroundaudio.log' % (short or 'FFmpeg / GStreamer unavailable'))
        if vuplus:
            raise RuntimeError('Vu+ audio backend failed (R31P7 independent ALSA). %s. See /tmp/alkuds-backgroundaudio.log' % (short or 'Enigma2 audio release / GStreamer alsasink unavailable'))
        raise RuntimeError('No IPAUDIO backend could be started (R25 native-timeshift). %s' % short)
    delay_ms = configured_audio_delay_ms()
    if delay_ms > 0 and ('FFmpeg' in backend or 'FFplay' in backend):
        backend += ' | delay %.2fs' % (float(delay_ms) / 1000.0)
    with _LOCK:
        if not _STATE.get('wanted'):
            discard = True
        else:
            discard = False
            _STATE['procs'] = procs
            _STATE['name'] = str(channel_name or _STATE.get('name') or 'IPTV')
            _STATE['backend'] = backend
            _STATE['url'] = stream_url
            _STATE['restarting'] = False
            _STATE['error'] = ''
            _STATE['headers'] = dict(headers or _STATE.get('headers') or {})
            _STATE['status_error'] = ''
            _STATE['status_error_until'] = 0.0
            _STATE['status_name'] = str(channel_name or _STATE.get('name') or 'IPTV')
    if discard:
        _terminate_procs(procs)
        raise RuntimeError('Background audio was cancelled')
    _log('Background audio started with %s' % backend)
    return backend

def _alive_list(procs):
    alive = []
    for proc in procs or []:
        try:
            if proc.poll() is None:
                alive.append(proc)
        except Exception:
            pass
    return alive

def report_start_error(error):
    _log('Start error: %s' % error)
    with _LOCK:
        _STATE['error'] = str(error or 'Unable to start background audio')
        _STATE['restarting'] = False
        _STATE['status_error'] = _STATE['error']
        _STATE['status_error_until'] = time.time() + 10.0
        _STATE['status_name'] = str(_STATE.get('name') or 'IPTV')

def _restart_worker(url, name, headers, retry_resolver=None, request_epoch=None):
    if request_epoch is None:
        with _LOCK:
            request_epoch = _STATE.get('audio_epoch', 0)
    if not _audio_request_current(request_epoch):
        return
    try:
        refreshed_url = str(url or '')
        refreshed_headers = dict(headers or {})
        if callable(retry_resolver):
            result = retry_resolver()
            if isinstance(result, dict):
                refreshed_url = str(result.get('url') or result.get('stream_url') or '')
                if isinstance(result.get('headers'), dict):
                    refreshed_headers = dict(result.get('headers') or {})
            elif isinstance(result, (list, tuple)):
                refreshed_url = str(result[0] if result else '')
                if len(result) > 1 and isinstance(result[1], dict):
                    refreshed_headers = dict(result[1] or {})
            else:
                refreshed_url = str(result or '')
            refreshed_url = clean_stream_url(refreshed_url)
            if not refreshed_url:
                raise RuntimeError('MAC portal did not return a fresh playable URL')
            with _LOCK:
                if not _STATE.get('wanted') or _STATE.get('audio_epoch', 0) != request_epoch:
                    return
                _STATE['url'] = refreshed_url
                _STATE['headers'] = dict(refreshed_headers)
            _log('R30 refreshed MAC/Stalker stream link before audio restart')
        start_audio_backend(refreshed_url, name, restart=True, headers=refreshed_headers, request_epoch=request_epoch)
    except Exception as e:
        if not _audio_request_current(request_epoch):
            return
        with _LOCK:
            _STATE['error'] = str(e)
            _STATE['restarting'] = False
            if _STATE.get('settings_restart_epoch') == request_epoch:
                _STATE.update(url='', restart_due=0.0, settings_restart_failed=True, error_reported=False, status_error=str(e), status_error_until=time.time() + 15.0)
            elif _is_novaler_hisi_receiver():
                _STATE['url'] = ''
                _STATE['restart_due'] = 0.0
            else:
                _STATE['restart_due'] = time.time() + 2.0
        _log('Restart failed: %s' % e)
        with _LOCK:
            settings_failed = bool(_STATE.get('settings_restart_failed'))
        if not settings_failed and (not _is_novaler_hisi_receiver()):
            _record_provider_failure(None)

def _schedule_restart(delay=0.45):
    with _LOCK:
        if _STATE.get('wanted') and _STATE.get('url'):
            _STATE['restart_due'] = time.time() + float(delay)

def _watchdog_tick():
    with _LOCK:
        wanted = bool(_STATE.get('wanted'))
        session = _STATE.get('session')
        last_service = str(_STATE.get('last_service') or '')
        error = str(_STATE.get('error') or '')
        error_reported = bool(_STATE.get('error_reported'))
    if not wanted:
        _stop_timer()
        return
    current_service = _current_service_string(session)
    native_timeshift = _native_timeshift_enabled(session)
    with _LOCK:
        dvb_stopped = bool(_STATE.get('dvb_stopped'))
        service_audio_released = bool(_STATE.get('e2_audio_disabled'))
    if service_audio_released and (_is_octagon_egami_receiver() or _audio_preferences().get('audio_mode') in ('alsa', 'pcm')):
        dvb_stopped = True
    changed = bool(current_service and current_service != last_service)
    try:
        from .flashbackpvr import owned_service
        beta_owned = owned_service(session)
    except Exception:
        beta_owned = False
    if beta_owned:
        with _LOCK:
            _STATE['last_service'] = current_service
    elif changed and _is_dvb_service_string(current_service):
        isolated = _release_main_audio_for_ipaudio(session, preserve_timeshift=native_timeshift)
        if isolated:
            with _LOCK:
                _STATE['last_service'] = current_service
            try:
                from .videodelay import _controller
                if _controller is not None:
                    _controller.same_service()
            except Exception:
                pass
            try:
                recover_video_delay_audio(recover_sink=True)
                _log('R189 DVB zap: retained IP audio source and recovered output')
            except Exception as failure:
                _log('R189 DVB zap audio output recovery failed: %s' % failure)
    elif native_timeshift:
        with _LOCK:
            _STATE['last_service'] = current_service
    elif changed:
        with _LOCK:
            _STATE['last_service'] = current_service
        _log('R189 service transition: IP audio remains requested')
    elif current_service and _is_dvb_service_string(current_service) and (not dvb_stopped):
        _release_main_audio_for_ipaudio(session, preserve_timeshift=False)
    alive = _alive_procs()
    with _LOCK:
        url = str(_STATE.get('url') or '')
        name = str(_STATE.get('name') or 'IPTV')
        due = float(_STATE.get('restart_due') or 0.0)
        restarting = bool(_STATE.get('restarting'))
        headers = dict(_STATE.get('headers') or {})
        retry_resolver = _STATE.get('retry_resolver')
        request_epoch = _STATE.get('audio_epoch', 0)
    now = time.time()
    needs_restart = bool(url and (not alive) and (not restarting) and (not due or now >= due))
    if url and due and (now >= due):
        needs_restart = True
    if needs_restart and (not restarting):
        with _LOCK:
            _STATE['restart_due'] = 0.0
            _STATE['restarting'] = True
        _stop_processes_only()
        t = threading.Thread(target=_restart_worker, args=(url, name, headers, retry_resolver, request_epoch))
        t.daemon = True
        t.start()
    if error and (not url) and (not error_reported):
        with _LOCK:
            _STATE['error_reported'] = True
        try:
            from .xStaticText import MessageBox
            if session:
                session.open(MessageBox, 'Unable to start background audio:\n%s' % error, MessageBox.TYPE_ERROR, timeout=7)
        except Exception:
            pass
        with _LOCK:
            preserve_recording = bool(_STATE.get('settings_restart_failed'))
        if not preserve_recording:
            stop_background_audio(keep_status=True)

def restart_audio_with_preferences():
    """GUI-thread handoff; worker-only renderer restart, never a PVR retune."""
    from .playbacksettings import load_preferences
    options = load_preferences()
    with _LOCK:
        if not _STATE.get('wanted'):
            return False
        url = str(_STATE.get('url') or _STATE.get('pending_url') or '')
        if not url:
            return False
        session = _STATE.get('session')
        name = str(_STATE.get('name') or 'IP AUDIO')
        headers = dict(_STATE.get('headers') or {})
        retry = _STATE.get('retry_resolver')
        previous = _STATE.get('audio_options')
        _STATE['audio_options'] = dict(options)
    try:
        if not _release_main_audio_for_ipaudio(session, preserve_timeshift=True):
            raise RuntimeError('Unable to release service audio for the selected output')
        if options['audio_mode'] in ('alsa', 'pcm'):
            _release_enigma_alsa_output()
    except Exception:
        with _LOCK:
            _STATE['audio_options'] = previous
        raise
    with _LOCK:
        if not _STATE.get('wanted'):
            return False
        epoch = _STATE.get('audio_epoch', 0) + 1
        _STATE.update(audio_epoch=epoch, settings_restart_epoch=epoch, settings_restart_failed=False, error_reported=False, restarting=True, restart_due=0.0, error='', status_error='', status_error_until=0.0)
        _STATE['novaler_epoch'] = _STATE.get('novaler_epoch', 0) + 1
    worker = threading.Thread(target=_restart_worker, args=(url, name, headers, retry, epoch))
    worker.daemon = True
    worker.start()
    _log('FIX8 saved audio options: queued one background restart; recording untouched')
    return True

def start_background_audio_direct(session, stream_url, channel_name='IPTV', headers=None, resume_context=None, retry_resolver=None, preserve_delay_controller=False):
    try:
        from .receivercompat import receiver_signature
        _log('R25 native-timeshift receiver=%s; Local Remux fallback disabled' % (receiver_signature() or '<unknown>'))
    except Exception:
        _log('R25 native-timeshift mode; Local Remux fallback disabled')
    arm_background_audio(session, channel_name, headers, resume_context=resume_context, retry_resolver=retry_resolver, preserve_delay_controller=preserve_delay_controller)
    with _LOCK:
        request_epoch = _STATE.get('audio_epoch', 0)
        _STATE['pending_url'] = clean_stream_url(stream_url)

    def worker():
        try:
            start_audio_backend(stream_url, channel_name, headers=headers, request_epoch=request_epoch)
        except Exception as e:
            if _audio_request_current(request_epoch):
                report_start_error(e)
    t = threading.Thread(target=worker)
    t.daemon = True
    t.start()
    return True

def background_audio_ui_status():
    """Cheap UI snapshot only. The existing watchdog owns health/recovery."""
    with _LOCK:
        wanted = bool(_STATE.get('wanted'))
        procs = _STATE.get('procs') or []
        backend = str(_STATE.get('backend') or '')
        name = str(_STATE.get('name') or _STATE.get('status_name') or '')
        error = bool(_STATE.get('error') or _STATE.get('status_error'))
        restarting = bool(_STATE.get('restarting') or _STATE.get('sink_recovery_pending'))
        context = _STATE.get('resume_context') or {}
        source = str(context.get('source') or '')
        if not wanted:
            state = 'stopped'
        elif procs and (('DVB-verified' in backend or 'PCM-verified' in backend or 'ALSA-verified' in backend) and len(procs) != 2):
            state = 'starting'
        elif restarting:
            state = 'restarting'
        elif error:
            state = 'failed'
        elif procs:
            state = 'running'
        else:
            state = 'starting'
        return {'name': name, 'state': state, 'source': source}

def get_resume_context():
    """Return cached source/channel context while IPAUDIO is active."""
    with _LOCK:
        if not _STATE.get('wanted'):
            return {}
        context = _STATE.get('resume_context') or {}
        try:
            result = dict(context)
            if isinstance(context.get('channels'), list):
                result['channels'] = list(context.get('channels') or [])
            return result
        except Exception:
            return {}

def update_resume_context(**values):
    """Update quick-return context without touching the running audio backend."""
    with _LOCK:
        context = dict(_STATE.get('resume_context') or {})
        context.update(values)
        _STATE['resume_context'] = context
        return dict(context)

def background_audio_status():
    alive = _alive_procs()
    with _LOCK:
        wanted = bool(_STATE.get('wanted'))
        name = str(_STATE.get('name') or '')
        backend = str(_STATE.get('backend') or '')
        error = str(_STATE.get('error') or '')
        restarting = bool(_STATE.get('restarting'))
        dvb_stopped = bool(_STATE.get('dvb_stopped'))
    if alive and ('DVB-verified' in backend or 'PCM-verified' in backend or 'ALSA-verified' in backend) and (len(alive) != 2):
        return (True, name, 'starting')
    if alive:
        with _LOCK:
            e2_audio_disabled = bool(_STATE.get('e2_audio_disabled'))
        if e2_audio_disabled:
            isolation = ('DreamOS audio STOP acknowledged' if _STATE['dreamos_audio_stop'].get('confirmation') == 'driver-ack' else 'DreamOS audio STOP verified') if _STATE.get('dreamos_audio_stop') else 'Enigma2 audio PID released'
        else:
            isolation = 'DVB decoder STOP' if dvb_stopped else 'audio isolation unavailable'
        return (True, name, backend + ' | ' + isolation)
    if wanted and restarting:
        return (True, name, 'restarting')
    if wanted and (not error):
        return (True, name, 'starting')
    return (False, name, backend)

def background_audio_diagnostics():
    """Return badge-safe state without exposing URL, headers, or credentials."""
    alive = _alive_procs()
    now = time.time()
    with _LOCK:
        wanted = bool(_STATE.get('wanted'))
        name = str(_STATE.get('name') or _STATE.get('status_name') or '')
        backend = str(_STATE.get('backend') or '')
        restarting = bool(_STATE.get('restarting'))
        error = str(_STATE.get('error') or _STATE.get('status_error') or '')
        error_until = float(_STATE.get('status_error_until') or 0.0)
    if alive and ('DVB-verified' in backend or 'PCM-verified' in backend or 'ALSA-verified' in backend) and (len(alive) != 2):
        state = 'starting'
    elif alive:
        state = 'running'
    elif error and (wanted or error_until > now):
        state = 'failed'
    elif wanted and restarting:
        state = 'restarting'
    elif wanted:
        state = 'starting'
    else:
        state = 'stopped'
    flows = [getattr(proc, '_alkuds_audio_progress', {}) for proc in alive]
    flow = max(flows, key=lambda item: int(item.get('time_us') or 0)) if flows else {}
    size, duration = (int(flow.get('bytes') or 0), int(flow.get('time_us') or 0))
    return {'state': state, 'name': name, 'backend': backend, 'error': error if state == 'failed' else '', 'output_kbps': size * 8000.0 / duration if size > 0 and duration > 0 else None, 'output_age': max(0.0, now - float(flow['last'])) if flow.get('last') else None, 'output_time_us': duration}

def prepare_foreground_playback():
    """A channel/video selection must not implicitly cancel requested IP audio."""
    return False

def stop_background_audio(restore_main=True, keep_status=False):
    with _LOCK:
        _STATE['audio_epoch'] = _STATE.get('audio_epoch', 0) + 1
    if _is_novaler_hisi_receiver():
        with _LOCK:
            _STATE['novaler_epoch'] = _STATE.get('novaler_epoch', 0) + 1
            _STATE['wanted'] = False
    try:
        from .videodelay import stop
        stop()
    except Exception:
        pass
    with _LOCK:
        procs = list(_STATE.get('procs', []))
        session = _STATE.get('session')
        had_state = bool(_STATE.get('wanted')) or bool(procs)
        _STATE['wanted'] = False
        _STATE['name'] = ''
        _STATE['url'] = ''
        _STATE['backend'] = ''
        _STATE['procs'] = []
        _STATE['restart_due'] = 0.0
        _STATE['restarting'] = False
        _STATE['error'] = ''
        _STATE['error_reported'] = False
        _STATE['headers'] = {}
        _STATE['retry_resolver'] = None
        _STATE['bridge_port'] = 0
        _STATE['resume_context'] = {}
        _STATE['sink_retry_count'] = 0
        _STATE['sink_handoff_until'] = 0.0
        _STATE['vu_handoff_phase'] = ''
        _STATE['vu_handoff_action'] = ''
        _STATE['vu_handoff_started'] = 0.0
        _STATE['vu_video_paused'] = False
        if not keep_status:
            _STATE['status_error'] = ''
            _STATE['status_error_until'] = 0.0
            _STATE['status_name'] = ''
    _stop_timer()
    try:
        if _KEY_TIMER is not None:
            _KEY_TIMER.stop()
    except Exception:
        pass
    try:
        if _STOP_TIMER is not None:
            _STOP_TIMER.stop()
    except Exception:
        pass
    try:
        if _VU_HANDOFF_TIMER is not None:
            _VU_HANDOFF_TIMER.stop()
    except Exception:
        pass
    _unbind_pause_isolation()
    _terminate_procs(procs)
    if restore_main:
        restored = _restore_main_audio_after_ipaudio(session)
        if not restored:
            _log('R187 native audio restoration could not be confirmed')
    else:
        _restore_dreambox_audio_controls()
    with _LOCK:
        _STATE['session'] = None
        _STATE['dvb_stopped'] = False
        _STATE['e2_audio_disabled'] = False
        _STATE['dvb_devices'] = []
    if restore_main:
        _log('Background audio stopped; native Enigma2 audio restored')
    else:
        _log('Background audio stopped for foreground service handoff')
    if not keep_status:
        try:
            from .streammonitor import hide_ipaudio_status
            hide_ipaudio_status(session)
        except Exception as e:
            _log('IPAudio status badge close failed: %s' % e)
    return had_state

def _stop_native_timeshift(session):
    """Stop native Enigma2 Timeshift without retuning the DVB service.

    Images expose the high-level controller under Screens.InfoBar, while some
    older forks only make the service-level iTimeshift object available.  Use
    the controller first so its seek/UI state is cleaned up, then keep a small
    service-level fallback for cross-image compatibility.
    """
    stopped = False
    try:
        from Screens.InfoBar import InfoBar
        infobar = getattr(InfoBar, 'instance', None)
        # r223-py27: try the non-interactive stop entry points of every image family.
        #   OpenATV : stopTimeshiftcheckTimeshiftRunningCallback(True)
        #   DreamOS / OpenPLi : stopTimeshiftConfirmed(True)  (stopTimeshift() only opens a Yes/No dialog)
        for entry in ('stopTimeshiftcheckTimeshiftRunningCallback', 'stopTimeshiftConfirmed'):
            callback = getattr(infobar, entry, None)
            if callable(callback):
                try:
                    callback(True)
                    stopped = True
                    _log('R31 native Timeshift stopped through InfoBar.%s' % entry)
                    break
                except Exception as e:
                    _log('R31 InfoBar.%s failed: %s' % (entry, e))
        if (not stopped) and infobar is not None:
            action = getattr(infobar, 'stopTimeshift', None)
            if callable(action):
                action()
                stopped = True
                _log('R31 native Timeshift stop requested through InfoBar')
    except Exception as e:
        _log('R31 InfoBar Timeshift stop unavailable: %s' % e)
    if stopped:
        return True
    try:
        service = session.nav.getCurrentService() if session and getattr(session, 'nav', None) else None
        timeshift = service and service.timeshift()
        if timeshift is None:
            return False
        for probe in ('isTimeshiftEnabled', 'isTimeshiftActive'):
            enabled = getattr(timeshift, probe, None)
            if callable(enabled) and (not enabled()):
                return False
            if callable(enabled):
                break
        action = getattr(timeshift, 'stopTimeshift', None)
        if not callable(action):
            return False
        try:
            action(True)
        except TypeError:
            action()
        _log('R31 native Timeshift stopped through service fallback')
        return True
    except Exception as e:
        _log('R31 service Timeshift stop failed: %s' % e)
        return False

def _close_active_alkuds_dialog(session):
    try:
        dialog = getattr(session, 'current_dialog', None) if session else None
        module = str(getattr(getattr(dialog, '__class__', None), '__module__', '') or '')
        if dialog is not None and (module.startswith('Plugins.Extensions.Alkuds') or '.Alkuds.' in module):
            dialog.close()
            _log('R31 active Alkuds ipaudio screen closed after STOP')
            return True
    except Exception as e:
        _log('R31 unable to close active plugin screen: %s' % e)
    return False

def stop_ipaudio_and_timeshift(session=None, close_plugin=False):
    """One public, idempotent shutdown path for the square STOP button."""
    with _LOCK:
        active_session = session or _STATE.get('session')
    had_audio = stop_background_audio(restore_main=True)
    stopped_timeshift = _stop_native_timeshift(active_session)
    closed = _close_active_alkuds_dialog(active_session) if close_plugin else False
    _log('R31 full stop complete audio=%s timeshift=%s screen=%s' % (had_audio, stopped_timeshift, closed))
    return (had_audio, stopped_timeshift, closed)
