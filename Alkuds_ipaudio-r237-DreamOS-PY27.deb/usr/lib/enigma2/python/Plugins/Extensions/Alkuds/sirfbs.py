# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Sir TV public schedules, named AlbaPlayer servers and ordinary HLS."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
import hashlib
from .py2compat import json
from .py2compat import re
from .py2compat import time
import uuid
from .py2compat import datetime
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlparse = urllib.parse.urlparse
urlencode = urllib.parse.urlencode
from .sportacity import _Document, _text, UA
from .livehd import _get_html, _iframe_urls, _media_urls
BASE = 'https://www.sirfbs.live/'
SECTION_MAP = {'matches': (u'جدول المباريات', '')}

def parse_matches(html, day):
    entries = []
    for card in _Document(html).root.walk():
        if not card.has('eni-match'):
            continue
        nodes = list(card.walk())
        home = next((_text(n) for n in nodes if n.has('eni-team-home')), '')
        away = next((_text(n) for n in nodes if n.has('eni-team-away')), '')
        if not home or not away:
            continue
        scores = [_text(n) for n in nodes if n.has('eni-score') and (not n.has('eni-score-empty'))]
        clock = next((_text(n) for n in nodes if n.has('eni-live')), '')
        kickoff = next((n for n in nodes if n.has('eni-kickoff')), None)
        timestamp = kickoff.attrs.get('data-ts', '') if kickoff else ''
        when, hour = ('', '')
        if timestamp.isdigit():
            try:
                when = datetime.fromtimestamp(int(timestamp)).strftime('%Y-%m-%d %H:%M')
                hour = when[11:]
            except (ValueError, OverflowError, OSError):
                pass
        status = u'جارية الآن' + (' ' + clock if clock else '') if card.has('is-live') else u'انتهت' if len(scores) == 2 else u'لم تبدأ بعد'
        status_node = next((_text(n) for n in nodes if n.has('eni-status')), '')
        if status_node:
            status = status_node
        league = next((_text(n) for n in nodes if n.has('eni-competition')), '')
        link = urljoin(BASE, card.attrs.get('href', '')) if card.attrs.get('data-stream-link') == '1' else ''
        if urlparse(link).scheme not in ('http', 'https'):
            link = ''
        image = next((n.attrs.get('src', '') for n in nodes if n.tag == 'img'), '')
        result = ' - '.join(scores) if len(scores) == 2 else u'ضد'
        title = u'%s | %s %s %s | %s' % (hour or '--:--', home, result, away, status)
        identity = hashlib.sha1((day + '|' + home + '|' + away + '|' + timestamp + '|' + league).encode('utf8')).hexdigest()
        entries.append(dict(id=identity, name=title, title=title, home=home, away=away, day=day, url=link, time=hour, when=when, score=result, status=status, clock=clock, league=league, category=league, image=image, description=u' | '.join((x for x in (when, status, league) if x)), _match=True, is_live=True, source='sirfbs'))
    return entries

def groups():
    return [{'name': name, 'title': name, 'day': day, 'section': 'matches'} for day, name in [('today', u'مباريات اليوم'), ('yesterday', u'مباريات الأمس'), ('tomorrow', u'مباريات الغد')]]

def refresh():
    pass

def fetch_day(day):
    if day not in ('today', 'yesterday', 'tomorrow'):
        raise RuntimeError(u'يوم غير صحيح.')
    html, final = _get_html(BASE + '?match_day=' + day, UA, BASE)
    if re.search('cf-chl-|challenge-platform', html) and 'eni-match' not in html:
        raise RuntimeError(u'الموقع يطلب تحقق متصفح؛ لم يصل جدول المباريات.')
    return parse_matches(html, day)

def server_buttons(html, final):
    servers, seen = ([], set())
    for node in _Document(html).root.walk():
        if node.tag != 'a' or not node.has('aplr-link'):
            continue
        href = node.attrs.get('href', '')
        if not href or href.startswith(('javascript:', '#')):
            continue
        target = urljoin(final, href)
        if urlparse(target).scheme not in ('http', 'https') or target in seen:
            continue
        seen.add(target)
        servers.append({'name': _text(node) or u'سيرفر %d' % (len(servers) + 1), 'url': target, 'referer': final})
    return servers

def yasir_config(html):
    encoded = re.search('var _0x\\s*=\\s*["\\\']([A-Za-z0-9+/=]+)["\\\']', html)
    key = re.search('var k\\s*=\\s*["\\\']([^"\\\']+)["\\\']\\s*,\\s*d\\s*=\\s*atob\\(_0x\\)', html)
    if not encoded or not key:
        return {}
    try:
        raw, secret = (base64.b64decode(encoded.group(1)), key.group(1).encode('utf8'))
        decoded = bytes(bytearray(value ^ bytearray(secret)[index % len(secret)] for index, value in enumerate(bytearray(raw))))
        config = json.loads(decoded.decode('utf8'))
        return config if isinstance(config, dict) else {}
    except (ValueError, UnicodeError):
        return {}

def _yasir_servers(html, final):
    return [{'name': re.sub('\\[flag:[^\\]]+\\]', '', str(tab.get('name') or '')).strip() or u'مشغل %d' % (index + 1), 'url': final, 'referer': final, 'tab_index': index} for index, tab in enumerate(yasir_config(html).get('tabs') or []) if isinstance(tab, dict)]

def _broadcast_ended(html):
    return bool(re.search(r'<title[^>]*>\s*Match ended\s*</title>', html, re.I) or
                'This match has ended' in html)


def fetch_servers(item):
    if not item.get('url'):
        raise RuntimeError(u'المباراة موجودة في الجدول لكن الموقع لا يوفر رابط بث لها حالياً.')
    html, final = _get_html(item['url'], UA, BASE)
    if _broadcast_ended(html):
        raise RuntimeError(u'انتهى بث هذه المباراة من المصدر. اختر مباراة جارية من جدول اليوم.')
    roots = _iframe_urls(html, final)
    servers, seen = ([], set())
    for root in roots[:16]:
        if 'comment' in root.lower() or root == final:
            continue
        try:
            inner, page_url = _get_html(root, UA, final)
            found = server_buttons(inner, page_url) or _yasir_servers(inner, page_url) or [{'name': u'المشغل الرئيسي', 'url': page_url, 'referer': final}]
        except Exception:
            found = [{'name': u'المشغل الرئيسي', 'url': root, 'referer': final}]
        for server in found:
            key = (server['url'], server.get('tab_index'))
            if key not in seen:
                seen.add(key)
                server.update(server_key=server['url'] + ':' + str(server.get('tab_index', '')), action='play', day=item.get('day'), match_name=item['name'], description=item.get('description', ''), image=item.get('image', ''), source='sirfbs', is_live=True)
                servers.append(server)
    if not servers and (_media_urls(html, final) or 'AlbaPlayerControl(' in html):
        servers = [dict(item, name=u'المشغل الرئيسي', match_name=item['name'], url=final, referer=BASE, action='play', server_key=final)]
    if not servers:
        raise RuntimeError(u'صفحة المباراة لا تعرض مشغلات بث حالياً.')
    return servers

def page(parent, number):
    entries = fetch_servers(parent) if parent.get('_match') else fetch_day(parent.get('day', 'today'))
    start = (max(1, int(number)) - 1) * 24
    return {'entries': entries[start:start + 24], 'last_page': max(1, (len(entries) + 23) // 24)}

def media_candidates(html, final):
    urls = _media_urls(html, final)
    for value in re.findall('AlbaPlayerControl\\(\\s*["\\\']([A-Za-z0-9+/=_-]+)["\\\']\\s*,\\s*["\\\'](?:hls|plyr|mp4|html5|clappr)["\\\']', html, re.I):
        try:
            target = urljoin(final, base64.urlsafe_b64decode(value + '=' * (-len(value) % 4)).decode('utf8'))
            if urlparse(target).scheme in ('http', 'https') and target not in urls:
                urls.append(target)
        except (ValueError, UnicodeError):
            continue
    return urls

def _yasir_candidates(html, final, index):
    config = yasir_config(html)
    tabs = config.get('tabs') or []
    if not isinstance(index, int) or not 0 <= index < len(tabs):
        return []
    tab = tabs[index]
    if tab.get('type') == 'direct':
        target = str(tab.get('url') or '')
        return [(target, final)] if urlparse(target).scheme in ('http', 'https') else []
    path = str(tab.get('path') or '').lstrip('/')
    if tab.get('type') != 'regular' or not path:
        return []
    if urlparse(path).scheme in ('http', 'https'):
        return [(path, final)]
    value = path[7:] if path.startswith('kooora/') else path
    for prefix, suffix in [('kc/', '_kc'), ('mx/', '_mux'), ('loco/', '_loco'), ('sc/', '_sc')]:
        if value.startswith(prefix):
            path = 'kooora/' + value[len(prefix):] + suffix
            break
    else:
        if value.startswith('cf/'):
            path = 'kooora/' + value[3:]
    path = path[:-5] if path.endswith('.m3u8') else path
    encoded = re.search('var _e\\s*=\\s*["\\\']([A-Za-z0-9+/=]+)["\\\']', html)
    if not encoded:
        return []
    secret = base64.b64decode(encoded.group(1)).decode('ascii')
    session = uuid.uuid4().hex
    signed_path = path if path.startswith('kooora/') else 'kooora/' + path
    token = hashlib.md5((signed_path + session + secret).encode('ascii')).hexdigest()
    now, value, suffix = (int(time.time()), int(time.time()) % 100000, '')
    while value:
        value, digit = divmod(value, 36)
        suffix = '0123456789abcdefghijklmnopqrstuvwxyz'[digit] + suffix
    query = urlencode({'ts': now, 'nonce': uuid.uuid4().hex[:4] + (suffix or '0'), 'token': token, 'sid': session})
    return [(urljoin(domain.rstrip('/') + '/', path) + '?' + query, final) for domain in (config.get('activeDomains') or [])[:3] if urlparse(domain).scheme in ('http', 'https')]

def _resolve_pages(url, referer, depth=0, seen=None):
    seen = set() if seen is None else seen
    if depth > 5 or url in seen:
        return []
    seen.add(url)
    html, final = _get_html(url, UA, referer)
    if _broadcast_ended(html):
        raise RuntimeError(u'انتهى بث هذه المباراة من المصدر. اختر مباراة جارية من جدول اليوم.')
    urls = media_candidates(html, final)
    if urls:
        return [(target, final) for target in urls]
    results = []
    for child in _iframe_urls(html, final)[:16]:
        if child in (url, final) or 'comment' in child.lower():
            continue
        try:
            results.extend(_resolve_pages(child, final, depth + 1, seen))
        except Exception:
            continue
    return results

def resolve(item):
    from .py2compat import requests
    from .matchqualities import qualities as _hls_qualities
    streams, seen, failures = ([], set(), [])
    if 'tab_index' in item:
        html, final = _get_html(item['url'], UA, item.get('referer') or BASE)
        if _broadcast_ended(html):
            raise RuntimeError(u'انتهى بث هذه المباراة من المصدر. اختر مباراة جارية من جدول اليوم.')
        candidates = _yasir_candidates(html, final, item['tab_index'])
    else:
        candidates = _resolve_pages(item['url'], item.get('referer') or BASE)
    for url, referer in candidates:
        if url in seen:
            continue
        seen.add(url)
        headers = {'User-Agent': UA, 'Referer': referer}
        try:
            with requests.get(url, headers=headers, timeout=(7, 18), stream=True) as response:
                response.raise_for_status()
                chunks, size = ([], 0)
                for chunk in response.iter_content(16384):
                    chunks.append(chunk)
                    size += len(chunk)
                    if size >= 65536:
                        break
                raw, target = (b''.join(chunks), response.url)
            stream = dict(url=target, headers=headers, name=item['name'], quality='Auto', relay=True, relay_options={'live': True, 'livehd': True}, source='sirfbs')
            if raw.lstrip().startswith(b'#EXTM3U'):
                text = raw.decode('utf-8-sig', 'replace')
                if 'SAMPLE-AES' in text or re.search('KEYFORMAT="(?!identity")', text):
                    continue
                stream['mediatype'] = 'hls'
                streams.extend(_hls_qualities(text, stream))
            elif raw[:1] == b'G':
                streams.append(dict(stream, mediatype='ts', relay=False))
            elif b'ftyp' in raw[:32]:
                streams.append(dict(stream, mediatype='mp4', relay=False))
        except Exception as error:
            response = getattr(error, 'response', None)
            failures.append('HTTP %s' % response.status_code if response is not None else type(error).__name__)
            continue
    if not streams:
        reason = ' (' + ', '.join(sorted(set(failures))) + ')' if failures else ''
        raise RuntimeError(u'هذا المشغل لم يرجع بثاً صالحاً الآن؛ اختر مشغلاً آخر من القائمة.' + reason)
    return dict(item, name=item.get('match_name') or item['name'], url=streams[0]['url'], streams=streams, variants=streams)
