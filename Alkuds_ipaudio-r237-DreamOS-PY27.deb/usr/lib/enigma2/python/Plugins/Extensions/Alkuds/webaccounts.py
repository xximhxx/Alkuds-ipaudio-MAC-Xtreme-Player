# -*- coding: utf-8 -*-
"""Local account editor shared by Python 2.7 and Python 3. No network calls."""
from __future__ import unicode_literals
import glob
import hashlib
import io
import json
import os
import re
import sys
import tempfile
import threading
try:
    from urllib.parse import urlsplit, parse_qs, urlencode
except ImportError:
    from urlparse import urlsplit, parse_qs
    from urllib import urlencode
try:
    text_type = unicode
except NameError:
    text_type = str

LOCK = threading.RLock()
PLAYLIST = '/etc/enigma2/alkuds/playlists.txt'
STORE = '/etc/enigma2/alkuds/local-import.json'
MAC_FILES = None


def text(value):
    if isinstance(value, bytes):
        return value.decode('utf8')
    return text_type(value)


def configure():
    global PLAYLIST
    # The GUI has already loaded its config; HTTP workers never import Enigma.
    plugin = sys.modules.get(__package__ + '.plugin')
    if plugin is not None:
        PLAYLIST = text(plugin.cfg.playlist_file.value)


def read(path):
    try:
        with io.open(path, 'r', encoding='utf-8-sig') as handle:
            return handle.read()
    except IOError as error:
        if error.errno == 2:
            return ''
        raise


def atomic(path, content):
    parent = os.path.dirname(path)
    if not os.path.isdir(parent):
        os.makedirs(parent)
    fd, tmp = tempfile.mkstemp(prefix='.alkuds-web-', dir=parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(content.encode('utf8'))
            handle.flush()
            os.fsync(handle.fileno())
        os.rename(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def identity(kind, row):
    host = text(row.get('host') or row.get('portal') or '').strip().rstrip('/')
    p = urlsplit(host)
    host = p.scheme.lower() + '://' + p.netloc.lower() + p.path
    if kind == 'xtream':
        values = [kind, host, text(row.get('username') or ''), text(row.get('password') or '')]
    else:
        host = re.sub(r'/(?:c|server/load\.php|portal\.php)/?$', '', host.rstrip('/'))
        values = [kind, host.rstrip('/'), text(row.get('mac') or '').upper()]
    return hashlib.sha256(json.dumps(values, ensure_ascii=True).encode('utf8')).hexdigest()


def line_account(line):
    if not line.strip().startswith(('http://', 'https://')):
        return None
    raw, sep, name = line.strip().partition(' #')
    try:
        p = urlsplit(raw)
        p.port
        q = parse_qs(p.query)
        if not p.hostname or not q.get('username') or not q.get('password'):
            return None
        return dict(host=p.scheme + '://' + p.netloc, username=q['username'][0],
                    password=q['password'][0], name=name or p.hostname,
                    output=(q.get('output') or ['ts'])[0])
    except ValueError:
        return None


def mac_source():
    candidates = MAC_FILES if MAC_FILES is not None else (
        ['/media/%s/MultiStalkerPro.json' % x for x in ('hdd', 'usb', 'mmc', 'cf')] +
        sorted(glob.glob('/media/*/MultiStalkerPro.json')) +
        sorted(glob.glob('/media/*/*/MultiStalkerPro.json')) +
        ['/etc/enigma2/MultiStalkerPro.json', '/etc/enigma2/alkuds/MultiStalkerPro.json'])
    first = None
    for path in candidates:
        raw = read(path)
        if not raw.strip():
            continue
        try:
            data = json.loads(raw)
            if not isinstance(data, list):
                continue
        except ValueError:
            if first is None:
                first = (path, None)
            continue
        if first is None:
            first = (path, data)
        if any(isinstance(x, dict) and x.get('host') and x.get('mac') for x in data):
            return path, data
    if first:
        if first[1] is None:
            raise ValueError('صياغة ملف الماك غير صالحة؛ لم يتم تغييره')
        return first
    return candidates[-2] if len(candidates) > 1 else candidates[0], []


def snapshot(kind):
    with LOCK:
        store_raw = read(STORE)
        store = json.loads(store_raw) if store_raw.strip() else {}
        if not isinstance(store, dict):
            raise ValueError('صياغة ملف الاشتراكات غير صالحة')
        if kind == 'xtream':
            path, raw = PLAYLIST, read(PLAYLIST)
            original = raw.splitlines()
            rows = [line_account(line) for line in original]
            rows = [row for row in rows if row]
        elif kind == 'stalker':
            path, original = mac_source()
            raw = read(path)
            rows = [row for row in original if isinstance(row, dict) and row.get('host') and row.get('mac')]
        else:
            raise ValueError('نوع اشتراك غير صالح')
        hidden = set(store.get('removed_' + kind) or [])
        seen = set(identity(kind, row) for row in rows)
        for row in store.get(kind) or []:
            marker = identity(kind, row)
            if marker not in hidden and marker not in seen:
                rows.append(row)
                seen.add(marker)
        version = hashlib.sha256((path + '\0' + raw + '\0' + store_raw).encode('utf8')).hexdigest()
        return version, rows, path, original, store


def clean(value):
    value = text(value).strip()
    if len(value) > 4096 or any(x in value for x in ('\r', '\n', '\x00')):
        raise ValueError('قيمة غير صالحة')
    return value


def update(values):
    kind = values.get('account_kind')
    with LOCK:
        version, rows, path, original, store = snapshot(kind)
        if values.get('version') != version:
            raise RuntimeError('تغير الملف؛ حدّث الصفحة')
        index = int(values.get('index', '-1'))
        if index < -1 or index >= len(rows):
            raise ValueError('اشتراك غير موجود')
        old = rows[index] if index >= 0 else {}
        row = dict(old)
        for key in ('host', 'name', 'username', 'password', 'mac'):
            value = clean(values.get(key, ''))
            if value:
                row[key] = value
        host = row.get('host', '')
        p = urlsplit(host)
        try:
            port = p.port
        except ValueError:
            raise ValueError('بورت غير صالح')
        if p.scheme not in ('http', 'https') or not p.hostname or p.username or p.query or p.fragment or (port is not None and not 0 < port < 65536) or any(c.isspace() for c in host):
            raise ValueError('أدخل هوست صحيحًا يبدأ ببروتوكول الاتصال')
        row['name'] = row.get('name') or p.hostname
        if '#' in row['name'] or len(row['name']) > 100:
            raise ValueError('اسم غير صالح')
        if kind == 'xtream':
            row['host'] = p.scheme + '://' + p.netloc
            if not row.get('username') or not row.get('password'):
                raise ValueError('أدخل اسم المستخدم وكلمة المرور')
            output = values.get('output') or row.get('output', 'ts')
            if output not in ('ts', 'm3u8'):
                raise ValueError('صيغة غير صالحة')
            row['output'] = output
        else:
            row['mac'] = text(row.get('mac') or '').replace('-', ':').upper()
            if not re.match(r'^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$', row['mac']):
                raise ValueError('عنوان الماك غير صالح')
            row.setdefault('type', 1)
            row.setdefault('entryPoint', 'portal.php')
        marker = identity(kind, old) if old else None
        new_marker = identity(kind, row)
        if any(identity(kind, r) == new_marker and (not old or identity(kind, r) != marker) for r in rows):
            raise ValueError('الاشتراك موجود مسبقًا')
        if kind == 'xtream':
            lines = [line for line in original if not (line_account(line) and identity(kind, line_account(line)) == marker)]
            query = urlencode(dict((k, text(v).encode('utf8')) for k, v in dict(username=row['username'], password=row['password'], type='m3u_plus', output=row['output']).items()))
            lines.append(row['host'] + '/get.php?' + query + ' #' + row['name'])
            content = '\n'.join(lines) + '\n'
        else:
            remaining = [r for r in original if not (isinstance(r, dict) and r.get('host') and r.get('mac') and identity(kind, r) == marker)]
            remaining.append(row)
            content = json.dumps(remaining, ensure_ascii=True, indent=2) + '\n'
        # Suppress re-import of the edited old record, retaining unrelated state.
        if marker:
            store[kind] = [r for r in store.get(kind, []) if identity(kind, r) != marker]
            removed = set(store.get('removed_' + kind) or [])
            removed.add(marker)
            removed.discard(new_marker)
            store['removed_' + kind] = sorted(removed)
        atomic(path, content)
        if marker:
            atomic(STORE, json.dumps(store, ensure_ascii=True, indent=2) + '\n')


def render(esc, csrf):
    def hidden(key, value):
        return '<input type="hidden" name="%s" value="%s">' % (key, esc(text(value), quote=True))
    out = '<nav><a href="#xtream">الإكستريم</a> &nbsp; <a href="#stalker">الماك</a></nav>'
    for kind, title in (('xtream', 'اشتراكات الإكستريم'), ('stalker', 'اشتراكات الماك')):
        out += '<section id="%s"><h2>%s</h2>' % (kind, title)
        try:
            version, rows, path, unused, store = snapshot(kind)
        except (ValueError, IOError):
            out += '<p>تعذر قراءة ملف هذا القسم؛ تحقق من صياغته وصلاحياته.</p></section>'
            continue
        out += '<p dir="ltr">%s</p>' % esc(path)
        for index, row in list(enumerate(rows)) + [(-1, {})]:
            out += '<details%s><summary>%s</summary><form method="post" action="/accounts">' % (' open' if index < 0 else '', esc(text(row.get('name') or row.get('host') or 'إضافة اشتراك')))
            out += hidden('csrf', csrf) + hidden('version', version) + hidden('account_kind', kind) + hidden('index', index)
            fields = [('name', 'الاسم'), ('host', 'الهوست')]
            fields += [('username', 'اسم المستخدم'), ('password', 'كلمة المرور')] if kind == 'xtream' else [('mac', 'الماك')]
            for key, label in fields:
                value = text(row.get(key) or '') if key in ('name', 'host') else ''
                out += '<label>%s<input name="%s" type="%s" value="%s" autocomplete="off"></label>' % (label, key, 'password' if key == 'password' else 'text', esc(value, quote=True))
            if kind == 'xtream':
                out += '<label>صيغة البث<select name="output">' + ''.join('<option%s>%s</option>' % (' selected' if row.get('output', 'ts') == v else '', v) for v in ('ts', 'm3u8')) + '</select></label>'
            out += '<p>اترك بيانات الدخول فارغة عند التعديل للاحتفاظ بها.</p><button>حفظ</button></form></details>'
        out += '</section>'
    return out
