# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import service_reference, gui_text
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import os
from .py2compat import re
from .py2compat import threading
from .py2compat import time
from .py2compat import datetime
try:
    from http.client import HTTPConnection
    HTTPConnection.debuglevel = 0
except ImportError:
    from httplib import HTTPConnection
    HTTPConnection.debuglevel = 0
from requests.adapters import HTTPAdapter, Retry
from Components.ActionMap import ActionMap
from .xStaticText import List
from Screens.Console import Console
from .py2compat import gui_text
from Screens.Screen import Screen
from enigma import eServiceReference, iPlayableService, eTimer
from Components.ServiceEventTracker import ServiceEventTracker
from .xStaticText import ChoiceBox
from .xStaticText import MessageBox
from Components.Pixmap import Pixmap
from Components.config import configfile
from . import _
from . import alkuds_globals as glob
from . import processfiles as loadfiles
from .plugin import cfg, downloads_json, hasConcurrent, hasMultiprocessing, pythonFull, skin_directory, version, InternetSpeedTest_installed, NetSpeedTest_installed, debugs, pythonVer, dir_tmp
from .xStaticText import StaticText
hdr = {'User-Agent': str(cfg.useragent.value)}

def _release_badge(value):
    """Convert the internal version into a compact receiver-friendly label."""
    value = str(value or '')
    revision = re.search('(?:^|[-_])r(\\d+)(?:[-_]|$)', value, re.I)
    stamp = re.search('(?:^|[-_])(20\\d{6})(?:[-_]|$)', value)
    if revision and stamp:
        yyyymmdd = stamp.group(1)
        return 'R%s-%s%s%s' % (revision.group(1), yyyymmdd[6:8], yyyymmdd[4:6], yyyymmdd[0:4])
    return value
if pythonVer == 3:
    superscript_to_normal = str.maketrans(u'⁰¹²³⁴⁵⁶⁷⁸⁹ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖʳˢᵗᵘᵛʷˣʸᶻᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁⱽᵂ⁺⁻⁼⁽⁾', '0123456789abcdefghijklmnoprstuvwxyzABDEGHIJKLMNOPRTUVW+-=()')

def _cleanup_epg_folders(playlists_all):
    from .py2compat import shutil
    epg_root = os.path.join(str(cfg.epglocation.value).rstrip('/'), 'iptv-epg')
    if 'iptv-epg' not in epg_root:
        return
    if os.path.isdir(epg_root):
        valid_playlists = set()
        for playlist in playlists_all:
            try:
                valid_playlists.add(str(playlist['playlist_info']['name']))
            except Exception:
                pass
        for folder_name in os.listdir(epg_root):
            epgfolder = os.path.join(epg_root, folder_name)
            if not os.path.isdir(epgfolder):
                continue
            if folder_name not in valid_playlists:
                try:
                    shutil.rmtree(epgfolder)
                except Exception:
                    pass
                continue
            try:
                for filename in os.listdir(epgfolder):
                    if filename.lower().endswith('.xml'):
                        try:
                            os.remove(os.path.join(epgfolder, filename))
                        except Exception:
                            pass
            except Exception:
                pass
    try:
        if os.path.isdir(dir_tmp):
            for item in os.listdir(dir_tmp):
                path = os.path.join(dir_tmp, item)
                try:
                    if os.path.isdir(path):
                        shutil.rmtree(path)
                    else:
                        os.remove(path)
                except Exception:
                    pass
    except Exception:
        pass

def normalize_superscripts(text):
    return text.translate(superscript_to_normal)

def clean_names(streams):
    for item in streams:
        for field in ('name', 'category_name'):
            if field in item and isinstance(item[field], str):
                item[field] = normalize_superscripts(item[field])
    return streams

def _privacy_safe_host(value):
    value = str(value or '')
    if '://' in value:
        scheme, rest = value.split('://', 1)
        authority = rest.split('/', 1)[0].split('?', 1)[0]
        if '@' in authority:
            authority = authority.rsplit('@', 1)[-1]
        return scheme + '://' + authority
    return value.split('?', 1)[0]
playlists_json = cfg.playlists_json.value
_DEPENDENCIES_PROMPTED = False
_DEPENDENCIES_OK_AT = None

def _probe_menu_dependencies(vuplus):
    from .py2compat import requests
    from PIL import Image
    if pythonFull < (3, 9):
        from multiprocessing.pool import ThreadPool

    def _has_cmd(name):
        try:
            from .py2compat import shutil
            if hasattr(shutil, 'which'):
                return bool(shutil.which(name))
        except Exception:
            pass
        for d in ('/usr/bin', '/bin', '/usr/local/bin', '/usr/sbin', '/sbin'):
            p = os.path.join(d, name)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                return True
        return False
    need_media = not _has_cmd('ffmpeg') or not _has_cmd('openssl')
    if vuplus:
        if not (_has_cmd('gst-launch-1.0') and _has_cmd('gst-inspect-1.0')):
            need_media = True
        else:
            try:
                from .py2compat import subprocess
                with open(os.devnull, 'wb') as sink:
                    rc = subprocess.call(['gst-inspect-1.0', 'dvbaudiosink'], stdout=sink, stderr=sink, timeout=8)
                if rc != 0:
                    need_media = True
            except Exception:
                need_media = True
    elif not (_has_cmd('gst-launch-1.0') or _has_cmd('aplay')):
        need_media = True
    if need_media:
        raise RuntimeError('IPAudio media dependencies are missing')

class Alkuds_MainMenu(Screen):
    ALLOW_SUSPEND = True

    def __init__(self, session):
        if debugs:
            print('*** __init__ ***')
        Screen.__init__(self, session)
        self.session = session
        skin_path = os.path.join(skin_directory, cfg.skin.value)
        skin = os.path.join(skin_path, 'startmenu.xml')
        with open(skin, 'r') as f:
            self.skin = f.read()
        self._vertical_menu = 'menu-glow' in self.skin
        self.list = []
        self.drawList = []
        self.last_source_key = 21
        self['list'] = List(self.drawList, enableWrapAround=True)
        self.setup_title = _('Alkuds ipaudio - MAC & XTREME player')
        self['splash'] = Pixmap()
        self['splash'].show()
        self['background'] = StaticText('')
        self['version'] = StaticText(version)
        self['release_badge'] = StaticText(_release_badge(version))
        self['web_address'] = StaticText('')
        self['key_blue'] = StaticText(_('Update'))
        self._remote_status_started = False
        self._remote_status_done = False
        self._remote_status = None
        self._remote_status_error = ''
        self._remote_status_timer = eTimer()
        try:
            self._remote_status_timer_conn = self._remote_status_timer.timeout.connect(self._poll_remote_status)
        except Exception:
            self._remote_status_timer.callback.append(self._poll_remote_status)
        self['list1-bg'] = Pixmap()
        self['list2-bg'] = Pixmap()
        self['list1-bg'].show()
        self['list2-bg'].hide()
        actions = {'green': self.__next__, 'ok': self.__next__, 'left': self.goUp, 'right': self.goDown, 'menu': self.mainSettings, 'help': self.resetData, 'blue': self.updatePlugin, 'up': self.switchList, 'down': self.switchList, 'stop': self.stopAll}
        if self._vertical_menu:
            actions.update({'up': self.goUp, 'down': self.goDown, 'left': self.switchList, 'right': self.switchList})
        if not cfg.boot.value:
            actions.update({'red': self.quit, 'cancel': self.quit})
        self['actions'] = ActionMap(['AlkudsActions'], actions, -2)
        self.list2 = []
        self.drawList2 = []
        self['playlists'] = List(self.drawList2, enableWrapAround=True)
        self.toggle = False
        self.playlists_all = []
        self._accounts_state = None
        self._accounts_closed = False
        self._accounts_timer = eTimer()
        try:
            self._accounts_connection = self._accounts_timer.timeout.connect(self._poll_accounts)
        except Exception:
            self._accounts_timer.callback.append(self._poll_accounts)
        glob.active_playlist = []
        try:
            glob.currentPlayingServiceRef = self.session.nav.getCurrentlyPlayingServiceReference()
            glob.currentPlayingServiceRefString = self.session.nav.getCurrentlyPlayingServiceReference().toString()
            glob.newPlayingServiceRef = self.session.nav.getCurrentlyPlayingServiceReference()
            glob.newPlayingServiceRefString = glob.newPlayingServiceRef.toString()
        except:
            pass
        self.tracker = ServiceEventTracker(screen=self, eventmap={iPlayableService.evEOF: self.onEOF})
        self.onLayoutFinish.append(self.__layoutFinished)
        self.onFirstExecBegin.append(self._show_web_address)
        self.onFirstExecBegin.append(self.check_dependencies)
        self.onFirstExecBegin.append(self._load_accounts_async)
        self.onFirstExecBegin.append(self._start_remote_status_check)
        self.onClose.append(self._stop_remote_status_check)
        self.onClose.append(self._stop_accounts)

    def _show_web_address(self):
        try:
            from .audio_web import banner
            self['web_address'].setText(banner())
        except Exception:
            self['web_address'].setText(u'تعذر فتح صفحة الإدارة')

    def _load_accounts_async(self):
        if self._accounts_closed:
            return
        if self._accounts_state and (not self._accounts_state['done']):
            return
        state = {'done': False, 'rows': []}
        self._accounts_state = state

        def work():
            try:
                rows = loadfiles.process_files()
                for playlist in rows:
                    data = playlist.setdefault('data', {})
                    for key in ('live_categories', 'live_streams', 'vod_categories', 'series_categories'):
                        data[key] = []
                state['rows'] = rows
            except Exception as error:
                print('[Alkuds] Account load failed: ' + type(error).__name__)
            state['done'] = True
        worker = threading.Thread(target=work)
        worker.daemon = True
        worker.start()
        self._accounts_timer.start(120, False)

    def _poll_accounts(self):
        if self._accounts_closed:
            return
        state = self._accounts_state
        if not state or not state['done']:
            return
        if getattr(self.session, 'current_dialog', None) is not self:
            return
        self._accounts_timer.stop()
        self.playlists_all = state['rows']
        self._accounts_state = None
        self.createSourceOptions()

    def _stop_accounts(self):
        self._accounts_closed = True
        self._accounts_timer.stop()

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def _start_remote_status_check(self):
        if self._remote_status_started:
            return
        self._remote_status_started = True
        self._remote_status_done = False
        worker = threading.Thread(target=self._remote_status_worker)
        worker.daemon = True
        worker.start()
        self._remote_status_timer.start(250, False)

    def _remote_status_worker(self):
        try:
            from .remotealerts import fetch_status
            self._remote_status = fetch_status(version, cfg.useragent.value)
        except Exception as error:
            self._remote_status_error = str(error)
        self._remote_status_done = True

    def _poll_remote_status(self):
        if not self._remote_status_done:
            return
        self._remote_status_timer.stop()
        status = self._remote_status
        if not isinstance(status, dict):
            return
        if status.get('update_available'):
            self['key_blue'].setText(u'تحديث متوفر')
        else:
            self['key_blue'].setText(_('Update'))
        try:
            from .remotealerts import consume_pending_message
            message = consume_pending_message(status)
            if message:
                self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=0)
        except Exception as error:
            print('[Alkuds remote status]', error)

    def _stop_remote_status_check(self):
        try:
            self._remote_status_timer.stop()
        except Exception:
            pass

    def updatePlugin(self):
        self.session.openWithCallback(
            self._update_confirmed, MessageBox,
            _(u'هل تريد تنزيل وتثبيت تحديث Alkuds الآن؟'),
            MessageBox.TYPE_YESNO)

    def _update_confirmed(self, result):
        if not result:
            return
        try:
            from .pluginupdate import start_update
            start_update(self.session, self)
        except Exception as error:
            self.session.open(
                MessageBox, _(u'تعذر بدء التحديث:\n%s') % error,
                MessageBox.TYPE_ERROR, timeout=12)

    def switchList(self):
        if debugs:
            print('*** switchList ***')
        if getattr(self, 'lazy_source_mode', False):
            return
        if not cfg.startmenuplaylists.value:
            return
        self.toggle = not self.toggle
        instance1 = self['list'].master.master.instance
        instance2 = self['playlists'].master.master.instance
        if not self.toggle:
            instance1.setSelectionEnable(1)
            instance2.setSelectionEnable(0)
            self['list1-bg'].show()
            self['list2-bg'].hide()
        else:
            instance1.setSelectionEnable(0)
            instance2.setSelectionEnable(1)
            self['list1-bg'].hide()
            self['list2-bg'].show()

    def check_dependencies(self):
        self.start()
        now = time.monotonic()
        if _DEPENDENCIES_OK_AT is not None and now - _DEPENDENCIES_OK_AT < 600:
            return
        if getattr(self, '_dep_state', None) is not None:
            return
        try:
            from .receivercompat import is_vuplus
            vuplus = bool(is_vuplus())
        except Exception:
            vuplus = False
        state = {'done': False, 'ok': False}
        self._dep_state = state
        self._dep_closed = False
        self._dep_timer = eTimer()
        try:
            self._dep_connection = self._dep_timer.timeout.connect(self._dependencies_ready)
        except AttributeError:
            self._dep_timer.callback.append(self._dependencies_ready)
        self.onClose.append(self._stop_dependency_check)

        def work():
            try:
                _probe_menu_dependencies(vuplus)
                state['ok'] = True
            except Exception:
                state['ok'] = False
            state['done'] = True
        worker = threading.Thread(target=work)
        worker.daemon = True
        worker.start()
        self._dep_timer.start(250, False)

    def _dependencies_ready(self):
        global _DEPENDENCIES_OK_AT, _DEPENDENCIES_PROMPTED
        state = self._dep_state
        if self._dep_closed or not state or (not state['done']):
            return
        if state['ok']:
            _DEPENDENCIES_OK_AT = time.monotonic()
            self._dep_timer.stop()
            return
        if getattr(self.session, 'current_dialog', None) is not self:
            return
        self._dep_timer.stop()
        if _DEPENDENCIES_PROMPTED:
            return
        _DEPENDENCIES_PROMPTED = True
        path = '/usr/lib/enigma2/python/Plugins/Extensions/Alkuds/dependencies.sh'
        try:
            os.chmod(path, 493)
            self.session.openWithCallback(self._dependencies_installed, Console, title='Checking IPAudio Dependencies', cmdlist=[gui_text(path + ' manual')], closeOnSuccess=True)
        except OSError:
            self.session.open(MessageBox, 'IPAudio media dependencies are missing.', MessageBox.TYPE_ERROR, timeout=8)

    def _dependencies_installed(self, *args):
        self._dep_state = None

    def _stop_dependency_check(self):
        self._dep_closed = True
        self._dep_timer.stop()

    def start(self, answer=None):
        """Lite7: startup is local-only. Never probe every Xtream account."""
        if debugs:
            print('*** start (lazy sources) ***')
        try:
            self['playlists'].master.master.instance.setSelectionEnable(0)
        except Exception:
            pass
        self.toggle = False
        self.lazy_source_mode = True
        self.drawList2 = []
        self['playlists'].setList([])
        try:
            self['list1-bg'].show()
            self['list2-bg'].hide()
        except Exception:
            pass
        self['background'].setText('True')
        self['splash'].hide()
        self.createSourceOptions()

    def createSourceOptions(self):
        """First screen: choose the source type before any network work."""
        self.list = []
        downloads_all = []
        if os.path.isfile(downloads_json) and os.stat(downloads_json).st_size > 0:
            try:
                with open(downloads_json, 'r') as f:
                    downloads_all = json.load(f)
            except Exception:
                downloads_all = []
        self.list.append(['', 'Free Arabic TV', 21])
        self.list.append(['', 'Arabic Radio', 22])
        self.list.append(['', 'Xtream Codes', 11])
        self.list.append(['', 'IPAUDIO XTREME', 12])
        self.list.append(['', 'Portal / MAC', 10])
        self.list.append(['', 'MAC IPAUDIO', 13])
        self.list.append(['', 'Best Audio', 14])
        self.list.append(['', 'Sat Family Audio', 15])
        self.list.append(['', 'Orange IPAUDIO', 16])
        self.list.append(['', 'Free IPAUDIO', 17])
        self.list.append(['', 'Anis Free Audio', 19])
        self.list.append(['', 'FoX Free Audio', 20])
        self.list.append(['', _('Add Playlist'), 9])
        if self.playlists_all and cfg.manageplaylists.value:
            self.list.append(['', _('Manage Playlists'), 6])
        self.list.append(['', u'إدارة الصوتيات عبر المتصفح', 25])
        self.list.append(['', u'إعدادات الصوت والمشغّل', 24])
        self.list.append(['', _('Global Settings'), 4])
        if downloads_all:
            self.list.append(['', _('Download Manager'), 5])
        if cfg.boot.value:
            self.list.append(['', _('Reboot GUI'), 7])
        if cfg.speedtest.value and (InternetSpeedTest_installed is True or NetSpeedTest_installed is True):
            self.list.append(['', _('Speed Test'), 8])
        self.list.append(['', u'تحديث البلجن', 23])
        self.drawList = [self.buildListEntry(x[0], x[1], x[2], pos) for pos, x in enumerate(self.list)]
        self['list'].setList(self.drawList)
        try:
            restore_index = 0
            for position, entry in enumerate(self.list):
                if entry[2] == self.last_source_key:
                    restore_index = position
                    break
            self['list'].setIndex(restore_index)
        except Exception:
            pass

    def delayedDownload(self):
        if debugs:
            print('*** delayedDownload ***')
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.makePlaylistUrlList)
        except:
            try:
                self.timer.callback.append(self.makePlaylistUrlList)
            except:
                self.makePlaylistUrlList()
        self.timer.start(20, True)

    def makePlaylistUrlList(self):
        if debugs:
            print('*** makePlaylistUrlList ***')
        self.url_list = []
        for index, playlists in enumerate(self.playlists_all):
            player_api = str(playlists['playlist_info'].get('player_api', ''))
            full_url = str(playlists['playlist_info'].get('full_url', ''))
            domain = str(playlists['playlist_info'].get('domain', ''))
            username = str(playlists['playlist_info'].get('username', ''))
            password = str(playlists['playlist_info'].get('password', ''))
            if 'get.php' in full_url and domain and username and password:
                self.url_list.append([player_api, index])
        if self.url_list:
            self.processPlaylistDownloads()

    def processPlaylistDownloads(self):
        if debugs:
            print('*** processPlaylistDownloads ***')
        threads = min(len(self.url_list), 2)
        if hasConcurrent:
            self.concurrent_download(threads)
        elif hasMultiprocessing:
            self.multiprocessing_download(threads)
        else:
            self.sequential_download()
        self.buildPlaylistList()

    def concurrent_download(self, threads):
        if debugs:
            print('*** concurrent_download ***')
        from .py2compat import futures
        ThreadPoolExecutor = futures.ThreadPoolExecutor
        try:
            with ThreadPoolExecutor(max_workers=threads) as executor:
                results = list(executor.map(self.downloadUrl, self.url_list))
            self.update_playlists_with_results(results)
        except Exception as e:
            print('Concurrent execution error:', e)

    def multiprocessing_download(self, threads):
        if debugs:
            print('*** multiprocessing_download ***')
        from multiprocessing.pool import ThreadPool
        try:
            pool = ThreadPool(threads)
            results = pool.imap_unordered(self.downloadUrl, self.url_list)
            pool.close()
            pool.join()
            results_list = list(results)
            self.update_playlists_with_results(results_list)
        except Exception as e:
            print('Multiprocessing execution error:', e)

    def sequential_download(self):
        if debugs:
            print('*** sequential_download ***')
        for url in self.url_list:
            results = self.downloadUrl(url)
            self.update_playlists_with_results(results)

    def downloadUrl(self, url):
        if debugs:
            print('*** downloadUrl ***')
        from .py2compat import requests
        index = url[1]
        response = None
        retries = Retry(total=1, backoff_factor=1)
        adapter = HTTPAdapter(max_retries=retries)
        with requests.Session() as http:
            http.mount('http://', adapter)
            http.mount('https://', adapter)
            try:
                r = http.get(url[0], headers=hdr, timeout=6, verify=False)
                r.raise_for_status()
                content_type = r.headers.get('Content-Type', '')
                if 'application/json' in content_type:
                    try:
                        response = r.json()
                        if pythonVer == 3:
                            response = clean_names(response)
                    except ValueError as e:
                        print('Error decoding JSON:', e, url)
                        return (index, None)
                elif 'text/html' in content_type:
                    try:
                        response_text = r.text
                        response = json.loads(response_text)
                    except ValueError as e:
                        print('Error decoding JSON from HTML content:', e, url)
                        return (index, None)
                else:
                    print('Final response is non-JSON content:', r.url)
                    return (index, None)
            except requests.exceptions.RequestException as e:
                print('Request error:', e)
            except Exception as e:
                print('Unexpected error:', e)
        return (index, response)

    def update_playlists_with_results(self, results):
        if debugs:
            print('*** update_playlists_with_results ***')
        for index, response in results:
            if response:
                self.playlists_all[index].update(response)
            else:
                self.playlists_all[index]['user_info'] = {}

    def buildPlaylistList(self):
        if debugs:
            print('*** buildPlaylistList ***')
        for playlists in self.playlists_all:
            if 'user_info' in playlists:
                user_info = playlists['user_info']
                if 'message' in user_info:
                    del user_info['message']
                server_info = playlists.get('server_info', {})
                if 'https_port' in server_info:
                    del server_info['https_port']
                if 'rtmp_port' in server_info:
                    del server_info['rtmp_port']
                if 'time_now' in server_info:
                    time_formats = ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H-%M-%S', '%Y-%m-%d-%H:%M:%S', '%Y- %m-%d %H:%M:%S']
                    for time_format in time_formats:
                        try:
                            time_now_datestamp = datetime.strptime(str(server_info['time_now']), time_format)
                            offset = datetime.now().hour - time_now_datestamp.hour
                            playlists['player_info']['serveroffset'] = offset
                            break
                        except ValueError:
                            pass
                if 'timestamp_now' in server_info:
                    try:
                        timestamp = int(server_info['timestamp_now'])
                        timestamp_dt = datetime.utcfromtimestamp(timestamp)
                        current_dt = datetime.now()
                        time_difference = current_dt - timestamp_dt
                        hour_difference = int(time_difference.total_seconds() / 3600)
                        catchupoffset = hour_difference
                        playlists['player_info']['catchupoffset'] = catchupoffset
                    except:
                        pass
                auth = user_info.get('auth', 1)
                if not isinstance(auth, int):
                    user_info['auth'] = 1
                if 'status' in user_info:
                    valid_statuses = {'Active', 'Banned', 'Disabled', 'Expired'}
                    if user_info['status'] not in valid_statuses:
                        user_info['status'] = 'Active'
                    if user_info['status'] == 'Active':
                        playlists['data']['fail_count'] = 0
                    else:
                        playlists['data']['fail_count'] += 1
                if 'active_cons' in user_info and (not user_info['active_cons']):
                    user_info['active_cons'] = 0
                if 'max_connections' in user_info and (not user_info['max_connections']):
                    user_info['max_connections'] = 0
                if 'allowed_output_formats' in user_info:
                    allowed_formats = user_info['allowed_output_formats'] or []
                    output_format = playlists['playlist_info']['output']
                    if output_format not in allowed_formats:
                        playlists['playlist_info']['output'] = str(allowed_formats[0]) if allowed_formats else 'ts'
            else:
                playlists['data']['fail_count'] += 1
            playlists.pop('available_channels', None)
        self.writeJsonFile()
        self.createSetupPlaylists()

    def writeJsonFile(self):
        if debugs:
            print('*** writeJsonFile ***')
        with open(playlists_json, 'w') as f:
            json.dump(self.playlists_all, f, indent=4)

    def createSetupPlaylists(self):
        if debugs:
            print('*** createSetupPlaylists ***')
        if cfg.introvideo.value:
            self.playVideo()
        else:
            self['background'].setText('True')
        self['splash'].hide()
        self.list2 = []
        for playlist in self.playlists_all:
            name = playlist['playlist_info'].get('name', playlist['playlist_info'].get('domain', ''))
            url = _privacy_safe_host(playlist['playlist_info'].get('host', ''))
            activenum = ''
            maxnum = ''
            index = playlist['playlist_info']['index']
            user_info = playlist.get('user_info', {})
            if 'auth' in user_info:
                if str(user_info['auth']) == '1':
                    user_status = user_info.get('status', '')
                    if user_status == 'Active':
                        activenum = playlist['user_info']['active_cons']
                        try:
                            activenum = int(activenum)
                        except:
                            activenum = 0
                        maxnum = playlist['user_info']['max_connections']
                        try:
                            maxnum = int(maxnum)
                        except:
                            maxnum = 0
                        self.list2.append([index, name, url, activenum, maxnum])
            if playlist.get('data', {}).get('fail_count', 0) > 5:
                self.session.open(MessageBox, _('You have dead playlists that are slowing down loading.\n\nPress Yellow button to soft delete dead playlists'), MessageBox.TYPE_WARNING)
                for playlist in self.playlists_all:
                    playlist['data']['fail_count'] = 0
                with open(playlists_json, 'w') as f:
                    json.dump(self.playlists_all, f, indent=4)
        self.drawList2 = [self.buildPlalyistListEntry(x[0], x[1], x[2], x[3], x[4]) for x in self.list2]
        activeplaylists = any(('user_info' in playlist and 'status' in playlist['user_info'] and (playlist['user_info']['status'] == 'Active') for playlist in self.playlists_all))
        if activeplaylists:
            self.set_last_playlist()
            self.makeUrlCategoryList()
        else:
            self.addServer()
            self.close()

    def set_last_playlist(self):
        if debugs:
            print('*** set_last_playlist ***')
        activeindex = 0
        found = False
        for playlist in self.playlists_all:
            playlist_name = playlist['playlist_info']['name']
            if 'user_info' in playlist and playlist['user_info'] and ('status' in playlist['user_info']) and (playlist['user_info']['status'] == 'Active'):
                if playlist_name == cfg.lastplaylist.value:
                    glob.active_playlist = playlist
                    glob.current_active_playlist_selection = activeindex
                    self.original_active_playlist = glob.active_playlist
                    found = True
                    break
                activeindex += 1
        if not found:
            activeindex = 0
            for playlist in self.playlists_all:
                playlist_name = playlist['playlist_info']['name']
                if 'user_info' in playlist and playlist['user_info'] and ('status' in playlist['user_info']) and (playlist['user_info']['status'] == 'Active'):
                    glob.active_playlist = playlist
                    glob.current_active_playlist_selection = activeindex
                    cfg.lastplaylist.setValue(playlist_name)
                    cfg.save()
                    configfile.save()
                    break
                activeindex += 1
        glob.active_playlist['data']['live_streams'] = []
        self.original_active_playlist = glob.active_playlist
        self['playlists'].setList(self.drawList2)
        self['playlists'].setIndex(glob.current_active_playlist_selection)
        if not cfg.startmenuplaylists.value:
            self.drawList2 = []
            self['playlists'].setList(self.drawList2)

    def buildPlalyistListEntry(self, index, name, url, activenum, maxnum):
        text = str(name) + '   ' + _('Active:') + str(activenum) + ' ' + _('Max:') + str(maxnum)
        return (index, text, str(url))

    def getCurrentEntry(self):
        if debugs:
            print('*** getCurrentEntry ***')
        if self.list2:
            self['list'].setIndex(0)
            glob.active_playlist['data']['live_categories'] = []
            glob.active_playlist['data']['live_streams'] = []
            glob.active_playlist['data']['vod_categories'] = []
            glob.active_playlist['data']['series_categories'] = []
            glob.current_active_playlist_selection = self['playlists'].getIndex()
            current_playlist_selection = self['playlists'].getCurrent()[0]
            glob.active_playlist = self.playlists_all[current_playlist_selection]
            self.original_active_playlist = glob.active_playlist
            cfg.lastplaylist.setValue(glob.active_playlist['playlist_info']['name'])
            cfg.save()
            configfile.save()
            self.makeUrlCategoryList()

    def makeUrlCategoryList(self):
        if debugs:
            print('*** makeUrlCategoryList ***')
        self.url_list = []
        glob.active_playlist['data']['live_categories'] = []
        glob.active_playlist['data']['vod_categories'] = []
        glob.active_playlist['data']['series_categories'] = []
        glob.active_playlist['data']['live_streams'] = []
        glob.active_playlist['data']['catchup'] = False
        glob.active_playlist['data']['customsids'] = False
        self.active_player_api = glob.active_playlist['playlist_info']['player_api']
        self.active_live_categories_url = str(self.active_player_api) + '&action=get_live_categories'
        self.active_vod_categories_url = str(self.active_player_api) + '&action=get_vod_categories'
        self.active_series_categories_url = str(self.active_player_api) + '&action=get_series_categories'
        self.active_live_streams_url = str(self.active_player_api) + '&action=get_live_streams'
        show_live = glob.active_playlist['player_info'].get('showlive', False)
        show_vod = glob.active_playlist['player_info'].get('showvod', False)
        show_series = glob.active_playlist['player_info'].get('showseries', False)
        show_catchup = glob.active_playlist['player_info'].get('showcatchup', False)
        full_url = str(glob.active_playlist['playlist_info'].get('full_url', ''))
        domain = str(glob.active_playlist['playlist_info'].get('domain', ''))
        username = str(glob.active_playlist['playlist_info'].get('username', ''))
        password = str(glob.active_playlist['playlist_info'].get('password', ''))
        if 'get.php' in full_url and domain and username and password:
            if show_live:
                self.url_list.append([self.active_live_categories_url, 1])
            if show_vod:
                self.url_list.append([self.active_vod_categories_url, 2])
            if show_series:
                self.url_list.append([self.active_series_categories_url, 3])
            if show_catchup:
                self.url_list.append([self.active_live_streams_url, 4])
        self.processApiDownloads()

    def processApiDownloads(self):
        if debugs:
            print('*** processApiDownloads ***')
        threads = min(len(self.url_list), 2)
        if hasConcurrent:
            self.concurrent_api_download(threads)
        elif hasMultiprocessing:
            self.multiprocessing_api_download(threads)
        else:
            self.sequential_api_download()
        self.createSetupOptions()

    def concurrent_api_download(self, threads):
        if debugs:
            print('*** concurrent_api_download ***')
        from .py2compat import futures
        ThreadPoolExecutor = futures.ThreadPoolExecutor
        try:
            with ThreadPoolExecutor(max_workers=threads) as executor:
                results = list(executor.map(self.downloadUrl, self.url_list))
            self.update_playlists_with_api_results(results)
        except Exception as e:
            print('Concurrent execution error:', e)

    def multiprocessing_api_download(self, threads):
        if debugs:
            print('*** multiprocessing_api_download ***')
        from multiprocessing.pool import ThreadPool
        try:
            pool = ThreadPool(threads)
            results = pool.imap_unordered(self.downloadUrl, self.url_list)
            pool.close()
            pool.join()
            results_list = list(results)
            self.update_playlists_with_api_results(results_list)
        except Exception as e:
            print('Multiprocessing execution error:', e)

    def sequential_api_download(self):
        if debugs:
            print('*** sequential_api_download ***')
        for url in self.url_list:
            results = self.downloadUrl(url)
            self.update_playlists_with_api_results(results)

    def update_playlists_with_api_results(self, results):
        if debugs:
            print('*** update_playlists_with_api_results ***')
        for index, response in results:
            if response:
                if index == 1:
                    glob.active_playlist['data']['live_categories'] = response
                if index == 2:
                    glob.active_playlist['data']['vod_categories'] = response
                if index == 3:
                    glob.active_playlist['data']['series_categories'] = response
                if index == 4:
                    glob.active_playlist['data']['live_streams'] = response

    def createSetupOptions(self):
        if debugs:
            print('*** createSetupOptions ***')
        self.list = []
        self.index = 0
        downloads_all = []
        if os.path.isfile(downloads_json) and os.stat(downloads_json).st_size > 0:
            try:
                with open(downloads_json, 'r') as f:
                    downloads_all = json.load(f)
            except Exception as e:
                print(e)
        if self.playlists_all:
            show_live = glob.active_playlist['player_info'].get('showlive', False)
            show_vod = glob.active_playlist['player_info'].get('showvod', False)
            show_series = glob.active_playlist['player_info'].get('showseries', False)
            show_catchup = glob.active_playlist['player_info'].get('showcatchup', False)
            content = glob.active_playlist['data']['live_streams']
            has_catchup = any((str(item.get('tv_archive', '0')) == '1' for item in content if 'tv_archive' in item))
            has_custom_sids = any((item.get('custom_sid', False) for item in content if 'custom_sid' in item))
            glob.active_playlist['data']['live_streams'] = []
            if has_custom_sids:
                glob.active_playlist['data']['customsids'] = True
            if has_catchup:
                glob.active_playlist['data']['catchup'] = True
            if show_live and glob.active_playlist['data']['live_categories']:
                self.list.append(['', _('Live TV'), 0])
            if show_vod and glob.active_playlist['data']['vod_categories']:
                self.list.append(['', _('Movies'), 1])
            if show_series and glob.active_playlist['data']['series_categories']:
                self.list.append(['', _('Series'), 2])
            if show_catchup and glob.active_playlist['data']['catchup']:
                self.list.append(['', _('Catch Up TV'), 3])
        self.list.append(['', _('Add Playlist'), 9])
        self.list.append(['', 'Stalker / MAC', 10])
        if self.playlists_all:
            if cfg.manageplaylists.value:
                self.list.append(['', _('Manage Playlists'), 6])
        self.list.append(['', u'إدارة الصوتيات عبر المتصفح', 25])
        self.list.append(['', u'إعدادات الصوت والمشغّل', 24])
        self.list.append(['', _('Global Settings'), 4])
        if downloads_all:
            self.list.append(['', _('Download Manager'), 5])
        if cfg.boot.value:
            self.list.append(['', _('Reboot GUI'), 7])
        if cfg.speedtest.value and (InternetSpeedTest_installed is True or NetSpeedTest_installed is True):
            self.list.append(['', _('Speed Test'), 8])
        self.list.append(['', u'تحديث البلجن', 23])
        self.drawList = [self.buildListEntry(x[0], x[1], x[2], pos) for pos, x in enumerate(self.list)]
        self['list'].setList(self.drawList)
        if self.playlists_all:
            playlistindex = glob.active_playlist['playlist_info']['index']
            try:
                self.playlists_all[playlistindex] = glob.active_playlist
            except:
                glob.active_playlist['playlist_info']['index'] = 0
                self.playlists_all[0] = glob.active_playlist
            self.writeJsonFile()

    def _row_pixmap(self, position):
        """Pre-rendered coloured rectangle for a menu row (vertical skin only)."""
        try:
            cache = self.__dict__.setdefault('_row_pixmaps', {})
            slot = int(position) % 8
            if slot not in cache:
                from Tools.LoadPixmap import LoadPixmap
                path = os.path.join(skin_directory, cfg.skin.value, 'images', 'menu-row-%d.png' % slot)
                cache[slot] = LoadPixmap(path) if os.path.exists(path) else None
            return cache[slot]
        except Exception:
            return None

    def buildListEntry(self, index, title, num, position=0):
        return (index, str(title), num, self._row_pixmap(position))

    def __next__(self):
        if debugs:
            print('*** __next__ ***')
        current_entry = self['list'].getCurrent()
        current_index = current_entry[2] if current_entry else None
        if current_index is not None:
            self.last_source_key = current_index
        if cfg.introvideo.value and current_index not in (12, 13, 14, 15, 16, 17, 18, 19, 20, 24, 25):
            try:
                if glob.currentPlayingServiceRefString:
                    self.session.nav.playService(service_reference(glob.currentPlayingServiceRefString))
            except Exception as e:
                print(e)
        if self.playlists_all and isinstance(glob.active_playlist, dict) and glob.active_playlist.get('playlist_info'):
            glob.current_selection = glob.active_playlist['playlist_info'].get('index', 0)
        if current_entry:
            index = current_entry[2]
            state = self._accounts_state
            if index in (6, 9, 11, 12) and state and (not state['done']):
                self.session.open(MessageBox, u'جاري قراءة الاشتراكات؛ حاول بعد لحظة.', type=MessageBox.TYPE_INFO, timeout=2)
                return
            if index == 0:
                self.showLive()
            elif index == 1:
                self.showVod()
            elif index == 2:
                self.showSeries()
            elif index == 3:
                self.showCatchup()
            elif index == 4:
                self.mainSettings()
            elif index == 5:
                self.downloadManager()
            elif index == 6:
                self.showPlaylists()
            elif index == 7:
                self.ExecuteRestart()
            elif index == 8:
                self.runSpeedTest()
            elif index == 9:
                self.addServer()
            elif index == 10:
                self.showStalker()
            elif index == 11:
                self.showXtreamSelector()
            elif index == 12:
                self.showIPAudioXtream()
            elif index == 13:
                self.showIPAudioMAC()
            elif index == 14:
                self.showBestAudio()
            elif index == 15:
                self.showSatFamilyAudio()
            elif index == 16:
                self.showOrangeAudio()
            elif index == 17:
                self.showFreeAudio()
            elif index == 19:
                self.showAnisAudio()
            elif index == 20:
                self.showFoxAudio()
            elif index == 21:
                self.showFreeTV()
            elif index == 22:
                self.showArabicRadio()
            elif index == 23:
                self.updatePlugin()
            elif index == 25:
                from .audio_web import show_access
                show_access(self.session)
            elif index == 24:
                from .playbacksettings import open_playback_settings
                open_playback_settings(self.session)

    def runSpeedTest(self):
        if debugs:
            print('*** runSpeedTest ***')
        if InternetSpeedTest_installed:
            from Plugins.Extensions.InternetSpeedTest.plugin import internetspeedtest
            self.session.openWithCallback(self.reload, internetspeedtest)
        elif NetSpeedTest_installed:
            from Plugins.Extensions.NetSpeedTest.default import NetSpeedTestScreen
            self.session.openWithCallback(self.reload, NetSpeedTestScreen)

    def ExecuteRestart(self, result=None):
        from Screens import Standby
        Standby.quitMainloop(3)

    def showLive(self):
        from . import live
        self.session.openWithCallback(self.reload, live.Alkuds_Live_Categories)

    def showVod(self):
        from . import vod
        self.session.openWithCallback(self.reload, vod.Alkuds_Vod_Categories)

    def showSeries(self):
        from . import series
        self.session.openWithCallback(self.reload, series.Alkuds_Series_Categories)

    def showCatchup(self):
        from . import catchup
        self.session.openWithCallback(self.reload, catchup.Alkuds_Catchup_Categories)

    def mainSettings(self):
        from . import settings
        self.session.openWithCallback(self.noreload, settings.Alkuds_Settings)

    def downloadManager(self):
        from . import downloadmanager
        self.session.openWithCallback(self.reload, downloadmanager.Alkuds_DownloadManager)

    def showPlaylists(self):
        from . import playlists
        self.session.openWithCallback(self.reload, playlists.Alkuds_Playlists)

    def addServer(self):
        from . import server
        self.session.openWithCallback(self.noreload, server.Alkuds_AddServer)

    def showStalker(self):
        from . import stalker
        self.session.openWithCallback(self.noreload, stalker.Alkuds_Stalker_Manager)

    def showXtreamSelector(self):
        from . import xtreamlite
        self.session.openWithCallback(self.noreload, xtreamlite.Alkuds_Xtream_Manager)

    def _ipaudio_finished(self, result=None):
        if result == 'ipaudio-started':
            self.close('ipaudio-started')
            return
        self.noreload()

    def showIPAudioXtream(self):
        from . import xtreamlite
        self.session.openWithCallback(self._ipaudio_finished, xtreamlite.Alkuds_Xtream_Manager, True)

    def showIPAudioMAC(self):
        from . import stalker
        self.session.openWithCallback(self._ipaudio_finished, stalker.Alkuds_Stalker_Manager, True)

    def showBestAudio(self):
        from . import audiofeeds
        self.session.openWithCallback(self._ipaudio_finished, audiofeeds.Alkuds_AudioFeed_Manager, 'best_audio')

    def showSatFamilyAudio(self):
        from . import audiofeeds
        self.session.openWithCallback(self._ipaudio_finished, audiofeeds.Alkuds_AudioFeed_Manager, 'sat_family')

    def showOrangeAudio(self):
        self.session.openWithCallback(self._orange_provider_selected, ChoiceBox, title='Orange Audio', list=[('GoRadio | goradio.top | Username + Password', 'orange_goradio'), ('Radio Orange | radio.orange-audio.top | Token', 'orange_audio')])

    def _orange_provider_selected(self, answer=None):
        if not answer or len(answer) < 2 or answer[1] not in ('orange_goradio', 'orange_audio'):
            return
        from . import audiofeeds
        self.session.openWithCallback(self._ipaudio_finished, audiofeeds.Alkuds_AudioFeed_Manager, answer[1])

    def showFreeAudio(self):
        from . import audiofeeds
        self.session.openWithCallback(self._ipaudio_finished, audiofeeds.Alkuds_AudioFeed_Manager, 'free_audio')

    def showAnisAudio(self):
        from . import audiofeeds
        self.session.openWithCallback(self._ipaudio_finished, audiofeeds.Alkuds_AudioFeed_Manager, 'anis_audio')

    def showFoxAudio(self):
        from . import audiofeeds
        self.session.openWithCallback(self._ipaudio_finished, audiofeeds.Alkuds_AudioFeed_Manager, 'fox_audio')

    def showArabicRadio(self):
        from .freechannels import Alkuds_ArabicRadio_Browser
        self.session.open(Alkuds_ArabicRadio_Browser)

    def showFreeTV(self):
        from . import freechannels
        self.session.openWithCallback(self.noreload, freechannels.Alkuds_FreeTV_Menu)

    def stopAll(self):
        try:
            from .backgroundaudio import stop_ipaudio_and_timeshift
            stop_ipaudio_and_timeshift(session=self.session, close_plugin=True)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to stop IPAUDIO / Timeshift:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=6)

    def quit(self, data=None):
        try:
            from .backgroundaudio import background_audio_status
            active, _name, _backend = background_audio_status()
            if active:
                self.close()
                return
        except Exception:
            pass
        try:
            from .remux import is_local_remux_active
            if is_local_remux_active():
                try:
                    if cfg.remuxvideohold.value:
                        from .remuxreturn import schedule_video_hold
                        schedule_video_hold(self.session, int(cfg.remuxvideoholddelay.value))
                except Exception:
                    pass
                self.close()
                return
        except Exception:
            pass
        self.playOriginalChannel()

    def playOriginalChannel(self):
        if debugs:
            print('*** playOriginalChannel ***')
        try:
            from .backgroundaudio import background_audio_status
            active, _name, _backend = background_audio_status()
            if active:
                self.close()
                return
        except Exception:
            pass
        try:
            if glob.currentPlayingServiceRefString:
                original = service_reference(glob.currentPlayingServiceRefString)
                from .listpreview import restore_cinehd_channel
                if restore_cinehd_channel(self.session, original):
                    self.close()
                    return
                current = self.session.nav.getCurrentlyPlayingServiceReference()
                if not current or current.toString() != original.toString():
                    self.session.nav.playService(original)
        except Exception as e:
            print(e)
        self.close()

    def playVideo(self, result=None):
        if debugs:
            print('*** playVideo ***')
        self['background'].setText('')
        self.local_video_path = cfg.introvideoselection.value
        service = service_reference(4097, 0, self.local_video_path)
        try:
            self.session.nav.playService(service)
        except:
            pass

    def onEOF(self):
        if debugs:
            print('*** onEOF ***')
        if cfg.introvideo.value and cfg.introloop.value:
            self['background'].setText('')
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if seek:
                seek.seekTo(0)
        else:
            self['background'].setText('True')

    def goUp(self):
        instance1 = self['list'].master.master.instance
        instance2 = self['playlists'].master.master.instance
        if self.toggle is False:
            instance1.moveSelection(instance1.moveUp)
        else:
            instance2.moveSelection(instance2.moveUp)
            self.getCurrentEntry()

    def goDown(self):
        instance1 = self['list'].master.master.instance
        instance2 = self['playlists'].master.master.instance
        if self.toggle is False:
            instance1.moveSelection(instance1.moveDown)
        else:
            instance2.moveSelection(instance2.moveDown)
            self.getCurrentEntry()

    def resetData(self, answer=None):
        if debugs:
            print('*** resetData ***')
        if answer is None:
            self.session.openWithCallback(self.resetData, MessageBox, _('Warning: delete stored json data for all playlists... Settings, favourites etc. \nPlaylists will not be deleted.\nDo you wish to continue?'))
        elif answer:
            try:
                os.remove(playlists_json)
                with open(playlists_json, 'a'):
                    pass
            except OSError as e:
                print('Error deleting or recreating JSON file:', e)
            self.quit()

    def reload(self, Answer=None):
        self._load_accounts_async()
        self.original_active_playlist = glob.active_playlist
        self['background'].setText('True')
        self['splash'].hide()
        self.createSourceOptions()

    def noreload(self, Answer=None):
        self._load_accounts_async()
        self['background'].setText('True')
        self['splash'].hide()
        self.createSourceOptions()
