# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Free Arabic TV catalogues with on-demand provider refresh."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .py2compat import threading
from .py2compat import time
try:
    from .py2compat import urllib
    quote = urllib.parse.quote
except ImportError:
    from urllib import quote

def _lazy_call(module_name, function_name):
    resolved = []

    def call(*args, **kwargs):
        if module_name == 'listpreview' and function_name == 'attach_list_preview':
            if not getattr(args[0].session, '_alkuds_list_playback', None):
                return
        if module_name == 'listpreview' and function_name == 'stop_list_playback':
            if not getattr(args[0], '_alkuds_list_playback', None):
                return
        if not resolved:
            from importlib import import_module
            resolved.append(getattr(import_module('.' + module_name, __package__), function_name))
        return resolved[0](*args, **kwargs)
    return call
open_list_player = _lazy_call('listpreview', 'open_list_player')
attach_list_preview = _lazy_call('listpreview', 'attach_list_preview')
stop_list_playback = _lazy_call('listpreview', 'stop_list_playback')
from Components.ActionMap import ActionMap
from .freestyle import StyledList as List, FONT
from .xStaticText import ChoiceBox
from .xStaticText import MessageBox
from Screens.Screen import Screen
from enigma import eTimer, getDesktop
fetch_drama_channels = _lazy_call('freeproviders', 'fetch_drama_channels')
fetch_drama_episodes = _lazy_call('freeproviders', 'fetch_drama_episodes')
fetch_drama_show_topics = _lazy_call('freeproviders', 'fetch_drama_show_topics')
fetch_drama_shows = _lazy_call('freeproviders', 'fetch_drama_shows')
fetch_drama_topics = _lazy_call('freeproviders', 'fetch_drama_topics')
fetch_elahmad_catalogue = _lazy_call('freeproviders', 'fetch_elahmad_catalogue')
fetch_fajer_channels = _lazy_call('freeproviders', 'fetch_fajer_channels')
fetch_yacine_categories = _lazy_call('freeproviders', 'fetch_yacine_categories')
fetch_yacine_channels = _lazy_call('freeproviders', 'fetch_yacine_channels')
fetch_syria_live_events = _lazy_call('freeproviders', 'fetch_syria_live_events')
fetch_egybest_live_groups = _lazy_call('freeproviders', 'fetch_egybest_live_groups')
fetch_egybest_items = _lazy_call('freeproviders', 'fetch_egybest_items')
fetch_egybest_seasons = _lazy_call('freeproviders', 'fetch_egybest_seasons')
fetch_egybest_episodes = _lazy_call('freeproviders', 'fetch_egybest_episodes')
fetch_oscar_channels = _lazy_call('freeproviders', 'fetch_oscar_channels')
resolve_oscar_channel = _lazy_call('freeproviders', 'resolve_oscar_channel')
fetch_original_groups = _lazy_call('freeproviders', 'fetch_original_groups')
fetch_original_items = _lazy_call('freeproviders', 'fetch_original_items')
fetch_original_seasons = _lazy_call('freeproviders', 'fetch_original_seasons')
fetch_original_episodes = _lazy_call('freeproviders', 'fetch_original_episodes')
fetch_ostora_groups = _lazy_call('freeproviders', 'fetch_ostora_groups')
resolve_ostora_selection = _lazy_call('freeproviders', 'resolve_ostora_selection')
fetch_ostora_items = _lazy_call('freeproviders', 'fetch_ostora_items')
fetch_ostora_seasons = _lazy_call('freeproviders', 'fetch_ostora_seasons')
fetch_ostora_episodes = _lazy_call('freeproviders', 'fetch_ostora_episodes')
resolve_drama_channel = _lazy_call('freeproviders', 'resolve_drama_channel')
resolve_drama_episode = _lazy_call('freeproviders', 'resolve_drama_episode')
resolve_elahmad_channel = _lazy_call('freeproviders', 'resolve_elahmad_channel')
resolve_fajer_channel = _lazy_call('freeproviders', 'resolve_fajer_channel')
resolve_yacine_channel = _lazy_call('freeproviders', 'resolve_yacine_channel')
resolve_syria_live_event = _lazy_call('freeproviders', 'resolve_syria_live_event')
resolve_egybest_item = _lazy_call('freeproviders', 'resolve_egybest_item')
_resolve_egybest_page = _lazy_call('freeproviders', '_resolve_egybest_page')
resolve_original_item = _lazy_call('freeproviders', 'resolve_original_item')
resolve_ostora_item = _lazy_call('freeproviders', 'resolve_ostora_item')
resolve_ostora_live_item = _lazy_call('freeproviders', 'resolve_ostora_live_item')
hls_variant_streams = _lazy_call('freeproviders', 'hls_variant_streams')
service_stream_url = _lazy_call('freeproviders', 'service_stream_url')
stream_quality_label = _lazy_call('freeproviders', 'stream_quality_label')
from .plugin import cfg
from .receivercompat import selected_free_service_type, set_selected_free_service_type, available_free_service_types
prepare_hls_relay = _lazy_call('streamproxy', 'prepare_hls_relay')
from .xStaticText import StaticText
fetch_livehd_matches = _lazy_call('livehd', 'fetch_livehd_matches')
fetch_combined_match_servers = _lazy_call('livehd', 'fetch_combined_match_servers')
resolve_livehd_server = _lazy_call('livehd', 'resolve_livehd_server')
fetch_livekora_matches = _lazy_call('livekora', 'fetch_livekora_matches')
merge_match_catalogues = _lazy_call('livekora', 'merge_match_catalogues')
mytuner_radio_groups = _lazy_call('mytunerradio', 'groups')
mytuner_radio_items = _lazy_call('mytunerradio', 'items')
legacy_radio_groups = _lazy_call('radiobrowserradio', 'legacy_groups')
radio_browser_items = _lazy_call('radiobrowserradio', 'items')
world_radio_groups = _lazy_call('worldradiomapradio', 'groups')
world_radio_items = _lazy_call('worldradiomapradio', 'items')
world_radio_resolve = _lazy_call('worldradiomapradio', 'resolve')
COLOR_WHITE = 16777215
COLOR_GREEN = 7208838
COLOR_RED = 16737380

def _list_entry(text, value, marker='', marker_color=COLOR_WHITE):
    return (str(text or ''), value, str(marker or ''), int(marker_color))

def _free_channels_skin(hint=False):
    """Violet/white Free TV layout: a narrow list on the left and a mini TV on the right."""
    size = getDesktop(0).size()
    width, height = (size.width(), size.height())
    margin = 24 if width >= 1920 else 16
    panel = int(width * 0.54)
    top, foot = (110, 76) if height >= 1080 else (82, 60)
    font = 42 if width >= 1920 else 32 if width >= 1280 else 25
    item = 92 if height >= 1080 else 72 if height >= 720 else 58
    row = panel - margin * 2 - 24
    icon_size = 54 if height >= 1080 else 44
    template = '{"template":[MultiContentEntryText(pos=(0,2),size=(%d,%d),font=0,text=7,backcolor=0xff000004,backcolor_sel=0x6D3FC4),MultiContentEntryPixmapAlphaBlend(pos=(14,%d),size=(%d,%d),png=6),MultiContentEntryText(pos=(%d,4),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0,color=0xff000005,color_sel=0xFFFFFF,backcolor=0xff000004,backcolor_sel=0x6D3FC4),MultiContentEntryText(pos=(%d,4),size=(42,%d),font=0,text=2,color=0xff000003,color_sel=0xff000003,flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER)],"fonts":[gFont("%s",%d)],"itemHeight":%d}' % (row, item - 4, (item - icon_size) // 2, icon_size, icon_size, icon_size + 30, row - icon_size - 90, item - 8, row - 46, item - 8, FONT, font, item)
    right = panel + margin
    pig_w = width - right - margin
    pig_h = int(pig_w * 9 / 16)
    xml = ['<screen name="AlkudsFreeTVList" position="0,0" size="%d,%d" backgroundColor="#ff12061f" flags="wfNoBorder">' % (width, height), '<eLabel position="0,0" size="%d,%d" backgroundColor="#1a0b2e" />' % (panel, height), '<eLabel position="0,0" size="7,%d" backgroundColor="#7c3aed" zPosition="2" />' % height, '<widget source="title" render="Label" position="%d,14" size="%d,%d" font="%s;%d" foregroundColor="#ffffff" backgroundColor="#1a0b2e" valign="center" noWrap="1" zPosition="2" />' % (margin + 12, panel - 2 * margin - 24, top - 22, FONT, font + 6), '<widget source="list" render="Listbox" position="%d,%d" size="%d,%d" foregroundColor="#ffffff" backgroundColor="#1a0b2e" backgroundColorSelected="#6d3fc4" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2"><convert type="TemplatedMultiContent">%s</convert></widget>' % (margin, top, panel - margin * 2, height - top - foot, template), '<eLabel position="%d,%d" size="%d,%d" backgroundColor="#ffffff" zPosition="2" />' % (right - 4, top - 4, pig_w + 8, pig_h + 8), '<widget source="session.VideoPicture" render="Pig" position="%d,%d" size="%d,%d" backgroundColor="#ff000000" transparent="0" zPosition="3" />' % (right, top, pig_w, pig_h)]
    if hint:
        hint_text = u'OK ← معاينة مصغّرة     •     INFO ← ملء الشاشة'
        xml.append(u'<eLabel position="%d,%d" size="%d,%d" text="%s" font="%s;%d" foregroundColor="#e9d5ff" backgroundColor="#12061f" transparent="1" halign="center" valign="center" zPosition="2" />' % (right, top + pig_h + 22, pig_w, 70, hint_text, FONT, max(22, font - 12)))
    key_w = (panel - margin * 2) // 4
    for index, (key, color) in enumerate([('red', '#FF9292'), ('green', '#8DE3BA'), ('yellow', '#E9D5FF'), ('blue', '#C4B5FD')]):
        xml.append('<widget source="key_%s" render="Label" position="%d,%d" size="%d,%d" font="%s;%d" foregroundColor="%s" backgroundColor="#1a0b2e" valign="center" halign="center" zPosition="2" />' % (key, margin + index * key_w, height - foot, key_w, foot, FONT, max(22, font - 9), color))
    return ''.join(xml) + '</screen>'

def _alpha_key(item):
    value = item.get('name', '') if isinstance(item, dict) else item
    try:
        if not isinstance(value, str):
            value = value.decode('utf-8', 'replace')
    except Exception:
        pass
    try:
        return value.strip().lower()
    except Exception:
        return str(value).strip().lower()

def _natural_key(item):
    value = _alpha_key(item)
    parts = []
    for part in re.split('(\\d+)', value):
        parts.append((1, int(part)) if part.isdigit() else (0, part))
    return parts


def _prepare_dreamos_stream(stream):
    """Return a receiver URL while shielding DreamOS from HTTPS/header gaps.

    Native DreamOS IPTV services do not consistently forward URL-fragment
    headers and can reject HTTPS media while the receiver clock is at 1970.
    Route HTTP(S) HLS through the existing localhost relay so User-Agent,
    Referer, cookies, redirects and TLS are handled by our requests session.
    """
    url = str(stream.get('url') or '').strip()
    headers = stream.get('headers') if isinstance(stream.get('headers'), dict) else {}
    swap = stream.get('swap') if isinstance(stream.get('swap'), dict) else {}
    mediatype = str(stream.get('mediatype') or '').strip().lower()
    clean_url = url.lower().split('#', 1)[0]
    is_hls = mediatype == 'hls' or '.m3u8' in clean_url
    explicit_relay = bool(stream.get('relay'))
    relay_type = mediatype in ('', 'hls', 'mp4')
    if url.lower().startswith(('http://', 'https://')) and relay_type and (swap or explicit_relay or is_hls):
        options = stream.get('relay_options') or stream.get('ostora_hls') or {}
        return prepare_hls_relay(url, headers, swap, options)
    return service_stream_url(url, headers)

def _prepared_stream_entries(item):
    """Yield (raw_stream_dict, prepared_service_url) pairs, in order.

    Shared by _prepared_stream_urls() and _prepared_stream_labels() so the
    two lists can never drift out of sync with each other.
    """
    streams = item.get('streams') or []
    if not streams:
        streams = [{'url': value, 'headers': item.get('headers', {})} for value in list(item.get('urls') or [item.get('url')])]
    for stream in streams:
        if not isinstance(stream, dict):
            stream = {'url': stream, 'headers': item.get('headers', {})}
        url = str(stream.get('url') or '').strip()
        if not url:
            continue
        prepared_url = _prepare_dreamos_stream(stream)
        from .subtitledata import remember
        remember(prepared_url, stream.get('subtitles') or [])
        yield (stream, prepared_url)

def _prepared_stream_urls(item):
    return [prepared_url for _stream, prepared_url in _prepared_stream_entries(item)]

def _prepared_stream_labels(item):
    """Return labels without network probes; probing every server froze E2."""
    labels = []
    for stream, _prepared_url in _prepared_stream_entries(item):
        url = str(stream.get('url') or '').strip()
        headers = stream.get('headers') if isinstance(stream.get('headers'), dict) else {}
        supplied = str(stream.get('quality') or '').strip()
        if not supplied:
            name_match = re.search('(?:^|\\D)(2160|1440|1080|720|576|480|360|244)(?:p|\\D|$)', str(stream.get('name') or ''), re.I)
            supplied = '%sp' % name_match.group(1) if name_match else ''
        labels.append(supplied)
    return labels

class _ListNavigationMixin(object):

    def choose_player(self):
        current = selected_free_service_type()
        choices = [((u'✓ ' if current == 5002 else u'') + u'ExtePlayer3 (5002)', 5002), ((u'✓ ' if current == 5001 else u'') + u'GStreamer (5001)', 5001), ((u'✓ ' if current == 4097 else u'') + u'IPTV الأصلي (4097)', 4097)]
        choices = [choice for choice in choices if choice[1] in available_free_service_types()]
        self.session.openWithCallback(self._player_chosen, ChoiceBox, title=u'اختر المشغل الثابت لقنوات Free Arabic TV', list=choices)

    def _player_chosen(self, choice):
        if not choice:
            return
        try:
            set_selected_free_service_type(choice[1])
            controller = getattr(self, '_list_preview', None)
            if controller is not None:
                controller.change_player(choice[1])
            if hasattr(self, '_update_title'):
                self._update_title()
            self.session.open(MessageBox, u'تم تثبيت المشغل %s ولن يتغير تلقائياً.' % choice[1], MessageBox.TYPE_INFO, timeout=3)
        except Exception as error:
            self.session.open(MessageBox, str(error), MessageBox.TYPE_ERROR, timeout=5)

    def _move_list(self, movement):
        try:
            instance = self['list'].master.master.instance
            instance.moveSelection(getattr(instance, movement))
        except Exception:
            pass

    def go_up(self):
        self._move_list('moveUp')

    def go_down(self):
        self._move_list('moveDown')

    def page_up(self):
        self._move_list('pageUp')

    def page_down(self):
        self._move_list('pageDown')

    def _safe_close(self):
        """Detach asynchronous callbacks before a receiver destroys the screen."""
        if getattr(self, '_closing', False):
            return
        self._closing = True
        self._closed = True
        timer = getattr(self, '_timer', None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
            timer_conn = getattr(self, '_timer_conn', None)
            if timer_conn is not None:
                try:
                    timer.timeout.disconnect(timer_conn)
                except Exception:
                    pass
                self._timer_conn = None
        try:
            self['actions'].setEnabled(False)
        except Exception:
            pass
        try:
            self.close()
        except Exception:
            pass

class Alkuds_FreeTV_Menu(_ListNavigationMixin, Screen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self.onClose.append(lambda: stop_list_playback(self.session))
        self['title'] = StaticText(u'القدس  |  عالم المشاهدة')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'فتح')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['list'] = List([_list_entry(u'مباريات اليوم', 'today_matches', u'●', 8433141), _list_entry(u'الكابتن — بين سبورت', 'captintv', u'●', 8433141), _list_entry(u'NetMirror — الأفلام والمسلسلات', 'netmirror', u'●', 8433141), _list_entry(u'Cricfy TV - المباريات والأحداث والقنوات', 'cricfy', u'●', 8433141), _list_entry(u'جيت كورة Getkoora', 'getkoora', u'●', 8433141), _list_entry(u'سير تيفي Sir TV', 'sirfbs', u'●', 8433141), _list_entry(u'سيريا لايف', 'syrialive', u'●', 16737380), _list_entry(u'الأسطورة', 'ostora', u'●', 16765286), _list_entry(u'جينرال تي في GENRAL TV', 'generaltv', u'●', 16032353), _list_entry(u'بلازما Plasma 4K', 'plasmatv', u'●', 16032353), _list_entry(u'عالم الترفيه', 'entertainment', u'●', COLOR_GREEN), _list_entry(u'اوريجينال تي في', 'originaltv', u'●', 12946175), _list_entry(u'قنوات عربية مباشرة', 'elahmad', u'●', 8568831), _list_entry(u'قنوات الفجر  |  بث مباشر', 'alfajer', u'●', 16773514), _list_entry(u'فجر شو - أفلام ومسلسلات', 'fajershow', u'●', 16765286), _list_entry(u'أكوام AKWAM', 'akwam', u'●', 16765286), _list_entry(u'عرب سيد ArabSeed', 'arabseed', u'●', 16032353), _list_entry(u'لاروزا Laroza', 'laroza', u'●', 16032353), _list_entry(u'إيجي ديد EgyDead', 'egydead', u'●', 16032353), _list_entry(u'إيجي بيست — تطبيق Egybest', 'egyapp', u'●', 16032353), _list_entry(u'سيما فور يو Cima4U', 'cima4u', u'●', 16032353), _list_entry(u'CineHD', 'cinehd', u'●', 16032353), _list_entry(u'شوف ماكس Shoof Max', 'shoofmax', u'●', 16032353), _list_entry(u'ماي سيد MySeed', 'myseed', u'●', 16032353), _list_entry(u'زي أفلام Zaflam', 'zaflam', u'●', 16032353), _list_entry(u'كيو فيلم QFilm', 'qfilm', u'●', 16032353), _list_entry(u'توك توك سينما TukTuk', 'tuktuk', u'●', 16032353), _list_entry(u'فايف تي في 5TV', 'fivetv', u'●', 16032353), _list_entry(u'موفيز لاند MovizLand', 'movizland', u'●', 16032353), _list_entry(u'AlooYTV — الوي تي في', 'alooytv', u'●', 16032353)], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.close, 'red': self.close, 'ok': self.open_current, 'green': self.open_current, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down}, -2)

    def open_current(self):
        current = self['list'].getCurrent()
        if current and current[1]:
            if current[1] == 'egyapp':
                from .egyappui import Alkuds_EgyApp_Browser
                self.session.open(Alkuds_EgyApp_Browser, 'movies', 'groups')
            elif current[1] == 'today_matches':
                from .matches import Alkuds_Matches
                self.session.open(Alkuds_Matches)
            elif current[1] == 'netmirror':
                from .netmirrorui import Alkuds_NetMirror_Browser
                self.session.open(Alkuds_NetMirror_Browser)
            elif current[1] == 'captintv':
                from .captintvui import Alkuds_CaptinTV_Browser
                self.session.open(Alkuds_CaptinTV_Browser)
            elif current[1] == 'cricfy':
                from .cricfyui import Alkuds_Cricfy_Browser
                self.session.open(Alkuds_Cricfy_Browser)
            elif current[1] == 'getkoora':
                from .getkooraui import Alkuds_Getkoora_Browser
                self.session.open(Alkuds_Getkoora_Browser)
            elif current[1] == 'sirfbs':
                from .sirfbsui import Alkuds_SirTV_Browser
                self.session.open(Alkuds_SirTV_Browser)
            elif current[1] == 'ostora':
                self.session.open(Alkuds_Ostora_Menu)
            elif current[1] == 'entertainment':
                self.session.open(Alkuds_Entertainment_Menu)
            elif current[1] == 'fajershow':
                from .fajershowui import Alkuds_FajerShow_Browser
                self.session.open(Alkuds_FajerShow_Browser, 'movie', 'groups')
            elif current[1] == 'akwam':
                from .akwamui import Alkuds_Akwam_Browser
                self.session.open(Alkuds_Akwam_Browser)
            elif current[1] == 'arabseed':
                from .arabseedui import Alkuds_ArabSeed_Browser
                self.session.open(Alkuds_ArabSeed_Browser)
            elif current[1] == 'laroza':
                from .larozaui import Alkuds_Laroza_Browser
                self.session.open(Alkuds_Laroza_Browser)
            elif current[1] == 'egydead':
                from .egydeadui import Alkuds_EgyDead_Browser
                self.session.open(Alkuds_EgyDead_Browser)
            elif current[1] == 'cima4u':
                from .cima4uui import Alkuds_Cima4U_Browser
                self.session.open(Alkuds_Cima4U_Browser)
            elif current[1] == 'cinehd':
                from .cinehdui import Alkuds_CineHD_Browser
                self.session.open(Alkuds_CineHD_Browser)
            elif current[1] == 'shoofmax':
                from .shoofmaxui import Alkuds_ShoofMax_Browser
                self.session.open(Alkuds_ShoofMax_Browser)
            elif current[1] == 'myseed':
                from .myseedui import Alkuds_MySeed_Browser
                self.session.open(Alkuds_MySeed_Browser)
            elif current[1] == 'movizland':
                from .movizlandui import Alkuds_MovizLand_Browser
                self.session.open(Alkuds_MovizLand_Browser)
            elif current[1] == 'zaflam':
                from .zaflamui import Alkuds_Zaflam_Browser
                self.session.open(Alkuds_Zaflam_Browser)
            elif current[1] == 'qfilm':
                from .qfilmui import Alkuds_QFilm_Browser
                self.session.open(Alkuds_QFilm_Browser)
            elif current[1] == 'tuktuk':
                from .tuktukui import Alkuds_TukTuk_Browser
                self.session.open(Alkuds_TukTuk_Browser)
            elif current[1] == 'fivetv':
                from .fivetvui import Alkuds_5TV_Browser
                self.session.open(Alkuds_5TV_Browser)
            elif current[1] == 'alooytv':
                from .alooytvui import Alkuds_AlooYTV_Browser
                self.session.open(Alkuds_AlooYTV_Browser)
            elif current[1] == 'syrialive':
                from .syrialiveui import Alkuds_SyriaLive_Browser
                self.session.open(Alkuds_SyriaLive_Browser)
            elif current[1] == 'plasmatv':
                from .plasmatvui import Alkuds_PlasmaTV_Browser
                self.session.open(Alkuds_PlasmaTV_Browser)
            elif current[1] == 'generaltv':
                from .generaltvui import Alkuds_GeneralTV_Browser
                self.session.open(Alkuds_GeneralTV_Browser)
            elif current[1] == 'oscar':
                self.session.open(Alkuds_Oscar_Channels)
            elif current[1] == 'originaltv':
                self.session.open(Alkuds_OriginalTV_Menu)
            else:
                self.session.open(Alkuds_FreeTV_Channels, current[1])

class Alkuds_Ostora_Menu(_ListNavigationMixin, Screen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self['title'] = StaticText(u'Alkuds ipaudio - الأسطورة')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'فتح')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['list'] = List([_list_entry(u'لايف', 'live', u'●', COLOR_GREEN), _list_entry(u'مسلسلات', 'series', u'●', 8568831), _list_entry(u'أفلام', 'movie', u'●', 16773514)], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.close, 'red': self.close, 'ok': self.open_current, 'green': self.open_current, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down}, -2)

    def open_current(self):
        current = self['list'].getCurrent()
        if current and current[1] in ('live', 'series', 'movie'):
            self.session.open(Alkuds_Ostora_Browser, current[1], 'groups')

class Alkuds_Entertainment_Menu(_ListNavigationMixin, Screen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self['title'] = StaticText(u'Alkuds ipaudio - عالم الترفيه')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'فتح')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['list'] = List([_list_entry('Live', 'live', u'●', COLOR_GREEN), _list_entry(u'المسلسلات - عالم الترفيه', 'series', u'●', 8568831), _list_entry(u'الأفلام - عالم الترفيه', 'movie', u'●', 16773514)], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.close, 'red': self.close, 'ok': self.open_current, 'green': self.open_current, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down}, -2)

    def open_current(self):
        current = self['list'].getCurrent()
        if not current:
            return
        if current[1] == 'live':
            self.session.open(Alkuds_Drama_Topics)
        elif current[1] in ('series', 'movie'):
            self.session.open(Alkuds_Drama_Catalog, current[1], 'topics')

class Alkuds_Egybest_Menu(_ListNavigationMixin, Screen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self['title'] = StaticText(u'Alkuds ipaudio - ايجي بيست')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'فتح')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['list'] = List([_list_entry('Live', 'live', u'●', COLOR_GREEN), _list_entry('Series', 'series', u'●', 8568831), _list_entry('Movie', 'movie', u'●', 16773514)], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.close, 'red': self.close, 'ok': self.open_current, 'green': self.open_current, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down}, -2)

    def open_current(self):
        current = self['list'].getCurrent()
        if current and current[1] in ('live', 'series', 'movie'):
            self.session.open(Alkuds_Egybest_Browser, current[1], 'groups' if current[1] == 'live' else 'items')

class Alkuds_OriginalTV_Menu(_ListNavigationMixin, Screen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self['title'] = StaticText(u'Alkuds ipaudio - اوريجينال تي في')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'فتح')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['list'] = List([_list_entry('Live', 'live', u'●', COLOR_GREEN), _list_entry(u'Matches - المباريات', 'matches', u'●', COLOR_RED), _list_entry(u'المسلسلات - Reezn', 'series', u'●', 8568831), _list_entry(u'الأفلام - Reezn', 'movie', u'●', 16773514)], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.close, 'red': self.close, 'ok': self.open_current, 'green': self.open_current, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down}, -2)

    def open_current(self):
        current = self['list'].getCurrent()
        if current and current[1] in ('live', 'matches', 'series', 'movie'):
            self.session.open(Alkuds_OriginalTV_Browser, current[1], 'items' if current[1] == 'matches' else 'groups')

class Alkuds_Yacine_Categories(_ListNavigationMixin, Screen):
    """Dynamic Yacine TV category tree (including movie/series channels)."""

    def __init__(self, session, parent=None):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self.parent = dict(parent or {})
        self.entries = []
        self._loading = False
        self._done = False
        self._result = None
        self._error = ''
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self['title'] = StaticText(self._title())
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'فتح')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText(u'تحديث')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.back, 'red': self.back, 'ok': self.open_current, 'green': self.open_current, 'blue': self.load, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down, 'channelUp': self.page_up, 'channelDown': self.page_down}, -2)
        self.onFirstExecBegin.append(self.load)

    def _title(self, suffix=''):
        label = str(self.parent.get('name') or '').strip()
        return u'تلفزيون ياسين' + (' - ' + label if label else '') + suffix

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._done = False
        self._result = None
        self._error = ''
        self['list'].setList([_list_entry('Loading Yacine TV categories...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            self._result = fetch_yacine_categories(cfg.useragent.value, self.parent)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self['list'].setList([_list_entry('Yacine TV categories are unavailable.', -1, u'●', COLOR_RED)])
            self.session.open(MessageBox, 'Unable to load Yacine TV:\n%s' % self._error, MessageBox.TYPE_ERROR, timeout=8)
            return
        self.entries = list(self._result or [])
        rows = [_list_entry('%03d   %s' % (index + 1, item.get('name') or 'Category'), index) for index, item in enumerate(self.entries)]
        self['list'].setList(rows or [_list_entry('No Yacine TV categories are available.', -1)])
        self['title'].setText(self._title('  [%d]' % len(self.entries)))

    def open_current(self):
        if self._loading:
            return
        current = self['list'].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            index = -1
        if index < 0 or index >= len(self.entries):
            return
        item = dict(self.entries[index])
        if int(item.get('child_count') or 0) > 0:
            self.session.open(Alkuds_Yacine_Categories, item)
        else:
            self.session.open(Alkuds_FreeTV_Channels, 'yacine', item)

    def back(self):
        self._safe_close()

class Alkuds_Drama_Topics(_ListNavigationMixin, Screen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self.topics = []
        self._loading = False
        self._done = False
        self._result = None
        self._error = ''
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self['title'] = StaticText(u'عالم الترفيه - Live')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'فتح')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText(u'تحديث')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.back, 'red': self.back, 'ok': self.open_current, 'green': self.open_current, 'blue': self.load, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down, 'channelUp': self.page_up, 'channelDown': self.page_down}, -2)
        self.onFirstExecBegin.append(self.load)

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._done = False
        self._result = None
        self._error = ''
        self['list'].setList([_list_entry('Loading Live groups...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            self._result = fetch_drama_topics(cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self['list'].setList([_list_entry('Live groups are unavailable.', -1, u'●', COLOR_RED)])
            self.session.open(MessageBox, 'Unable to load Live groups:\n%s' % self._error, MessageBox.TYPE_ERROR, timeout=8)
            return
        self.topics = list(self._result or [])
        rows = [_list_entry('%03d   %s' % (index + 1, item.get('name') or 'Group'), index) for index, item in enumerate(self.topics)]
        self['list'].setList(rows or [_list_entry('No Live groups are available.', -1)])
        self['title'].setText(u'عالم الترفيه - Live  [%d]' % len(self.topics))

    def open_current(self):
        if self._loading:
            return
        current = self['list'].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            index = -1
        if 0 <= index < len(self.topics):
            self.session.open(Alkuds_FreeTV_Channels, 'dramalive', self.topics[index])

    def back(self):
        self._safe_close()

class Alkuds_Drama_Catalog(_ListNavigationMixin, Screen):
    """Series/Movie groups, titles and episodes from the source application."""

    def __init__(self, session, kind='series', level='topics', parent=None):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self.kind = kind if kind in ('series', 'movie') else 'series'
        self.level = level if level in ('topics', 'shows', 'episodes') else 'topics'
        self.parent = dict(parent or {})
        self.entries = []
        self._loading = False
        self._done = False
        self._result = None
        self._error = ''
        self._closed = False
        self._operation = 'load'
        self._selected_index = -1
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self['title'] = StaticText('')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText('Open' if self.level != 'episodes' else 'Play')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText(u'تحديث')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.back, 'red': self.back, 'ok': self.open_current, 'green': self.open_current, 'blue': self.load, 'stop': self.stop_stream, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down, 'channelUp': self.page_up, 'channelDown': self.page_down}, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()
        from .postergrid import install as install_posters
        install_posters(self, self.open_current, self.choose_player, 'list')

    def _label(self):
        section = 'Series' if self.kind == 'series' else 'Movie'
        if self.level == 'topics':
            return u'عالم الترفيه - %s' % section
        return u'عالم الترفيه - %s - %s' % (section, str(self.parent.get('name') or ''))

    def _update_title(self, suffix=''):
        self['title'].setText('%s%s' % (self._label(), suffix))

    def load(self):
        if self._loading:
            return
        self._operation = 'load'
        self._loading = True
        self._done = False
        self._result = None
        self._error = ''
        self['list'].setList([_list_entry('Loading entertainment catalogue...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == 'topics':
                self._result = fetch_drama_show_topics(self.kind, cfg.useragent.value)
            elif self.level == 'shows':
                self._result = fetch_drama_shows(self.parent, cfg.useragent.value)
            else:
                self._result = fetch_drama_episodes(self.parent, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            self._result = resolve_drama_episode(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = [_list_entry('%03d   %s' % (index + 1, item.get('name') or 'Item'), index) for index, item in enumerate(self.entries)]
        self['list'].setList(rows or [_list_entry('No items are currently available.', -1)])
        if 0 <= self._selected_index < len(self.entries):
            try:
                self['list'].setIndex(self._selected_index)
            except Exception:
                pass

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self._set_rows()
            self._update_title('  [failed]')
            self.session.open(MessageBox, 'Unable to load entertainment content:\n%s' % self._error, MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == 'load':
            sort_key = _natural_key if self.level == 'episodes' else _alpha_key
            self.entries = sorted(list(self._result or []), key=sort_key)
            self._set_rows()
            self._update_title('  [%d]' % len(self.entries))
            return
        self._start_resolved(self._result)

    def _index(self):
        current = self['list'].getCurrent()
        try:
            return int(current[1]) if current else -1
        except Exception:
            return -1

    def open_current(self):
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == 'topics':
            self.session.open(Alkuds_Drama_Catalog, self.kind, 'shows', item)
        elif self.level == 'shows':
            self.session.open(Alkuds_Drama_Catalog, self.kind, 'episodes', item)
        else:
            self._operation = 'resolve'
            self._loading = True
            self._done = False
            self._result = None
            self._error = ''
            self._update_title('  [resolving stream...]')
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _start_resolved(self, item):
        if not isinstance(item, dict) or not item.get('url'):
            self.session.open(MessageBox, 'No playable link was returned.', MessageBox.TYPE_ERROR, timeout=6)
            return
        prepared = _prepared_stream_urls(item)
        if not prepared:
            self.session.open(MessageBox, 'No playable link was returned.', MessageBox.TYPE_ERROR, timeout=6)
            return
        category = 'Series' if self.kind == 'series' else 'Movie'
        if len(prepared) > 1:
            labels = _prepared_stream_labels(item)
            resume_key = '%s:%s' % (self.kind, str(item.get('id') or item.get('name') or 'video'))
            self.session.open(Alkuds_StreamChooser, prepared, labels, item, str(item.get('name') or 'Video'), category, str(self.parent.get('name') or ''), str(item.get('image') or ''), resume_key, False)
            return
        self._open_video(prepared, item, category)

    def _open_video(self, prepared, item, category):
        from .freeplayer import Alkuds_FreeTV_Player
        resume_key = '%s:%s' % (self.kind, str(item.get('id') or item.get('name') or 'video'))
        open_list_player(self, None, Alkuds_FreeTV_Player, prepared, selected_free_service_type(), str(item.get('name') or 'Video'), category, str(self.parent.get('name') or ''), str(item.get('image') or ''), resume_key)

    def _player_closed(self, result=None, *args):
        self._set_rows()
        self._update_title('  [%d]' % len(self.entries))
        action = result[0] if isinstance(result, (tuple, list)) and result else result
        if action == 'failed' and (not self._closed):
            self.session.open(MessageBox, 'This video is offline or did not start.', MessageBox.TYPE_ERROR, timeout=6)

    def stop_stream(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass

    def back(self):
        self._safe_close()

class Alkuds_Egybest_Browser(_ListNavigationMixin, Screen):
    """Paged Egybest browser: categories/titles/seasons/episodes."""

    def __init__(self, session, kind='movie', level='items', parent=None, page=1):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self.kind = kind if kind in ('live', 'series', 'movie') else 'movie'
        self.level = level if level in ('groups', 'items', 'seasons', 'episodes', 'servers') else 'items'
        self.parent = dict(parent or {})
        self.page, self.last_page, self.total = (max(1, int(page or 1)), 1, 0)
        self.entries, self._result, self._error = ([], None, '')
        self._loading = self._done = self._closed = False
        self._operation, self._selected_index = ('load', -1)
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self['title'] = StaticText('')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText('Play' if self.level == 'episodes' else 'Open')
        self['key_yellow'] = StaticText('Previous' if self.level == 'items' else '')
        self['key_blue'] = StaticText('Next' if self.level == 'items' else 'Refresh')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.back, 'red': self.back, 'ok': self.open_current, 'green': self.open_current, 'yellow': self.previous_page, 'blue': self.next_or_refresh, 'stop': self.stop_stream, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down, 'channelUp': self.page_up, 'channelDown': self.page_down}, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()
        from .postergrid import install as install_posters
        install_posters(self, self.open_current, self.choose_player, 'list')

    def _label(self):
        section = {'live': 'Live', 'series': 'Series', 'movie': 'Movie'}[self.kind]
        parent = str(self.parent.get('name') or '').strip()
        return u'ايجي بيست - %s%s' % (section, ' - ' + parent if parent else '')

    def _update_title(self, suffix=''):
        page = '  [Page %d/%d]' % (self.page, self.last_page) if self.level == 'items' and self.last_page > 1 else ''
        pager = getattr(self, '_catalogue_pager', None)
        if pager is not None:
            page = u'  [الصفحة %d]' % self.page
            if pager.exhausted and (not pager.pending):
                page = u'  [الصفحة %d/%d]' % (self.page, max(1, len(pager.pages)))
        self['title'].setText(self._label() + page + suffix)

    def _catalogue_items(self, fetch):
        if self.kind == 'live' or self.parent.get('season') or self.parent.get('episode_query'):
            return fetch(self.page)
        from .cataloguepages import CataloguePages
        if not hasattr(self, '_catalogue_pager'):
            self._catalogue_pager = CataloguePages(cancelled=lambda: self._closed)
        return self._catalogue_pager.get(self.page, fetch)

    def load(self):
        if self._loading:
            return
        self._operation, self._loading, self._done = ('load', True, False)
        self._result, self._error = (None, '')
        self['list'].setList([_list_entry('Loading Egybest catalogue...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == 'groups':
                self._result = fetch_egybest_live_groups(cfg.useragent.value)
            elif self.level == 'items':
                self._result = self._catalogue_items(lambda page: fetch_egybest_items(self.kind, cfg.useragent.value, self.parent, page))
            elif self.level == 'seasons':
                self._result = fetch_egybest_seasons(self.parent, cfg.useragent.value)
            else:
                self._result = fetch_egybest_episodes(self.parent, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            self._result = resolve_egybest_item(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = [_list_entry('%03d   %s' % (i + 1, item.get('name') or 'Item'), i) for i, item in enumerate(self.entries)]
        self['list'].setList(rows or [_list_entry('No items are currently available.', -1)])
        if 0 <= self._selected_index < len(self.entries):
            try:
                self['list'].setIndex(self._selected_index)
            except Exception:
                pass

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self._set_rows()
            self._update_title('  [failed]')
            self.session.open(MessageBox, 'Unable to load content:\n%s' % self._error, MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == 'resolve':
            self._start_resolved(self._result)
            return
        if self.level == 'items' and isinstance(self._result, dict):
            self.entries = list(self._result.get('entries') or [])
            self.page = int(self._result.get('page') or self.page)
            self.last_page = max(self.page, int(self._result.get('last_page') or self.page))
            self.total = int(self._result.get('total') or len(self.entries))
        else:
            self.entries = list(self._result or [])
            if self.level in ('seasons', 'episodes'):
                self.entries = sorted(self.entries, key=_natural_key)
        self._set_rows()
        self._update_title('  [%d]' % (self.total if self.level == 'items' else len(self.entries)))

    def _index(self):
        current = self['list'].getCurrent()
        try:
            return int(current[1]) if current else -1
        except Exception:
            return -1

    def open_current(self):
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == 'groups':
            self.session.open(Alkuds_Egybest_Browser, 'live', 'items', item, 1)
        elif self.level == 'items' and self.kind == 'series':
            self.session.open(Alkuds_Egybest_Browser, 'series', 'seasons', item, 1)
        elif self.level == 'seasons':
            self.session.open(Alkuds_Egybest_Browser, 'series', 'episodes', item, 1)
        else:
            self._operation, self._loading, self._done = ('resolve', True, False)
            self._result, self._error = (None, '')
            self._update_title('  [resolving stream...]')
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item) if isinstance(item, dict) else []
        if not prepared:
            self.session.open(MessageBox, 'No playable link was returned.', MessageBox.TYPE_ERROR, timeout=6)
            return
        live = self.kind == 'live'
        category = 'Live' if live else 'Series' if self.kind == 'series' else 'Movie'
        description = str(self.parent.get('name') or item.get('description') or '')
        resume_key = '' if live else 'egybest:%s:%s' % (self.kind, item.get('id') or item.get('name'))
        if prepared:
            self.session.open(Alkuds_StreamChooser, prepared, _prepared_stream_labels(item), item, str(item.get('name') or 'Egybest'), category, description, str(item.get('image') or ''), resume_key, live)
        else:
            from .freeplayer import Alkuds_FreeTV_Player
            open_list_player(self, None, Alkuds_FreeTV_Player, prepared, selected_free_service_type(), str(item.get('name') or 'Egybest'), category, description, str(item.get('image') or ''), resume_key)

    def previous_page(self):
        if self.level == 'items' and (not self._loading) and (self.page > 1):
            self.page -= 1
            self._selected_index = -1
            self.load()

    def next_or_refresh(self):
        if self.level != 'items':
            self.load()
        elif self._error and (not self._loading):
            self.load()
        elif not self._loading and self.page < self.last_page:
            self.page += 1
            self._selected_index = -1
            self.load()

    def stop_stream(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass

    def back(self):
        self._safe_close()

class Alkuds_LiveHD_Browser(Alkuds_Egybest_Browser):
    """Today's public LiveHD matches with server discovery on selection."""

    def __init__(self, session, kind='live', level='items', parent=None, page=1):
        Alkuds_Egybest_Browser.__init__(self, session, 'live', 'items', parent, 1)
        self['key_yellow'].setText('')
        self['key_blue'].setText('Refresh')
        self._update_title()

    def _label(self):
        return u'شاهد المباريات - LiveHD + LiveKora'

    def load(self):
        if self._loading:
            return
        self._operation, self._loading, self._done = ('load', True, False)
        self._result, self._error = (None, '')
        self['list'].setList([_list_entry(u'جاري تحميل مباريات اليوم...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            livehd_result = None
            livekora_result = None
            try:
                livehd_result = fetch_livehd_matches(cfg.useragent.value)
            except Exception:
                pass
            try:
                livekora_result = fetch_livekora_matches(cfg.useragent.value)
            except Exception:
                pass
            self._result = merge_match_catalogues(livehd_result, livekora_result)
            if not self._result.get('entries'):
                raise RuntimeError('No match source is available')
        except Exception:
            self._error = 'Unable to load match sources. Press BLUE to retry.'
        self._done = True

    def _resolve_worker(self, item):
        try:
            self._result = fetch_combined_match_servers(item, cfg.useragent.value)
        except Exception:
            self._error = 'No playable LiveHD server is available for this match.'
        self._done = True

    def _set_rows(self):
        rows = []
        for index, item in enumerate(self.entries):
            details = u'%s | %s | %s' % (item.get('time') or '--:--', item.get('status') or u'غير معروف', item.get('channel') or item.get('league') or 'LiveHD')
            rows.append(_list_entry(u'%s   |   %s' % (item.get('name') or u'مباراة', details), index))
        self['list'].setList(rows or [_list_entry(u'لا توجد مباريات متاحة حاليًا.', -1)])

    def open_current(self):
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.entries):
            return
        item = dict(self.entries[index])
        self._selected_index = index
        self._operation, self._loading, self._done = ('resolve', True, False)
        self._result, self._error = (None, '')
        self._update_title('  [loading servers...]')
        worker = threading.Thread(target=self._resolve_worker, args=(item,))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item) if isinstance(item, dict) else []
        if not prepared:
            self.session.open(MessageBox, 'No playable LiveHD server was returned.', MessageBox.TYPE_ERROR, timeout=6)
            return
        self.session.open(Alkuds_StreamChooser, prepared, _prepared_stream_labels(item), item, str(item.get('name') or 'LiveHD'), 'Live', str(item.get('description') or ''), str(item.get('image') or ''), '', True)

    def previous_page(self):
        return

    def next_or_refresh(self):
        if not self._loading:
            self.load()

class Alkuds_Ostora_Browser(Alkuds_Egybest_Browser):
    """Ostora TV API browser; catalogue is always fetched live from the APK API."""

    def __init__(self, session, kind='movie', level='groups', parent=None, page=1):
        Alkuds_Egybest_Browser.__init__(self, session, kind, level, parent, page)
        self._update_title()

    def _label(self):
        section = {'live': u'لايف', 'series': u'مسلسلات', 'movie': u'أفلام'}[self.kind]
        parent = str(self.parent.get('name') or '').strip()
        return u'الأسطورة - %s%s' % (section, ' - ' + parent if parent else '')

    def load(self):
        if self._loading:
            return
        self._operation, self._loading, self._done = ('load', True, False)
        self._result, self._error = (None, '')
        self['list'].setList([_list_entry(u'جاري جلب بيانات الأسطورة...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == 'groups':
                self._result = fetch_ostora_groups(self.kind, cfg.useragent.value)
            elif self.level == 'items':
                self._result = self._catalogue_items(lambda page: fetch_ostora_items(self.kind, cfg.useragent.value, self.parent, page))
            elif self.level == 'seasons':
                self._result = fetch_ostora_seasons(self.parent, cfg.useragent.value)
            else:
                self._result = fetch_ostora_episodes(self.parent, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            if self.kind == 'live':
                self._result = resolve_ostora_selection(item, cfg.useragent.value)
            else:
                self._result = resolve_ostora_item(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def open_current(self):
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == 'groups':
            self.session.open(type(self), self.kind, 'items', item, 1)
        elif item.get('is_group'):
            self.session.open(type(self), self.kind, 'items', item, 1)
        elif self.level == 'seasons':
            self.session.open(type(self), 'series', 'episodes', item, 1)
        else:
            self._operation, self._loading, self._done = ('resolve', True, False)
            self._result, self._error = (None, '')
            self._update_title('  [resolving stream...]')
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item) if isinstance(item, dict) else []
        if not prepared:
            self.session.open(MessageBox, 'No playable link was returned.', MessageBox.TYPE_ERROR, timeout=6)
            return
        live = bool(item.get('is_live', self.kind == 'live'))
        category = 'Live' if live else 'Series' if self.kind == 'series' else 'Movie'
        resume_key = '' if live else 'ostora:%s:%s' % (self.kind, item.get('id') or item.get('name'))
        if live or len(prepared) > 1:
            self.session.open(Alkuds_StreamChooser, prepared, _prepared_stream_labels(item), item, str(item.get('name') or 'Ostora'), category, str(item.get('description') or ''), str(item.get('image') or ''), resume_key, live)
        else:
            from .freeplayer import Alkuds_FreeTV_Player
            open_list_player(self, None, Alkuds_FreeTV_Player, prepared, selected_free_service_type(), str(item.get('name') or 'Ostora'), category, str(item.get('description') or ''), str(item.get('image') or ''), resume_key)

class Alkuds_OriginalTV_Browser(Alkuds_Egybest_Browser):
    """Original TV browser for live groups, matches, movies and series."""

    def __init__(self, session, kind='movie', level='items', parent=None, page=1):
        requested = kind if kind in ('live', 'matches', 'series', 'movie') else 'movie'
        Alkuds_Egybest_Browser.__init__(self, session, 'live' if requested == 'matches' else requested, level, parent, page)
        self.kind = requested
        self._update_title()

    def _label(self):
        section = {'live': 'Live', 'matches': u'Matches - المباريات', 'series': 'Series', 'movie': 'Movie'}[self.kind]
        parent = str(self.parent.get('name') or '').strip()
        return u'اوريجينال تي في - %s%s' % (section, ' - ' + parent if parent else '')

    def load(self):
        if self._loading:
            return
        self._operation, self._loading, self._done = ('load', True, False)
        self._result, self._error = (None, '')
        self['list'].setList([_list_entry('Loading Original TV catalogue...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == 'groups':
                if self.kind in ('movie', 'series'):
                    from .reeznvod import groups
                    self._result = groups(self.kind)
                else:
                    self._result = fetch_original_groups(cfg.useragent.value)
            elif self.level == 'servers':
                from .reeznvod import servers
                self._result = servers(self.parent)
            elif self.level == 'items':
                self._result = self._catalogue_items(lambda page: fetch_original_items(self.kind, cfg.useragent.value, self.parent, page))
            elif self.level == 'seasons':
                self._result = fetch_original_seasons(self.parent, cfg.useragent.value)
            else:
                self._result = fetch_original_episodes(self.parent, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            self._result = resolve_original_item(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self._set_rows()
            self._update_title('  [failed]')
            self.session.open(MessageBox, 'Unable to load Original TV content:\n%s' % self._error, MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == 'resolve':
            self._start_resolved(self._result)
            return
        if self.level == 'items' and isinstance(self._result, dict):
            self.entries = list(self._result.get('entries') or [])
            self.page = int(self._result.get('page') or self.page)
            self.last_page = max(self.page, int(self._result.get('last_page') or self.page))
            self.total = int(self._result.get('total') or len(self.entries))
        else:
            self.entries = list(self._result or [])
            if self.level in ('seasons', 'episodes'):
                self.entries = sorted(self.entries, key=_natural_key)
        self._set_rows()
        self._update_title('  [%d]' % (self.total if self.level == 'items' else len(self.entries)))

    def open_current(self):
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == 'groups':
            action = item.get('action')
            if action in ('search', 'year'):
                from Screens.VirtualKeyBoard import VirtualKeyBoard
                self._input_action = action
                self.session.openWithCallback(self._catalogue_input, VirtualKeyBoard, title=u'اسم الفيلم أو المسلسل' if action == 'search' else u'سنة الإنتاج', text='')
            elif action == 'dramabox':
                self.session.open(Alkuds_Drama_Catalog, self.kind, 'topics')
            else:
                self.session.open(Alkuds_OriginalTV_Browser, self.kind, 'items', item, 1)
        elif self.level == 'items' and self.kind == 'series':
            self.session.open(Alkuds_OriginalTV_Browser, 'series', 'seasons', item, 1)
        elif self.level == 'seasons':
            self.session.open(Alkuds_OriginalTV_Browser, 'series', 'episodes', item, 1)
        elif self.kind in ('movie', 'series') and self.level in ('items', 'episodes'):
            self.session.open(Alkuds_OriginalTV_Browser, self.kind, 'servers', item, 1)
        else:
            self._operation, self._loading, self._done = ('resolve', True, False)
            self._result, self._error = (None, '')
            self._update_title('  [resolving stream...]')
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)

    def _catalogue_input(self, value):
        value = str(value or '').strip()
        if not value or self._closed:
            return
        media = 'movie' if self.kind == 'movie' else 'tv'
        if self._input_action == 'year':
            if not re.match('^\\d{4}$', value) or not 1870 <= int(value) <= 2200:
                self.session.open(MessageBox, 'Enter a four-digit production year.', MessageBox.TYPE_ERROR, timeout=5)
                return
            params = {'primary_release_year' if media == 'movie' else 'first_air_date_year': value, 'sort_by': 'popularity.desc'}
            path = 'discover/' + media
        else:
            params, path = ({'query': value}, 'search/' + media)
        parent = {'name': value, 'path': path, 'params': params, 'source': 'reezn_vod_group'}
        self.session.open(Alkuds_OriginalTV_Browser, self.kind, 'items', parent, 1)

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item) if isinstance(item, dict) else []
        if not prepared:
            self.session.open(MessageBox, 'No playable non-DRM link was returned.', MessageBox.TYPE_ERROR, timeout=6)
            return
        live = self.kind in ('live', 'matches')
        category = {'live': 'Live', 'matches': 'Matches', 'series': 'Series', 'movie': 'Movie'}[self.kind]
        description = str(self.parent.get('name') or item.get('description') or '')
        resume_key = '' if live else 'originaltv:%s:%s' % (self.kind, item.get('id') or item.get('name'))
        if len(prepared) > 1:
            self.session.openWithCallback(self._child_closed, Alkuds_StreamChooser, prepared, _prepared_stream_labels(item), item, str(item.get('name') or 'Original TV'), category, description, str(item.get('image') or ''), resume_key, live)
        else:
            from .freeplayer import Alkuds_FreeTV_Player
            open_list_player(self, self._child_closed, Alkuds_FreeTV_Player, prepared, selected_free_service_type(), str(item.get('name') or 'Original TV'), category, description, str(item.get('image') or ''), resume_key)

    def _child_closed(self, result=None, *args):
        if self.kind not in ('live', 'matches') or not self.entries:
            return
        if isinstance(result, (tuple, list)):
            action = result[0] if result else None
        else:
            action = result
        if action not in ('next', 'prev'):
            return
        index = self._selected_index if 0 <= self._selected_index < len(self.entries) else 0
        index = (index + (1 if action == 'next' else -1)) % len(self.entries)
        self._selected_index = index
        try:
            self['list'].setIndex(index)
        except Exception:
            pass
        item = dict(self.entries[index])
        self._operation, self._loading, self._done = ('resolve', True, False)
        self._result, self._error = (None, '')
        self._update_title('  [resolving stream...]')
        worker = threading.Thread(target=self._resolve_worker, args=(item,))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

class Alkuds_Oscar_Channels(Alkuds_Egybest_Browser):
    """OscarTV live channels, with server and quality lists."""

    def __init__(self, session, kind='live', level='items', parent=None, page=1):
        Alkuds_Egybest_Browser.__init__(self, session, 'live', 'items', {}, page)

    def _label(self):
        return u'أوسكار - القنوات'

    def _load_worker(self):
        try:
            self._result = fetch_oscar_channels(cfg.useragent.value, page=self.page)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _resolve_worker(self, item):
        try:
            self._result = resolve_oscar_channel(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

class _MiniPreviewMixin(object):
    """First OK plays in the mini TV beside the list; OK again on the same item goes fullscreen.

    Any failure falls back to the previous behaviour (open the fullscreen player at once).
    """

    def _preview_on(self):
        try:
            return bool(cfg.freepreview.value)
        except Exception:
            return False

    def _preview_start(self, key, url, name=None):
        from .freeplayer import Alkuds_FreeTV_Player
        try:
            result = open_list_player(self, getattr(self, '_player_closed', None), Alkuds_FreeTV_Player, [url], selected_free_service_type(), name or getattr(self, 'name', 'Video'), getattr(self, 'category', 'Live'))
            self._preview_key = key
            return result
        except Exception:
            return False

    def _preview_forget(self):
        self._preview_key = None

    def _preview_stop(self):
        controller = getattr(self, '_list_preview', None)
        if controller:
            controller.close()
            self._preview_key = None
            return
        if getattr(self, '_preview_key', None) is not None:
            self._preview_key = None
            try:
                self.session.nav.stopService()
            except Exception:
                pass

class Alkuds_StreamChooser(_MiniPreviewMixin, _ListNavigationMixin, Screen):
    """Persistent stream/server chooser.

    It deliberately remains below the player in the screen stack. Pressing
    Back in the player therefore returns here, allowing server 2, 3, ... to be
    selected immediately without changing the channel or episode first.
    """

    def __init__(self, session, prepared, labels, item, name, category='Live', description='', image='', resume_key='', live=True):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin(True)
        self.session = session
        self.prepared = list(prepared or [])
        self.labels = list(labels or [])
        self.item = dict(item or {})
        self.name = str(name or 'Channel')
        self.category = str(category or 'Live')
        self.description = str(description or '')
        self.image = str(image or '')
        self.resume_key = str(resume_key or '')
        self.live = bool(live)
        self.last_state = None
        chooser = u'اختر الجودة' if self.item.get('source') == 'alfajer' else u'اختر السيرفر'
        self['title'] = StaticText(u'%s - %s' % (chooser, self.name))
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'تشغيل')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        rows = []
        streams = list(self.item.get('streams') or [])
        for index in range(len(self.prepared)):
            quality = self.labels[index] if index < len(self.labels) else None
            server = ''
            if index < len(streams) and isinstance(streams[index], dict):
                server = str(streams[index].get('name') or '').strip()
            text = u'%s%s' % (server or u'سيرفر %d' % (index + 1), u'  (%s)' % quality if quality else u'')
            rows.append(_list_entry(text, index, u'●', COLOR_GREEN if index == 0 else COLOR_WHITE))
        self['list'] = List(rows, enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.back, 'red': self.back, 'ok': self.play, 'green': self.play, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down}, -2)

    def play(self):
        current = self['list'].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            index = -1
        if index < 0 or index >= len(self.prepared):
            return
        streams = list(self.item.get('streams') or [])
        if index < len(streams) and isinstance(streams[index], dict):
            self.session.openWithCallback(self._player_closed, Alkuds_QualityChooser, streams[index], self.name, self.category, self.description, self.image, self.resume_key)
            return
        if self._preview_start(index, self.prepared[index], self.name):
            return
        self._preview_forget()
        from .freeplayer import Alkuds_FreeTV_Player
        open_list_player(self, self._player_closed, Alkuds_FreeTV_Player, [self.prepared[index]], selected_free_service_type(), self.name, self.category, self.description, self.image, self.resume_key)

    def _player_closed(self, result=None, *args):
        self._preview_forget()
        if isinstance(result, (tuple, list)):
            action = result[0] if result else None
            state = result[1] if len(result) > 1 else None
        else:
            action, state = (result, None)
        if state in ('working', 'offline'):
            self.last_state = state
        if self.live and action in ('next', 'prev'):
            self.close((action, self.last_state))
        elif action == 'failed':
            self.session.open(MessageBox, 'This player is offline or did not start.', MessageBox.TYPE_ERROR, timeout=5)

    def back(self):
        self._preview_stop()
        if self.live:
            self.close(('back', self.last_state))
        else:
            self.close()

class Alkuds_QualityChooser(_ListNavigationMixin, Screen):
    """Second-level HLS quality chooser for a selected Reezn server."""

    def __init__(self, session, stream, name, category, description, image, resume_key):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin()
        self.session = session
        self.stream = dict(stream or {})
        self.variants = []
        self._done = False
        self._closed = False
        self._auto_started = False
        self._started_at = 0.0
        self._error = ''
        self.name, self.category = (str(name), str(category))
        self.description, self.image = (str(description), str(image))
        self.resume_key = str(resume_key or '')
        title = u'اختر المشغل' if self.stream.get('source') == 'alfajer_quality' else u'اختر جودة التشغيل'
        self['title'] = StaticText(u'%s - %s' % (title, self.name))
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'تشغيل')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        loading = u'جاري تجهيز المشغلات...' if self.stream.get('source') == 'alfajer_quality' else u'جاري جلب الجودات...'
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.close, 'red': self.close, 'ok': self.play, 'green': self.play, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down}, -2)
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self.onFirstExecBegin.append(self.load)
        self.onClose.append(self._cleanup)
        self.onShown.append(self._hide_pending)

    def _hide_pending(self):
        if getattr(self, '_list_preview', None):
            return
        if not self._done or self._auto_started or (len(self.variants) == 1 and (not self._error)):
            self.hide()

    def load(self):
        self._started_at = time.time()
        if self.stream.get('variants'):
            self.variants = list(self.stream['variants'])
            self._done = True
            self.hide()
            self._timer.start(1, True)
            return
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            stream = dict(self.stream)
            if stream.get('variants'):
                variants = list(stream.get('variants') or [])
            elif stream.get('source') == 'egybest' and stream.get('supported_host'):
                stream = _resolve_egybest_page(stream)
                stream['supported_host'] = False
                variants = hls_variant_streams(stream)
            elif stream.get('source') == 'livehd_server':
                stream = resolve_livehd_server(stream, cfg.useragent.value)
                variants = hls_variant_streams(stream)
            else:
                variants = stream.get('variants') if stream.get('source') in ('oscar', 'livehd') else hls_variant_streams(stream)
            if not self._closed and (not self._done):
                self.variants = variants or [stream]
                self._done = True
        except Exception:
            if not self._closed and (not self._done):
                self._error = 'Server could not be resolved. Go back and choose another server.'
                self._done = True

    def _poll(self):
        if self._closed:
            return
        if not self._done:
            host_page = self.stream.get('source') == 'egybest' and self.stream.get('supported_host') or self.stream.get('source') == 'livehd_server'
            limit = 65 if host_page else 10
            if self._started_at and time.time() - self._started_at >= limit:
                if host_page:
                    self._error = 'Server timed out. Go back and choose another server.'
                    self.variants = []
                else:
                    self.variants = [self.stream]
                self._done = True
            else:
                return
        self._timer.stop()
        if self._error:
            self['list'].setList([_list_entry(self._error, -1)])
            self.show()
            return
        rows = []
        for index, item in enumerate(self.variants):
            label = str(item.get('quality') or item.get('name') or 'Auto')
            if len(self.variants) == 1 and label == str(self.stream.get('name') or ''):
                label = 'Auto / Original'
            rows.append(_list_entry(label, index, u'●', COLOR_GREEN if index == 0 else COLOR_WHITE))
        self['list'].setList(rows or [_list_entry('No playable quality', -1)])
        if len(self.variants) == 1 and (not self._auto_started):
            self._auto_started = True
            try:
                self['list'].setIndex(0)
            except Exception:
                pass
            self.play()
        else:
            self.show()

    def _cleanup(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass

    def play(self):
        current = self['list'].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            index = -1
        if index < 0 or index >= len(self.variants):
            return
        stream = self.variants[index]
        prepared = _prepare_dreamos_stream(stream)
        from .freeplayer import Alkuds_FreeTV_Player
        open_list_player(self, self._player_closed, Alkuds_FreeTV_Player, [prepared], selected_free_service_type(), self.name, self.category, self.description, self.image, self.resume_key, subtitles=stream.get('subtitles') or [], subtitle_search=stream.get('subtitle_search') or {})

    def _player_closed(self, result=None, *args):
        if isinstance(result, (tuple, list)) and result and (result[0] in ('next', 'prev')):
            self.close(result)
        elif self._auto_started:
            self.close()

class Alkuds_FreeTV_Channels(_MiniPreviewMixin, _ListNavigationMixin, Screen):

    def __init__(self, session, provider='alfajer', topic=None):
        Screen.__init__(self, session)
        self.onShown.append(lambda: attach_list_preview(self))
        self.skin = _free_channels_skin(True)
        self.session = session
        self.provider = provider if provider in ('elahmad', 'alfajer', 'dramalive', 'yacine', 'syrialive') else 'alfajer'
        self.topic = dict(topic or {})
        self.channels = []
        self.playing_index = None
        self.channel_states = {}
        self._loading = False
        self._done = False
        self._result = None
        self._error = ''
        self._closed = False
        self._operation = 'load'
        self._selected_index = -1
        self._panel_hidden = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self['title'] = StaticText('')
        self['key_red'] = StaticText(u'رجوع')
        self['key_green'] = StaticText(u'تشغيل')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText(u'تحديث')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'menu': self.choose_player, 'cancel': self.back, 'red': self.back, 'ok': self.play, 'green': self.play, 'blue': self.load, 'stop': self.stop_stream, 'up': self.go_up, 'down': self.go_down, 'left': self.page_up, 'right': self.page_down, 'channelUp': self.page_up, 'channelDown': self.page_down}, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()
        from .postergrid import install as install_posters
        install_posters(self, self.play, self.choose_player, 'list')

    def _update_title(self, suffix=''):
        if self.provider == 'elahmad':
            label = u'قنوات عربية مباشرة'
        elif self.provider == 'dramalive':
            label = u'عالم الترفيه - Live - %s' % str(self.topic.get('name') or 'Channels')
        elif self.provider == 'yacine':
            label = u'تلفزيون ياسين - %s' % str(self.topic.get('name') or 'Channels')
        elif self.provider == 'syrialive':
            label = u'سيريا لايف - البث المباشر'
        else:
            label = u'قنوات الفجر 1 - 5'
        preferred = selected_free_service_type()
        player = 'ExtePlayer3 5002' if preferred == 5002 else 'GStreamer 5001' if preferred == 5001 else 'IPTV 4097'
        self['title'].setText('%s  [%s]%s' % (label, player, suffix))

    def load(self):
        if self._loading:
            return
        self._show_panel()
        self._operation = 'load'
        self._loading = True
        self._done = False
        self._result = None
        self._error = ''
        self['list'].setList([_list_entry('Loading current channel list...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.provider == 'elahmad':
                self._result = fetch_elahmad_catalogue(cfg.useragent.value)
            elif self.provider == 'dramalive':
                self._result = fetch_drama_channels(self.topic, cfg.useragent.value)
            elif self.provider == 'yacine':
                self._result = fetch_yacine_channels(self.topic, cfg.useragent.value)
            elif self.provider == 'syrialive':
                self._result = fetch_syria_live_events(cfg.useragent.value)
            else:
                self._result = fetch_fajer_channels(cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = []
        for index, item in enumerate(self.channels):
            state = self.channel_states.get(index)
            if index == self.playing_index or state == 'working':
                marker, color = (u'●', COLOR_GREEN)
            elif state == 'offline':
                marker, color = (u'●', COLOR_RED)
            else:
                marker, color = ('', COLOR_WHITE)
            text = '%03d   %s' % (index + 1, item.get('name') or 'Channel')
            rows.append(_list_entry(text, index, marker, color))
        if not rows:
            rows = [_list_entry('No channels are currently available.', -1)]
        self['list'].setList(rows)
        if self.playing_index is not None and rows and (rows[0][1] >= 0):
            try:
                self['list'].setIndex(self.playing_index)
            except Exception:
                pass

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            if self._operation == 'resolve' and self._selected_index >= 0:
                self.channel_states[self._selected_index] = 'offline'
            self._set_rows()
            self._update_title('  [failed]')
            self.session.open(MessageBox, 'Unable to load the selected free source:\n%s' % self._error, MessageBox.TYPE_ERROR, timeout=8)
            return
        if self._operation == 'load':
            self.channels = list(self._result or [])
            if self.provider not in ('dramalive', 'syrialive'):
                self.channels = sorted(self.channels, key=_alpha_key)
            self.playing_index = None
            self.channel_states = {}
            self._set_rows()
            self._update_title('  [%d channels]' % len(self.channels))
            return
        self._start_resolved(self._result)

    def _index(self):
        current = self['list'].getCurrent()
        try:
            return int(current[1]) if current else -1
        except Exception:
            return -1

    def play(self):
        if self._panel_hidden:
            self._show_panel()
            return
        if self._loading:
            return
        index = self._index()
        if index < 0 or index >= len(self.channels):
            return
        payload = getattr(self, '_preview_payload', None)
        if payload and getattr(self, '_preview_key', None) == index:
            self._preview_payload = None
            self._preview_forget()
            self._open_player(payload[0], payload[1], payload[2], force=True)
            return
        if self.playing_index == index:
            return
        item = self.channels[index]
        self._operation = 'resolve'
        self._selected_index = index
        self._loading = True
        self._done = False
        self._result = None
        self._error = ''
        self._update_title('  [resolving stream...]')
        worker = threading.Thread(target=self._resolve_worker, args=(dict(item),))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _resolve_worker(self, item):
        try:
            if self.provider == 'elahmad':
                self._result = resolve_elahmad_channel(item, cfg.useragent.value)
            elif self.provider == 'dramalive':
                self._result = resolve_drama_channel(item, cfg.useragent.value)
            elif self.provider == 'yacine':
                self._result = resolve_yacine_channel(item, cfg.useragent.value)
            elif self.provider == 'syrialive':
                self._result = resolve_syria_live_event(item, cfg.useragent.value)
            else:
                self._result = resolve_fajer_channel(item, cfg.useragent.value)
            result = self._result
            streams = result.get('streams') or ([result] if result.get('url') else []) if isinstance(result, dict) else []
            if isinstance(result, dict) and len(streams) == 1 and isinstance(streams[0], dict):
                stream = streams[0]
                if stream.get('source') not in ('alfajer_quality', 'livehd_server') and (not stream.get('supported_host')):
                    try:
                        variants = stream.get('variants') or hls_variant_streams(stream)
                    except Exception:
                        variants = []
                    if len(variants) == 1:
                        result = dict(result, streams=[variants[0]], _single_quality=True)
                        self._result = result
                    elif variants:
                        stream['variants'] = list(variants)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _start_resolved(self, item):
        if not isinstance(item, dict) or not item.get('url'):
            self.session.open(MessageBox, 'No playable link was returned.', MessageBox.TYPE_ERROR, timeout=6)
            return
        index = self._selected_index
        name = str(item.get('name') or 'Channel')
        prepared = _prepared_stream_urls(item)
        if not prepared:
            self.session.open(MessageBox, 'No playable link was returned.', MessageBox.TYPE_ERROR, timeout=6)
            return
        if not item.get('_single_quality') and (self.provider in ('elahmad', 'dramalive', 'alfajer') or len(prepared) > 1):
            labels = _prepared_stream_labels(item)
            self.session.openWithCallback(self._player_closed, Alkuds_StreamChooser, prepared, labels, item, name, 'Live', str(self.topic.get('name') or ''), str(item.get('image') or ''), '', True)
            return
        self._open_player(prepared, name, item)

    def _open_player(self, prepared, name, item, force=False):
        if getattr(self, '_skip_preview_once', False):
            force = True
            self._skip_preview_once = False
        if not force and prepared and self._preview_start(self._selected_index, prepared[0], name):
            self._preview_payload = (list(prepared), name, item)
            self.playing_index = self._selected_index
            self._set_rows()
            return
        self._preview_forget()
        self._preview_payload = None
        self.playing_index = self._selected_index
        self._set_rows()
        from .freeplayer import Alkuds_FreeTV_Player
        category = 'Live'
        open_list_player(self, self._player_closed, Alkuds_FreeTV_Player, prepared, selected_free_service_type(), name, category, str(self.topic.get('name') or ''), str(item.get('image') or ''))

    def _player_closed(self, result=None, *args):
        self._preview_forget()
        self._preview_payload = None
        if isinstance(result, (tuple, list)):
            action = result[0] if result else None
            state = result[1] if len(result) > 1 else None
        else:
            action, state = (result, None)
        if self._selected_index >= 0 and state in ('working', 'offline'):
            self.channel_states[self._selected_index] = state
        if action in ('next', 'prev') and self.channels:
            direction = 1 if action == 'next' else -1
            target = (self._selected_index + direction) % len(self.channels)
            self.playing_index = None
            self._skip_preview_once = True
            try:
                self['list'].setIndex(target)
            except Exception:
                pass
            self.play()
            return
        self.playing_index = None if action in ('failed', 'stopped') else self._selected_index
        self._set_rows()
        self._update_title('  [%d channels]' % len(self.channels))
        if action == 'failed' and (not self._closed):
            self.session.open(MessageBox, 'This channel is offline or did not start.', MessageBox.TYPE_ERROR, timeout=6)

    def stop_stream(self):
        self._show_panel()
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.playing_index = None
        self._preview_forget()
        self._preview_payload = None
        if self.channels:
            self._set_rows()

    def _show_panel(self):
        if self._panel_hidden:
            try:
                self.show()
            except Exception:
                pass
        self._panel_hidden = False

    def back(self):
        self._preview_stop()
        self._show_panel()
        self._safe_close()

class Alkuds_RadioStreamChooser(Alkuds_StreamChooser):

    def play(self):
        current = self['list'].getCurrent()
        try:
            index = int(current[1]) if current else -1
        except Exception:
            return
        if not 0 <= index < len(self.prepared):
            return
        from .freeplayer import Alkuds_FreeTV_Player
        open_list_player(self, self._player_closed, Alkuds_FreeTV_Player, [self.prepared[index]], selected_free_service_type(), self.name, 'Live', self.description, self.image, radio=True)

class Alkuds_ArabicRadio_Browser(Alkuds_Ostora_Browser):

    def __init__(self, session, kind='live', level='groups', parent=None, page=1):
        Alkuds_Ostora_Browser.__init__(self, session, kind, level, parent, page)

    def _label(self):
        return u'الإذاعات العربية' + (' - ' + str(self.parent.get('name')) if self.parent.get('name') else '')

    def load(self):
        if self._loading:
            return
        self._operation, self._loading, self._done = ('load', True, False)
        self._result, self._error = (None, '')
        self['list'].setList([_list_entry(u'جاري تحميل الإذاعات العربية...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == 'groups':
                self._result = legacy_radio_groups() + world_radio_groups() + mytuner_radio_groups()
            elif self.parent.get('source') == 'mytuner':
                self._result = mytuner_radio_items(self.parent, self.page)
            elif self.parent.get('source') == 'radio_browser':
                self._result = radio_browser_items(self.parent, cfg.useragent.value, self.page)
            elif self.parent.get('source') == 'worldradiomap':
                self._result = world_radio_items(self.parent, cfg.useragent.value, self.page)
            else:
                self._result = fetch_ostora_items('live', cfg.useragent.value, self.parent, self.page)
        except Exception as error:
            self._error = str(error) or 'Unable to load radio stations. Press BLUE to retry.'
        self._done = True

    def _resolve_worker(self, item):
        try:
            if item.get('source') == 'worldradiomap':
                self._result = world_radio_resolve(item, cfg.useragent.value)
            elif item.get('source') in ('mytuner', 'radio_browser'):
                self._result = item
            else:
                self._result = resolve_ostora_selection(item, cfg.useragent.value)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item) if isinstance(item, dict) else []
        if not prepared:
            self.session.open(MessageBox, u'لا يوجد رابط تشغيل للإذاعة.', MessageBox.TYPE_ERROR, timeout=6)
            return
        self.session.open(Alkuds_RadioStreamChooser, prepared, _prepared_stream_labels(item), item, str(item.get('name') or 'Arabic Radio'), 'Live', str(item.get('description') or ''), str(item.get('image') or ''), '', True)
