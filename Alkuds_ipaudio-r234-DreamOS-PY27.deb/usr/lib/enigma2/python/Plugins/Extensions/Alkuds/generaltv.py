# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""GENRAL TV 2.19 public catalogues. No APK execution or account reporting."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
import hashlib
import hmac
from .py2compat import json
from .py2compat import re
from .py2compat import threading
from .py2compat import time
import uuid
from .py2compat import os
from .py2compat import requests
from .py2compat import html as html_module
try:
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
    parse_qs = urllib.parse.parse_qs
    unquote_plus = urllib.parse.unquote_plus
except ImportError:
    from urlparse import urljoin, urlparse, parse_qs
    from urllib import unquote_plus
from .py2compat import native
string_types = (native.str, native.unicode)
BASE = 'generaltv'
SECTION_MAP = {'browse': (u'جينرال تي في', '')}
BOOTSTRAP = 'https://firestore.googleapis.com/v1/projects/api-genral/databases/(default)/documents/settings/app_v3_1'
FALLBACK = 'https://posta13.blogspot.com/p/httpsk8500.html'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36'
_identity = uuid.uuid4().hex[:16]
_origin = ('', 0)
_settings = ({}, 0)
_pages = {}
_lock = threading.RLock()
_key = hashlib.sha256(b'yNPSFW@;Au,!ir%2').digest()
LOG_FILE = '/tmp/alkuds_generaltv.log'

def log(stage, url='', error=None):
    try:
        host = urlparse(url).hostname or ''
        status = getattr(getattr(error, 'response', None), 'status_code', None)
        line = '%s %s host=%s error=%s status=%s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), stage, host, type(error).__name__ if error else '', status or '')
        if os.path.isfile(LOG_FILE) and os.path.getsize(LOG_FILE) > 65536:
            with open(LOG_FILE, 'w') as target:
                target.write('GENRAL TV log rotated\n')
        with open(LOG_FILE, 'a') as target:
            target.write(line)
    except Exception:
        pass

def request_headers():
    message = 'GENRAL TV|com.genraltvpro.app|2.19|29CA406BCB43A33B2FECBD228BDDC7A1E11E772D|%d' % (int(time.time()) // 300)
    return {'User-Agent': 'okhttp/5.1.0', 'x-app-id': _identity, 'x-v3-token': hmac.new(_identity.encode('ascii'), message.encode('ascii'), hashlib.sha256).hexdigest()}

def decrypt(value):
    raw = base64.b64decode(value)
    if len(raw) < 32 or len(raw) % 16:
        raise ValueError('Invalid catalogue envelope')
    try:
        from Crypto.Cipher import AES
        plain = AES.new(_key, AES.MODE_CBC, raw[:16]).decrypt(raw[16:])
    except ImportError:
        try:
            from Cryptodome.Cipher import AES
            plain = AES.new(_key, AES.MODE_CBC, raw[:16]).decrypt(raw[16:])
        except ImportError:
            from .generalaes import AESModeOfOperationCBC
            cipher = AESModeOfOperationCBC(_key, iv=raw[:16])
            plain = b''.join((cipher.decrypt(raw[n:n + 16]) for n in range(16, len(raw), 16)))
    pad = bytearray(plain)[-1]
    if not 1 <= pad <= 16 or plain[-pad:] != bytes(bytearray([pad] * pad)):
        raise ValueError('Invalid catalogue padding')
    return plain[:-pad].decode('utf-8-sig')

def decode(value):
    for unused in range(8):
        if not isinstance(value, string_types):
            return value
        try:
            value = json.loads(value)
            continue
        except ValueError:
            pass
        try:
            value = decrypt(value)
        except (ValueError, TypeError, UnicodeError):
            return value
    return value

def unwrap(value):
    """Keep cursor metadata while unwrapping nested encrypted/JSON envelopes."""
    next_page = ''
    kind = 'data'
    for unused in range(10):
        value = decode(value)
        if not isinstance(value, dict):
            break
        next_page = value.get('nextPage') or next_page
        key = next((k for k in ('data', 'matches', 'servers') if k in value), None)
        if key is None:
            break
        kind = key
        value = value[key]
    if isinstance(value, dict):
        value = [value]
    return (value if isinstance(value, list) else [], next_page, kind)

def origin(force=False):
    global _origin
    with _lock:
        if not force and _origin[0] and (time.time() - _origin[1] < 1800):
            return _origin[0]
        for url in (BOOTSTRAP, FALLBACK):
            try:
                response = requests.get(url, timeout=(5, 12))
                response.raise_for_status()
                if url == BOOTSTRAP:
                    found = response.json()['fields']['url']['stringValue']
                else:
                    match = re.search('<p\\b[^>]*id=["\\\']url_v3["\\\'][^>]*>(.*?)</p>', response.text, re.S | re.I)
                    found = re.sub('<[^>]+>', '', match.group(1)).strip() if match else ''
                if urlparse(found).scheme in ('http', 'https') and urlparse(found).netloc:
                    _origin = (found.rstrip('/'), time.time())
                    return _origin[0]
            except Exception:
                continue
    raise RuntimeError(u'مصدر جينرال تي في غير متاح حالياً؛ حاول التحديث لاحقاً.')

def api_url(url):
    return origin() + '/genral/api/v3' + url if url.startswith('/') else url

def get(url):
    url = api_url(url)
    response = requests.get(url, headers=request_headers(), timeout=(5, 22))
    response.raise_for_status()
    if len(response.content) > 12 * 1024 * 1024:
        raise ValueError('Catalogue response too large')
    raw = response.content.decode('utf-8-sig')
    if raw.lstrip().startswith('#EXTM3U'):
        entries, info = ([], {})
        for line in raw.splitlines():
            if line.startswith('#EXTINF:'):
                info = {'title': line.rsplit(',', 1)[-1], 'logo': (re.findall('tvg-logo="([^"]*)"', line) or [''])[0]}
            elif line.strip() and (not line.startswith('#')):
                row = dict(info)
                row['servers'] = [{'name': 'Original', 'url': urljoin(response.url, line.strip())}]
                entries.append(row)
                info = {}
        return (entries, '', 'data')
    return unwrap(raw)

def configuration():
    global _settings
    with _lock:
        if _settings[0] and time.time() - _settings[1] < 900:
            return dict(_settings[0])
        rows, unused, unused2 = get('/settings/app.php?v=')
        if not rows:
            raise RuntimeError(u'تعذر تحميل إعدادات البث.')
        cfg = dict(rows[0])
        for key in ('stream_hosts', 'stream_key', 'remote_addr_url', 'remote_url', 'remote_key', 'remote_url_2', 'remote_key_2'):
            cfg[key] = str(decode(cfg.get(key, '')))
        _settings = (cfg, time.time())
        return dict(cfg)

def text(value):
    value = str(value or '').strip()
    if any((mark in value for mark in (u'ط§', u'ظ„', u'ط³', u'ظ…'))):
        for encoding in ('cp1256', 'latin-1'):
            try:
                fixed = value.encode(encoding).decode('utf-8')
                if fixed:
                    return fixed
            except (UnicodeError, LookupError):
                pass
    return value

def groups():
    return [{'name': u'المباريات', 'section': 'matches', 'url': '/matches/', 'catalogue': True}, {'name': u'المسلسلات', 'section': 'series', 'url': '/get/?from=library&type=serie', 'categories': True}, {'name': u'الأفلام', 'section': 'movies', 'url': '/get/?from=library&type=movie', 'categories': True}, {'name': u'القنوات', 'section': 'channels', 'url': '/get/?from=categories', 'categories': True}]

def server_list(value):
    result = decode(value)
    if isinstance(result, dict):
        return [result]
    if isinstance(result, list):
        return result
    if isinstance(value, string_types):
        repaired = re.sub('("(?:headers|otherHeaders)"\\s*:\\s*")({.*?})("\\s*,)', lambda m: m.group(1) + m.group(2).replace('"', '\\"') + m.group(3), value)
        try:
            return json.loads(repaired)
        except ValueError:
            pass
    return []

def server_rows(servers, parent):
    result = []
    for n, server in enumerate(server_list(servers)):
        if not isinstance(server, dict) or not server.get('url'):
            continue
        row = dict(parent)
        row.update(server)
        row.update(name=text(server.get('name') or server.get('title') or u'مشغل %d' % (n + 1)), title=parent.get('title') or parent.get('name') or text(server.get('title')), action='play', server=dict(server), quality=text(server.get('name') or ''), image=parent.get('image', ''), section=parent.get('section', 'movies'))
        row['id'] = '%s:%s:%d' % (parent.get('id', ''), server.get('name', ''), n)
        row['server_index'] = n
        row['server_key'] = hashlib.sha256(json.dumps(server, sort_keys=True, ensure_ascii=True).encode('ascii')).hexdigest()
        if parent.get('section') in ('movies', 'series'):
            row['catalogue_url'] = parent.get('catalogue_url') or parent.get('url', '')
        row['url'] = str(server['url']).replace('\\/', '/')
        result.append(row)
    return result

def megamax_players(server, parent):
    """Normal read-only Inertia partial GET used by the public mirror picker."""
    url = str(server.get('url') or '').replace('\\/', '/')
    with requests.Session() as session:
        headers = media_headers(server)
        reply = session.get(url, headers=headers, timeout=(5, 12))
        reply.raise_for_status()
        match = re.search('<script\\b[^>]*data-page=["\\\']app["\\\'][^>]*>(.*?)</script>', reply.text, re.S | re.I)
        if not match:
            return []
        page_data = json.loads(match.group(1))
        headers.update({'X-Inertia': 'true', 'X-Inertia-Version': str(page_data.get('version') or ''), 'X-Inertia-Partial-Component': str(page_data.get('component') or 'files/mirror/video'), 'X-Inertia-Partial-Data': 'streams', 'X-Requested-With': 'XMLHttpRequest', 'Referer': reply.url})
        data = session.get(reply.url, headers=headers, timeout=(5, 15))
        data.raise_for_status()
        streams = data.json().get('props', {}).get('streams', {})
        result = []
        for group in streams.get('data') or []:
            for mirror in group.get('mirrors') or []:
                link = urljoin(reply.url, mirror.get('link') or '')
                if not link.startswith(('http://', 'https://')):
                    continue
                quality = text(group.get('label') or 'Original')
                driver = text(mirror.get('driver') or 'Player')
                leaf = {'name': '%s | %s | %s' % (text(server.get('name') or 'S1'), quality, driver), 'url': link, 'headers': {'User-Agent': headers.get('User-Agent') or UA, 'Referer': reply.url}}
                row = server_rows([leaf], parent)[0]
                row.update(quality=quality, origin_server=dict(server), mirror_key=(quality, driver))
                result.append(row)
        return result

def expanded_players(entries):
    result = []
    for item in entries:
        if item.get('action') == 'play' and (urlparse(item['url']).hostname or '').lower() == 'megamax.me':
            try:
                mirrors = megamax_players(item.get('server') or item, item)
                if mirrors:
                    result.extend(mirrors)
                    continue
            except Exception as error:
                log('mirror-list-failed', item['url'], error)
        result.append(item)
    return result

def normalized(row, parent):
    name = text(row.get('title') or row.get('name'))
    if row.get('ft_name') or row.get('st_name'):
        name = u'%s × %s' % (text(row.get('ft_name')), text(row.get('st_name')))
        details = u' | '.join((text(row.get(k)) for k in ('date', 'time', 'champion') if row.get(k)))
        if details:
            name += u'   |   ' + details
    result = dict(row)
    result.update(name=name or u'عنصر', title=name or parent.get('name', ''), image=row.get('logo') or row.get('image') or parent.get('image', ''), section=parent.get('section', 'movies'), action='folder', url=text(row.get('url') or ''), category=text(row.get('lang') or ''))
    if 'servers' in row:
        result['action'] = 'servers'
        result['servers'] = server_list(row['servers'])
        if parent.get('section') in ('movies', 'series'):
            result['catalogue_url'] = parent.get('url') or parent.get('catalogue_url', '')
    return result

def page(parent, number=1):
    if parent.get('servers') is not None:
        entries = server_rows(parent['servers'], parent)
        if parent.get('section') in ('movies', 'series'):
            entries = expanded_players(entries)
        return {'entries': entries, 'last_page': 1}
    start = parent.get('url') or ''
    if not start:
        return {'entries': [], 'last_page': 1}
    key = (parent.get('section'), start)
    with _lock:
        state = _pages.setdefault(key, {'urls': {1: start}, 'results': {}})
        cached = state['results'].get(number)
        url = state['urls'].get(number)
    if cached is not None and (not (any((x.get('action') == 'play' for x in cached['entries'])) and time.time() - cached.get('_fetched_at', 0) > 60)):
        return dict(cached, entries=[dict(x) for x in cached['entries']])
    if not url:
        return {'entries': [], 'last_page': max(1, number - 1)}
    rows, next_page, kind = get(url)
    entries = []
    if kind == 'servers' or (rows and all((isinstance(x, dict) and x.get('name') and x.get('url') and (not x.get('title')) and ('headers' in x or 'position' in x) for x in rows))):
        entries = server_rows(rows, parent)
    elif rows and all((isinstance(x, dict) and 'servers' in x and (not x.get('title')) and (not x.get('ft_name')) for x in rows)):
        servers = []
        for row in rows:
            servers.extend(server_list(row['servers']))
        entries = server_rows(servers, dict(parent, title=parent.get('title') or parent.get('name')))
    else:
        ordered = sorted(rows, key=lambda x: int(x.get('position') or 0)) if rows and all((str(x.get('position') or '').isdigit() for x in rows)) else rows
        entries = [normalized(row, parent) for row in ordered if isinstance(row, dict)]
        if entries and all((re.search(u'(?:حلقة|حلقه|الحلقة)\\s*\\d+', x['name']) for x in entries)):

            def episode_order(row):
                season = re.search(u'(?:موسم|الموسم)\\s*(\\d+)', row['name'])
                episode = re.search(u'(?:حلقة|حلقه|الحلقة)\\s*(\\d+)', row['name'])
                return (int(season.group(1)) if season else 1, int(episode.group(1)))
            entries.sort(key=episode_order)
    if parent.get('categories') and number == 1 and (parent.get('section') == 'channels'):
        entries.insert(0, {'name': u'جميع القنوات', 'title': u'جميع القنوات', 'section': 'channels', 'action': 'folder', 'url': '/get/?from=channels&cat=channels&parent=allchannels'})
    if parent.get('section') in ('movies', 'series'):
        entries = expanded_players(entries)
    result = {'entries': entries, 'last_page': number + 1 if next_page else number, '_fetched_at': time.time()}
    with _lock:
        if next_page and next_page != url and (next_page not in state['urls'].values()):
            state['urls'][number + 1] = next_page
        else:
            result['last_page'] = number
        state['results'][number] = result
        if len(_pages) > 80:
            old = next(iter(_pages))
            if old != key:
                _pages.pop(old, None)
    return dict(result, entries=[dict(x) for x in entries])

def refresh(parent=None):
    global _settings, _origin
    with _lock:
        compat_clear(_pages)
        _settings = ({}, 0)
        _origin = ('', 0)

def protocol_headers(server):
    headers = {}
    for field in ('headers', 'otherHeaders'):
        value = server.get(field) or {}
        for unused in range(3):
            if isinstance(value, dict):
                break
            try:
                value = json.loads(value)
            except (ValueError, TypeError):
                if isinstance(value, string_types) and '=' in value and (not value.startswith('{')):
                    value = dict((x.split('=', 1) for x in value.split('|') if '=' in x))
                else:
                    value = value.replace('\\"', '"') if isinstance(value, string_types) else {}
        if isinstance(value, dict):
            headers.update({str(k): str(v).replace('\\/', '/') for k, v in value.items()})
    return headers

def media_headers(server):
    internal = ('use-multi-hosts', 'streamkey', 'key', 'id', 'find', 'use-tk', 'use-jwp', 'edge-api-url', 'use-yc', 'yc-key')
    headers = {k: v for k, v in protocol_headers(server).items() if k.lower() not in internal and '\n' not in k + v and ('\r' not in k + v)}
    if not any((key.lower() == 'user-agent' for key in headers)):
        headers['User-Agent'] = str(server.get('userAgent') or UA)
    if server.get('Referer'):
        headers['Referer'] = str(server['Referer'])
    return headers

def stream_candidates(server):
    url = str(server.get('url') or '').replace('\\/', '/')
    extra = protocol_headers(server)
    if url.startswith(('stream=', 'id=')) or (extra.get('id') and extra.get('key')) or extra.get('use-tk'):
        cfg = configuration()
        reply = requests.get(cfg['remote_addr_url'], timeout=(4, 8))
        reply.raise_for_status()
        ip = reply.text.strip()
        if not re.match('^[0-9a-fA-F:.]{3,80}$', ip):
            raise RuntimeError(u'تعذر تحديد عنوان اتصال البث.')
        if extra.get('id') and extra.get('key') or url.startswith('id='):
            channel = extra.get('id') or url[3:]
            host = url if extra.get('id') else cfg['remote_url']
            start = int(time.time()) - 300
            end = start + 10800
            nonce = byte_hex(os.urandom(16))
            key = extra.get('key') or cfg['remote_key']
            token = hashlib.sha1((channel + ip + str(start) + str(end) + key + nonce).encode('utf-8')).hexdigest()
            return [host.rstrip('/') + '/' + channel + '/index.m3u8?token=' + token + '-' + nonce + '-' + str(end) + '-' + str(start) + '&remote=' + ip]
        if url.startswith('stream=') and (not extra.get('use-multi-hosts')) or extra.get('use-tk'):
            token = hashlib.md5((ip + ':' + cfg['remote_key_2']).encode('utf-8')).hexdigest()
            return [cfg['remote_url_2'] + url.replace('stream=', '', 1) + '?token=' + token]
        key = str(extra.get('streamKey') or cfg['stream_key'])
        token = hashlib.md5((ip + ':' + key).encode('utf-8')).hexdigest()
        path = url[len('stream='):]
        return [host.rstrip('/') + '/' + path.lstrip('/') + '?token=' + token + '&ip=' + ip for host in dict.fromkeys(cfg['stream_hosts'].split('|')) if host.startswith(('https://', 'http://'))]
    return [url] if url.startswith(('http://', 'https://')) else []

def fresh_player(item):
    url = item.get('catalogue_url')
    if not url or item.get('section') not in ('movies', 'series'):
        return item
    try:
        rows, unused, kind = get(url)
        servers = rows if kind == 'servers' else []
        if not servers:
            for row in rows:
                if isinstance(row, dict) and 'servers' in row:
                    servers.extend(server_list(row['servers']))
                elif isinstance(row, dict) and row.get('name') and row.get('url') and (not row.get('title')):
                    servers.append(row)
        if not servers:
            return item
        original = item.get('origin_server') or item.get('server') or item
        matches = [x for x in servers if str(x.get('name', '')) == str(original.get('name', '')) and str(x.get('position', '')) == str(original.get('position', ''))]
        if not matches:
            matches = [x for x in servers if str(x.get('name', '')) == str(original.get('name', ''))]
        if not matches:
            return item
        if item.get('mirror_key'):
            mirrors = megamax_players(matches[0], item)
            match = next((row for row in mirrors if tuple(row.get('mirror_key', ())) == tuple(item['mirror_key'])), None)
            return match or item
        result = dict(item)
        result['server'] = matches[0]
        result['url'] = str(matches[0].get('url') or '').replace('\\/', '/')
        log('refresh-player', url)
        return result
    except Exception as error:
        log('refresh-failed', url, error)
        return item

def web_sources(session, url, headers, depth=0, seen=None):
    from . import arabseed
    from .freeproviders import _unpack_egybest_script
    from .subtitledata import extract
    if depth > 4:
        return []
    seen = seen if seen is not None else set()
    if url in seen:
        return []
    seen.add(url)
    if arabseed._media_type(url):
        return [{'url': url, 'mediatype': arabseed._media_type(url), 'headers': dict(headers)}]
    reply = session.get(url, headers=headers, timeout=(5, 15))
    reply.raise_for_status()
    if len(reply.content) > 3 * 1024 * 1024:
        raise ValueError('Player page too large')
    content = reply.content.decode('utf-8', 'replace')
    if 'cf-chl-' in content:
        raise RuntimeError('Browser verification required')
    content = content.replace('\\/', '/')
    unpacked = _unpack_egybest_script(content)
    if unpacked:
        content += '\n' + unpacked.replace('\\/', '/')
    final = reply.url
    parsed = urlparse(final)
    media_headers = {'User-Agent': next((v for k, v in headers.items() if k.lower() == 'user-agent'), UA), 'Referer': final, 'Origin': parsed.scheme + '://' + parsed.netloc}
    tracks = extract(content, final, media_headers)
    document = arabseed.Document(content).root
    urls = []
    for tag in document.find('source') + document.find('video'):
        if tag.attrs.get('src'):
            urls.append((tag.attrs['src'], tag.attrs.get('label') or tag.attrs.get('res') or 'Original'))
    for value in re.findall('(?:file|source|src|wurl|hls)["\\\']?\\s*[:=]\\s*["\\\']([^"\\\']+)["\\\']', content, re.I):
        urls.append((value, 'Original'))
    for value in re.findall('["\\\']((?:https?:)?//[^"\\\']+\\.(?:m3u8|mp4)(?:\\?[^"\\\']*)?)["\\\']', content, re.I):
        urls.append((value, 'Original'))
    result, unique = ([], set())
    for value, quality in urls:
        target = urljoin(final, html_module.unescape(value))
        kind = arabseed._media_type(target)
        if kind and target not in unique:
            unique.add(target)
            result.append({'url': target, 'mediatype': kind, 'quality': quality, 'headers': dict(media_headers), 'subtitles': tracks})
    if not result:
        for frame in document.find('iframe'):
            target = frame.attrs.get('src') or frame.attrs.get('data-src')
            if target:
                try:
                    result.extend(web_sources(session, urljoin(final, target), media_headers, depth + 1, seen))
                except Exception as error:
                    log('iframe-failed', urljoin(final, target), error)
    return result

def resolve(item):
    from .freeproviders import hls_variant_streams
    item = fresh_player(item)
    server = item.get('server') or item
    if server.get('license') or server.get('scheme'):
        raise RuntimeError(u'هذا المشغل يستخدم DRM ولا يدعمه مشغل الرسيفر؛ اختر مشغلاً آخر.')
    headers = media_headers(server)
    failure = ''
    for url in stream_candidates(server):
        response = None
        try:
            host = urlparse(url).hostname or ''
            if host.endswith('.0') and (not re.match('^\\d+\\.\\d+\\.\\d+\\.\\d+$', host)):
                failure = u'المصدر أرسل رابط فيديو غير صالح (%s).' % host
                log('invalid-source', url)
                continue
            response = requests.get(url, headers=headers, timeout=(4, 9), stream=True)
            response.raise_for_status()
            raw = response.raw.read(262144, decode_content=True)
            final = response.url
            response.close()
            response = None
            if b'#EXTM3U' in raw[:300]:
                stream = {'url': final, 'headers': headers, 'relay': True, 'mediatype': 'hls', 'quality': item.get('quality') or 'Auto', 'relay_options': {'livehd': True}}
                streams = hls_variant_streams(stream)
            elif raw[:1] == b'G' or b'ftyp' in raw[:32] or urlparse(final).path.lower().endswith(('.mp4', '.ts', '.mp3', '.aac')):
                streams = [{'url': final, 'headers': headers, 'relay': True, 'mediatype': 'mp4' if b'ftyp' in raw[:32] else 'ts', 'quality': item.get('quality') or 'Original', 'relay_options': {'livehd': True}}]
            else:
                with requests.Session() as session:
                    found = web_sources(session, final, headers)
                streams = []
                for media in found:
                    streams.extend(hls_variant_streams({'url': media['url'], 'mediatype': media['mediatype'], 'headers': media.get('headers') or {'User-Agent': UA, 'Referer': final}, 'relay': True, 'quality': media.get('quality') or item.get('quality') or 'Original', 'subtitles': media.get('subtitles') or []}))
            if streams:
                result = dict(item)
                result.update(name=item.get('title') or item['name'], streams=streams)
                return result
        except Exception as error:
            log('resolve-failed', url, error)
            status = getattr(getattr(error, 'response', None), 'status_code', None)
            failure = 'HTTP %s' % status if status else type(error).__name__
            continue
        finally:
            if response is not None:
                response.close()
    raise RuntimeError(u'تعذر تشغيل هذا المصدر. %s اختر مشغلاً آخر إن توفر.' % failure)
