# -*- coding: utf-8 -*-
"""Fushaar.meme catalogue, seasons, episodes and public HLS resolver.

The catalogue, series and season pages are ordinary HTML.  Film/episode
pages and their player endpoints are protected by the site's own anti-bot
middleware and can answer 403 from some networks.  This module never tries to
bypass that protection: it reports the refusal in Arabic instead.  It also
ignores the fake ``SCRAPER_HONEYPOT_CF_V1`` links embedded in detail pages.
"""
from __future__ import unicode_literals
import json
import re
import sys
if sys.version_info[0] == 2:
    from .py2compat import requests
else:
    import requests
try:
    from urllib.parse import urljoin, urlparse, unquote, urlencode
except ImportError:
    from urlparse import urljoin, urlparse
    from urllib import unquote, urlencode
from . import arabseed as a
from . import sitecatalogue as c

BASE = 'https://fushaar.meme/'
HOSTS = ('fushaar.meme', 'www.fushaar.meme')

MOVIE_SECTIONS = (
    ('movies_foreign', u'أفلام أجنبي', 'category/افلام-اجنبي'),
    ('movies_indian', u'أفلام هندي', 'category/افلام-هندي'),
    ('movies_anime', u'أفلام أنمي', 'category/افلام-انمي'),
    ('movies_asian', u'أفلام آسيوية', 'category/افلام-اسيوية'),
    ('movies_turkish', u'أفلام تركية', 'category/افلام-تركية'),
    ('movies_arabic', u'أفلام عربي', 'category/افلام-عربي'),
)
SERIES_SECTIONS = (
    ('series_foreign', u'مسلسلات أجنبي', 'category/مسلسلات-اجنبي'),
    ('series_anime', u'مسلسلات أنمي', 'category/مسلسلات-انمي'),
    ('series_turkish', u'مسلسلات تركية', 'category/مسلسلات-تركية'),
    ('series_asian', u'مسلسلات آسيوية', 'category/مسلسلات-اسيوية'),
    ('series_dubbed', u'مسلسلات مدبلجة', 'category/مسلسلات-مدبلجة'),
    ('series_arabic', u'مسلسلات عربي', 'category/مسلسلات-عربي'),
    ('series_indian', u'مسلسلات هندية', 'category/مسلسلات-هندية'),
)
OTHER_SECTIONS = (
    ('tv_programs', u'برامج تلفزيونية', 'category/برامج-تلفزيونية'),
    ('wrestling', u'عروض مصارعة', 'category/عروض-مصارعة'),
    ('ramadan_2026', u'مسلسلات رمضان 2026', 'category/مسلسلات-رمضان-2026'),
)
SECTIONS = ((('home', u'جديد الموقع', ''),
             ('search', u'البحث في الموقع', 'search')) +
            MOVIE_SECTIONS + SERIES_SECTIONS + OTHER_SECTIONS)
SECTION_MAP = dict((key, (name, path)) for key, name, path in SECTIONS)
for _key, _name in (('movies', u'الأفلام'), ('series', u'المسلسلات'),
                    ('all', u'كل الأقسام')):
    SECTION_MAP[_key] = (_name, '')

_ACCESS_DENIED = (u'الموقع يرفض الوصول إلى صفحة المشاهدة من هذه الشبكة '
                  u'(حماية مكافحة الروبوت). أعد المحاولة لاحقاً أو من شبكة أخرى.')
_EXPIRED = (u'انتهت صلاحية رابط المشغل. أعد فتح الحلقة أو الفيلم ثم حاول مرة أخرى.')
_CLOUDFLARE = (u'الموقع يطلب تحقق المتصفح (Cloudflare). لا يمكن تجاوزه من '
               u'الرسيفر؛ أعد المحاولة لاحقاً.')
_NO_PLAYER = u'لم يعرض موقع فشار مشغلاً صالحاً لهذا المحتوى.'
_NO_STREAM = (u'تعذر الوصول إلى ملف البث. قد يكون الرابط مؤقتاً أو محمياً؛ '
              u'أعد المحاولة.')
_DRM = (u'هذا المصدر محمي بـ DRM (ClearKey أو Widevine أو ما يعادله)، '
        u'ولا يمكن تشغيله على الرسيفر.')
_NO_SEASONS = (u'تعذر العثور على مواسم هذا المسلسل. قد يكون الموقع يحجب صفحات '
               u'التفاصيل من هذه الشبكة أو تغيّر عنوان المسلسل.')
_NO_EPISODES = u'لم يعرض الموقع حلقات هذا الموسم حالياً.'
_CHOOSE_EPISODE = u'افتح المسلسل ثم اختر الموسم والحلقة أولاً.'
_BAD_URL = u'رابط المحتوى غير صالح.'
_TIMEOUT = u'انتهت مهلة الاتصال بالموقع. أعد المحاولة.'
_CONNECTION = u'تعذر الاتصال بالموقع. تحقق من الشبكة.'
_TLS = u'فشل الاتصال الآمن بالموقع (TLS). تحقق من تاريخ الجهاز.'
_NETWORK = u'تعذر إكمال الطلب من الموقع. أعد المحاولة.'
_RATE = u'الموقع يرفض الطلبات المتكررة مؤقتاً. انتظر قليلاً ثم أعد المحاولة.'
_SERVER = u'الموقع غير متاح حالياً (خطأ في الخادم). أعد المحاولة لاحقاً.'
_HTTP_ERROR = u'أعاد الموقع استجابة غير متوقعة (HTTP %s).'


def _local(value):
    target = urljoin(BASE, _as_text(value))
    parsed = urlparse(target)
    if parsed.scheme not in ('http', 'https') or parsed.hostname not in HOSTS:
        raise ValueError(_BAD_URL)
    return _requote(target)


def _requote(value):
    # requests on old DreamOS cannot quote raw non-ASCII unicode URLs.
    value = _as_text(value)
    if sys.version_info[0] == 2:
        value = value.encode('utf-8')
    return _as_text(requests.utils.requote_uri(value))


def _decode(raw, content_type=''):
    if raw is None:
        return u''
    if isinstance(raw, type(u'')):
        return raw
    try:
        return raw.decode('utf-8-sig')
    except (UnicodeDecodeError, AttributeError):
        try:
            return raw.decode('cp1256', 'replace')
        except (UnicodeDecodeError, AttributeError):
            return u''


def _as_text(value):
    if isinstance(value, type(u'')):
        return value
    if isinstance(value, bytearray):
        return _decode(value)
    if isinstance(value, bytes):
        return _decode(value)
    return u'%s' % (value or u'')


def _unquote(value):
    if sys.version_info[0] == 2:
        value = _as_text(value).encode('utf-8')
    return _as_text(unquote(value))


def _network_error(error):
    name = error.__class__.__name__.lower()
    if 'timeout' in name:
        return _TIMEOUT
    if 'ssl' in name or 'certificate' in name:
        return _TLS
    if 'connection' in name:
        return _CONNECTION
    return _NETWORK


def _looks_like_cloudflare(text):
    value = (text or u'').lower()
    return ('cf-chl-' in value or 'just a moment' in value or
            'checking your browser' in value or
            'enable javascript and cookies to continue' in value)


def _looks_like_access_denied(text):
    value = (text or u'').strip().lower()
    return value in ('access denied.', 'access denied') or (
        len(value) < 500 and 'access denied' in value)


def _status_error(status, text=''):
    text = text or u''
    if status in (401, 403):
        if _looks_like_cloudflare(text):
            return _CLOUDFLARE
        return _ACCESS_DENIED
    if status == 404:
        if u'انتهت صلاحية' in text:
            return _EXPIRED
        return _EXPIRED
    if status == 429:
        return _RATE
    if status >= 500:
        return _SERVER
    return _HTTP_ERROR % status


def _page_headers(referer):
    return {'User-Agent': a.UA, 'Referer': referer or BASE,
            'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8'}


def _media_headers(referer):
    result = _page_headers(referer)
    result.update({'Accept': ('application/vnd.apple.mpegurl,'
                              'application/x-mpegURL,video/*,*/*;q=0.8')})
    return result


def _request(session, url, referer=BASE, accept=None):
    """Fetch one page/endpoint without hiding HTTP status codes."""
    try:
        target = _local(url)
    except ValueError:
        raise RuntimeError(_BAD_URL)
    headers = _page_headers(referer)
    if accept:
        headers['Accept'] = accept
    response = None
    try:
        response = session.get(_requote(target),
                               headers=headers, timeout=(6, 20),
                               allow_redirects=True, stream=True)
        raw = bytearray()
        for chunk in response.iter_content(32768):
            if not chunk:
                continue
            raw.extend(chunk)
            if len(raw) > 5 * 1024 * 1024:
                break
        content_type = (response.headers.get('Content-Type') or '').lower()
        return (response.status_code, _decode(raw, content_type),
                response.url, content_type)
    except requests.exceptions.RequestException as error:
        raise RuntimeError(_network_error(error))
    finally:
        if response is not None:
            response.close()


def _get(session, url, referer=BASE, accept=None):
    status, text, final, content_type = _request(session, url, referer, accept)
    if status != 200:
        raise RuntimeError(_status_error(status, text))
    if _looks_like_cloudflare(text):
        raise RuntimeError(_CLOUDFLARE)
    if _looks_like_access_denied(text):
        raise RuntimeError(_ACCESS_DENIED)
    return text, final


def _download(session, url, headers):
    """Read the first bytes of a media URL, retaining HTTP status."""
    value = urlparse(url or '')
    if value.scheme not in ('http', 'https'):
        raise RuntimeError(_BAD_URL)
    if _forbidden(url):
        raise RuntimeError(_BAD_URL)
    if value.hostname in HOSTS:
        try:
            url = _local(url)
        except ValueError:
            raise RuntimeError(_BAD_URL)
    response = None
    try:
        response = session.get(_requote(url),
                               headers=headers, timeout=(6, 20),
                               allow_redirects=True, stream=True)
        raw = bytearray()
        for chunk in response.iter_content(32768):
            if not chunk:
                continue
            raw.extend(chunk)
            if len(raw) >= 2 * 1024 * 1024:
                break
        content_type = (response.headers.get('Content-Type') or '').lower()
        return response.status_code, raw, response.url, content_type
    except requests.exceptions.RequestException as error:
        raise RuntimeError(_network_error(error))
    finally:
        if response is not None:
            response.close()


def _cookie_state(session):
    try:
        return [{'name': cookie.name, 'value': cookie.value,
                 'domain': cookie.domain, 'path': cookie.path,
                 'secure': cookie.secure} for cookie in session.cookies]
    except Exception:
        return []


def _restore_cookies(session, cookies):
    for value in cookies or []:
        try:
            session.cookies.set(value.get('name'), value.get('value'),
                                domain=value.get('domain') or '',
                                path=value.get('path') or '/',
                                secure=bool(value.get('secure')))
        except Exception:
            continue


def groups():
    return [
        {'name': u'البحث في الموقع', 'section': 'search', 'action': 'search'},
        {'name': u'جديد الموقع — أحدث الأفلام والحلقات', 'section': 'home',
         'node': 'sections'},
        {'name': u'الأفلام', 'section': 'movies', 'node': 'sections'},
        {'name': u'المسلسلات', 'section': 'series', 'node': 'sections'},
        {'name': u'برامج تلفزيونية', 'section': 'tv_programs', 'node': 'sections'},
        {'name': u'عروض مصارعة', 'section': 'wrestling', 'node': 'sections'},
        {'name': u'مسلسلات رمضان 2026', 'section': 'ramadan_2026',
         'node': 'sections'},
        {'name': u'كل الأقسام', 'section': 'all', 'node': 'sections'},
    ]


def sections(section, parent):
    if section == 'movies':
        return [{'name': name, 'section': key, 'node': 'items'}
                for key, name, _path in MOVIE_SECTIONS]
    if section == 'series':
        return [{'name': name, 'section': key, 'node': 'sections'}
                for key, name, _path in SERIES_SECTIONS]
    if section == 'all':
        return [{'name': name, 'section': key,
                 'node': 'sections' if key.startswith('series_') else 'items'}
                for key, name, _path in
                MOVIE_SECTIONS + SERIES_SECTIONS + OTHER_SECTIONS]
    choices = [{'name': u'بحث في الموقع', 'action': 'search'},
            {'name': u'عرض كل الأفلام والحلقات بترتيب الموقع', 'node': 'items', 'grouped': False},
            {'name': u'ترتيب أبجدي أ–ي', 'node': 'items', 'order': 'az'},
            {'name': u'ترتيب أبجدي ي–أ', 'node': 'items', 'order': 'za'}]
    if section.startswith('series_'):
        choices.insert(2, {'name': u'تجميع المسلسلات — المواسم والحلقات',
                           'node': 'items', 'grouped': True})
    return choices


def filters(section, parent):
    return []


def _natural_key(value):
    parts = re.split(r'(\d+)', value or '')
    result = []
    for part in parts:
        if part.isdigit():
            result.append(int(part))
        elif part:
            result.append(part.lower())
    return result


def _series_name(title):
    value = _as_text(title).strip()
    value = re.compile(u'\\s*(?:الموسم|موسم|الحلقة|حلقة|الجزء|Season|Episode)\\s*',
                       re.I).split(value, 1)[0]
    value = re.compile(u'\\s+(?:مترجم|مترجمة|مدبلج|مدبلجة)\\s*$',
                       re.I).sub(u'', value).strip()
    return value or _as_text(title).strip()


def _card_title(node):
    title = c.text(node, 'title') or node.attrs.get('title') or ''
    if not title:
        images = node.find('img')
        if images:
            title = images[0].attrs.get('alt') or ''
    if not title:
        title = node.text()
    return re.sub(r'\s+', u' ', _as_text(title)).strip()


def parse_items(html, page_url, section='home', grouped=True):
    root = a.Document(html).root
    result, seen, series_seen = [], set(), set()
    for node in root.find('a'):
        classes = (node.attrs.get('class') or '').split()
        if 'show-card' not in classes:
            continue
        href = node.attrs.get('href') or ''
        if not href:
            continue
        try:
            url = _local(href)
        except Exception:
            continue
        if url in seen:
            continue
        path = urlparse(url).path
        if not any(part in path for part in
                   ('/film/', '/episode/', '/series/', '/season/')):
            continue
        title = _card_title(node)
        if not title:
            continue
        is_series = ('/episode/' in path or '/series/' in path or
                     '/season/' in path)
        row = {'id': url, 'url': url, 'name': title, 'title': title,
               'image': c.image(node, page_url), 'category': c.text(node, 'categ'),
               'quality': c.text(node, 'quality'),
               'description': c.text(node, 'description'),
               'search_text': title.lower(), 'section': section,
               'is_series': bool(is_series and (grouped or '/series/' in path or '/season/' in path))}
        if grouped and is_series:
            name = _series_name(title)
            if u'مدبلج' in title and u'مدبلج' not in name:
                name += u' — مدبلج'
            key = name.strip().lower()
            if not key or key in series_seen:
                continue
            series_seen.add(key)
            row.update(name=name, series_key=key, quality='')
        seen.add(url)
        result.append(row)
    return result


def _last_page(root, page):
    values = [int(page)]
    for node in root.find():
        href = node.attrs.get('href') or ''
        for match in re.finditer(r'[?&]page=(\d+)', href):
            values.append(int(match.group(1)))
        onclick = node.attrs.get('onclick') or ''
        for match in re.finditer(r"updateQuery\(\s*['\"]page['\"]\s*,\s*(\d+)",
                                 onclick):
            values.append(int(match.group(1)))
    return max(values)


def fetch_items(section, page=1, query='', order='latest', options=None):
    page = max(1, int(page or 1))
    query = (query or u'').strip()
    if query:
        url = BASE + 'search?' + c.urlencode(
            [('s', query.encode('utf-8')), ('page', str(page))])
        name = u'البحث: ' + query
    else:
        key = section if section in SECTION_MAP else 'home'
        if key in ('movies', 'series', 'all', 'search'):
            key = 'home'
        name, path = SECTION_MAP.get(key, SECTION_MAP['home'])
        base = _local(path) if path else BASE
        url = c.page_url(base, page)
    with requests.Session() as session:
        html, final = _get(session, url, referer=BASE)
    root = a.Document(html).root
    # Keep every episode/event accessible. Group only actual series categories;
    # home, search, TV and wrestling stay in the site's original episode order.
    grouped = bool(not query and (options or {}).get('grouped'))
    entries = parse_items(html, final, section, grouped)
    if order in ('az', 'za'):
        entries.sort(key=lambda item: (item.get('name') or u'').lower(),
                     reverse=order == 'za')
    return {'entries': entries, 'page': page,
            'last_page': _last_page(root, page), 'total': len(entries),
            'name': name, 'url': final}


def series_candidates(url):
    path = urlparse(url or '').path
    if '/series/' in path:
        try:
            return [_local(url)]
        except Exception:
            return []
    if '/film/' in path:
        return []
    slug = _unquote(path.rstrip('/').rsplit('/', 1)[-1])
    if not slug:
        return []
    base = re.compile(u'-(?:الموسم|موسم|الجزء|season)-', re.I).split(slug, 1)[0]
    if base == slug:
        base = re.compile(u'-(?:الحلقة|حلقه|حلقة|episode)-',
                          re.I).split(slug, 1)[0]
    base = re.compile(u'-(?:مترجمة|مترجم|مدبلجة|مدبلج|مترجمه|مدبلجه)\\s*$',
                      re.I).sub(u'', base).strip(u'- ')
    if not base:
        return []
    if u'مدبلج' in slug:
        suffixes = (u'مدبلج', u'مترجم', u'')
    else:
        suffixes = (u'مترجم', u'مدبلج', u'')
    result = []
    for suffix in suffixes:
        value = base + ((u'-' + suffix) if suffix else u'')
        try:
            target = _local('/series/' + value)
        except Exception:
            continue
        if target not in result:
            result.append(target)
    return result


def series_from_detail(html, page_url):
    for match in re.finditer(
            r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>'
            r'(.*?)</script>', html, re.S | re.I):
        try:
            data = json.loads(match.group(1).strip())
        except (TypeError, ValueError):
            continue
        stack = [data]
        while stack:
            value = stack.pop()
            if isinstance(value, dict):
                if value.get('@type') == 'BreadcrumbList':
                    for entry in value.get('itemListElement') or []:
                        target = entry.get('item') or entry.get('@id') or ''
                        if '/series/' in target:
                            try:
                                return _local(target)
                            except Exception:
                                pass
                stack.extend(value.values())
            elif isinstance(value, list):
                stack.extend(value)
    for match in re.finditer(r'href=["\']([^"\']*/series/[^"\']+)["\']',
                             html, re.I):
        target = c.unescape(match.group(1))
        if '/series/' not in target:
            continue
        try:
            return _local(target)
        except Exception:
            continue
    return ''


def parse_seasons(html, page_url, item):
    root = a.Document(html).root
    rows, seen = [], set()
    series_title = item.get('series_title') or item.get('name') or u'المسلسل'
    for link in root.find('a'):
        href = link.attrs.get('href') or ''
        if '/season/' not in href:
            continue
        try:
            url = _local(href)
        except Exception:
            continue
        if url in seen:
            continue
        seen.add(url)
        number_text = c.text(link, 'fs-2')
        if not number_text:
            found = re.search(r'(\d+)', link.text() or '')
            number_text = found.group(1) if found else ''
        try:
            number = int(number_text)
        except (TypeError, ValueError):
            number = 0
        name = (u'الموسم %d' % number) if number else (link.text() or u'موسم')
        row = dict(item)
        row.pop('node', None)
        row.pop('action', None)
        row.update(name=name, title=series_title + u' — ' + name, url=url,
                   season=True, season_url=url, season_number=number,
                   is_series=False, series_title=series_title, referer=page_url)
        rows.append(row)
    if rows:
        rows.sort(key=lambda row: (row.get('season_number') or 0,
                                   _natural_key(row.get('name') or u'')))
        return rows
    if any('/episode/' in (link.attrs.get('href') or '')
           for link in root.find('a')):
        row = dict(item)
        row.pop('node', None)
        row.pop('action', None)
        row.update(name=u'حلقات المسلسل', title=series_title, url=page_url,
                   season=True, season_url=page_url, season_number=0,
                   is_series=False, series_title=series_title, referer=page_url)
        return [row]
    return []


def seasons(item):
    item = dict(item)
    candidates = []
    source = item.get('url') or item.get('series_url') or ''
    for value in series_candidates(source):
        if value not in candidates:
            candidates.append(value)
    session = requests.Session()
    _restore_cookies(session, item.get('cookies'))
    try:
        for url in candidates:
            status, html, final, content_type = _request(
                session, url, referer=BASE,
                accept='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
            if status != 200:
                continue
            rows = parse_seasons(html, final, item)
            if rows:
                return rows
            if not final.rstrip('/').endswith('/seasons'):
                status, more, final_more, content_type = _request(
                    session, final.rstrip('/') + '/seasons', referer=final,
                    accept='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
                if status == 200:
                    rows = parse_seasons(more, final_more, item)
                    if rows:
                        return rows
        detail = item.get('url')
        if detail:
            status, html, final, content_type = _request(
                session, detail, referer=BASE,
                accept='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
            if status == 200:
                series_url = series_from_detail(html, final)
                if series_url:
                    status, html, final, content_type = _request(
                        session, series_url, referer=final,
                        accept='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
                    if status == 200:
                        rows = parse_seasons(html, final, item)
                        if rows:
                            return rows
        raise RuntimeError(_NO_SEASONS)
    finally:
        session.close()


def parse_episodes(html, page_url, item):
    root = a.Document(html).root
    anchors = [node for node in root.find('a')
               if 'epss' in (node.attrs.get('class') or '').split()]
    if not anchors:
        anchors = [node for node in root.find('a')
                   if '/episode/' in (node.attrs.get('href') or '')]
    rows, seen = [], set()
    series_title = item.get('series_title') or item.get('name') or u'المسلسل'
    for link in anchors:
        href = link.attrs.get('href') or ''
        if '/episode/' not in href:
            continue
        try:
            url = _local(href)
        except Exception:
            continue
        if url in seen:
            continue
        seen.add(url)
        number_text = c.text(link, 'fs-2')
        if not number_text:
            found = re.search(u'الحلقة[- ]?(\\d+)', _unquote(url))
            number_text = found.group(1) if found else ''
        try:
            number = int(number_text)
        except (TypeError, ValueError):
            number = 0
        label = c.text(link, 'title') or link.text() or ''
        name = (u'الحلقة %d' % number) if number else (label or u'حلقة')
        row = dict(item)
        for key in ('node', 'action', 'season', 'season_url', 'season_number'):
            row.pop(key, None)
        row.update(name=name, title=series_title + u' — ' + name, url=url,
                   episode=number, is_series=False, series_title=series_title,
                   referer=page_url)
        rows.append(row)
    rows.sort(key=lambda row: (row.get('episode') or 999999,
                               _natural_key(row.get('name') or u'')))
    return rows


def episodes(item, page=1):
    url = item.get('season_url') or item.get('url')
    if not url:
        raise RuntimeError(_CHOOSE_EPISODE)
    session = requests.Session()
    _restore_cookies(session, item.get('cookies'))
    try:
        html, final = _get(session, url, referer=item.get('referer') or BASE)
    finally:
        session.close()
    rows = parse_episodes(html, final, item)
    if not rows:
        raise RuntimeError(_NO_EPISODES)
    return {'entries': rows, 'page': 1, 'last_page': 1, 'total': len(rows)}


def video_candidate(html):
    match = re.search(r'id=["\']hpv3-media-candidates["\'][^>]*>(.*?)</script>',
                      html, re.S | re.I)
    if not match:
        return ''
    try:
        value = json.loads(match.group(1).strip()).get('video_candidate') or ''
    except (AttributeError, TypeError, ValueError):
        return ''
    try:
        value = _local(c.unescape(value))
    except Exception:
        return ''
    if _forbidden(value):
        return ''
    if not a._media_type(value):
        return ''
    return value


def _forbidden(url):
    value = (url or u'').lower()
    return ('shaahedd4u.net' in value or '_scrape_trap' in value or
            not value.startswith(('http://', 'https://')))


def _template_urls(html, page_url):
    result = []
    root = a.Document(html).root
    for node in root.find('template'):
        if node.attrs.get('id') != 'content-media-template':
            continue
        for key in ('data-player-url', 'data-iframe-url'):
            value = node.attrs.get(key) or ''
            if not value:
                continue
            try:
                target = _local(value)
            except Exception:
                continue
            if not _forbidden(target) and target not in result:
                result.append(target)
    return result


def _watch_urls(html, page_url):
    result = []
    root = a.Document(html).root
    for node in root.find('a'):
        href = node.attrs.get('href') or ''
        if '/watch/' not in href:
            continue
        try:
            target = _local(href)
        except Exception:
            continue
        if target not in result:
            result.append(target)
    return result


def _media_urls(payload, base):
    text = _decode(payload) if not isinstance(payload, type(u'')) else payload
    text = (text or u'').replace('\\/', '/').replace('&amp;', '&')
    result, seen = [], set()

    def add(value):
        value = _as_text(value).replace('\\/', '/').replace('&amp;', '&').strip()
        if not value or _forbidden(c.urljoin(base, value)):
            return
        target = c.urljoin(base, value)
        if urlparse(target).scheme not in ('http', 'https'):
            return
        kind = a._media_type(target)
        if not kind or target in seen:
            return
        seen.add(target)
        result.append((target, kind))

    stripped = text.lstrip()
    if stripped.startswith(('{', '[')):
        try:
            data = json.loads(stripped)
        except (TypeError, ValueError):
            data = None
        if data is not None:
            stack = [data]
            while stack:
                value = stack.pop()
                if isinstance(value, dict):
                    stack.extend(value.values())
                elif isinstance(value, list):
                    stack.extend(value)
                elif isinstance(value, type(u'')):
                    add(value)
    root = a.Document(text).root
    for node in root.find('source') + root.find('video'):
        add(node.attrs.get('src') or '')
    for node in root.find('iframe'):
        add(node.attrs.get('src') or node.attrs.get('data-src') or '')
    for match in re.finditer(
            r'(?:https?:)?//[^\s"\'<>\\]+?\.(?:m3u8|mp4)'
            r'(?:\?[^\s"\'<>\\]*)?', text, re.I):
        add(match.group(0))
    return result


def _protected_payload(text):
    return bool(re.search(
        r'["\'](?:drm|keySystem|keySystems|clearkey|widevine|licenseUrl)["\']'
        r'\s*:\s*(?!null\b|false\b|["\']["\'])[\[{"\']', text, re.I))


def _endpoint_media(session, body, final, referer, depth=0):
    if _protected_payload(body):
        return []
    if _is_manifest(body):
        return [(final, 'hls')]
    result = _media_urls(body, final)
    if depth >= 2:
        return result
    for node in a.Document(body).root.find('iframe')[:3]:
        url = c.urljoin(final, node.attrs.get('src') or node.attrs.get('data-src') or '')
        if _forbidden(url) or url == final or a._media_type(url):
            continue
        status, raw, target, mime = _download(session, url, _media_headers(referer))
        if status == 200:
            result.extend(_endpoint_media(session, _decode(raw, mime), target,
                                          referer, depth + 1))
    return result


def _candidates(session, html, page_url, fallback=False):
    result, seen = [], set()

    def add(label, url, kind=''):
        if not url or _forbidden(url) or url in seen:
            return
        if not kind:
            kind = a._media_type(url)
        if not kind:
            return
        seen.add(url)
        result.append((label, url, kind))

    candidate = video_candidate(html)
    if candidate:
        add(u'المشغل الرئيسي — HLS', candidate, 'hls')
        if not fallback:
            return result  # Signed URLs are short-lived; do not delay probing.
    for endpoint in _template_urls(html, page_url):
        status, body, final, content_type = _request(
            session, endpoint, referer=page_url,
            accept='text/html,application/json,*/*')
        if status != 200:
            continue
        nested = video_candidate(body)
        if nested:
            add(u'المشغل الرئيسي — HLS', nested, 'hls')
        for url, kind in _endpoint_media(session, body, final, page_url):
            add(u'المشغل الرئيسي — ' + ('HLS' if kind == 'hls' else 'MP4'),
                url, kind)
    for endpoint in _watch_urls(html, page_url):
        status, body, final, content_type = _request(
            session, endpoint, referer=page_url,
            accept='text/html,application/xhtml+xml,application/json,*/*')
        if status != 200:
            continue
        nested = video_candidate(body)
        if nested:
            add(u'المشغل الرئيسي — HLS', nested, 'hls')
        for url, kind in _endpoint_media(session, body, final, page_url):
            add(u'المشغل الرئيسي — ' + ('HLS' if kind == 'hls' else 'MP4'),
                url, kind)
    for url, kind in _media_urls(html, page_url):
        add(u'المشغل الرئيسي — ' + ('HLS' if kind == 'hls' else 'MP4'), url, kind)
    return result


def servers(item):
    item = dict(item)
    page_url = item.get('page_url') or item.get('url') or ''
    path = urlparse(page_url).path
    if '/series/' in path or '/season/' in path:
        raise RuntimeError(_CHOOSE_EPISODE)
    session = requests.Session()
    _restore_cookies(session, item.get('cookies'))
    try:
        html, final = _get(session, page_url,
                           referer=item.get('referer') or BASE)
        if _protected_payload(html):
            raise RuntimeError(_DRM)
        candidates = _candidates(session, html, final)
        if not candidates:
            raise RuntimeError(_NO_PLAYER)
        cookies = _cookie_state(session)
        rows = []
        for index, (label, url, kind) in enumerate(candidates):
            row = dict(item)
            row.pop('node', None)
            row.pop('action', None)
            row.update(name=(label if len(candidates) == 1 else
                             u'%d — %s' % (index + 1, label)),
                       title=item.get('title') or item.get('name') or u'فشار',
                       server_url=url, referer=final, page_url=final,
                       headers=_media_headers(final), candidate_kind=kind,
                       is_series=False, cookies=cookies)
            rows.append(row)
        return rows
    finally:
        session.close()


def protected_manifest(text):
    value = text or u''
    upper = value.upper()
    for token in ('SAMPLE-AES', 'SAMPLE-AES-CTR', 'WIDEVINE', 'PLAYREADY',
                  'CLEARKEY', 'FAIRPLAY', 'STREAMINGKEYDELIVERY'):
        if token in upper:
            return True
    for line in value.splitlines():
        stripped = line.strip()
        if not stripped.upper().startswith(('#EXT-X-KEY', '#EXT-X-SESSION-KEY')):
            continue
        upper_line = stripped.upper()
        if re.search(r'METHOD=NONE(?:,|\s|$)', upper_line):
            continue
        method = re.search(r'METHOD=([^,\s]+)', upper_line)
        if method and method.group(1) not in ('AES-128',):
            return True
        keyformat = re.search(r'KEYFORMAT=["\']?([^,"\'\s]+)', stripped, re.I)
        if keyformat and keyformat.group(1).strip().lower() not in ('identity',):
            return True
        uri = re.search(r'URI="([^"]+)"', stripped, re.I)
        if uri and uri.group(1).strip().lower().startswith(
                ('data:', 'skd:', 'clearkey:')):
            return True
    return False


def parse_variants(text, base):
    lines = (text or u'').splitlines()
    result, seen = [], set()
    for index, line in enumerate(lines):
        if not line.strip().upper().startswith('#EXT-X-STREAM-INF'):
            continue
        attrs = line.split(':', 1)[1] if ':' in line else ''
        resolution = re.search(r'RESOLUTION=(\d+)x(\d+)', attrs, re.I)
        bandwidth = re.search(r'BANDWIDTH=(\d+)', attrs, re.I)
        if resolution:
            quality = u'%sp' % resolution.group(2)
        elif bandwidth:
            quality = u'%d kbps' % (int(bandwidth.group(1)) // 1000)
        else:
            quality = u'تلقائي'
        for following in lines[index + 1:]:
            value = following.strip()
            if not value or value.startswith('#'):
                continue
            target = c.urljoin(base, value)
            if target not in seen:
                seen.add(target)
                result.append({'url': target, 'quality': quality})
            break
    return result


def _is_manifest(text):
    return (text or u'').lstrip(u'\ufeff \t\r\n').upper().startswith('#EXTM3U')


def _is_mp4(raw, content_type, url):
    # Never mistake a 200 HTML error at a .mp4 URL for playable media.
    if raw is None or len(raw) < 8 or raw[4:8] != b'ftyp':
        return False
    if any(marker in raw for marker in
           (b'pssh', b'tenc', b'encv', b'enca', b'cenc', b'cbcs')):
        raise RuntimeError(_DRM)
    # Require the full movie metadata box in the probe. A moov-at-end file
    # cannot be established as clear from its filename or MIME type alone.
    import struct
    offset = 0
    while offset + 8 <= len(raw):
        size = struct.unpack('>I', bytes(raw[offset:offset + 4]))[0]
        tag = raw[offset + 4:offset + 8]
        if size < 8 or offset + size > len(raw):
            return False
        if tag == b'moov':
            return True
        offset += size
    return False


def _stream(url, kind, quality, headers, cookies):
    stream = {'url': url, 'mediatype': kind, 'quality': quality,
              'name': quality, 'headers': dict(headers), 'relay': True}
    if cookies:
        stream['relay_options'] = {'cookies': list(cookies)}
    return stream


def _check_manifest(session, text, final, headers, depth=0, seen=None):
    if protected_manifest(text):
        raise RuntimeError(_DRM)
    if depth > 4:
        raise RuntimeError(_NO_STREAM)
    seen = set(seen or ())
    if final in seen:
        raise RuntimeError(_NO_STREAM)
    seen.add(final)
    targets = [row['url'] for row in parse_variants(text, final)]
    # Alternate audio/subtitle playlists may carry their own DRM declaration.
    for line in text.splitlines():
        if line.strip().upper().startswith(('#EXT-X-MEDIA:', '#EXT-X-I-FRAME-STREAM-INF:')):
            match = re.search(r'URI="([^"]+)"', line, re.I)
            if match:
                targets.append(c.urljoin(final, match.group(1)))
    if len(targets) > 32:
        raise RuntimeError(_NO_STREAM)
    for target in set(targets):
        status, raw, child, mime = _download(session, target, headers)
        body = _decode(raw, mime)
        if status != 200 or not _is_manifest(body):
            raise RuntimeError(_NO_STREAM)
        _check_manifest(session, body, child, headers, depth + 1, seen)


def _streams_from_manifest(session, text, final, headers, cookies):
    if protected_manifest(text):
        raise RuntimeError(_DRM)
    variants = parse_variants(text, final)
    if '#EXT-X-MEDIA:' in text.upper():
        _check_manifest(session, text, final, headers)
        return [_stream(final, 'hls', u'تلقائي', headers, cookies)]
    if not variants:
        return [_stream(final, 'hls', u'تلقائي', headers, cookies)]
    streams, protected = [], False
    for variant in variants[:8]:
        status, raw, variant_final, content_type = _download(
            session, variant['url'], headers)
        if status != 200:
            continue
        body = _decode(raw, content_type)
        if not _is_manifest(body):
            continue
        try:
            _check_manifest(session, body, variant_final, headers)
        except RuntimeError as error:
            protected = protected or _as_text(error.args[0]) == _DRM
            continue
        streams.append(_stream(variant_final or variant['url'], 'hls',
                               variant.get('quality') or u'تلقائي',
                               headers, cookies))
    if streams:
        return streams
    if protected:
        raise RuntimeError(_DRM)
    raise RuntimeError(_NO_STREAM)


def _resolve_embedded(session, payload, base, headers, cookies, depth=1):
    if depth > 2:
        return []
    urls = _media_urls(payload, base)
    candidate = video_candidate(payload)
    if candidate:
        urls.append((candidate, 'hls'))
    streams, seen = [], set()
    for url, kind in urls:
        if url in seen:
            continue
        seen.add(url)
        status, raw, final, content_type = _download(session, url, headers)
        if _protected_payload(_decode(raw, content_type)):
            raise RuntimeError(_DRM)
        if status != 200:
            continue
        text = _decode(raw, content_type)
        if _is_manifest(text):
            streams.extend(_streams_from_manifest(
                session, text, final, headers, cookies))
        elif _is_mp4(raw, content_type, final):
            streams.append(_stream(final or url, 'mp4', u'تلقائي',
                                   headers, cookies))
    return streams


def _refresh_candidates(session, item):
    page_url = item.get('page_url') or item.get('url') or ''
    if not page_url:
        return []
    status, html, final, content_type = _request(
        session, page_url, referer=item.get('referer') or BASE)
    if status != 200:
        return []
    if _protected_payload(html):
        raise RuntimeError(_DRM)
    candidates = _candidates(session, html, final, fallback=True)
    if not candidates:
        return []
    rows = []
    for label, url, kind in candidates:
        row = dict(item)
        row.update(server_url=url, referer=final, page_url=final,
                   headers=_media_headers(final), candidate_kind=kind,
                   cookies=_cookie_state(session))
        rows.append(row)
    return rows


def resolve(item):
    item = dict(item)
    url = item.get('server_url') or ''
    if not url:
        raise RuntimeError(_NO_PLAYER)
    headers = dict(item.get('headers') or
                   _media_headers(item.get('referer') or BASE))
    session = requests.Session()
    _restore_cookies(session, item.get('cookies'))
    try:
        status, raw, final, content_type = _download(session, url, headers)
        if _protected_payload(_decode(raw, content_type)):
            raise RuntimeError(_DRM)
        if status != 200 or not raw or (not _is_manifest(_decode(raw, content_type))
                                        and not _is_mp4(raw, content_type, final)):
            for fresh in _refresh_candidates(session, item)[:6]:
                item.update(fresh)
                url = item['server_url']
                headers = dict(item.get('headers') or headers)
                status, raw, final, content_type = _download(
                    session, url, headers)
                if status == 200 and (_is_manifest(_decode(raw, content_type)) or
                                      _is_mp4(raw, content_type, final)):
                    break
        if status in (401, 403):
            text = _decode(raw, content_type)
            raise RuntimeError(_CLOUDFLARE if _looks_like_cloudflare(text)
                               else _ACCESS_DENIED)
        if status == 404:
            raise RuntimeError(_EXPIRED)
        if status != 200:
            raise RuntimeError(_status_error(status, _decode(raw, content_type)))
        text = _decode(raw, content_type)
        if _protected_payload(text):
            raise RuntimeError(_DRM)
        if _looks_like_cloudflare(text):
            raise RuntimeError(_CLOUDFLARE)
        if _looks_like_access_denied(text):
            raise RuntimeError(_ACCESS_DENIED)
        cookies = _cookie_state(session) or item.get('cookies')
        if _is_manifest(text):
            streams = _streams_from_manifest(session, text, final,
                                             headers, cookies)
        elif _is_mp4(raw, content_type, final):
            streams = [_stream(final or url, 'mp4', u'تلقائي', headers, cookies)]
        else:
            streams = _resolve_embedded(session, text, final, headers, cookies)
        if not streams:
            raise RuntimeError(_NO_STREAM)
        item.update(name=item.get('title') or item.get('name') or u'فشار',
                    streams=streams)
        return item
    finally:
        session.close()
