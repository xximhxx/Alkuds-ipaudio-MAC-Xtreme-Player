# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""List-owned playback and a compact instance of the existing stream metrics."""
from __future__ import absolute_import, division, print_function
from .py2compat import service_reference, gui_text
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import time
from .py2compat import ElementTree as ET
from enigma import eServiceReference, iServiceInformation
from Components.ActionMap import ActionMap
from .streammonitor import AlkudsStreamInfoBar, _safe_service_info, destroy_stream_info_dialog

def _preview_log(message, reset=False):
    try:
        with open('/tmp/alkuds-listpreview.log', 'w' if reset else 'a') as output:
            output.write(time.strftime('%H:%M:%S') + ' ' + message + '\n')
    except Exception:
        pass

def restore_cinehd_channel(session, previous):
    """Release CineHD on the GUI loop before returning to the DVB decoder."""
    pending = getattr(session, '_alkuds_cinehd_return', None)
    if pending:
        if previous is not None:
            pending['previous'] = previous
        return True
    current = session.nav.getCurrentlyPlayingServiceReference()
    if current is None:
        return False
    try:
        from . import streamproxy
        from .py2compat import urllib
        urlparse = urllib.parse.urlparse
        parsed = urlparse(current.getPath())
        parts = parsed.path.strip('/').split('/')
        if parsed.hostname != '127.0.0.1' or len(parts) != 3 or parts[0] != 'alkuds-hls':
            return False
        with streamproxy._LOCK:
            relay = streamproxy._SESSIONS.get(parts[1])
        if relay is None or not relay.options.get('cinehd'):
            return False
    except Exception:
        return False
    from enigma import eTimer
    timer = eTimer()
    job = {'timer': timer, 'previous': previous, 'expected': current.toString(), 'stopped': False}
    session._alkuds_cinehd_return = job

    def finished():
        timer.stop()
        if getattr(session, '_alkuds_cinehd_return', None) is job:
            session._alkuds_cinehd_return = None

    def step():
        if getattr(session, '_alkuds_cinehd_return', None) is not job:
            return
        try:
            active = session.nav.getCurrentlyPlayingServiceReference()
            if not job['stopped']:
                if not active or active.toString() != job['expected']:
                    _preview_log('cinehd return cancelled: service changed')
                    finished()
                    return
                _preview_log('cinehd return: stopping video')
                session.nav.stopService()
                job['stopped'] = True
                _preview_log('cinehd return: video stopped; release 350ms')
                timer.start(350, True)
                return
            if active:
                _preview_log('cinehd return cancelled: new service active')
                finished()
                return
            target = job['previous']
            if target:
                _preview_log('cinehd return: restoring channel')
                session.nav.playService(target)
            _preview_log('cinehd return: complete')
        except Exception as error:
            _preview_log('cinehd return failed: ' + type(error).__name__)
        finished()
    try:
        job['connection'] = timer.timeout.connect(step)
    except Exception:
        timer.callback.append(step)
    timer.start(50, True)
    _preview_log('cinehd return scheduled')
    return True

def reference_type(reference):
    value = getattr(reference, 'type', None)
    if value is not None:
        return int(value)
    getter = getattr(reference, 'getType', None)
    if callable(getter):
        return int(getter())
    return int(reference.toString().split(':', 1)[0])

def geometry(skin):
    root = ET.fromstring(skin)
    width, height = [int(x) for x in root.attrib['size'].split(',')]
    pig = next((n for n in root.iter('widget') if n.get('render') == 'Pig'))
    x, y = [int(v) for v in pig.get('position').split(',')]
    w, h = [int(v) for v in pig.get('size').split(',')]
    return (x, y + h + 12, w, max(120, height - (y + h + 12) - 75))

def info_skin(rect):
    x, y, w, h = rect
    step = min(40, max(12, (h - 16) // 14))
    font = min(25, max(10, min(step - 3, int(w / 33))))
    names = ('channel', 'clock', 'event', 'event_time', 'quality', 'player', 'video_rate', 'audio_rate', 'total_rate', 'network', 'diagnosis', 'hint')
    parts = ['<screen name="AlkudsListStreamInfo" position="%d,%d" size="%d,%d" backgroundColor="#000000" flags="wfNoBorder" zPosition="10">' % (x, y, w, h)]
    for i, n in enumerate(names):
        parts.append('<widget name="%s" position="8,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="%s" transparent="1" noWrap="1" />' % (n, 8 + i * step, w - 16, step, font, '#8DE3BA' if n == 'network' else '#E9D5FF'))
    parts.append('<widget name="flow" position="8,%d" size="%d,8" foregroundColor="#8DE3BA" backgroundColor="#382744" />' % (8 + 12 * step, w - 16))
    return ''.join(parts) + '</screen>'

class ListInfo(AlkudsStreamInfoBar):

    def __init__(self, session, rect):
        AlkudsStreamInfoBar.__init__(self, session)
        self.skin = info_skin(rect)
        self.started_at = time.time()
        self.ready_at = None
        self.failure = ''
        self.last_position = None
        self.video_signal = False
        self.expected_reference = None
        self.progress_ticks = 0
        self.last_progress_at = None

    def _update(self):
        AlkudsStreamInfoBar._update(self)
        if not self._visible:
            return
        elapsed = time.time() - self.started_at
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            width = _safe_service_info(info, 'sVideoWidth')
            height = _safe_service_info(info, 'sVideoHeight')
            seek = service and service.seek()
            pos = seek and seek.getPlayPosition()
            position = pos[1] if pos and (not pos[0]) else None
            advancing = position is not None and self.last_position is not None and (position > self.last_position)
            self.last_position = position
            current = is_current(self.session, self.expected_reference)
            if current and advancing:
                self.progress_ticks += 1
                self.last_progress_at = time.time()
            elif not current:
                self.progress_ticks = 0
            if self.ready_at is None and current and width and height and self.video_signal and (self.progress_ticks >= 2):
                self.ready_at = time.time()
                _preview_log('decoder progress confirmed')
            if not current:
                self.ready_at = None
                for key, text in (('quality', 'Video: --'), ('event', 'Event: --'), ('event_time', ''), ('video_rate', 'V: N/A'), ('audio_rate', 'A: N/A')):
                    try:
                        self[key].setText(text)
                    except Exception:
                        pass
                try:
                    self['flow'].setValue(0)
                except Exception:
                    pass
        except Exception:
            pass
        if self.failure:
            status = self.failure
        elif self.ready_at is not None and self.last_progress_at and (time.time() - self.last_progress_at < 8):
            status = u'المشغّل يتقدم في البث — زمن الاتصال %.1f ثانية' % (self.ready_at - self.started_at)
        elif self.ready_at is not None:
            status = u'توقف تقدم المشغّل — جاري التخزين أو تعذر فك الفيديو'
        elif self.video_signal:
            status = u'وصلت بيانات فيديو؛ لم يتأكد تقدم التشغيل بعد'
        elif elapsed >= 25:
            status = u'لم يبدأ الفيديو بعد %.0f ثانية — جرّب رابطاً آخر' % elapsed
        else:
            status = u'جاري الاتصال وتجهيز الفيديو: %.0f ثانية' % elapsed
        self['network'].setText(status)
        self._set_network_colour('red' if self.failure or (self.ready_at is None and elapsed >= 25) else 'green' if self.ready_at is not None and self.last_progress_at and (time.time() - self.last_progress_at < 8) else 'orange')
        self['hint'].setText(u'OK مرة ثانية / INFO: ملء الشاشة')

class Preview(object):

    def __init__(self,owner):
        self._fullscreen_active=False
        self._urls=[];self._url_index=0;self._advance_pending=False
        self._types=[];self._type_index=0;self._learned_key=None;self._force_release=False;self._rx_mark=0;self._reconnects=0
        from enigma import eTimer
        self._attempt_timer=eTimer()
        try:self._attempt_connection=self._attempt_timer.timeout.connect(self._check_attempt)
        except Exception:self._attempt_timer.callback.append(self._check_attempt)
        self._switch_timer=None;self._switch_connection=None;self._switch_pending=False
        self.owner=owner;self.dialog=None;self.reference=None;self.previous=owner.session.nav.getCurrentlyPlayingServiceReference();self.full_call=None;self.dead=False;self.selection=None;self.keep_playing=False
        state=getattr(owner.session,'_alkuds_list_playback',None)
        if state and is_current(owner.session,state['reference']):self.previous=state['previous']
        owner.onHide.append(self.hide);owner.onShown.append(self.show);owner.onClose.append(self.close)
        from Components.ServiceEventTracker import ServiceEventTracker
        from enigma import iPlayableService
        events={}
        for key,callback in (('evVideoFramerateChanged',self.video_updated),('evVideoSizeChanged',self.video_updated),('evTuneFailed',self.failed),('evEOF',self.failed)):
            event=getattr(iPlayableService,key,None)
            if event is not None:events[event]=callback
        self.tracker=ServiceEventTracker(screen=owner,eventmap=events)
        owner['_list_preview_actions']=ActionMap(['InfobarEPGActions','OkCancelActions'],{'showEventInfo':self.fullscreen,'ok':self.second_ok},-10)
        if getattr(owner,'execing',False):owner['_list_preview_actions'].execBegin()

    def second_ok(self):
        if self._fullscreen_active or self._switch_pending:
            return 0
        if self.full_call and self.selection is not None and (self.selection == selection_key(self.owner)) and is_current(self.owner.session, self.reference):
            self.fullscreen()
            return 1
        return 0

    def change_player(self, service_type):
        # Manual switching was removed; players are chosen automatically.
        return False

    def video_updated(self):
        if self.dialog and (not self._switch_pending) and is_current(self.owner.session, self.reference):
            self.dialog.video_signal = True
            _preview_log('current-service video event')
            self._learn_ok()

    def failed(self):
        if self.dead or self._fullscreen_active or self._switch_pending or not self.dialog:return
        current=self.owner.session.nav.getCurrentlyPlayingServiceReference()
        if current and not is_current(self.owner.session,self.reference):return
        self.dialog.failure=u'فشل الاتصال بالمشغّل'
        if self._advance_pending:return
        self._advance_pending=True
        # Never nest playService inside its own service-event callback.
        self._attempt_timer.start(1,True)

    def show(self):
        if self.dialog and (not self.dead) and (not self._fullscreen_active):
            self.dialog.show_for()

    def hide(self):
        if self.dialog:
            self.dialog.hide()

    def close(self):
        if self.dead:return
        self._attempt_timer.stop()
        self._advance_pending=False
        pending=self._switch_pending
        self._cancel_switch()
        if pending:
            # Leaving during the short decoder release must not tune later.
            if not self.owner.session.nav.getCurrentlyPlayingServiceReference():
                if self.previous:self.owner.session.nav.playService(self.previous)
            state=getattr(self.owner.session,'_alkuds_list_playback',None)
            if state and state.get('reference') is self.reference:self.owner.session._alkuds_list_playback=None
        if self.keep_playing and self.reference and is_current(self.owner.session,self.reference):
            remember(self)
            self.dead=True
            if self.dialog:destroy_stream_info_dialog(self.owner.session,self.dialog);self.dialog=None
            return
        self.dead=True
        if self.dialog:destroy_stream_info_dialog(self.owner.session,self.dialog);self.dialog=None
        try:
            current=self.owner.session.nav.getCurrentlyPlayingServiceReference()
            if self.reference and current and current.toString()==self.reference.toString():
                if restore_cinehd_channel(self.owner.session,self.previous):return
                if self.previous:self.owner.session.nav.playService(self.previous)
                else:self.owner.session.nav.stopService()
        except Exception:pass

    def _cancel_switch(self):
        if self._switch_timer:
            try:
                self._switch_timer.stop()
            except Exception:
                pass
        self._switch_pending = False

    def _tune(self,reference):
        if self.dead or self.reference is not reference:return
        self._switch_pending=False
        _preview_log('tune service-type=%s'%reference_type(reference))
        try:
            nav=self.owner.session.nav
            try:result=nav.playService(reference,forceRestart=True)
            except TypeError:result=nav.playService(reference)
            _preview_log('nav accepted=%s current-reference=%s'%(result is not False,is_current(self.owner.session,reference)))
            if result is False or (type(result) is type(0) and result!=0):self.failed()
            elif not self._advance_pending:self._attempt_timer.start(1000,True)
            preview_video(self.owner,True)
            if self.keep_playing:remember(self)
        except Exception as e:
            self.failed()
            _preview_log('tune error='+type(e).__name__)

    def start(self,urls,stype,name,play=True,_retry=False):
        unique=[]
        for url in urls:
            if url not in unique:unique.append(url)
        urls=unique
        if not urls:raise ValueError('No playable stream URL')
        if not _retry:
            self._urls=urls;self._url_index=0;self._learned_key=None;self._reconnects=0
            if play:
                try:
                    self._types=self._order_for(urls[0],stype);self._type_index=0
                    stype=self._types[0]
                except Exception:pass
        self._attempt_timer.stop()
        self._advance_pending=False
        self.name=str(name)
        rect=geometry(self.owner.skin)
        reference=service_reference(int(stype),0,str(urls[0]));reference.setName(gui_text(name))
        same=self.reference and self.reference.toString()==reference.toString() and not (self.dialog and self.dialog.failure)
        if not self.dialog:
            self.dialog=self.owner.session.instantiateDialog(ListInfo,rect)
            self.dialog.set_context(name,stype,str(urls[0]))
        if not same:
            _preview_log('new preview play=%s service-type=%s'%(play,stype),reset=True)
            self.dialog.started_at=time.time();self.dialog.ready_at=None;self.dialog.failure='';self.dialog.last_position=None;self.dialog.video_signal=False;self.dialog.progress_ticks=0;self.dialog.last_progress_at=None
            self.dialog.hide()
            self.dialog.set_context(name,stype,str(urls[0]))
            self._cancel_switch()
            self.reference=reference
            self.dialog.expected_reference=reference
            try:
                from .playerbrain import rx_bytes
                self._rx_mark=rx_bytes()
            except Exception:pass
            if play:
                try:
                    from .backgroundaudio import prepare_foreground_playback
                    prepare_foreground_playback()
                    # FreeTV switching releases the old native video decoder before the
                    # new ExtePlayer instance opens it. Fullscreen adoption never tunes.
                    free=self.full_call and self.full_call[1].__name__=='Alkuds_FreeTV_Player'
                    release=free or self._force_release
                    self._force_release=False
                    if release and self.owner.session.nav.getCurrentlyPlayingServiceReference():
                        self._switch_pending=True
                        _preview_log('release previous decoder; deferred start 250ms')
                        self.owner.session.nav.stopService()
                        from enigma import eTimer
                        timer=eTimer();self._switch_timer=timer
                        callback=lambda:self._tune(reference)
                        try:self._switch_connection=timer.timeout.connect(callback)
                        except Exception:timer.callback.append(callback)
                        timer.start(250,True)
                    else:self._tune(reference)
                except Exception as e:
                    self.failed()
                    _preview_log('preview start error='+type(e).__name__)
        elif play:
            self._attempt_timer.start(1000,True)
        self.owner.show();self.show()
        self.selection=selection_key(self.owner)
        if self.keep_playing:remember(self)
        return True

    def fullscreen(self):
        if not self.full_call or self._fullscreen_active:return
        if self._switch_pending:return
        self._attempt_timer.stop()
        self._advance_pending=False
        self._fullscreen_active=True
        self.owner['_list_preview_actions'].setEnabled(False)
        try:
            return self._fullscreen()
        except Exception as error:
            self._fullscreen_active=False
            self.owner['_list_preview_actions'].setEnabled(True)
            preview_video(self.owner, True)
            self.show()
            from Screens.MessageBox import MessageBox
            self.owner.session.open(MessageBox, u'تعذر فتح ملء الشاشة: ' + str(error), MessageBox.TYPE_ERROR, timeout=10)

    def _fullscreen(self):
        if not self.full_call:return
        callback,player,args,kwargs=self.full_call
        if player.__name__=='Alkuds_FreeTV_Player':
            # Transfer ownership of the already playing service, never resolve/tune again.
            reuse=not bool(self.dialog and self.dialog.failure)
            kwargs=dict(kwargs,reuse_service=reuse,keep_playing_on_back=self.keep_playing,fullscreen_retune=reuse)
            urls=[self.reference.getPath()]+[url for url in self._urls[self._url_index+1:] if url!=self.reference.getPath()]
            args=(urls, reference_type(self.reference))+tuple(args[2:])
        self.hide()
        preview_video(self.owner, False)
        def done(*values):
            self._fullscreen_active=False
            if player.__name__=='Alkuds_FreeTV_Player' and not self.dead:
                current=self.owner.session.nav.getCurrentlyPlayingServiceReference()
                if current and current.getPath() in self._urls:
                    self.reference=current
                    self._url_index=self._urls.index(current.getPath())
                    if self.dialog:
                        self.dialog.expected_reference=current
                        self.dialog.failure=''
                        if self.dialog.ready_at is None:self.dialog.started_at=time.time()
            if not self.dead:self.owner['_list_preview_actions'].setEnabled(True)
            preview_video(self.owner, True)
            result=values[0] if values else None
            action=result[0] if isinstance(result,(tuple,list)) and result else result
            if callback and (player.__name__!='Alkuds_FreeTV_Player' or action in ('next','prev','failed','stopped')):callback(*values)
            if not self.dead:
                self.show()
                if is_current(self.owner.session,self.reference):self._attempt_timer.start(1000,True)
                if self.keep_playing:remember(self)
        self.owner.session.openWithCallback(done,player,*args,**kwargs)

    def _cat(self):
        try:
            callback,player,args,kwargs=self.full_call
            name=player.__name__
            if name=='Alkuds_FreeTV_Player':
                text=str(args[3] if len(args)>3 else 'Live').lower()
                return 'live' if text.startswith('live') or text.startswith('radio') else 'vod'
            if name in ('Alkuds_VodPlayer','Alkuds_CatchupPlayer'):return 'vod'
        except Exception:pass
        return 'live'
    def _order_for(self,url,default):
        from .playerbrain import order
        return list(order(self._cat(),url,default=default))[:3]
    def _learn_ok(self):
        if not self.reference or not self.dialog:return
        key=(self.reference.getPath(),reference_type(self.reference))
        if self._learned_key==key:return
        self._learned_key=key
        try:
            from .playerbrain import learn_ok
            learn_ok(self._cat(),key[0],key[1],max(0.1,time.time()-self.dialog.started_at))
        except Exception:pass
    def _learn_fail(self):
        if not self.reference:return
        try:
            from .playerbrain import learn_fail
            learn_fail(self._cat(),self.reference.getPath(),reference_type(self.reference))
        except Exception:pass
    def _check_attempt(self):
        if self.dead or self._fullscreen_active or self._switch_pending or not self.dialog:return
        current=self.owner.session.nav.getCurrentlyPlayingServiceReference()
        if current and not is_current(self.owner.session,self.reference):return
        if not self._advance_pending:
            if self.dialog.ready_at is not None or self.dialog.video_signal:
                self._learn_ok();return
            elapsed=time.time()-self.dialog.started_at
            try:
                from .playerbrain import rx_bytes
                flowing=rx_bytes()-self._rx_mark>=65536
            except Exception:flowing=False
            limit=10 if self._cat()=='live' else 16
            if flowing:limit=40
            if elapsed<limit:
                self._attempt_timer.start(1000,True)
                return
        self._advance_pending=False
        if (self.dialog.ready_at is not None or self.dialog.video_signal) and self._reconnects<2:
            # The stream was working and then dropped: reconnect it, do not
            # blame the player or switch to another one.
            self._reconnects+=1
            self._force_release=True
            _preview_log('reconnecting dropped stream')
            self.start([self._urls[self._url_index]],reference_type(self.reference),self.name,_retry=True)
            return
        self._learn_fail()
        self._advance_attempt()
    def _advance_attempt(self):
        if self.dead or not self.dialog:return
        url=self._urls[self._url_index]
        if self._type_index+1<len(self._types):
            self._type_index+=1
            service_type=self._types[self._type_index]
            _preview_log('trying player %s for current stream'%service_type)
            self._force_release=True
            self.start([url],service_type,self.name,_retry=True)
            return
        if self._url_index+1<len(self._urls):
            self._url_index+=1
            url=self._urls[self._url_index]
            try:self._types=self._order_for(url,reference_type(self.reference))
            except Exception:self._types=[reference_type(self.reference)]
            self._type_index=0
            _preview_log('trying alternative %d/%d'%(self._url_index+1,len(self._urls)))
            self._force_release=True
            self.start([url],self._types[0],self.name,_retry=True)
            return
        self.dialog.failure=u'تعذر تشغيل الروابط المتاحة؛ راجع حالة المصدر'
        _preview_log('all supplied stream URLs failed')

def preview(owner, urls, stype, name, play=True):
    controller = getattr(owner, '_list_preview', None)
    if controller is None:
        controller = Preview(owner)
        owner._list_preview = controller
    return controller.start(urls, stype, name, play)

def open_list_player(owner, callback, player, *args, **kwargs):
    if kwargs.get('radio'):
        return owner.session.openWithCallback(callback, player, *args, **kwargs) if callback else owner.session.open(player, *args, **kwargs)
    urls = args[0] if isinstance(args[0], (tuple, list)) else [args[0]]
    name = args[2] if player.__name__ == 'Alkuds_FreeTV_Player' and len(args) > 2 else getattr(owner, 'name', '')
    if not name:
        try:
            name = owner['main_list'].getCurrent()[0]
        except Exception:
            name = 'Video'
    try:
        controller = getattr(owner, '_list_preview', None)
        if controller and controller.second_ok():
            return controller
        if controller is None:
            controller = Preview(owner)
            owner._list_preview = controller
        controller.keep_playing = player.__name__ == 'Alkuds_FreeTV_Player' and ET.fromstring(owner.skin).get('name') == 'AlkudsFreeTVList'
        controller.full_call = (callback, player, args, kwargs)
        preview(owner, urls, args[1], name)
        controller.full_call = (callback, player, args, kwargs)
        if controller.keep_playing:
            remember(controller)
        return owner._list_preview
    except Exception as e:
        from .xStaticText import MessageBox
        owner.session.open(MessageBox, u'تعذر بدء المعاينة: ' + str(e), MessageBox.TYPE_ERROR, timeout=6)
        return None

def unmask_preview(skin):
    try:
        root = ET.fromstring(skin)
        pig = next((n for n in root.iter('widget') if n.get('render') == 'Pig'))
        w, h = [int(v) for v in pig.get('size').split(',')]
        for n in list(root):
            if n.tag == 'eLabel' and n.get('position') == pig.get('position'):
                nw, nh = [int(v) for v in n.get('size', '0,0').split(',')]
                if nw >= w * 0.9 and nh >= h * 0.9:
                    root.remove(n)
        return ET.tostring(root, encoding='unicode')
    except Exception:
        return skin

def is_current(session, reference):
    try:
        current = session.nav.getCurrentlyPlayingServiceReference()
        return bool(reference and current and (reference.toString() == current.toString()))
    except Exception:
        return False

def selection_key(owner):
    try:
        try:
            listing = owner['main_list']
        except (KeyError, TypeError):
            listing = owner['list']
        row = listing.getCurrent()
        return (listing.getIndex(), str(row[0])) if row else None
    except Exception:
        return None

def remember(controller):
    controller.owner.session._alkuds_list_playback = {'reference': controller.reference, 'previous': controller.previous, 'full_call': controller.full_call, 'name': getattr(controller, 'name', 'Video'), 'started_at': controller.dialog.started_at if controller.dialog else time.time(), 'ready_at': controller.dialog.ready_at if controller.dialog else None}

def attach_list_preview(owner):
    state = getattr(owner.session, '_alkuds_list_playback', None)
    if not state or not is_current(owner.session, state['reference']):
        return
    controller = getattr(owner, '_list_preview', None)
    if controller and (not controller.dead) and controller.reference and (controller.reference.toString() == state['reference'].toString()):
        controller.show()
        return
    if controller is None or controller.dead:
        controller = Preview(owner)
        owner._list_preview = controller
    controller.keep_playing = True
    callback, player, args, kwargs = state['full_call']
    controller.full_call = (None, player, args, kwargs)
    controller.start([state['reference'].getPath()], reference_type(state['reference']), state.get('name') or (args[2] if player.__name__ == 'Alkuds_FreeTV_Player' else 'Video'), play=False)
    controller.selection = None
    controller.dialog.started_at = state['started_at']
    controller.dialog.ready_at = state['ready_at']
    remember(controller)

def stop_list_playback(session):
    state = getattr(session, '_alkuds_list_playback', None)
    session._alkuds_list_playback = None
    if state and is_current(session, state['reference']):
        if restore_cinehd_channel(session, state['previous']):
            return
        if state['previous']:
            session.nav.playService(state['previous'])
        else:
            session.nav.stopService()

def preview_video(owner, visible):
    for renderer in getattr(owner, 'renderer', []):
        if renderer.__class__.__name__ != 'Pig':
            continue
        instance = getattr(renderer, 'instance', None)
        if instance is None:
            continue
        try:
            if visible:
                instance.show()
                renderer.onShow()
            else:
                instance.hide()
                instance.restoreFullsize()
        except Exception:
            pass

def install_fullscreen_video(player):
    """Reset the native decoder after the preview's hide/show cycle finishes."""
    from enigma import eTimer
    from .freeplayer import _player_skin
    player.skin = _player_skin(False)
    timer = eTimer()

    def reset():
        if getattr(player, '_closed', False):
            return
        for renderer in getattr(player, 'renderer', []):
            if renderer.__class__.__name__ == 'Pig' and getattr(renderer, 'instance', None):
                restore = getattr(renderer.instance, 'restoreFullsize', None)
                if callable(restore):
                    try:
                        restore()
                    except Exception:
                        pass
                else:
                    try:
                        from enigma import getDesktop, ePoint
                        renderer.instance.resize(getDesktop(0).size())
                        renderer.instance.move(ePoint(0, 0))
                    except Exception:
                        pass
    try:
        player._fullscreen_video_conn = timer.timeout.connect(reset)
    except Exception:
        timer.callback.append(reset)
    player._fullscreen_video_timer = timer
    player.onShown.append(lambda: timer.start(100, True))
    player.onHide.append(timer.stop)
    player.onClose.append(timer.stop)
