#!/usr/bin/python
# -*- coding: utf-8 -*-

"""External configuration for optional third-party providers.

The Original TV / Reezn entries in the plugin talk to a service that requires
a provider-issued endpoint and signing key.  Those values belong to the
provider, can change at any time, and must never be a reason to patch Python.

This module lets the receiver owner supply their own values in one small JSON
file.  A legitimate subscription therefore survives plugin upgrades, and a
provider that is no longer wanted can be switched off without touching code.

Search order (first existing file wins):

    $ALKUDS_PROVIDERS_CONFIG
    /etc/enigma2/alkuds/providers.json
    /media/hdd/alkuds/providers.json
    /media/usb/alkuds/providers.json
    /media/mmc/alkuds/providers.json
    /media/cf/alkuds/providers.json

Every field is optional.  Missing fields fall back to the values that shipped
with the plugin, so an absent file keeps the current behaviour.
"""

from __future__ import absolute_import, division, print_function

import binascii
import io
import json
import os
import re
import threading

try:
    string_types = (basestring,)
except NameError:
    string_types = (str,)

SEARCH_PATHS = (
    '/etc/enigma2/alkuds/providers.json',
    '/media/hdd/alkuds/providers.json',
    '/media/usb/alkuds/providers.json',
    '/media/mmc/alkuds/providers.json',
    '/media/cf/alkuds/providers.json',
)
ENVIRONMENT_VARIABLE = 'ALKUDS_PROVIDERS_CONFIG'

# Values that shipped inside the plugin.  They are only defaults: a file on
# the receiver always wins, and an owner who holds a legitimate subscription
# is expected to replace them with the values of that subscription.
DEFAULTS = {
    'original': {
        'enabled': True,
        'api': 'https://panel.originalpro.online/api.php',
        'home': 'https://panel.originalpro.online/',
        'key': 'cda11IxQWjX1bZP5Yfdhqm2B4NwzuLJGHE3RDCcsAn7rT9aVU0',
        'page_size': 100,
    },
    'reezn': {
        'enabled': True,
        'api': 'https://api.ott-topred.site/api/v3/',
        'sign_key': 'fb674c0686ec14c0fc271e93663ac7cc1189036a4ef57ab6444b7957cf63dc72f1a36b12dec96da4907740916ba36926fede34cde3f2a0785eb2c70996b4276b',
        'live_path': 'app/live/get_channels_db.php',
        'cache_ttl': 300,
    },
}

LABELS = {
    'original': u'مزوّد «اوريجينال تي في»',
    'reezn': u'مزوّد «ريزن» للبث المباشر',
}

_CACHE = {'stamp': None, 'path': '', 'data': None}
_LOCK = threading.Lock()


class ProviderConfigError(RuntimeError):
    """User-facing configuration error, always written in Arabic."""


def _text(value):
    if isinstance(value, string_types):
        if not isinstance(value, type(u'')):
            try:
                return value.decode('utf-8').strip()
            except Exception:
                return value.strip()
        return value.strip()
    if isinstance(value, bool):
        return u'true' if value else u'false'
    if value is None:
        return u''
    return u'%s' % (value,)


def _flag(value, default=True):
    if isinstance(value, bool):
        return value
    if isinstance(value, string_types):
        lowered = _text(value).lower()
        if lowered in ('1', 'true', 'yes', 'on', 'enabled'):
            return True
        if lowered in ('0', 'false', 'no', 'off', 'disabled'):
            return False
    if isinstance(value, int):
        return bool(value)
    return default


def _clamp(value, default, minimum, maximum):
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return max(minimum, min(maximum, number))


def _valid_url(value):
    text = _text(value)
    if not text:
        return False
    if not re.match(r'^https?://[^/\s]+', text, re.I):
        return False
    return True


def _origin(value):
    match = re.match(r'^(https?://[^/]+)/?', _text(value), re.I)
    return match.group(1) + '/' if match else ''


def _key_bytes(value):
    """Return (bytes, problem).  Hex keys are decoded, text keys are UTF-8."""
    text = _text(value)
    if not text:
        return b'', u'الحقل reezn.sign_key مطلوب'
    if len(text) >= 32 and len(text) % 2 == 0 and re.match(r'^[0-9a-fA-F]+$', text):
        try:
            return binascii.unhexlify(text.encode('ascii')), None
        except (binascii.Error, TypeError, ValueError):
            pass
    try:
        return text.encode('utf-8'), None
    except Exception:
        return b'', u'تعذّر تحويل reezn.sign_key إلى بايتات'


def config_path():
    override = _text(os.environ.get(ENVIRONMENT_VARIABLE))
    if override:
        return override
    for path in SEARCH_PATHS:
        try:
            if os.path.isfile(path):
                return path
        except Exception:
            continue
    return SEARCH_PATHS[0]


def _stamp(path):
    try:
        info = os.stat(path)
        return (path, info.st_mtime, info.st_size)
    except Exception:
        return (path, None, None)


def _read(path):
    if not path:
        return {}
    try:
        if not os.path.isfile(path):
            return {}
    except Exception:
        return {}
    try:
        with io.open(path, 'r', encoding='utf-8') as handle:
            text = handle.read()
    except Exception as error:
        raise ProviderConfigError(
            u'تعذّرت قراءة ملف إعدادات المزوّدين «%s»: %s' % (path, error))
    if not _text(text):
        return {}
    try:
        payload = json.loads(text)
    except ValueError as error:
        raise ProviderConfigError(
            u'ملف إعدادات المزوّدين «%s» غير صالح (JSON): %s' % (path, error))
    if not isinstance(payload, dict):
        raise ProviderConfigError(
            u'ملف إعدادات المزوّدين «%s» يجب أن يحتوي كائن JSON واحدًا.' % path)
    return payload


def _section(payload, name):
    value = payload.get(name)
    return value if isinstance(value, dict) else {}


def _merge(payload):
    merged = {}
    for name in DEFAULTS:
        user = _section(payload, name)
        section = dict(DEFAULTS[name])
        section.update(user)
        # A custom endpoint usually implies its own origin.  Do not leak the
        # shipped Referer into a different service when only `api` was given.
        if name == 'original' and 'api' in user and 'home' not in user:
            section['home'] = ''
        merged[name] = section
    return merged


def load(force=False):
    """Return the merged configuration; safe to call often (cached by mtime)."""
    path = config_path()
    stamp = _stamp(path)
    if (not force and _CACHE['data'] is not None and
            _CACHE['stamp'] == stamp and _CACHE['path'] == path):
        return _CACHE['data']
    with _LOCK:
        stamp = _stamp(path)
        if (not force and _CACHE['data'] is not None and
                _CACHE['stamp'] == stamp and _CACHE['path'] == path):
            return _CACHE['data']
        data = _merge(_read(path))
        _CACHE['stamp'] = stamp
        _CACHE['path'] = path
        _CACHE['data'] = data
        return data


def reset_cache():
    with _LOCK:
        _CACHE['stamp'] = None
        _CACHE['path'] = ''
        _CACHE['data'] = None


def _normalise_original(values):
    problems = []
    api = _text(values.get('api'))
    if not _valid_url(api):
        problems.append(u'الحقل original.api يجب أن يكون رابطًا يبدأ بـ http:// أو https://')
    home = _text(values.get('home')) or _origin(api)
    if home and not _valid_url(home):
        problems.append(u'الحقل original.home يجب أن يكون رابطًا يبدأ بـ http:// أو https://')
    key = _text(values.get('key'))
    if not key:
        problems.append(u'الحقل original.key مطلوب')
    return {
        'enabled': _flag(values.get('enabled'), True),
        'api': api,
        'home': home,
        'key': key,
        'page_size': _clamp(values.get('page_size'), 100, 1, 500),
        'problems': problems,
    }


def _normalise_reezn(values):
    problems = []
    api = _text(values.get('api'))
    if not _valid_url(api):
        problems.append(u'الحقل reezn.api يجب أن يكون رابطًا يبدأ بـ http:// أو https://')
    if api and not api.endswith('/'):
        api += '/'
    key, key_problem = _key_bytes(values.get('sign_key'))
    if key_problem:
        problems.append(key_problem)
    live_path = _text(values.get('live_path')).lstrip('/')
    if not live_path:
        problems.append(u'الحقل reezn.live_path مطلوب')
    return {
        'enabled': _flag(values.get('enabled'), True),
        'api': api,
        'sign_key': key,
        'live_path': live_path,
        'cache_ttl': _clamp(values.get('cache_ttl'), 300, 0, 86400),
        'problems': problems,
    }


_NORMALISERS = {
    'original': _normalise_original,
    'reezn': _normalise_reezn,
}


def get(section, force=False):
    name = _text(section).lower()
    normaliser = _NORMALISERS.get(name)
    if normaliser is None:
        raise ProviderConfigError(u'قسم إعدادات غير معروف: %s' % _text(section))
    return normaliser(load(force=force)[name])


def require(section):
    """Return validated settings or raise a clear Arabic explanation."""
    name = _text(section).lower()
    settings = get(name)
    label = LABELS.get(name, u'المزوّد')
    path = config_path()
    if not settings['enabled']:
        raise ProviderConfigError(
            u'%s مُعطَّل في إعدادات البلجن (%s).' % (label, path))
    problems = list(settings.get('problems') or [])
    if problems:
        raise ProviderConfigError(
            u'%s غير مُهيّأ:\n- %s\nالملف: %s' %
            (label, u'\n- '.join(problems), path))
    return settings


def describe():
    """Diagnostics for logs and tests; never raises."""
    path = config_path()
    try:
        exists = os.path.isfile(path)
    except Exception:
        exists = False
    providers = []
    for name in ('original', 'reezn'):
        try:
            settings = get(name)
            problems = list(settings.get('problems') or [])
            providers.append({
                'name': name,
                'enabled': bool(settings.get('enabled')),
                'ready': bool(settings.get('enabled')) and not problems,
                'api': settings.get('api') or '',
                'problems': problems,
            })
        except Exception as error:
            providers.append({
                'name': name,
                'enabled': False,
                'ready': False,
                'api': '',
                'problems': [u'%s' % (error,)],
            })
    return {'path': path, 'exists': exists, 'providers': providers}
