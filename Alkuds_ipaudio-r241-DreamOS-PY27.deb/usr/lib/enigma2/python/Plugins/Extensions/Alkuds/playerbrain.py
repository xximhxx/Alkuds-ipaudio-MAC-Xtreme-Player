# -*- coding: utf-8 -*-
"""Automatic player selection with per-site memory (ExtePlayer3 / GStreamer / native).

The plugin no longer asks the user to switch players.  For every site (host)
and kind of content (live / vod) it remembers which player really produced
video and how fast, tries the best known player first, and only falls back to
another player when the first one has clearly failed.  Only the host name and
the player type are stored - never a full URL, token or credential.

Works unchanged on Python 2.7 (DreamOS) and Python 3 (OpenATV/OpenPLi/...).
"""

from __future__ import absolute_import, division, print_function

import json
import os
import re
import time

STORE = "/etc/enigma2/alkuds/player_brain.json"
KNOWN = (5002, 5001, 4097, 8193)
MAX_HOSTS = 300
STALE_FAIL_SECONDS = 3 * 24 * 3600      # a failure is forgotten after 3 days
SLOW_MS = 8000                          # a player slower than this may be re-tested
_CACHE = {"mtime": None, "data": None}


# ---------------------------------------------------------------- helpers
def _s(value):
    """Text of any value; safe for Python 2 unicode with non-ASCII characters."""
    try:
        return str(value or "")
    except Exception:
        try:
            return value.encode("utf-8")
        except Exception:
            return ""


def _category(value):
    text = (_s(value) or "live").strip().lower()
    if text.startswith(("movie", "film", "vod", "cinema", "series", "episode", "season", "catch")):
        return "vod"
    return "live"


def host_key(url):
    """Family name of the host: 'cdn3.example.com:8080' -> 'example.com'."""
    try:
        text = _s(url).strip()
        if "://" not in text:
            return ""
        rest = text.split("://", 1)[1]
        host = rest.split("/", 1)[0].split("?", 1)[0].split("#", 1)[0]
        host = host.split("@")[-1].split(":")[0].strip().lower()
        if not host:
            return ""
        if re.match(r"^\d+\.\d+\.\d+\.\d+$", host):
            return host
        labels = [part for part in host.split(".") if part]
        if len(labels) <= 2:
            return ".".join(labels)
        if len(labels[-1]) == 2 and labels[-2] in ("co", "com", "net", "org", "gov", "edu"):
            return ".".join(labels[-3:])
        return ".".join(labels[-2:])
    except Exception:
        return ""


def stream_kind(url):
    try:
        text = _s(url).lower().split("#", 1)[0].split("|", 1)[0].split("?", 1)[0]
        extension = os.path.splitext(text)[1]
    except Exception:
        extension = ""
    if extension in (".m3u8", ".m3u"):
        return "hls"
    if extension in (".mp4", ".mkv", ".avi", ".mov", ".webm", ".flv", ".m4v"):
        return "file"
    if extension in (".ts", ".m2ts", ".mts"):
        return "ts"
    return "other"


def rx_bytes():
    """Total received bytes on all non-loopback interfaces (cheap activity probe)."""
    total = 0
    try:
        with open("/proc/net/dev", "r") as handle:
            for line in handle:
                if ":" not in line:
                    continue
                name, values = line.split(":", 1)
                if name.strip() == "lo":
                    continue
                fields = values.split()
                if fields:
                    total += int(fields[0])
    except Exception:
        pass
    return total


def available_types():
    """Players that exist on this image (never DVB '1')."""
    values = []
    try:
        from .receivercompat import available_free_service_types
        values = [int(v) for v in available_free_service_types()]
    except Exception:
        values = [4097]
    if os.path.exists("/usr/bin/apt-get") and 8193 not in values:
        values.append(8193)
    return [v for v in values if v in KNOWN] or [4097]


# ---------------------------------------------------------------- storage
def _load():
    try:
        mtime = os.path.getmtime(STORE)
    except Exception:
        mtime = None
    if _CACHE["data"] is not None and _CACHE["mtime"] == mtime:
        return _CACHE["data"]
    data = {}
    if mtime is not None:
        try:
            with open(STORE, "r") as handle:
                data = json.load(handle)
        except Exception:
            data = {}
    if not isinstance(data, dict):
        data = {}
    if not isinstance(data.get("sites"), dict):
        data["sites"] = {}
    _CACHE["data"] = data
    _CACHE["mtime"] = mtime
    return data


def _save(data):
    try:
        sites = data.get("sites") or {}
        if len(sites) > MAX_HOSTS:
            ordered = sorted(sites.items(), key=lambda pair: pair[1].get("ts", 0))
            data["sites"] = dict(ordered[-MAX_HOSTS:])
        folder = os.path.dirname(STORE)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = STORE + ".tmp"
        with open(temporary, "w") as handle:
            json.dump(data, handle)
        os.rename(temporary, STORE)
        _CACHE["data"] = data
        try:
            _CACHE["mtime"] = os.path.getmtime(STORE)
        except Exception:
            _CACHE["mtime"] = None
    except Exception:
        pass


def _site(data, url, category, create=False):
    key = "%s|%s" % (host_key(url) or "?", _category(category))
    sites = data["sites"]
    if key not in sites and create:
        sites[key] = {"ts": 0, "p": {}}
    return sites.get(key), key


def _entry_state(entry, now):
    """Return (usable, score) - lower score is better."""
    ok = int(entry.get("ok", 0))
    fail = int(entry.get("fail", 0))
    last_fail = float(entry.get("lf", 0))
    if fail and now - last_fail > STALE_FAIL_SECONDS:
        fail = 0
    if fail >= 2 and fail >= ok:
        return False, 10 ** 9 + fail
    ms = float(entry.get("ms", 0)) if ok else 0
    return True, ms + fail * 4000


# ---------------------------------------------------------------- decisions
def order(category, url, default=None, available=None):
    """Players to try for this stream, best first."""
    category = _category(category)
    types = [t for t in (available or available_types()) if t in KNOWN]
    if not types:
        types = [4097]
    try:
        default = int(default) if default is not None else None
    except Exception:
        default = None
    if default not in types:
        default = None
    kind = stream_kind(url)
    if kind == "file":
        heuristic = [5002, 5001, 4097, 8193]
    elif kind == "ts":
        heuristic = [5002, 4097, 5001, 8193]
    else:
        heuristic = [5002, 4097, 5001, 8193]
    base = []
    if default is not None:
        base.append(default)
    for value in heuristic:
        if value in types and value not in base:
            base.append(value)
    for value in types:
        if value not in base:
            base.append(value)
    try:
        data = _load()
        site, _key = _site(data, url, category)
    except Exception:
        site = None
    if not site or not site.get("p"):
        return base
    now = time.time()
    proven, untested, bad = [], [], []
    for value in base:
        entry = site["p"].get(str(value))
        if not entry:
            untested.append(value)
            continue
        usable, score = _entry_state(entry, now)
        if not usable:
            bad.append((score, value))
        elif int(entry.get("ok", 0)) > 0:
            proven.append((score, value))
        else:
            untested.append(value)
    proven.sort()
    bad.sort()
    result = [value for _score, value in proven]
    # A working but slow player gets one chance to be beaten by an untested one.
    if result and untested:
        best_entry = site["p"].get(str(result[0])) or {}
        if float(best_entry.get("ms", 0)) > SLOW_MS:
            result.insert(0, untested.pop(0))
    result.extend(untested)
    result.extend(value for _score, value in bad)
    return result or base


def pick(category, url, default=None, available=None):
    return order(category, url, default, available)[0]


def learn_ok(category, url, service_type, seconds):
    try:
        service_type = int(service_type)
        if service_type not in KNOWN:
            return
        data = _load()
        site, _key = _site(data, url, category, create=True)
        now = time.time()
        ms = max(0.0, float(seconds)) * 1000.0
        entry = site["p"].setdefault(str(service_type), {"ok": 0, "fail": 0, "ms": 0, "lf": 0})
        previous = int(entry.get("ok", 0))
        entry["ms"] = int(ms if not previous else (entry.get("ms", ms) * 0.6 + ms * 0.4))
        entry["ok"] = min(previous + 1, 50)
        entry["fail"] = 0
        site["ts"] = now
        _save(data)
    except Exception:
        pass


def learn_fail(category, url, service_type):
    try:
        service_type = int(service_type)
        if service_type not in KNOWN:
            return
        data = _load()
        site, _key = _site(data, url, category, create=True)
        now = time.time()
        entry = site["p"].setdefault(str(service_type), {"ok": 0, "fail": 0, "ms": 0, "lf": 0})
        entry["fail"] = min(int(entry.get("fail", 0)) + 1, 20)
        entry["lf"] = now
        site["ts"] = now
        _save(data)
    except Exception:
        pass


def reset():
    try:
        os.unlink(STORE)
    except Exception:
        pass
    _CACHE["data"] = None
    _CACHE["mtime"] = None


def summary():
    """Short human readable list for the settings screen."""
    lines = []
    try:
        data = _load()
        rows = sorted(data["sites"].items(), key=lambda pair: -pair[1].get("ts", 0))
        for key, site in rows[:12]:
            proven = []
            for value, entry in site.get("p", {}).items():
                if int(entry.get("ok", 0)) > 0:
                    proven.append((float(entry.get("ms", 0)), value))
            proven.sort()
            if proven:
                lines.append("%s -> %s (%.1fs)" % (key, proven[0][1], proven[0][0] / 1000.0))
    except Exception:
        pass
    return lines


# ---------------------------------------------------------------- watchdog
class PlayWatch(object):
    """Confirms that a started stream really shows video; otherwise replays it
    with the next best player.  The caller supplies replay(service_type) which
    must stop the current service and start the same URL with that player."""

    LIVE_LIMIT = 10      # seconds without video and without incoming data
    VOD_LIMIT = 16
    HARD_LIMIT = 45      # data is flowing but no picture yet
    MAX_FALLBACKS = 2

    def __init__(self, session, replay, category="live"):
        self.session = session
        self.replay = replay
        self.category = _category(category)
        self.url = ""
        self.type = None
        self.candidates = []
        self.tried = []
        self.confirmed = False
        self.done = True
        self._timer = None
        self._conn = None
        self._started = 0.0
        self._last_rx = 0
        self._data_ticks = 0
        self._ready_ticks = 0
        self._moves = 0
        self._last_position = None
        self._missing = 0

    # -- control
    def begin(self, url, service_type, candidates=None, category=None):
        self.stop()
        if category:
            self.category = _category(category)
        self.url = str(url or "")
        self.type = int(service_type)
        self.candidates = list(candidates or order(self.category, self.url, self.type))
        self.tried = [self.type]
        self._restart_clock()
        self.confirmed = False
        self.done = False
        try:
            from enigma import eTimer
            self._timer = eTimer()
            try:
                self._conn = self._timer.timeout.connect(self._tick)
            except Exception:
                self._timer.callback.append(self._tick)
            self._timer.start(1000, False)
        except Exception:
            self.done = True

    def stop(self):
        self.done = True
        if self._timer is not None:
            try:
                self._timer.stop()
            except Exception:
                pass

    def _restart_clock(self):
        self._started = time.time()
        self._last_rx = rx_bytes()
        self._data_ticks = 0
        self._ready_ticks = 0
        self._missing = 0
        self._last_position = None
        self._moves = 0

    # -- probes
    def _video_size(self):
        try:
            from enigma import iServiceInformation
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if not info:
                return 0, 0
            return (max(0, int(info.getInfo(iServiceInformation.sVideoWidth))),
                    max(0, int(info.getInfo(iServiceInformation.sVideoHeight))))
        except Exception:
            return 0, 0

    def _position(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            result = seek and seek.getPlayPosition()
            if result and not result[0]:
                return int(result[1])
        except Exception:
            pass
        return None

    def _still_ours(self):
        """False when the user zapped to something else or closed the player."""
        try:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            return True
        if current is None:
            self._missing += 1
            return self._missing < 5
        self._missing = 0
        try:
            return int(str(current.toString()).split(":", 1)[0]) in KNOWN
        except Exception:
            return True

    def _tick(self):
        if self.done:
            return
        if not self._still_ours():
            self.stop()
            return
        now = time.time()
        elapsed = now - self._started
        width, height = self._video_size()
        self._ready_ticks = self._ready_ticks + 1 if (width and height) else 0
        position = self._position()
        if position is not None and self._last_position is not None and position > self._last_position:
            self._moves += 1
        self._last_position = position
        received = rx_bytes()
        if received - self._last_rx >= 8192:
            self._data_ticks += 1
        self._last_rx = received
        if self._ready_ticks >= 2 or self._moves >= 3 or (self._data_ticks >= 6 and elapsed >= 10):
            self.confirmed = True
            learn_ok(self.category, self.url, self.type, elapsed)
            self.stop()
            return
        limit = self.LIVE_LIMIT if self.category == "live" else self.VOD_LIMIT
        if self._data_ticks:
            limit = self.HARD_LIMIT
        if elapsed < limit:
            return
        learn_fail(self.category, self.url, self.type)
        following = [t for t in order(self.category, self.url, None, self.candidates) if t not in self.tried]
        if not following or len(self.tried) > self.MAX_FALLBACKS:
            self.stop()
            return
        self.type = following[0]
        self.tried.append(self.type)
        self._restart_clock()
        try:
            self.replay(self.type)
        except Exception:
            self.stop()


# -------------------------------------------------- helpers for old players
def choose_for_player(owner, category, url, requested):
    """Used by the Xtream/MAC player screens at the top of playStream().

    Returns the player type to use (same Python type as `requested`) and arms
    the fallback watchdog.  A request for DVB ('1') or an unknown type is left
    untouched.
    """
    try:
        forced = getattr(owner, "_brain_force", None)
        try:
            wanted = int(requested)
        except Exception:
            return requested
        if forced is None and wanted not in KNOWN:
            return requested
        if forced is not None:
            owner._brain_force = None
            chosen = int(forced)
            candidates = order(category, url, chosen)
        else:
            candidates = order(category, url, wanted)
            chosen = candidates[0]
        watch = getattr(owner, "_brain_watch", None)
        if watch is None:
            watch = PlayWatch(owner.session, lambda value: _replay(owner, value), category)
            owner._brain_watch = watch
            try:
                owner.onClose.append(watch.stop)
            except Exception:
                pass
        if forced is None:
            watch.begin(url, chosen, candidates, category)
        else:
            watch.type = chosen
        for attribute in ("servicetype", "service_type", "playing_service_type"):
            if hasattr(owner, attribute):
                try:
                    current = getattr(owner, attribute)
                    setattr(owner, attribute, str(chosen) if isinstance(current, str) else chosen)
                except Exception:
                    pass
        return type(requested)(chosen) if isinstance(requested, (str, int)) else chosen
    except Exception:
        return requested


def _replay(owner, service_type):
    owner._brain_force = int(service_type)
    try:
        owner.session.nav.stopService()
    except Exception:
        pass
    try:
        from enigma import eTimer
        timer = eTimer()
        owner._brain_replay_timer = timer

        def go():
            try:
                hook = getattr(owner, "_brain_replay", None)
                if hook is not None:
                    hook()
                else:
                    owner.playStream(owner.servicetype, owner.streamurl)
            except Exception:
                pass
        try:
            owner._brain_replay_conn = timer.timeout.connect(go)
        except Exception:
            timer.callback.append(go)
        timer.start(300, True)
    except Exception:
        pass
