# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Local playback preferences and lazily opened receiver settings menu."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import os
from .py2compat import re
PREFERENCES = '/etc/enigma2/alkuds/playback.json'
AUDIO_LABELS = {'auto': u'تلقائي — موصى به', 'alsa': u'ALSA مستقل — حاوية صوت محلية', 'pcm': u'PCM مستقل — GStreamer / ALSA', 'native': u'مخرج الصورة الأصلي — DVB'}

def load_preferences():
    result = {'audio_mode': 'auto', 'alsa_device': ''}
    try:
        with open(PREFERENCES, 'r') as stream:
            data = json.loads(stream.read(4097))
        if isinstance(data, dict):
            if data.get('audio_mode') in AUDIO_LABELS:
                result['audio_mode'] = data['audio_mode']
            value = data.get('alsa_device', '')
            if isinstance(value, str) and (not value or re.match('^[A-Za-z0-9_.,:=+/-]{1,96}$', value)):
                result['alsa_device'] = value
    except (OSError, ValueError, TypeError):
        pass
    return result

def save_preferences(audio_mode=None, alsa_device=None):
    values = load_preferences()
    if audio_mode is not None:
        if audio_mode not in AUDIO_LABELS:
            raise ValueError('Unsupported audio mode')
        values['audio_mode'] = audio_mode
    if alsa_device is not None:
        if not isinstance(alsa_device, str) or (alsa_device and (not re.match('^[A-Za-z0-9_.,:=+/-]{1,96}$', alsa_device))):
            raise ValueError('Invalid ALSA device')
        values['alsa_device'] = alsa_device
    parent = os.path.dirname(PREFERENCES)
    os.makedirs(parent, exist_ok=True)
    temp = PREFERENCES + '.tmp'
    try:
        with open(temp, 'w') as stream:
            json.dump(values, stream, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temp, 384)
        os.replace(temp, PREFERENCES)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return values
VISIBILITY_FILE = '/etc/enigma2/alkuds/audio_osd.json'

def load_audio_visibility():
    values = {'show_icon': True, 'show_name': True}
    try:
        with open(VISIBILITY_FILE, 'r') as stream:
            data = json.loads(stream.read(4097))
        if isinstance(data, dict):
            for key in values:
                if type(data.get(key)) is bool:
                    values[key] = data[key]
    except (OSError, ValueError, TypeError):
        pass
    return values

def save_audio_visibility(**changes):
    values = load_audio_visibility()
    for key, value in changes.items():
        if key not in values or type(value) is not bool:
            raise ValueError('Unsupported audio visibility option')
        values[key] = value
    os.makedirs(os.path.dirname(VISIBILITY_FILE), exist_ok=True)
    temp = VISIBILITY_FILE + '.tmp'
    try:
        with open(temp, 'w') as stream:
            json.dump(values, stream, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temp, 384)
        os.replace(temp, VISIBILITY_FILE)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return values

def probe_audio_options():
    """Read-only, bounded capability checks. Called on a worker, never the GUI."""
    from . import backgroundaudio as b
    from .receivercompat import is_octagon_egami
    tools = {name: bool(b._find_executable((name,))) for name in ('ffmpeg', 'gst-launch-1.0', 'gst-inspect-1.0', 'aplay', 'exteplayer3', 'gstplayer')}
    modes = ['auto']
    report = [name + ': ' + ('OK' if present else 'MISSING') for name, present in tools.items()]
    if tools['ffmpeg'] and tools['gst-launch-1.0']:
        ffmpeg = b._find_executable(('ffmpeg',))
        caps = b._ffmpeg_audio_capabilities(ffmpeg)
        raw = 's16le' in caps['muxers'] and 'pcm_s16le' in caps['encoders']
        ts = 'mpegts' in caps['muxers']
        mp2 = 'mp2' in caps['encoders']
        aac = 'aac' in caps['encoders']
        alsa = b._gst_has_element('alsasink')
        report += ['FFmpeg MP2: ' + str(mp2), 'FFmpeg AAC: ' + str(aac), 'FFmpeg raw PCM: ' + str(raw), 'ALSA sink: ' + str(alsa)]
        novaler = b._is_novaler_hisi_receiver()
        if alsa and (ts and mp2 or (not novaler and (raw or (ts and aac)))):
            modes.append('alsa')
        if not novaler and alsa and (raw and b._gst_has_element('rawaudioparse') or (ts and mp2)):
            modes.append('pcm')
        if is_octagon_egami() and ts and (mp2 or aac) and b._gst_has_element('dvbaudiosink'):
            modes.append('native')
    devices = b._alsa_playback_devices(ignore_preference=True) if tools['aplay'] else []
    devices = [value for value in devices if re.match('^[A-Za-z0-9_.,:=+/-]{1,96}$', value)]
    return {'modes': modes, 'devices': devices, 'report': '\n'.join(report)}

def _probe_dialog(session, callback):
    from .xStaticText import MessageBox
    from enigma import eTimer
    from .py2compat import threading

    class Probe(MessageBox):

        def __init__(self, session):
            MessageBox.__init__(self, session, u'جاري فحص أدوات الصوت والمشغّلات…\nيمكنك الضغط على EXIT للإلغاء.', type=MessageBox.TYPE_INFO, timeout=0)
            self.job = {'done': False, 'result': None}
            self.timer = eTimer()
            try:
                self.connection = self.timer.timeout.connect(self.poll)
            except AttributeError:
                self.timer.callback.append(self.poll)
            self.onClose.append(self.timer.stop)
            job = self.job

            def run():
                try:
                    job['result'] = probe_audio_options()
                except Exception as error:
                    job['result'] = {'error': str(error)}
                job['done'] = True
            worker = threading.Thread(target=run)
            worker.daemon = True
            worker.start()
            self.timer.start(150, False)

        def poll(self):
            if self.job['done']:
                self.timer.stop()
                self.close(self.job['result'])
    session.openWithCallback(callback, Probe)

def _run_probe(session, callback, func):
    """Run an arbitrary read-only probe on a worker thread and hand the result
    back to the GUI callback. Used for the r233 operation-assurance checks."""
    from .xStaticText import MessageBox
    from enigma import eTimer
    from .py2compat import threading

    class Probe(MessageBox):

        def __init__(self, session):
            MessageBox.__init__(self, session, u'جاري الفحص…\nيمكنك الضغط على EXIT للإلغاء.', type=MessageBox.TYPE_INFO, timeout=0)
            self.job = {'done': False, 'result': None}
            self.timer = eTimer()
            try:
                self.connection = self.timer.timeout.connect(self.poll)
            except AttributeError:
                self.timer.callback.append(self.poll)
            self.onClose.append(self.timer.stop)
            job = self.job

            def run():
                try:
                    job['result'] = func()
                except Exception as error:
                    job['result'] = {'error': str(error)}
                job['done'] = True
            worker = threading.Thread(target=run)
            worker.daemon = True
            worker.start()
            self.timer.start(150, False)

        def poll(self):
            if self.job['done']:
                self.timer.stop()
                self.close(self.job['result'])
    session.openWithCallback(callback, Probe)

def _probe_tsstorage():
    from .systemcheck import probe_timeshift_storage
    return probe_timeshift_storage()

def _probe_players():
    from .systemcheck import probe_players
    return probe_players()

def _probe_integrity():
    from .systemcheck import probe_plugin_integrity
    return probe_plugin_integrity()

class PlaybackMenu(object):

    def __init__(self, session):
        self.session = session

    def show(self, *args):
        from .xStaticText import ChoiceBox
        prefs = load_preferences()
        visibility = load_audio_visibility()
        rows = [(u'مسار الصوت: ' + AUDIO_LABELS[prefs['audio_mode']], 'audio'), (u'مخرج ALSA: ' + (prefs['alsa_device'] or u'تلقائي'), 'device'), (u'المشغّلات التلقائية الذكية (عرض وإعادة تعلّم)', 'video'), (u'إظهار أيقونة الصوتية: ' + (u'نعم' if visibility['show_icon'] else u'لا'), 'show_icon'), (u'إظهار اسم الصوتية: ' + (u'نعم' if visibility['show_name'] else u'لا'), 'show_name'), (u'فحص الأدوات وعرض الحالة', 'check'), (u'تثبيت الأدوات الناقصة من مستودعات الصورة', 'install'), (u'فحص ذاكرة التايم شيفت واختيار الأنسب', 'tsstorage'), (u'فحص المشغلات الثلاثة والمكملات', 'players'), (u'فحص سلامة البلجن (دريم/أوبن)', 'integrity'), (u'إعدادات الفيديو والصوت الإضافية', 'advanced'), (u'استعادة الصوت للوضع التلقائي', 'reset'), (u'إغلاق', 'close')]
        self.session.openWithCallback(self.selected, ChoiceBox, title=u'إعدادات الصوت والمشغّل — تطبيق الصوت تلقائيًا', list=rows)

    def selected(self, answer):
        if not answer or len(answer) < 2 or answer[1] == 'close':
            return
        action = answer[1]
        if action in ('show_icon', 'show_name'):
            self.toggle_visibility(action)
        elif action in ('audio', 'device', 'check'):
            _probe_dialog(self.session, lambda result: self.probed(action, result))
        elif action == 'video':
            from .xStaticText import ChoiceBox
            from .playerbrain import summary
            lines = summary()
            title = u'المشغّل يُختار تلقائياً لكل موقع'
            title += (u'\n' + u'\n'.join(lines)) if lines else u'\nلم يتعلّم المشغّل المناسب بعد'
            options = [(u'إعادة تعلّم المشغّلات من البداية', 'reset_brain'), (u'رجوع', 'back')]
            self.session.openWithCallback(self.video_selected, ChoiceBox, title=title, list=options)
        elif action == 'reset':
            self.saved(lambda: save_preferences(audio_mode='auto', alsa_device=''))
        elif action == 'advanced':
            from .settings import Alkuds_Settings
            self.session.openWithCallback(self.show, Alkuds_Settings)
        elif action == 'install':
            from Screens.Console import Console
            self.session.openWithCallback(self.show, Console, title=u'تثبيت مستلزمات الصوت والفيديو', cmdlist=['sh /usr/lib/enigma2/python/Plugins/Extensions/Alkuds/dependencies.sh manual'], closeOnSuccess=False)
        elif action == 'tsstorage':
            _run_probe(self.session, lambda result: self._tsstorage_probed(result), _probe_tsstorage)
        elif action == 'players':
            _run_probe(self.session, lambda result: self._players_probed(result), _probe_players)
        elif action == 'integrity':
            _run_probe(self.session, lambda result: self._integrity_probed(result), _probe_integrity)

    def _tsstorage_probed(self, result):
        from .xStaticText import ChoiceBox
        from .xStaticText import MessageBox
        if not isinstance(result, dict):
            self.show()
            return
        if result.get('error'):
            self.session.openWithCallback(self.show, MessageBox, u'تعذر إكمال الفحص:\n' + str(result['error']), type=MessageBox.TYPE_ERROR)
            return
        suitable = [v for v in result.get('volumes', []) if v.get('suitable')]
        options = [(u'%s — %d MiB متاح (%s)' % (v['path'], v['free'] // (1024 * 1024), v['filesystem'] or u'غير معروف'), v['path']) for v in suitable]
        if not options:
            options = [(u'تلقائي (لا يوجد قرص مناسب الآن)', 'auto')]
        options.append((u'إلغاء', 'cancel'))
        self.session.openWithCallback(self._tsstorage_selected, ChoiceBox, title=u'اختر ذاكرة حفظ التايم شيفت', list=options)

    def _tsstorage_selected(self, answer):
        from .xStaticText import MessageBox
        if not answer or len(answer) < 2 or answer[1] == 'cancel':
            self.show()
            return
        try:
            chosen = answer[1]
            if chosen == 'auto':
                from .systemcheck import TIMESHIFT_PREF
                try:
                    os.unlink(TIMESHIFT_PREF)
                except OSError:
                    pass
                text = u'أُلغي التحديد اليدوي؛ سيُختار أفضل قرص تلقائيًا عند تسجيل التايم شيفت.'
            else:
                from .systemcheck import save_timeshift_pref
                save_timeshift_pref(chosen)
                try:
                    from .flashbackrecorder import persist_buffer_path
                    persist_buffer_path(chosen)
                except Exception:
                    pass
                text = u'تم حفظ مسار التايم شيفت:\n' + chosen
            self.session.openWithCallback(self.show, MessageBox, text, type=MessageBox.TYPE_INFO)
        except Exception as error:
            self.session.openWithCallback(self.show, MessageBox, str(error), type=MessageBox.TYPE_ERROR)

    def _players_probed(self, result):
        from .xStaticText import MessageBox
        if not isinstance(result, dict):
            self.show()
            return
        if result.get('error'):
            self.session.openWithCallback(self.show, MessageBox, u'تعذر إكمال الفحص:\n' + str(result['error']), type=MessageBox.TYPE_ERROR)
            return
        lines = []
        for p in result.get('players', []):
            lines.append(u'%s %s (%d): %s' % (u'✓' if p.get('available') else u'✗', p.get('name'), p.get('code'), p.get('detail')))
        missing_tools = [name for name, ok in result.get('tools', {}).items() if not ok]
        lines.append(u'أدوات ناقصة: ' + (u', '.join(missing_tools) if missing_tools else u'لا شيء'))
        missing_codecs = [name for name, ok in result.get('codecs', {}).items() if not ok]
        lines.append(u'مكمّلات GStreamer ناقصة: ' + (u', '.join(missing_codecs) if missing_codecs else u'لا شيء'))
        missing_players = [p for p in result.get('players', []) if not p.get('available') and p.get('code') in (5001, 5002)]
        if missing_players:
            self.session.openWithCallback(self._install_missing_players, MessageBox, u'\n'.join(lines) + u'\n\nتوجد مشغّلات ناقصة. هل تريد تثبيتها الآن من فيد الصورة؟', type=MessageBox.TYPE_YESNO)
        else:
            self.session.openWithCallback(self.show, MessageBox, u'\n'.join(lines), type=MessageBox.TYPE_INFO)

    def _install_missing_players(self, answer):
        from Screens.Console import Console
        if answer:
            self.session.openWithCallback(self.show, Console, title=u'تثبيت المشغلات والمكملات من فيد الصورة', cmdlist=['sh /usr/lib/enigma2/python/Plugins/Extensions/Alkuds/dependencies.sh manual'], closeOnSuccess=False)
        else:
            self.show()

    def _integrity_probed(self, result):
        from .xStaticText import MessageBox
        if not isinstance(result, dict):
            self.show()
            return
        if result.get('error'):
            self.session.openWithCallback(self.show, MessageBox, u'تعذر إكمال الفحص:\n' + str(result['error']), type=MessageBox.TYPE_ERROR)
            return
        lines = [u'الإصدار: %s' % (result.get('version') or u'غير معروف'), u'بايثون: %s | %s' % (result.get('python_major') or u'?', result.get('package_manager') or u'?')]
        if result.get('ok'):
            lines.append(u'✓ %d ملف بايثون سليمة الصياغة' % result.get('files_scanned', 0))
        else:
            lines.append(u'✗ فشل صياغة %d ملف:' % len(result.get('failed', [])))
            for f in result.get('failed', [])[:6]:
                lines.append(u'  – %s: %s' % (f.get('path'), f.get('error')))
        self.session.openWithCallback(self.show, MessageBox, u'\n'.join(lines), type=MessageBox.TYPE_INFO)

    def toggle_visibility(self, key):
        from .xStaticText import MessageBox
        try:
            current = load_audio_visibility()
            values = save_audio_visibility(**{key: not current[key]})
            from .streammonitor import refresh_ipaudio_visibility
            refresh_ipaudio_visibility(values)
            self.show()
        except Exception as error:
            self.session.openWithCallback(self.show, MessageBox, str(error), type=MessageBox.TYPE_ERROR)

    def probed(self, action, result):
        from .xStaticText import ChoiceBox
        from .xStaticText import MessageBox
        if not isinstance(result, dict):
            self.show()
            return
        if result.get('error'):
            self.session.openWithCallback(self.show, MessageBox, u'تعذر إكمال الفحص:\n' + result['error'], type=MessageBox.TYPE_ERROR)
        elif action == 'check':
            from .backgroundaudio import background_audio_ui_status
            state = background_audio_ui_status()
            text = result['report'] + '\n\n' + str(state.get('backend') or state.get('state') or '') + '\n\n' + u'الفحص يؤكد توفر الأدوات فقط؛ جرّب الصوتية للتأكد من خروج الصوت.'
            self.session.openWithCallback(self.show, MessageBox, text, type=MessageBox.TYPE_INFO)
        elif action == 'audio':
            self.session.openWithCallback(self.audio_selected, ChoiceBox, title=u'المسارات الممكنة — التحقق النهائي عند تشغيل الصوتية', list=[(AUDIO_LABELS[mode], mode) for mode in result['modes']])
        else:
            self.session.openWithCallback(self.device_selected, ChoiceBox, title=u'مخرج ALSA — لا يؤثر على مسار DVB', list=[(u'تلقائي', '')] + [(value, value) for value in result['devices']])

    def saved(self, action, restart_audio=True):
        from .xStaticText import MessageBox
        try:
            before = load_preferences()
            action()
            restarting = False
            if restart_audio and load_preferences() != before:
                from .backgroundaudio import restart_audio_with_preferences
                restarting = restart_audio_with_preferences()
            text = u'تم الحفظ. جاري إعادة تشغيل الصوتية في الخلفية.' if restarting else u'تم الحفظ. سيُستخدم الاختيار عند التشغيل القادم.'
            self.session.openWithCallback(self.show, MessageBox, text + u'\nتسجيل التايم شيفت لا يتغير.', type=MessageBox.TYPE_INFO)
        except Exception as error:
            self.session.openWithCallback(self.show, MessageBox, str(error), type=MessageBox.TYPE_ERROR)

    def audio_selected(self, answer):
        if answer and len(answer) > 1:
            self.saved(lambda: save_preferences(audio_mode=answer[1]))
        else:
            self.show()

    def device_selected(self, answer):
        if answer and len(answer) > 1:
            self.saved(lambda: save_preferences(alsa_device=answer[1]))
        else:
            self.show()

    def video_selected(self, answer):
        if answer and len(answer) > 1 and answer[1] == 'reset_brain':
            try:
                from .playerbrain import reset
                reset()
            except Exception:
                pass
        self.show()

def open_playback_settings(session):
    PlaybackMenu(session).show()
