# -*- coding: utf-8 -*-
from . import fushaar
from .sitecatalogueui import Alkuds_SiteCatalogue_Browser


class Alkuds_Fushaar_Browser(Alkuds_SiteCatalogue_Browser):
    provider = fushaar
    site_name = u'فشار Fushaar'

    def __init__(self, session, section='home', level='groups', parent=None, page=1):
        Alkuds_SiteCatalogue_Browser.__init__(self, session, section, level, parent, page)
