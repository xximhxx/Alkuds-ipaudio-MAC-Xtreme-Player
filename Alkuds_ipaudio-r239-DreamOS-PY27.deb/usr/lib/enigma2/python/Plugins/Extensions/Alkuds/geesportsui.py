# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r238.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import geesports
from .generaltvui import Alkuds_GeneralTV_Browser
from .freechannels import (_prepared_stream_urls, _prepared_stream_labels,
                           Alkuds_StreamChooser, selected_free_service_type)
from .listpreview import open_list_player


class Alkuds_GeeSports_Browser(Alkuds_GeneralTV_Browser):
    provider = geesports
    site_name = u'GeeSports — الأحداث والقنوات'

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item)
        if len(prepared) == 1:
            from .freeplayer import Alkuds_FreeTV_Player
            open_list_player(self, None, Alkuds_FreeTV_Player, prepared,
                             selected_free_service_type(), item['name'], 'Live',
                             item.get('description', ''), item.get('image', ''), '')
        else:
            self.session.open(Alkuds_StreamChooser, prepared, _prepared_stream_labels(item),
                              item, item['name'], 'Live', item.get('description', ''),
                              item.get('image', ''), '', True)
