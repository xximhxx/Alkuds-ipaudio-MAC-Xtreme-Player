# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""CENC DASH with an explicitly supplied key, remuxed without transcoding.

No license acquisition, device emulation or key discovery. This module is
loaded only when a Cricfy item carries a valid key and is selected by the user.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
import Queue as queue
from .py2compat import re
import select
from .py2compat import socket
from .py2compat import subprocess
from .py2compat import threading
from .py2compat import time
import uuid
from .py2compat import ElementTree as ET
from .py2compat import http_server
BaseHTTPRequestHandler = http_server.BaseHTTPRequestHandler
ThreadingHTTPServer = http_server.ThreadingHTTPServer
from .py2compat import urllib
urlparse = urllib.parse.urlparse
_lock = threading.RLock()
_sessions = {}
_server = None
_capabilities = {}
_LOG = '/tmp/alkuds-cricfy.log'
_APP_VIDEO_UA = 'Mozilla/5.0 (Linux; Android 10; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36'

def playback_headers(values):
    headers = dict(values or {})
    existing = next((k for k in headers if k.lower() == 'user-agent'), None)
    if existing is None or not str(headers[existing]).strip() or str(headers[existing]).startswith('Mozilla/5.0 CricfyTV/'):
        if existing is not None:
            headers.pop(existing)
        headers['User-Agent'] = _APP_VIDEO_UA
    return headers

def diagnostic(stage, **fields):
    try:
        allowed = ('status', 'pid', 'exitcode', 'packets', 'reason')
        text = time.strftime('%H:%M:%S') + ' | CENC ' + stage
        text += ''.join((' %s=%s' % (k, str(v)[:80]) for k, v in fields.items() if k in allowed))
        with open(_LOG, 'w' if os.path.exists(_LOG) and os.path.getsize(_LOG) > 65536 else 'a') as out:
            out.write(text + '\n')
    except Exception:
        pass

def supplied_key(item):
    value = item.get('api')
    if not isinstance(value, basestring):
        raise RuntimeError(u'هذا المصدر لا يحتوي مفتاح ClearKey مباشرًا مدعومًا')
    match = re.fullmatch('\\s*([0-9a-fA-F]{32})\\s*:\\s*([0-9a-fA-F]{32})\\s*', value)
    if not match:
        raise RuntimeError(u'صيغة مفتاح المصدر غير مدعومة؛ لا يكفي تصنيف DRM للتشغيل')
    return tuple((v.lower() for v in match.groups()))

def validate_manifest(raw, kid):
    if len(raw) > 512 * 1024 or b'<!DOCTYPE' in raw.upper():
        raise RuntimeError(u'بيانات DASH غير صالحة')
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        raise RuntimeError(u'السيرفر لم يُرجع قائمة DASH صالحة')
    if root.tag.rsplit('}', 1)[-1] != 'MPD':
        raise RuntimeError(u'هذا المصدر ليس DASH')
    kids = set()
    schemes = set()
    for node in root.iter():
        for name, value in node.attrib.items():
            if name.rsplit('}', 1)[-1] == 'default_KID':
                kids.update((v.replace('-', '').lower() for v in value.split()))
        if node.tag.rsplit('}', 1)[-1] == 'ContentProtection' and node.get('schemeIdUri') == 'urn:mpeg:dash:mp4protection:2011':
            schemes.add(node.get('value', '').lower())
    if schemes - {'cenc'}:
        raise RuntimeError(u'نوع تشفير DASH هذا غير مدعوم في هذا المسار')
    if kids != {kid}:
        raise RuntimeError(u'معرّف المفتاح لا يطابق كل مسارات البث؛ يلزم مصدر متوافق')

def executable():
    for path in ('/usr/bin/ffmpeg', '/bin/ffmpeg', '/usr/local/bin/ffmpeg'):
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    raise RuntimeError(u'يلزم تثبيت ffmpeg من إضافات الصورة لتشغيل هذا المصدر')

def check_support(path):
    stamp = (path, os.stat(path).st_mtime)
    with _lock:
        if stamp in _capabilities:
            return
    try:
        run = subprocess.run([path, '-hide_banner', '-h', 'demuxer=dash'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=4, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except (OSError, subprocess.TimeoutExpired):
        raise RuntimeError(u'تعذر فحص ffmpeg خلال المهلة؛ أوقف المحاولة بأمان')
    if run.returncode or b'cenc_decryption_key ' not in run.stdout:
        raise RuntimeError(u'نسخة ffmpeg في الصورة لا تدعم CENC DASH؛ يلزم تحديثها من مستودع الصورة')
    with _lock:
        compat_clear(_capabilities)
        _capabilities[stamp] = True

def command(state):
    headers = state['headers']
    args = [state['executable'], '-hide_banner', '-nostdin', '-loglevel', 'error', '-protocol_whitelist', 'http,https,tcp,tls,crypto', '-rw_timeout', '8000000']
    if headers:
        args += ['-headers', ''.join(('%s: %s\r\n' % (k, v) for k, v in headers.items()))]
    return args + ['-cenc_decryption_key', state['key'], '-i', state['url'], '-map', '0:v:0', '-map', '0:a:0?', '-c', 'copy', '-avoid_negative_ts', 'make_zero', '-mpegts_flags', '+resend_headers', '-muxdelay', '0', '-muxpreload', '0', '-f', 'mpegts', 'pipe:1']

def stop_process(proc):
    if proc is None:
        return
    try:
        if proc.poll() is None:
            proc.terminate()
        try:
            proc.wait(timeout=1)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=1)
    except (OSError, subprocess.TimeoutExpired):
        pass

def verify_video(state):
    args = command(state)
    args = args[:args.index('-map')]
    args += ['-map', '0:v:0', '-frames:v', '1', '-an', '-xerror', '-progress', 'pipe:1', '-nostats', '-f', 'null', '-']
    try:
        run = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=12, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except subprocess.TimeoutExpired:
        diagnostic('verification-failed', reason='timeout')
        raise RuntimeError(u'انتهت مهلة اختبار فيديو المباراة؛ أعد المحاولة أو اختر سيرفرًا آخر')
    if run.returncode or not re.search(b'(?m)^frame=\\s*[1-9][0-9]*\\s*$', run.stdout):
        diagnostic('verification-failed', exitcode=run.returncode, reason='no-decoded-frame')
        raise RuntimeError(u'تعذر فك فيديو المباراة بالمفتاح المتاح؛ حدّث السيرفر أو اختر آخر')

class Handler(BaseHTTPRequestHandler):

    def log_message(self, *args):
        pass

    def do_HEAD(self):
        self.serve(True)

    def do_GET(self):
        self.serve(False)

    def gone(self):
        try:
            ready, unused, errors = select.select([self.connection], [], [self.connection], 0)
            return bool(errors) or bool(ready and (not self.connection.recv(1, socket.MSG_PEEK)))
        except OSError:
            return True

    def error(self, status):
        try:
            self.send_response(status)
            self.send_header('Content-Length', '0')
            self.send_header('Connection', 'close')
            self.end_headers()
        except OSError:
            pass

    def serve(self, head):
        ident = self.path.split('?', 1)[0].strip('/')
        if ident.endswith('.ts'):
            ident = ident[:-3]
        with _lock:
            state = _sessions.get(ident)
            if state is None or state['cancel'].is_set():
                self.error(404)
                return
            if state['active'] and (not head):
                self.error(409)
                return
            if not head:
                state['active'] = True
        if head:
            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Connection', 'close')
            self.end_headers()
            return
        proc = None
        sent = False
        finished = threading.Event()
        workers = []
        chunks = queue.Queue(maxsize=8)
        try:
            self.connection.settimeout(2)
            proc = subprocess.Popen(command(state), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            diagnostic('started', pid=proc.pid)

            def reader():
                try:
                    while not finished.is_set():
                        chunk = proc.stdout.read(188 * 32)
                        while not finished.is_set():
                            try:
                                chunks.put(chunk, timeout=0.2)
                                break
                            except queue.Full:
                                pass
                        if not chunk:
                            return
                except (OSError, ValueError):
                    pass

            def errors():
                try:
                    while not finished.is_set():
                        if not proc.stderr.read(2048):
                            return
                except (OSError, ValueError):
                    pass
            for target in (reader, errors):
                worker = threading.Thread(target=target, daemon=True)
                workers.append(worker)
                worker.start()
            last = time.monotonic()
            while not state['cancel'].is_set() and (not self.gone()):
                try:
                    chunk = chunks.get(timeout=0.2)
                except queue.Empty:
                    if proc.poll() is not None:
                        break
                    if time.monotonic() - last > (15 if sent else 25):
                        raise RuntimeError('video-timeout')
                    continue
                if not chunk:
                    break
                if not sent:
                    if len(chunk) < 188 * 5 or any((chunk[n * 188] != 71 for n in range(5))):
                        raise RuntimeError('invalid-ts')
                    self.send_response(200)
                    self.send_header('Content-Type', 'video/mp2t')
                    self.send_header('Cache-Control', 'no-store')
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    sent = True
                    diagnostic('video-packets', packets=len(chunk) // 188)
                self.wfile.write(chunk)
                self.wfile.flush()
                last = time.monotonic()
            if not sent:
                self.error(502)
        except (OSError, RuntimeError):
            diagnostic('stopped', reason='video-unavailable-or-client-closed')
            if not sent:
                self.error(502)
        finally:
            finished.set()
            stop_process(proc)
            if proc:
                for pipe in (proc.stdout, proc.stderr):
                    try:
                        pipe.close()
                    except OSError:
                        pass
                diagnostic('cleaned', pid=proc.pid, exitcode=proc.returncode)
            for worker in workers:
                worker.join(timeout=0.3)
            with _lock:
                state['active'] = False
                if _sessions.get(ident) is state:
                    _sessions.pop(ident, None)
                state['key'] = ''
                compat_clear(state['headers'])

def prepare(item, player):
    global _server
    kid, key = supplied_key(item)
    url = item.get('url') or item.get('link') or ''
    if urlparse(url).scheme not in ('http', 'https'):
        raise RuntimeError(u'رابط DASH غير صالح')
    path = executable()
    check_support(path)
    headers = playback_headers(item.get('headers'))
    if len(headers) > 24 or any((re.search('[\\r\\n]', str(k) + str(v)) for k, v in headers.items())):
        raise RuntimeError(u'إعدادات طلب البث غير صالحة')
    try:
        raw, final = player.fetch(url, headers)
    except Exception as error:
        response = getattr(error, 'response', None)
        status = getattr(response, 'status_code', None)
        diagnostic('manifest-failed', status=status or 'network')
        if status:
            raise RuntimeError(u'خادم المباراة رفض قائمة البث (HTTP %s)؛ أعد تحديث السيرفر' % status)
        raise RuntimeError(u'تعذر الاتصال بقائمة المباراة؛ الرابط قديم أو غير متاح من الشبكة')
    validate_manifest(raw, kid)
    state = {'url': final, 'headers': player.stream_headers(final, headers), 'key': key, 'executable': path, 'cancel': threading.Event(), 'active': False}
    verify_video(state)
    ident = uuid.uuid4().hex
    with _lock:
        if _server is None:
            _server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
            _server.daemon_threads = True
            threading.Thread(target=_server.serve_forever, daemon=True).start()
        for old in _sessions.values():
            old['cancel'].set()
        compat_clear(_sessions)
        _sessions[ident] = state
        local = 'http://127.0.0.1:%d/%s.ts' % (_server.server_port, ident)
    diagnostic('prepared')
    stream = {'url': local, 'headers': {}, 'mediatype': 'ts', 'relay': False, 'quality': 'CENC | Auto', 'source': 'cricfy'}
    result = {k: v for k, v in item.items() if k not in ('api', 'license', 'drm')}
    return dict(result, name=item.get('match_name') or item['name'], url=local, streams=[stream], variants=[stream])
