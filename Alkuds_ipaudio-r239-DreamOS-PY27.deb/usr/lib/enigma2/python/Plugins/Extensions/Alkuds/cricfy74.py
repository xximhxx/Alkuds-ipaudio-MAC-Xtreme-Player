# -*- coding: utf-8 -*-
"""CRICFy 7.4 catalogue transport and model adapter (Python 2.7/3)."""
from __future__ import absolute_import
import base64
import calendar
import hashlib
import json
import re
import struct
import sys
import threading
import time
from datetime import datetime
if sys.version_info[0] == 2:
    from .py2compat import requests
else:
    import requests

BASE = 'https://cftkhffmgf147.top/'
# Live 7.4 ClearKey samples did not decode a frame. Keep the existing
# explicit-key backend, but do not advertise unverified DRM in this release.
# Ordinary HLS AES-128 is handled independently and remains available.
DRM_ENABLED = False
_cache = {'value': None, 'until': 0}
_lock = threading.Lock()
_BOOTSTRAP = ('https://firebaseremoteconfig.googleapis.com/v1/projects/cfynewtv/'
              'namespaces/firebase:fetch?key=AIzaSyA00Wj4mCOey1dBrvdjYfTP5FF_j9V78Ps')


def config():
    with _lock:
        if _cache['value'] and time.time() < _cache['until']:
            return dict(_cache['value'])
        base = (_cache['value'] or {}).get('api_url', BASE)
        response = None
        try:
            response = requests.post(_BOOTSTRAP, json={
                'app_id': '1:185914741153:android:49da167219b6ef69907be0',
                'package_name': 'com.cricfytv.sports', 'app_instance_id': 'x',
            }, timeout=(5, 8))
            response.raise_for_status()
            candidate = response.json().get('entries', {}).get('cric_api2', '')
            if not re.match(r'^https://[A-Za-z0-9.-]+(?::[0-9]+)?/?$', candidate):
                raise ValueError('Invalid Cricfy catalogue host')
            base = candidate.rstrip('/') + '/'
            ttl = 300
        except Exception:
            ttl = 60
        finally:
            if response is not None:
                response.close()
        value = {'api_url': base, 'events_path': 'categories/live-events.txt',
                 'categories_path': 'cats.txt', 'event_cats_path': 'eventCats.txt',
                 'sports_slug_path': 'categories/sports.txt', 'app_version': '7.4'}
        _cache.update(value=value, until=time.time() + ttl)
        return dict(value)


def _cbc(raw, key, iv):
    if not raw or len(raw) % 16:
        raise ValueError('Invalid Cricfy ciphertext length')
    from .generalaes import AESModeOfOperationCBC
    cipher = AESModeOfOperationCBC(key, iv=iv)
    clear = b''.join(cipher.decrypt(raw[n:n+16]) for n in range(0, len(raw), 16))
    pad = bytearray(clear)[-1]
    if not 1 <= pad <= 16 or clear[-pad:] != struct.pack('B', pad) * pad:
        raise ValueError('Invalid Cricfy padding')
    return clear[:-pad]


def decode(text):
    """The native Baker decoder: salted envelope or either shipped AES pair."""
    text = text.strip()
    if text.startswith(('[', '{')):
        return json.loads(text)
    raw = base64.b64decode(text)
    # New salted envelope: SHA-256 counter mask over AES ciphertext. The
    # source's catalogue wrapper is separate from media/DRM encryption.
    if len(raw) > 16 and len(raw) % 16 == 0:
        salt, body = raw[:16], raw[16:]
        mask = b''.join(hashlib.sha256(salt + struct.pack('>I', counter)).digest()
                        for counter in range((len(body) + 31) // 32))
        encrypted = b''.join(struct.pack('B', a ^ b) for a, b in zip(bytearray(body), bytearray(mask)))
        keyiv = hashlib.sha256(salt).digest()
        try:
            return json.loads(_cbc(encrypted, keyiv[:16], keyiv[16:]).decode('utf8'))
        except (ValueError, UnicodeError):
            pass
    for key, iv in ((b'3hHzxYAgSGI8/ham', b'UqCvkvjecEIz842V'),
                    (b'MqeYGCT4AYKoHKrT', b'oHKrTQuPx8zl8oJ+')):
        try:
            return json.loads(_cbc(raw, key, iv).decode('utf8'))
        except (ValueError, UnicodeError):
            pass
    raise RuntimeError('Cricfy 7.4 catalogue format is unavailable or changed')


def normalise(row):
    item = dict(row)
    if row.get('publish') in ('0', 0, False):
        item['visible'] = False
    item.setdefault('logo', row.get('image') or '')
    slug = row.get('slug')
    if slug:
        if not re.match(r'^[A-Za-z0-9_-]+$', slug):
            raise ValueError('Invalid Cricfy channel slug')
        item['links'] = 'channels/' + slug.lower() + '.txt'
    details = row.get('eventInfo')
    if isinstance(details, dict):
        item['eventDetails'] = dict(details, category=details.get('eventCat') or 'Other')
        item['teamA'], item['teamB'] = details.get('teamA'), details.get('teamB')
        item['eventName2'] = row.get('title')
        for source, date_key, time_key in (('startTime', 'date', 'time'), ('endTime', 'end_date', 'end_time')):
            value = details.get(source) or ''
            try:
                stamp, zone = value.rsplit(' ', 1)
                seconds = calendar.timegm(datetime.strptime(stamp, '%Y/%m/%d %H:%M:%S').timetuple())
                if re.match(r'^[+-][0-9]{4}$', zone):
                    seconds -= (1 if zone[0] == '+' else -1) * (int(zone[1:3])*3600 + int(zone[3:5])*60)
                utc = time.gmtime(seconds)
                item[date_key] = time.strftime('%Y-%m-%d', utc)
                item[time_key] = time.strftime('%H:%M:%S', utc)
            except (ValueError, TypeError):
                pass
    return item


def drm_supported(item):
    """Never advertise a license-only DRM stream as a playable alternative."""
    if not DRM_ENABLED:
        return False
    scheme = str(item.get('license_type') or item.get('drmScheme') or '').lower()
    if scheme and 'clearkey' not in scheme and 'e2719d58' not in scheme:
        return False
    try:
        from .cricfyclearkey import supplied_key, executable, check_support
        supplied_key(item)
        check_support(executable())
        return True
    except Exception:
        return False
