# -*- coding: utf-8 -*-
"""GeeSports 3.8 live catalogue.

The Android client receives AES-CBC protected text files from its API.  The
key is not a fixed secret in the code: it is derived from the signing
certificate embedded in the APK.  For GeeSports 3.8 the resulting 16-byte key
is ``RT1zdnBRcVZvSU1t`` and the IV is ``bkmlmKnk9i5Khs9n``.  The derivation is
documented in ``r238`` reports; when the publisher signs a new APK the key
changes and this module needs to be refreshed.

Only ordinary HLS/MPEG-TS/MPD links are exposed.  Entries carrying a ClearKey
``api`` field are omitted because the receiver cannot reliably play CENC
streams (same policy as Cricfy 7.4 in r238).
"""
from __future__ import absolute_import

import base64
import re
import threading
import time

try:
    text_type = unicode
except NameError:
    text_type = str

try:
    from urllib.parse import urljoin, urlparse
except ImportError:
    from urlparse import urljoin, urlparse

try:
    from .py2compat import json
except ImportError:
    import json

try:
    from .py2compat import requests
except ImportError:
    import requests

from .streamrequest import split_url

BASE = 'https://hello-how.pages.dev/'
UA = 'okhttp/4.12.0'
KEY = b'RT1zdnBRcVZvSU1t'
IV = b'bkmlmKnk9i5Khs9n'
SECTION_MAP = {'channels': (u'قنوات GeeSports', ''), 'matches': (u'أحداث GeeSports', '')}

_cache = {}
_lock = threading.RLock()


def refresh():
    with _lock:
        _cache.clear()


def _memo(key, load, ttl=60):
    with _lock:
        cached = _cache.get(key)
        if cached and time.time() - cached[0] < ttl:
            return cached[1]
    value = load()
    with _lock:
        _cache[key] = (time.time(), value)
    return value


def _swap_pairs(text):
    chars = list(text)
    for index in range(0, len(chars) - 1, 2):
        chars[index], chars[index + 1] = chars[index + 1], chars[index]
    return ''.join(chars)


def _unpad(data):
    if not data:
        raise ValueError('empty payload')
    padding = bytearray(data)[-1]
    if not 1 <= padding <= 16 or data[-padding:] != bytes(bytearray([padding])) * padding:
        raise ValueError('invalid padding')
    return data[:-padding]


def _aes_decrypt(data):
    try:
        from Crypto.Cipher import AES
        return AES.new(KEY, AES.MODE_CBC, IV).decrypt(data)
    except ImportError:
        from .generalaes import AESModeOfOperationCBC
        cipher = AESModeOfOperationCBC(KEY, iv=IV)
        return b''.join(cipher.decrypt(data[index:index + 16]) for index in range(0, len(data), 16))


def decode(text):
    text = (text or '').strip()
    if not text:
        raise RuntimeError(u'خدمة GeeSports أعادت بيانات فارغة.')
    if text.startswith(('{', '[')):
        return json.loads(text)
    if text.startswith('<'):
        raise RuntimeError(u'خدمة GeeSports أعادت صفحة خطأ بدلاً من البيانات.')
    try:
        outer = base64.b64decode(text).decode('ascii')
        payload = base64.b64decode(_swap_pairs(outer)[::-1])
        plain = _unpad(_aes_decrypt(payload)).decode('utf-8')
    except Exception:
        raise RuntimeError(u'تعذر فك بيانات GeeSports؛ قد يكون التطبيق قد حدّث مفتاحه.')
    try:
        return json.loads(plain)
    except ValueError:
        raise RuntimeError(u'صيغة بيانات GeeSports غير مفهومة.')


def _get(path, raw=False):
    url = path if path.startswith(('http://', 'https://')) else urljoin(BASE, path.lstrip('/'))
    if urlparse(url).scheme not in ('http', 'https'):
        raise ValueError('invalid GeeSports address')
    try:
        response = requests.get(url, headers={'User-Agent': UA, 'Accept': 'text/plain, application/json, */*'},
                                timeout=(7, 20), stream=True)
    except Exception:
        raise RuntimeError(u'تعذر الاتصال بخدمة GeeSports.')
    try:
        try:
            response.raise_for_status()
        except Exception:
            raise RuntimeError(u'خدمة GeeSports أعادت خطأ %s لهذا الرابط.' % response.status_code)
        chunks, size = [], 0
        for chunk in response.iter_content(32768):
            size += len(chunk)
            if size > 8 * 1024 * 1024:
                raise RuntimeError(u'استجابة GeeSports أكبر من الحد المسموح.')
            chunks.append(chunk)
        body = b''.join(chunks)
        final = response.url
    finally:
        response.close()
    if raw:
        return body.decode('utf-8-sig'), final
    return decode(body.decode('utf-8-sig')), final


def _data(path):
    return _memo(('data', path), lambda: _get(path)[0], 60)


def _obj(value):
    if isinstance(value, text_type) and value.strip().startswith((u'{', u'[')):
        try:
            return json.loads(value)
        except ValueError:
            return {}
    return value


def _rows(value):
    value = _obj(value)
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        for key in ('items', 'channels', 'events', 'categories', 'data', 'results', 'links'):
            if isinstance(_obj(value.get(key)), list):
                return _obj(value[key])
        return [value]
    return []


def _clean(value):
    if value is None:
        return u''
    if not isinstance(value, text_type):
        value = text_type(value)
    return u' '.join(value.split())


def _events():
    rows = []
    for raw in _rows(_data('events.txt')):
        if not isinstance(raw, dict):
            continue
        info = _obj(raw.get('event')) or raw
        if not isinstance(info, dict) or info.get('visible') is False:
            continue
        name = _clean(info.get('eventName') or info.get('name'))
        team_a = _clean(info.get('teamAName'))
        team_b = _clean(info.get('teamBName'))
        if team_a and team_b and team_a != team_b and team_a.lower() not in name.lower():
            title = u'%s × %s' % (team_a, team_b)
        else:
            title = name or u'حدث رياضي'
        clock = _clean(info.get('time'))
        date = _clean(info.get('date'))
        label = u'%s %s | %s' % (date, clock, title) if date else title
        rows.append(dict(name=label, title=title, match_name=title,
                         category=_clean(info.get('category')) or u'أحداث',
                         image=info.get('eventLogo') or info.get('teamAFlag') or '',
                         description=u'%s | %s' % (u'GeeSports', label),
                         links=info.get('links'), action='browse', kind='servers',
                         section='matches'))
    return rows


def _catalogue_rows(name):
    if name == 'sports':
        return [_obj(row.get('cat')) for row in _rows(_data('sports.txt'))]
    return [_obj(row.get('cat')) for row in _rows(_data('categories.txt'))]


def groups():
    events = _events()
    result = [dict(name=u'كل الأحداث المباشرة (%d)' % len(events), kind='events', section='matches')]
    categories = []
    for event in events:
        if event['category'] not in categories:
            categories.append(event['category'])
    for category in categories:
        total = len([event for event in events if event['category'] == category])
        result.append(dict(name=u'%s (%d)' % (category, total), kind='events',
                           category=category, section='matches'))
    result.append(dict(name=u'قنوات GeeSports (%d)' % len(_catalogue_rows('categories')),
                       kind='cats', source='categories', section='channels'))
    result.append(dict(name=u'الرياضة (%d)' % len(_catalogue_rows('sports')),
                       kind='cats', source='sports', section='channels'))
    return result


def _groups_page(parent, page):
    if parent.get('kind') == 'events':
        rows = _events()
        if parent.get('category'):
            rows = [row for row in rows if row['category'] == parent['category']]
        return rows
    if parent.get('kind') == 'cats':
        name = parent.get('source') or 'categories'
        rows = []
        for cat in _catalogue_rows(name):
            if not isinstance(cat, dict) or cat.get('visible') is False:
                continue
            label = _clean(cat.get('name')) or u'تصنيف'
            rows.append(dict(name=label, title=label, image=cat.get('logo') or '',
                             description=u'GeeSports | %s' % label, action='browse',
                             kind='catalogue', path=cat.get('api') or '',
                             type=cat.get('type') or 'custom', section='channels'))
        return rows
    if parent.get('kind') == 'catalogue':
        path = parent.get('path') or ''
        if not path:
            raise RuntimeError(u'هذا التصنيف لا يحتوي رابطاً.')
        if parent.get('type') == 'm3u' or path.split('?')[0].endswith(('.m3u', '.m3u8')):
            body, final = _get(path, raw=True)
            return _parse_m3u(body, final)
        rows = []
        for raw in _rows(_data(path)):
            if not isinstance(raw, dict):
                continue
            info = _obj(raw.get('channel')) or raw
            if not isinstance(info, dict) or info.get('visible') is False:
                continue
            label = _clean(info.get('name')) or u'قناة'
            rows.append(dict(name=label, title=label, image=info.get('logo') or '',
                             description=u'GeeSports | %s' % label, links=info.get('links'),
                             is_playlist=bool(info.get('is_playlist')),
                             action='browse', kind='servers', section='channels'))
        return rows
    if parent.get('kind') == 'servers':
        return _servers(parent)
    raise RuntimeError(u'نوع صفحة GeeSports غير معروف.')


def _parse_m3u(text, final):
    rows, entry, headers, protected = [], None, {}, False
    for line in (text or '').splitlines():
        line = line.strip()
        if line.startswith('#EXTINF:'):
            attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', line))
            label = _clean(line.rsplit(',', 1)[-1]) or u'قناة'
            entry = dict(name=label, title=label, match_name=label,
                         image=attrs.get('tvg-logo', ''),
                         category=_clean(attrs.get('group-title')))
            headers, protected = {}, False
        elif entry and line.startswith('#EXTVLCOPT:'):
            key, _, value = line[len('#EXTVLCOPT:'):].partition('=')
            names = {'http-user-agent': 'User-Agent', 'http-referrer': 'Referer',
                     'http-origin': 'Origin'}
            if key in names:
                headers[names[key]] = value
        elif entry and line.startswith('#KODIPROP:'):
            prop, _, value = line[len('#KODIPROP:'):].partition('=')
            if prop.endswith(('license_type', 'license_key')):
                protected = True
                if prop.endswith('license_key'):
                    entry['api'] = value.strip()
        elif entry and line and not line.startswith('#'):
            if protected:
                entry = None
                continue
            url, options = split_url(urljoin(final, line), headers)
            if urlparse(url).scheme not in ('http', 'https'):
                entry = None
                continue
            entry.update(action='play', url=url, headers=options, source='geesports')
            rows.append(entry)
            entry = None
    return rows


def _servers(parent):
    links = parent.get('links')
    if not links:
        return []
    rows = []
    protected = 0
    for number, raw in enumerate(_rows(_data(links))):
        if isinstance(raw, text_type):
            raw = {'link': raw}
        if not isinstance(raw, dict):
            continue
        link = raw.get('link') or raw.get('url') or ''
        if not link:
            continue
        # ClearKey links need a CENC-capable player and a license; r238 hides
        # them instead of offering a stream that cannot start.
        if raw.get('api') or raw.get('license') or raw.get('license_key') or raw.get('drm'):
            protected += 1
            continue
        url, headers = split_url(link, parent.get('headers'))
        if urlparse(url).scheme not in ('http', 'https'):
            continue
        label = _clean(raw.get('name')) or u'سيرفر %d' % (number + 1)
        name = _clean(parent.get('title') or parent.get('name')) + u' | ' + label
        rows.append(dict(raw, name=name, title=name, match_name=parent.get('match_name') or name,
                         url=url, headers=headers, action='play', source='geesports',
                         image=parent.get('image', ''), description=parent.get('description', ''),
                         server_key=str(number)))
    if not rows and protected:
        raise RuntimeError(u'روابط هذه القناة محمية بـ DRM (ClearKey) ولا يمكن تشغيلها على هذا الجهاز.')
    return rows


def page(parent, page=1):
    rows = _memo(('page', parent.get('kind'), parent.get('source'), parent.get('category'),
                  parent.get('path'), parent.get('links')),
                 lambda: _groups_page(parent, page), 45)
    start = (page - 1) * 24
    return {'entries': rows[start:start + 24], 'page': page,
            'total': len(rows), 'last_page': max(1, (len(rows) + 23) // 24)}


def resolve(item):
    """Return the single stream for the shared player screen."""
    url, headers = split_url(item.get('url'), item.get('headers'))
    result = dict(item)
    result['streams'] = [{'url': url, 'headers': headers, 'source': 'geesports'}]
    return result
