# -*- coding: utf-8 -*-
"""Shared HTTP stream preparation, independent of the receiver's player."""
from __future__ import absolute_import

import json
import os
import re
import time
try:
    from urllib.parse import parse_qsl, urlparse
except ImportError:
    from urlparse import parse_qsl as _parse_qsl, urlparse
    def parse_qsl(value, **kwargs):
        # Python 2 treats semicolons inside a browser User-Agent as query
        # separators. HTTP option lists use '&'; preserve literal ';' bytes.
        return _parse_qsl(value.replace(';', '%3B'), **kwargs)
try:
    text_type = unicode
except NameError:
    text_type = str


def headers(*values):
    result = {}
    aliases = {'user-agent': 'User-Agent', 'referrer': 'Referer',
               'referer': 'Referer', 'origin': 'Origin', 'cookie': 'Cookie',
               'authorization': 'Authorization'}
    for value in values:
        if isinstance(value, (str, text_type)):
            try:
                value = json.loads(value)
            except (ValueError, TypeError):
                value = dict(parse_qsl(value.replace('|', '&'), keep_blank_values=True))
        if not isinstance(value, dict):
            continue
        for key, item in value.items():
            key, item = text_type(key), text_type(item or '')
            if not re.match(r"^[!#$%&'*+.^_`~0-9A-Za-z-]+\Z", key) or '\r' in item or '\n' in item:
                raise ValueError('Invalid stream header')
            # HTTP header names are case-insensitive, including custom names.
            for previous in list(result):
                if previous.lower() == key.lower():
                    del result[previous]
            result[aliases.get(key.lower(), key)] = item
    return result


def split_url(value, supplied=None):
    url = text_type(value or '').strip()
    url, separator, options = url.partition('|')
    if not separator and '#' in url:
        base, fragment = url.rsplit('#', 1)
        if re.match(r'(?i)(?:user-agent|referer|referrer|origin|cookie|authorization)=', fragment):
            url, options = base, fragment
    return url, headers(supplied, dict(parse_qsl(options, keep_blank_values=True)))


def stream_entries(item):
    streams = item.get('streams') or item.get('variants') or item.get('urls') or [item.get('url')]
    if isinstance(streams, (str, text_type, dict)):
        streams = [streams]
    inherited = ('relay', 'mediatype', 'swap', 'relay_options', 'ostora_hls', 'source', 'subtitles')
    for stream in streams:
        row = {key: item[key] for key in inherited if key in item}
        row.update(stream if isinstance(stream, dict) else {'url': stream})
        try:
            row['headers'] = headers(item.get('headers'), row.get('headers'))
        except ValueError as error:
            diagnostic('headers', error=error)
            continue
        if row.get('url'):
            yield row


def prepare_stream(stream):
    from .freeproviders import service_stream_url
    url, request_headers = split_url(stream.get('url'), stream.get('headers'))
    parsed = urlparse(url)
    options = dict(stream.get('relay_options') or stream.get('ostora_hls') or {})
    media = text_type(stream.get('mediatype') or '').lower()
    if not media:
        extension = parsed.path.lower().rsplit('.', 1)[-1]
        media = extension if extension in ('ts', 'mp4', 'mp3', 'aac') else ''
    remote = parsed.scheme in ('http', 'https') and parsed.hostname not in ('127.0.0.1', 'localhost', '::1')
    forced = stream.get('relay') or stream.get('swap')
    if (forced or (remote and request_headers)) and parsed.scheme in ('http', 'https') and media in ('', 'hls', 'mp4', 'ts', 'mp3', 'aac', 'audio'):
        from .streamproxy import prepare_hls_relay
        if media in ('mp4', 'ts', 'mp3', 'aac', 'audio'):
            options.setdefault('media_type', 'mp3' if media == 'audio' else media)
        return prepare_hls_relay(url, request_headers, stream.get('swap') or {}, options)
    return service_stream_url(url, request_headers)


def cookie_headers(session, url, supplied):
    import requests
    result = headers(supplied)
    prepared = requests.Request('GET', url).prepare()
    cookie = requests.cookies.get_cookie_header(session.cookies, prepared)
    if cookie:
        existing = {}
        for pair in result.get('Cookie', '').split(';'):
            key, sep, value = pair.strip().partition('=')
            if sep:
                existing[key] = value
        for pair in cookie.split(';'):
            key, sep, value = pair.strip().partition('=')
            if sep:
                existing[key] = value
        result['Cookie'] = '; '.join('%s=%s' % pair for pair in existing.items())
    return result


def cookie_state(session):
    return [{'name': c.name, 'value': c.value, 'domain': c.domain,
             'path': c.path, 'secure': c.secure} for c in session.cookies]


def read_probe(response, limit=262144):
    chunks = response.iter_content(188 * 16)
    first = next(chunks, b'')
    transport = len(first) >= 377 and first[0:1] == first[188:189] == first[376:377] == b'G'
    if transport or first[4:8] in (b'ftyp', b'styp', b'moof'):
        return first
    raw = first
    for chunk in chunks:
        raw += chunk
        if len(raw) > limit:
            raise RuntimeError('Stream manifest or player response too large')
    return raw


def safe_message(message):
    value = re.sub(r'https?://[^\s\"\'<>]+', lambda m: (urlparse(m.group(0)).hostname or 'source') + '/[redacted]', text_type(message))
    return re.sub(r'first8=\S+', 'first8=[redacted]', value)


def diagnostic(stage, url='', status=None, error=None, provider=''):
    try:
        path = '/tmp/alkuds-playback.log'
        if os.path.exists(path) and os.path.getsize(path) > 65536:
            with open(path, 'w'):
                pass
        fields = (time.strftime('%H:%M:%S'), stage, provider,
                  urlparse(url).hostname or '', status or '', type(error).__name__ if error else '')
        line = '%s stage=%s provider=%s host=%s status=%s error=%s\n' % fields
        with open(path, 'ab') as output:
            output.write(line.encode('utf-8'))
    except Exception:
        pass
