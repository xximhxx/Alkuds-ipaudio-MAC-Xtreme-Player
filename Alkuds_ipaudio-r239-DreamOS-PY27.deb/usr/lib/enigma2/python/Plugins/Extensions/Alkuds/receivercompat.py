# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Receiver-specific compatibility helpers for Alkuds IPAUDIO (R31P7).

Vu+ 4K receivers use Broadcom vendor audio drivers whose DVB audio decoder is
paused together with native Timeshift. Detect Vu+ using both procfs and
Enigma2's own boxbranding/BoxInfo APIs, then select the audio-only Enigma2
handoff plus the independent ALSA renderer. The main DVB video service and
native Timeshift remain untouched; Local Remux is never selected here.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import os
from .py2compat import re
from .py2compat import time

def is_dreambox_arm():
    """DM900/DM920 require the image's GStreamer audio renderer first."""
    return bool(re.search('(?<![a-z0-9])dm(?:900|920)(?![a-z0-9])', receiver_signature().lower()))
FREE_PLAYER_FILE = '/etc/enigma2/alkuds/free_player_type'

def _read_text(path):
    try:
        with open(path, 'rb') as f:
            data = f.read(2048)
        if not isinstance(data, str):
            data = data.decode('utf-8', 'ignore')
        return str(data or '').replace('\x00', ' ').strip()
    except Exception:
        return ''

def _safe_call(module_name, names):
    values = []
    try:
        mod = __import__(module_name, fromlist=list(names))
        for name in names:
            try:
                fn = getattr(mod, name, None)
                if callable(fn):
                    value = fn()
                    if value is not None and str(value).strip():
                        values.append('%s=%s' % (name, str(value).strip()))
            except Exception:
                pass
    except Exception:
        pass
    return values

def _boxinfo_values():
    values = []
    try:
        from Components.SystemInfo import BoxInfo
        for key in ('brand', 'model', 'boxtype', 'machinebuild', 'machinename', 'machinebrand', 'oem'):
            try:
                value = BoxInfo.getItem(key)
                if value is not None and str(value).strip():
                    values.append('BoxInfo.%s=%s' % (key, str(value).strip()))
            except Exception:
                pass
    except Exception:
        pass
    try:
        from Tools.HardwareInfo import HardwareInfo
        hw = HardwareInfo()
        for name in ('get_device_model', 'get_device_name', 'get_vu_device_name'):
            try:
                fn = getattr(hw, name, None)
                if callable(fn):
                    value = fn()
                    if value is not None and str(value).strip():
                        values.append('HardwareInfo.%s=%s' % (name, str(value).strip()))
            except Exception:
                pass
    except Exception:
        pass
    return values

def receiver_signature():
    values = []
    for path in ('/proc/stb/info/brand', '/proc/stb/info/model', '/proc/stb/info/boxtype', '/proc/stb/info/boxmodel', '/proc/stb/info/vumodel', '/proc/stb/info/machinebuild', '/proc/stb/info/chipset', '/proc/device-tree/model', '/sys/firmware/devicetree/base/model', '/etc/hostname'):
        value = _read_text(path)
        if value:
            values.append('%s=%s' % (path, value))
    values.extend(_safe_call('boxbranding', ('getBoxType', 'getMachineBuild', 'getMachineBrand', 'getMachineName', 'getBrandOEM', 'getMachineMake', 'getModel')))
    values.extend(_boxinfo_values())
    return ' | '.join(values)

def _normalise(value):
    return ''.join((ch for ch in str(value or '').lower() if ch.isalnum() or ch == '+'))

def is_octagon():
    """Use physical/branding identity; Egami's dm800se/vumodel are aliases."""
    signature = receiver_signature()
    for field in str(signature).split('|'):
        key, sep, value = field.strip().partition('=')
        value = _normalise(value)
        if not sep:
            continue
        if key in ('/proc/stb/info/brand', 'getMachineBrand', 'getBrandOEM', 'BoxInfo.brand', 'BoxInfo.machinebrand') and value == 'octagon':
            return True
        if key in ('/proc/stb/info/model', '/proc/stb/info/boxtype', 'getBoxType', 'getMachineBuild', 'BoxInfo.model') and value in ('sf4008', 'sf8008', 'sf8008m', 'sf8008mini', 'sf8008supreme', 'sf8008combo', 'sf8008single', 'sfx6008'):
            return True
    return False

def is_octagon_egami():
    if not is_octagon():
        return False
    image = ' '.join((_read_text(path) for path in ('/etc/image-version', '/etc/issue', '/etc/egami-version')))
    image += ' ' + ' '.join(_safe_call('boxbranding', ('getImageDistro', 'getImageVersion')))
    return 'egami' in image.lower()

def is_vuplus():
    signature = receiver_signature()
    ident = _normalise(signature)
    if not ident:
        return False
    physical = {}
    for field in str(signature).split('|'):
        key, sep, value = field.strip().partition('=')
        if sep and key.startswith('/proc/stb/info/'):
            physical[key.rsplit('/', 1)[-1]] = _normalise(value)
    octagon_models = {'sf4008', 'sf8008', 'sf8008m', 'sf8008mini', 'sf8008supreme', 'sf8008combo', 'sf8008single', 'sfx6008'}
    if physical.get('brand') == 'octagon' or any((physical.get(key) in octagon_models for key in ('model', 'boxtype', 'boxmodel'))):
        return False
    if not physical.get('vumodel') and physical.get('brand') not in ('vu+', 'vuplus', 'vu'):
        for field in str(signature).split('|'):
            key, sep, value = field.strip().partition('=')
            if sep and key in ('getMachineBrand', 'getBrandOEM', 'BoxInfo.brand', 'BoxInfo.machinebrand') and (_normalise(value) == 'octagon'):
                return False
    legacy = {'solo', 'solo2', 'solose', 'solosev2', 'uno', 'duo', 'duo2', 'ultimo', 'zero'}
    for field in str(signature).split('|'):
        key, separator, value = field.strip().partition('=')
        value = _normalise(value)
        if separator and key == '/proc/stb/info/vumodel' and (value in legacy):
            return True
        if separator and key in ('getBoxType', 'getMachineBuild', 'getMachineMake', 'BoxInfo.model', 'BoxInfo.machinebuild') and value.startswith('vu') and (value[2:] in legacy):
            return True
    markers = ('vu+', 'vuplus', 'vusolo4k', 'solo4k', 'vuuno4k', 'uno4k', 'vuuno4kse', 'uno4kse', 'vuultimo4k', 'ultimo4k', 'vuduo4k', 'duo4k', 'vuduo4kse', 'duo4kse', 'vuzero4k', 'zero4k')
    if any((_normalise(marker) in ident for marker in markers)):
        return True
    vu_brand = any((x in ident for x in ('machinebrandvu', 'brandvu', 'oemvu', 'brandvutplus', 'vuplus')))
    vu_4k_model = any((x in ident for x in ('solo4k', 'uno4k', 'ultimo4k', 'duo4k', 'zero4k')))
    return bool(vu_brand and vu_4k_model)

def needs_single_service_audio():
    """Compatibility flag for legacy/remux callers on Vu+ hardware."""
    return is_vuplus()

def preferred_local_service_type():
    """Prefer ExtePlayer3 on Vu+ when installed; otherwise native 4097."""
    if is_vuplus() and os.path.isfile('/usr/bin/exteplayer3') and os.access('/usr/bin/exteplayer3', os.X_OK):
        return 5002
    return 4097

def preferred_foreground_service_type():
    """Use ServiceApp/ExtePlayer3 for normal IPTV whenever it is installed."""
    for path in ('/usr/bin/exteplayer3', '/usr/bin/exteplayer3.sh'):
        try:
            if os.path.isfile(path) and os.access(path, os.X_OK):
                return 5002
        except Exception:
            pass
    return 4097

def available_free_service_types():
    available = []
    for kind, paths in ((5002, ('/usr/bin/exteplayer3', '/usr/bin/exteplayer3.sh')),
                        (5001, ('/usr/bin/gstplayer', '/usr/bin/gstplayer2', '/usr/bin/gstplayer_gst-1.0'))):
        if not any(os.path.isfile(path) and os.access(path, os.X_OK) for path in paths):
            continue
        try:
            from enigma import eServiceCenter, eServiceReference
            if eServiceCenter.getInstance().info(eServiceReference(kind, 0, 'http://127.0.0.1/alkuds-check.ts')) is None:
                continue
        except Exception:
            pass
        available.append(kind)
    return tuple(available + [4097])

def selected_free_service_type():
    """Persistent manual player choice for every Free Arabic TV screen."""
    try:
        with open(FREE_PLAYER_FILE, "r") as handle:
            value = int(str(handle.read() or "").strip())
        if value in available_free_service_types():
            return value
    except Exception:
        pass
    preferred = preferred_foreground_service_type()
    return preferred if preferred in available_free_service_types() else 4097

def set_selected_free_service_type(value):
    value = int(value)
    if value not in (5002, 5001, 4097):
        raise ValueError("Unsupported IPTV player")
    if value not in available_free_service_types():
        raise ValueError('The selected IPTV player is not installed or registered; restart the GUI after installation')
    folder = os.path.dirname(FREE_PLAYER_FILE)
    if not os.path.isdir(folder):
        os.makedirs(folder)
    temporary = FREE_PLAYER_FILE + ".tmp"
    with open(temporary, "w") as handle:
        handle.write(str(value))
    os.rename(temporary, FREE_PLAYER_FILE)
    return value

FREE_PLAYER_BEST_FILE = '/etc/enigma2/alkuds/free_player_best.json'
_FREE_PLAYER_LAST = {'type': None}

def set_free_player_auto():
    """Enable probing: the next stream starts with the best known player."""
    try:
        os.unlink(FREE_PLAYER_FILE)
    except Exception:
        pass

def free_player_is_auto():
    """True when no valid manual player was pinned by the user."""
    try:
        with open(FREE_PLAYER_FILE, 'r') as handle:
            text = str(handle.read() or '').strip()
        return not text or int(text) not in (5002, 5001, 4097)
    except Exception:
        return True

def current_free_service_type(default=None):
    """Last player that actually produced playback in this GUI session."""
    value = _FREE_PLAYER_LAST.get('type')
    return value if value in (5002, 5001, 4097) else default

def _normalise_category(category):
    value = str(category or 'Live').strip().lower()
    if value.startswith(('movie', 'film', 'vod', 'cinema')):
        return 'movie'
    if value.startswith(('series', 'episode', 'season')):
        return 'series'
    return 'live'

def _stream_key(stream_url):
    """Host plus extension only; never persist a URL, token or credentials."""
    try:
        text = str(stream_url or '').strip()
        if '://' not in text:
            return ''
        rest = text.split('://', 1)[1]
        host = rest.split('/', 1)[0].split('?', 1)[0].split('#', 1)[0]
        host = host.split('@')[-1].split(':')[0].strip().lower()
        path = '/' + rest.split('/', 1)[1] if '/' in rest else ''
        path = path.split('?', 1)[0].split('#', 1)[0]
        extension = os.path.splitext(path)[1].lower()
        return host + '|' + extension if host else ''
    except Exception:
        return ''

def _read_player_memory():
    try:
        with open(FREE_PLAYER_BEST_FILE, 'r') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _write_player_memory(data):
    try:
        folder = os.path.dirname(FREE_PLAYER_BEST_FILE)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = FREE_PLAYER_BEST_FILE + '.tmp'
        with open(temporary, 'w') as handle:
            json.dump(data, handle)
        os.rename(temporary, FREE_PLAYER_BEST_FILE)
    except Exception:
        pass

def _memory_entry(data, group, key):
    if not key:
        return None
    entry = (data.get(group) or {}).get(key)
    if isinstance(entry, (list, tuple)) and entry:
        try:
            value = int(entry[0])
        except Exception:
            value = None
    else:
        try:
            value = int(entry)
        except Exception:
            value = None
    return value if value in (5002, 5001, 4097) else None

def _learned_free_service_type(category, stream_url):
    data = _read_player_memory()
    key = _stream_key(stream_url)
    value = _memory_entry(data, 'streams', key)
    if value is None:
        value = _memory_entry(data, 'categories', _normalise_category(category))
    return value

def candidate_free_service_types(category='Live', stream_url='', preferred=None):
    """Ordered players for this stream, with every installed player included."""
    available = list(available_free_service_types())
    category = _normalise_category(category)
    try:
        preferred = int(preferred if preferred is not None else selected_free_service_type())
    except Exception:
        preferred = selected_free_service_type()
    if preferred not in available:
        preferred = available[0]
    learned = _learned_free_service_type(category, stream_url)
    if category == 'live':
        heuristic = [5002, 4097, 5001]
    else:
        heuristic = [5002, 5001, 4097]
    key = _stream_key(stream_url)
    if key.endswith('|.m3u8'):
        heuristic = [5002, 4097, 5001] if category == 'live' else [5002, 5001, 4097]
    elif key.endswith(('|.mp4', '|.mkv', '|.avi', '|.mov', '|.webm')):
        heuristic = [5002, 5001, 4097]
    elif key.endswith(('|.ts', '|.m2ts', '|.mts')):
        heuristic = [5002, 4097, 5001]
    order = []

    def add(value):
        try:
            value = int(value)
        except Exception:
            return
        if value in available and value not in order:
            order.append(value)

    if free_player_is_auto():
        add(learned)
        for value in heuristic:
            add(value)
        add(preferred)
    else:
        add(preferred)
        add(learned)
        for value in heuristic:
            add(value)
    for value in available:
        add(value)
    return tuple(order)

def remember_best_free_service_type(service_type, category='Live', stream_url=''):
    """Remember the player that really started this stream/category."""
    try:
        value = int(service_type)
    except Exception:
        return service_type
    if value not in (5002, 5001, 4097):
        return value
    _FREE_PLAYER_LAST['type'] = value
    try:
        now = int(time.time())
        data = _read_player_memory()
        categories = data.get('categories') if isinstance(data.get('categories'), dict) else {}
        streams = data.get('streams') if isinstance(data.get('streams'), dict) else {}
        categories[_normalise_category(category)] = [value, now]
        key = _stream_key(stream_url)
        if key:
            streams[key] = [value, now]
        if len(streams) > 80:
            ordered = sorted(streams.items(), key=lambda pair: pair[1][1] if isinstance(pair[1], (list, tuple)) and len(pair[1]) > 1 else 0)
            streams = dict(ordered[-80:])
        _write_player_memory({'version': 1, 'updated': now, 'categories': categories, 'streams': streams})
    except Exception:
        pass
    return value
