# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""LAN configuration editor. No provider requests or Enigma calls in HTTP workers."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import hashlib
import hmac
from .py2compat import html
from .py2compat import ipaddress
from .py2compat import os
from .py2compat import secrets
from .py2compat import socket
from .py2compat import threading
from .py2compat import time
from .py2compat import http_cookies
SimpleCookie = http_cookies.SimpleCookie
from .py2compat import http_server
BaseHTTPRequestHandler = http_server.BaseHTTPRequestHandler
ThreadingHTTPServer = http_server.ThreadingHTTPServer
from .py2compat import urllib
parse_qs = urllib.parse.parse_qs
urlsplit = urllib.parse.urlsplit
from . import audioconfig
PORT = 8787
LOCK = threading.RLock()
SERVER = None
ERROR = ''
SESSIONS = {}
SLOTS = threading.BoundedSemaphore(8)
KINDS = {'best_audio': u'بيست', 'sat_family': u'سات فاميلي', 'orange_goradio': u'أورانج جو راديو', 'orange_audio': u'أورانج راديو', 'anis_audio': u'أنيس', 'free_audio': u'صوتيات مجانية', 'fox_audio': u'فوكس'}
HOSTS = {'best_audio': 'http://radio.best-audio.org', 'sat_family': 'http://stereofm.live', 'orange_goradio': 'http://goradio.top', 'orange_audio': 'http://radio.orange-audio.top'}

def _interface_addresses():
    result = []
    try:
        import fcntl
        import struct
        for unused, interface in socket.if_nameindex():
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                    raw = fcntl.ioctl(sock.fileno(), 35093, struct.pack('256s', interface[:15].encode()))[20:24]
                    result.append((interface, socket.inet_ntoa(raw)))
            except OSError:
                pass
    except (ImportError, OSError, AttributeError):
        pass
    return result

def lan_ip():
    addresses = _interface_addresses()
    try:
        with open('/proc/net/route') as handle:
            routes = handle.readlines()[1:]
        defaults = [row.split()[0] for row in routes if len(row.split()) > 1 and row.split()[1] == '00000000']
        for interface in defaults:
            for name, ip in addresses:
                if name == interface and (not ipaddress.ip_address(ip).is_loopback):
                    return ip
    except OSError:
        pass
    for name, ip in addresses:
        if not ipaddress.ip_address(ip).is_loopback and ip != '0.0.0.0':
            return ip
    return '127.0.0.1'

def local_addresses():
    return {ip for name, ip in _interface_addresses()} | {'127.0.0.1', 'localhost', '0.0.0.0'}

def start():
    global SERVER, ERROR
    with LOCK:
        if SERVER:
            return True
        try:
            server = Server(('0.0.0.0', PORT), Handler)
            SERVER = server
            ERROR = ''
            threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.3}, daemon=True, name='AlkudsWeb').start()
            return True
        except Exception:
            ERROR = u'تعذر فتح صفحة الإدارة؛ قد يكون البورت مستخدمًا'
            return False

def stop():
    global SERVER
    with LOCK:
        server = SERVER
        SERVER = None
        compat_clear(SESSIONS)
    if server:

        def close():
            server.shutdown()
            server.server_close()
        threading.Thread(target=close, daemon=True).start()

def address():
    return 'http://%s:%d/' % (lan_ip(), PORT)

def banner():
    return address() if start() else ERROR

def show_access(session):
    from .xStaticText import MessageBox
    if start():
        text = u'إدارة الصوتيات عبر المتصفح\n%s\nالبورت: %d\nافتح الرابط مباشرة من هاتف أو حاسوب على نفس الشبكة.' % (address(), PORT)
    else:
        text = ERROR
    session.open(MessageBox, text, MessageBox.TYPE_INFO)

def snapshot():
    with audioconfig.LOCK:
        audioconfig.ensure(audioconfig.PATH, mirror=audioconfig.HDD_PATH)
        with open(audioconfig.PATH, 'rb') as handle:
            raw = handle.read()
        return (hashlib.sha256(raw).hexdigest(), audioconfig.load(audioconfig.PATH))

def update(values):
    with audioconfig.LOCK:
        version, data = snapshot()
        if not hmac.compare_digest(values.get('version', ''), version):
            raise RuntimeError(u'تغير الملف؛ حدّث الصفحة قبل الحفظ')
        kind = values.get('kind', '')
        if kind not in KINDS:
            raise ValueError(u'قسم غير صالح')
        rows = data.setdefault(kind, [])
        index = int(values.get('index', '-1'))
        if index < -1 or index >= len(rows):
            raise ValueError(u'اشتراك غير موجود')
        if values.get('action') == 'delete':
            if index < 0:
                raise ValueError(u'اشتراك غير موجود')
            rows.pop(index)
        else:
            if index < 0 and len(rows) >= 100:
                raise ValueError(u'تم بلوغ الحد الأقصى للاشتراكات')
            old = rows[index] if index >= 0 else {}
            name = values.get('name', '').strip() or old.get('name') or KINDS[kind]
            if len(name) > 100 or any((c in name for c in '\r\n\x00')):
                raise ValueError(u'اسم غير صالح')
            entry = {'name': name}
            mode = values.get('mode', 'token')
            if kind in ('anis_audio', 'orange_audio'):
                mode = 'token'
            if kind in ('free_audio', 'fox_audio'):
                mode = 'url'
            if mode == 'account':
                if kind not in ('best_audio', 'sat_family', 'orange_goradio'):
                    raise ValueError(u'نوع بيانات غير صالح')
                for field in ('username', 'password'):
                    entry[field] = values.get(field, '').strip() or old.get(field, '')
                if not entry['username'] or not entry['password']:
                    raise ValueError(u'أدخل اسم المستخدم وكلمة المرور')
                entry['token'] = entry['username'] + '_' + entry['password']
                entry['url'] = HOSTS[kind]
            elif mode == 'token':
                token = values.get('token', '').strip() or old.get('token', '')
                if not token:
                    raise ValueError(u'أدخل التوكن')
                entry['token'] = token
                entry['url'] = HOSTS.get(kind, '')
            elif mode == 'url':
                url = values.get('url', '').strip() or old.get('url', '')
                parts = urlsplit(url)
                if parts.scheme not in ('http', 'https') or not parts.hostname or parts.username:
                    raise ValueError(u'أدخل رابط بث أو قائمة صحيحًا')
                entry['url'] = url
            else:
                raise ValueError(u'نوع بيانات غير صالح')
            if any((len(str(value)) > 4096 or any((c in str(value) for c in '\r\n\x00')) for value in entry.values())):
                raise ValueError(u'قيمة غير صالحة')
            if index < 0:
                rows.append(entry)
            else:
                rows[index] = entry
        audioconfig.save(data, audioconfig.PATH, audioconfig.HDD_PATH)
    if kind not in ('anis_audio', 'fox_audio'):
        try:
            from .remote_backup import backup_audio_config
            backup_audio_config()
        except Exception:
            pass

class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def process_request(self, request, client_address):
        if not SLOTS.acquire(False):
            request.close()
            return
        try:
            super(Server, self).process_request(request, client_address)
        except Exception:
            SLOTS.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super(Server, self).process_request_thread(request, client_address)
        finally:
            SLOTS.release()

    def handle_error(self, *args):
        pass

class Handler(BaseHTTPRequestHandler):
    server_version = 'Alkuds'

    def setup(self):
        super(Handler, self).setup()
        self.connection.settimeout(5)

    def log_message(self, *args):
        pass

    def local_hosts(self):
        # Accept the address the browser used, even when a router or a
        # reverse proxy changes the port in the Host header.
        hosts = {str(host).lower() for host in local_addresses()}
        hosts.discard('0.0.0.0')
        for address in (self.server.server_address[0], self.connection.getsockname()[0]):
            hosts.add(str(address).lower())
        return hosts

    def allowed(self):
        try:
            address = self.client_address[0]
            # The bundled Python 2 ipaddress backport accepts text only.
            if not isinstance(address, unicode):
                address = address.decode('ascii')
            peer = ipaddress.ip_address(address)
            if not (peer.is_private or peer.is_loopback):
                return False
            authority = self.headers.get('Host', '').strip()
            if not authority:
                return False
            parsed = urlsplit('//' + authority)
            return bool(parsed.hostname) and parsed.hostname.lower() in self.local_hosts() and (not parsed.username)
        except Exception:
            return False

    def same_origin(self):
        # The page may be opened over HTTP or HTTPS and through a proxy that
        # changes the port. Compare only the host, never the exact URL.
        origin = self.headers.get('Origin')
        if not origin or origin == 'null':
            return True
        try:
            parsed = urlsplit(origin)
            if parsed.scheme not in ('http', 'https') or parsed.username or (not parsed.hostname):
                return False
            name = parsed.hostname.lower()
            if name in self.local_hosts():
                return True
            host = urlsplit('//' + self.headers.get('Host', '').strip()).hostname
            return bool(host) and name == host.lower()
        except Exception:
            return False

    def respond(self, code, body='', cookie=None, location=None):
        raw = body.encode('utf8')
        self.send_response(code)
        for key, value in {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Frame-Options': 'DENY', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'", 'Content-Length': str(len(raw))}.items():
            self.send_header(key, value)
        if cookie:
            self.send_header('Set-Cookie', cookie)
        if location:
            self.send_header('Location', location)
        self.end_headers()
        self.wfile.write(raw)

    def session(self):
        try:
            cookie = SimpleCookie(self.headers.get('Cookie', ''))
            key = cookie['alkuds'].value
            with LOCK:
                now = time.time()
                for stale in [k for k, v in SESSIONS.items() if v['until'] < now]:
                    SESSIONS.pop(stale, None)
                session = SESSIONS.get(key)
                if session and session['ip'] == self.client_address[0]:
                    return session
        except Exception:
            pass
        return None

    def page(self, body):
        return u'<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>القدس — إدارة الصوتيات</title><style>body{background:#160c2a;color:#fff;font:18px sans-serif;max-width:920px;margin:auto;padding:20px}section,fieldset{background:#291543;padding:16px;margin:18px 0;border:1px solid #8050ca;border-radius:12px}input,select,button{font:inherit;padding:9px;max-width:92%;margin:5px}input{direction:ltr}button{background:#7040bd;color:white;border:0;border-radius:6px}label{display:block}a{color:#dfbaff}.row{border-bottom:1px solid #8050ca;padding:9px}</style><h1>القدس — إدارة الصوتيات</h1>' + body + '</html>'

    def do_GET(self):
        if not self.allowed():
            self.respond(403, self.page(u'عنوان الدخول غير صالح'))
            return
        if self.path != '/':
            self.respond(404)
            return
        session = self.session()
        cookie = None
        if not session:
            with LOCK:
                if len(SESSIONS) >= 32:
                    SESSIONS.pop(next(iter(SESSIONS)))
                key = secrets.token_hex(24)
                session = {'csrf': secrets.token_hex(24), 'until': time.time() + 1800, 'ip': self.client_address[0]}
                SESSIONS[key] = session
                cookie = 'alkuds=' + key + '; Path=/; HttpOnly; SameSite=Strict'
        try:
            self.respond(200, self.render(session), cookie=cookie)
        except Exception:
            self.respond(503, self.page(u'تعذر قراءة ملف الصوتيات. تحقق من صياغة الملف والمساحة المتاحة.'))

    def do_POST(self):
        if not self.allowed():
            self.respond(403, self.page(u'عنوان الدخول غير صالح. افتح الصفحة من عنوان الرسيفر على الشبكة المحلية.'))
            return
        if not self.same_origin():
            self.respond(403, self.page(u'طلب الحفظ لم يأت من صفحة القدس. أعد فتح الصفحة ثم حاول مجددًا.'))
            return
        try:
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/x-www-form-urlencoded':
                raise ValueError()
            length = int(self.headers.get('Content-Length', '0'))
            if length < 1 or length > 32768:
                raise ValueError()
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError()
            fields = parse_qs(raw.decode('utf8'), max_num_fields=30)
            values = {k: v[0] for k, v in fields.items() if len(v) == 1}
        except Exception:
            self.respond(400)
            return
        session = self.session()
        if not session:
            with LOCK:
                session = next((item for item in SESSIONS.values() if item['ip'] == self.client_address[0] and item['until'] >= time.time() and hmac.compare_digest(values.get('csrf', '').encode('utf8'), item['csrf'].encode('utf8'))), None)
        if not session or not hmac.compare_digest(values.get('csrf', '').encode('utf8'), session['csrf'].encode('utf8')):
            self.respond(403, self.page(u'انتهت صلاحية الصفحة؛ <a href="/">افتح الصفحة مجددًا</a>'))
            return
        try:
            if self.path == '/audio':
                update(values)
            else:
                self.respond(404)
                return
        except RuntimeError:
            self.respond(409, self.page(u'تغير الملف؛ <a href="/">حدّث الصفحة وأعد المحاولة</a>'))
            return
        except ValueError as error:
            self.respond(400, self.page(html.escape(str(error)) + u' <a href="/">رجوع</a>'))
            return
        except Exception:
            self.respond(500, self.page(u'تعذر الحفظ؛ تحقق من الملف ومساحة التخزين.'))
            return
        self.respond(303, location='/')

    def render(self, session):
        esc = html.escape
        version, data = snapshot()
        csrf = session['csrf']

        def hidden(name, value):
            return '<input type="hidden" name="%s" value="%s">' % (name, esc(str(value), quote=True))

        def form(action):
            return '<form method="post" action="' + action + '">' + hidden('csrf', csrf)
        out = u'<p>الحفظ يحدّث النسخة الداخلية ونسخة الهارد المتاحة. افتح قائمة الصوتيات مجددًا لتظهر التعديلات. القيم السرية لا تُعرض؛ اتركها فارغة عند التعديل للاحتفاظ بها.</p>'
        out += '<nav>' + ''.join(('<a href="#' + kind + '">' + title + '</a> &nbsp; ' for kind, title in KINDS.items())) + '</nav>'
        for kind, title in KINDS.items():
            out += '<section id="' + kind + '"><h2>' + title + '</h2>'
            if kind in HOSTS:
                out += '<p dir="ltr">' + HOSTS[kind] + '</p>'
            rows = data.get(kind, [])
            for index, entry in list(enumerate(rows)) + [(-1, {})]:
                out += '<details' + (' open' if index < 0 else '') + '><summary>' + (u'إضافة اشتراك' if index < 0 else esc(entry.get('name') or title)) + '</summary>'
                out += form('/audio') + hidden('version', version) + hidden('kind', kind) + hidden('index', index)
                out += u'<label>الاسم<input name="name" maxlength="100" value="' + esc(entry.get('name', ''), quote=True) + '"></label>'
                if kind in ('best_audio', 'sat_family', 'orange_goradio'):
                    mode = 'account' if entry.get('username') else 'token'
                    out += u'<label>طريقة الإضافة<select name="mode">' + ''.join(('<option value="' + v + '"' + (' selected' if v == mode else '') + '>' + t + '</option>' for v, t in [('account', u'اسم مستخدم وكلمة مرور'), ('token', u'توكن')])) + '</select></label>'
                    out += u'<label>اسم المستخدم<input name="username" autocomplete="off"></label><label>كلمة المرور<input type="password" name="password" autocomplete="new-password"></label>'
                if kind in ('free_audio', 'fox_audio'):
                    out += u'<label>رابط البث أو القائمة<input type="password" name="url" autocomplete="new-password"></label>'
                else:
                    out += u'<label>التوكن<input type="password" name="token" autocomplete="new-password"></label>'
                out += u'<button name="action" value="save">حفظ</button></form>'
                if index >= 0:
                    out += form('/audio') + hidden('version', version) + hidden('kind', kind) + hidden('index', index) + hidden('action', 'delete') + u'<label><input type="checkbox" required>تأكيد حذف هذا الاشتراك</label><button>حذف الاشتراك</button></form>'
                out += '</details>'
            out += '</section>'
        return self.page(out)
