# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Laroza public catalogue, grouped series and selected-player resolution."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .py2compat import os
from .py2compat import threading
from .py2compat import requests
from . import arabseed as a
try:
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
    urlencode = urllib.parse.urlencode
    parse_qs = urllib.parse.parse_qs
except ImportError:
    from urlparse import urljoin, urlparse, parse_qs
    from urllib import urlencode
BASE = 'https://larroza.beer/'
CATALOGUE_HOSTS = ('larroza.beer', 'www.larroza.beer', 'larozza.study', 'www.larozza.study', 'llaroza.skin', 'www.llaroza.skin', 'llaroza.hair', 'www.llaroza.hair')
KNOWN_HOSTS = set(CATALOGUE_HOSTS)
ORIGIN_LOCK = threading.Lock()
LOG_FILE = '/tmp/alkuds_laroza.log'
LOG_LOCK = threading.Lock()

def _log(stage, detail):
    try:
        with LOG_LOCK:
            if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 65536:
                os.remove(LOG_FILE)
            with open(LOG_FILE, 'a') as handle:
                handle.write('%s %s\n' % (stage, detail))
    except Exception:
        pass

def _video_link(url):
    parsed = urlparse(url)
    return parsed.path.endswith('/video.php') and bool(parse_qs(parsed.query).get('vid'))
SECTIONS = [('browse', u'تصفح الموقع', ''), ('foreign_movies', u'أفلام أجنبية', 'all_movies_13'), ('arabic_movies', u'أفلام عربية', 'arabic-movies33'), ('turkish_movies', u'أفلام تركية', '8-aflam3isk'), ('indian_movies', u'أفلام هندية', 'indian-movies9'), ('asian_movies', u'أفلام آسيوية', '6-asian-movies'), ('anime_movies', u'أفلام أنمي', 'anime-movies-7'), ('dubbed_movies', u'أفلام مدبلجة', '7-aflammdblgh'), ('arabic_series', u'مسلسلات عربية', 'arabic-series46'), ('turkish_series', u'مسلسلات تركية', 'turkish-3isk-seriess47'), ('foreign_series', u'مسلسلات أجنبية', 'english-series10'), ('indian_series', u'مسلسلات هندية', '11indian-series'), ('asian_series', u'مسلسلات آسيوية', '6-asya'), ('anime_series', u'مسلسلات أنمي', '6-anime-series'), ('programs', u'برامج تلفزيونية', 'tv-programs12'), ('plays', u'مسرحيات', 'masrh-5')]
SECTION_MAP = dict(((key, (name, cat)) for key, name, cat in SECTIONS))
BRAND_HOST = re.compile('^(?:[a-z0-9-]+\\.)*(?:llaroza|larozaa|larroza|larozza|laroza)[a-z0-9-]*\\.[a-z]{2,24}$')

def _trusted_host(host):
    """Catalogue mirrors plus Laroza-branded hosts or subdomains of a known mirror.

    Detail and watch pages can live on another mirror or a subdomain; only the
    exact catalogue mirrors were accepted before, which broke playback."""
    host = (host or '').lower().rstrip('.')
    if not host:
        return False
    if host in KNOWN_HOSTS or BRAND_HOST.match(host):
        return True
    labels = host.split('.')
    return len(labels) > 2 and any((known.split('.')[-2:] == labels[-2:] for known in KNOWN_HOSTS))

def _local(url):
    url = urljoin(BASE, url)
    parsed = urlparse(url)
    host = (parsed.hostname or '').lower()
    if parsed.scheme not in ('http', 'https') or not _trusted_host(host):
        _log('rejected_address', host or 'unknown')
        raise ValueError('Unexpected Laroza catalogue address')
    if host in KNOWN_HOSTS:
        return urljoin(BASE, parsed.path.lstrip('/') + ('?' + parsed.query if parsed.query else ''))
    return url.split('#', 1)[0]

def _accept_redirect(page_url, html):
    global BASE
    parsed = urlparse(page_url)
    host = (parsed.hostname or '').lower()
    if parsed.scheme not in ('http', 'https') or not _trusted_host(host):
        _log('rejected_redirect', host or 'unknown')
        raise ValueError('Unexpected Laroza catalogue address')
    if host not in KNOWN_HOSTS:
        branded_host = re.match('^(?:www\\.)?(?:llaroza|larozaa|larroza|larozza|laroza)\\.[a-z]{2,24}$', host)
        title = re.search('<title[^>]*>(.*?)</title>', html, re.I | re.S)
        branded_page = title and u'لاروزا' in title.group(1)
        catalogue_page = any((marker in html for marker in ('category.php', 'video.php', 'newvideos', 'moslslat')))
        if branded_host and branded_page and catalogue_page:
            with ORIGIN_LOCK:
                KNOWN_HOSTS.add(host)
                BASE = '%s://%s/' % (parsed.scheme, parsed.netloc)
            _log('origin', host)
        else:
            _log('branded_host_accepted', host)
        return
    with ORIGIN_LOCK:
        BASE = '%s://%s/' % (parsed.scheme, parsed.netloc)
    _log('origin', host)

def _get(session, url, referer=BASE):
    session.verify = False
    try:
        html, page_url = a._get(session, _local(url), _local(referer))
        _accept_redirect(page_url, html)
        _log('page', '%s bytes=%d' % (urlparse(page_url).path, len(html)))
        return (html, page_url)
    except Exception as error:
        response = getattr(error, 'response', None)
        _log('request_failed', '%s status=%s' % (type(error).__name__, getattr(response, 'status_code', 'unknown')))
        raise

def groups():
    return [{'name': name, 'section': key} for key, name, cat in SECTIONS]

def fetch_items(section, page=1, query='', order='latest', grouped=True):
    name, cat = SECTION_MAP[section]
    values = {'page': int(page)}
    if query:
        path = 'search.php'
        values['keywords'] = query.encode('utf-8')
    elif cat:
        path = 'category.php'
        values['cat'] = cat
    else:
        path = 'newvideos.php'
    if order in ('az', 'za'):
        values.update(sortby='title', order='ASC' if order == 'az' else 'DESC')
    session = requests.Session()
    try:
        html, page_url = _get(session, path + '?' + urlencode(values))
    finally:
        session.close()
    root = a.Document(html).root
    entries, seen = ([], set())
    for block in root.find(css='thumbnail'):
        links = [x for x in block.find('a') if _video_link(urljoin(page_url, x.attrs.get('href', '')))]
        if not links:
            continue
        link = links[0]
        url = _local(urljoin(page_url, link.attrs['href']))
        if url in seen:
            continue
        seen.add(url)
        title = (link.attrs.get('title') or link.text()).strip()
        if not title:
            title_links = [x for x in links if x.attrs.get('title') or x.text()]
            if title_links:
                title = (title_links[0].attrs.get('title') or title_links[0].text()).strip()
        if not title:
            continue
        if section.endswith('_movies') and title.startswith(u'مسلسل'):
            continue
        if section.endswith('_series') and title.startswith(u'فيلم'):
            continue
        images = block.find('img')
        attrs = images[0].attrs if images else {}
        image = attrs.get('data-original-thumbnail') or attrs.get('data-echo') or attrs.get('src', '')
        entries.append({'url': url, 'name': title, 'image': urljoin(page_url, image), 'section': section, 'category': name})
    pages = [int(page)]
    for link in root.find('a'):
        params = parse_qs(urlparse(link.attrs.get('href', '')).query)
        if params.get('page', [''])[0].isdigit():
            pages.append(int(params['page'][0]))
    if grouped:
        entries = a.group_series(entries)
    _log('catalogue', '%s page=%d entries=%d grouped=%d' % (section, int(page), len(entries), bool(grouped)))
    return {'entries': entries, 'page': int(page), 'last_page': max(pages), 'total': len(entries)}

def seasons(item):
    row = dict(item)
    row.update(name=u'حلقات المسلسل', series_title=item['name'], episode_query=item['name'])
    return [row]

def episodes(item, page=1):
    result = fetch_items(item['section'], page, item['episode_query'], grouped=False)
    result['entries'] = [dict(x, is_series=False, series_title=item['series_title']) for x in result['entries'] if a.series_name(x['name']).lower() == item['episode_query'].lower()]
    result['entries'].sort(key=lambda x: int((re.search(u'(?:الحلقة|حلقة)\\s*(\\d+)', x['name']) or re.search('(\\d+)', '0')).group(1)))
    _log('episodes', 'page=%d entries=%d' % (int(page), len(result['entries'])))
    return result

def servers(item):
    session = requests.Session()
    try:
        html, detail_url = _get(session, item['url'])
        root = a.Document(html).root
        play_url = next((x.attrs['href'] for x in root.find('a') if 'play.php?vid=' in x.attrs.get('href', '')), '')
        if not play_url:
            raise RuntimeError('Laroza did not return a watch page')
        html, page_url = _get(session, urljoin(detail_url, play_url), detail_url)
        root = a.Document(html).root
        result, seen = ([], set())
        for node in root.find():
            url = node.attrs.get('data-embed-url')
            if url and url not in seen:
                seen.add(url)
                row = dict(item)
                row.update(name=node.text() or u'مشغل', title=item['name'], server_url=urljoin(page_url, url), referer=page_url)
                result.append(row)
        if not result:
            raise RuntimeError('Laroza did not return any players')
        return result
    finally:
        session.close()

def resolve(item):
    from .freeproviders import hls_variant_streams
    session = requests.Session()
    try:
        media = a._resolve_page(session, item['server_url'], item['referer'])
        variants = []
        for stream in media:
            variants.extend(hls_variant_streams({'url': stream['url'], 'relay': True, 'mediatype': stream['mediatype'], 'subtitles': stream.get('subtitles') or [], 'quality': stream.get('quality', 'Original'), 'headers': {'User-Agent': a.UA, 'Referer': a._referer(stream['referer'])}}))
        if not variants:
            raise RuntimeError('This player is unavailable or requires browser verification. Choose another player.')
        result = dict(item)
        result.update(name=item.get('title', item['name']), streams=variants)
        return result
    finally:
        session.close()
