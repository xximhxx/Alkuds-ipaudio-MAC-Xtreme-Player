# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import plasmatv
from .generaltvui import Alkuds_GeneralTV_Browser
from .fajershowui import Alkuds_FajerShow_Qualities

class Alkuds_PlasmaTV_Browser(Alkuds_GeneralTV_Browser):
    provider = plasmatv
    site_name = u'بلازما Plasma 4K'

    def _start_resolved(self, item):
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']}, item['name'], 'Live', item.get('category', ''), item.get('image', ''), '')
