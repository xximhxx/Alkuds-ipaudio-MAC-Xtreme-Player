# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""FLASHBACK BETA3: raw recording + native FILE PVR, never native timeshift.

Native calls are made exclusively by this main-loop controller. No drift guard,
remux, transcoder, PTS rewriting or global audio mute is used for the video.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import service_reference, gui_text
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .py2compat import time
from enigma import eTimer, eServiceReference, iPlayableService
from .flashbackrecorder import RawRecorder, settings, native_dvb_reference, log
_ACTIVE = None

def current_reference(session):
    ref = session.nav.getCurrentlyPlayingServiceReference()
    return ref.toString() if ref else ''

def owned_service(session):
    return bool(_ACTIVE and _ACTIVE.session is session and _ACTIVE.owns_current())

def video_only_service(session):
    owner = _ACTIVE
    return bool(owner and owner.session is session and not owner.closed
                and owner.active and owner.owns_current()
                and getattr(getattr(owner.recorder, 'video_filter', None), 'ready', False))

def audio_handoff_pending(session):
    """A bounded native PVR opening, never a blanket audio watchdog bypass."""
    owner = _ACTIVE
    return bool(owner and owner.session is session and not owner.closed
                and owner.active and owner.owns_current()
                and owner.state in ('OPENING', 'SEEKING')
                and not owner.file_audio_ready
                and time.monotonic() < owner.deadline)

def shutdown():
    if _ACTIVE:
        _ACTIVE.stop(restore=False, stop_owned=True)

class RawPVRSession(object):

    def __init__(self, session, on_error):
        self.session, self.on_error = (session, on_error)
        self.recorder = None
        self.live_ref = None
        self.file_ref = None
        self.state = 'LIVE'
        self.target_ms = 0
        self.started = 0
        self.deadline = 0
        self.pending_seek = False
        self.stopping = False
        self.closed = False
        self.switching = False
        self.eof = False
        self.hold_media = 0
        self.hold_gap = 0
        self.audio_due = 0
        self.cleanup_after = 0
        self.empty_since = None
        self.file_paused = False
        self.file_audio_ready = False
        self.last_native_wait = None
        try:
            from .receivercompat import is_vuplus
            self.vu_reader_check = bool(is_vuplus())
        except Exception:
            self.vu_reader_check = False
        self.reader_probe = None
        self.timer = eTimer()
        self.audio_recovery_timer = eTimer()
        try:
            self.audio_recovery_connection = self.audio_recovery_timer.timeout.connect(self._recover_audio)
        except Exception:
            self.audio_recovery_timer.callback.append(self._recover_audio)
        try:
            self.connection = self.timer.timeout.connect(self._tick_safe)
        except Exception:
            self.timer.callback.append(self._tick_safe)
        self.hooked = False
        events = getattr(session.nav, 'event', None)
        if isinstance(events, list):
            events.append(self._event)
            self.hooked = True

    @property
    def active(self):
        return self.recorder is not None and (not self.stopping)

    def owns_current(self):
        if self.file_ref is None:
            return False
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            return bool(ref and ref.getPath() == self.recorder.storage.path)
        except Exception:
            return False

    def _event(self, event):
        try:
            if self.switching or not self.active:
                return
            if event == iPlayableService.evEOF and self.owns_current():
                self.eof = True
        except Exception:
            log('ignored event callback error')

    def apply(self, milliseconds):
        global _ACTIVE
        requested = max(0, min(120000, int(milliseconds)))
        if not requested:
            self.stop(restore=True)
            return
        if self.stopping:
            raise RuntimeError('Previous raw buffer is still closing; retry after cleanup')
        self.target_ms = max(500, requested)
        if self.active:
            self.pending_seek = True
            self.deadline = time.monotonic() + self.target_ms / 1000.0 + 20
            if self.owns_current():
                self.state = 'SEEKING'
            return
        if _ACTIVE and _ACTIVE is not self:
            raise RuntimeError('Another beta buffer still owns the recorder')
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        if not ref or not native_dvb_reference(ref.toString()):
            raise RuntimeError('Tune a native satellite channel first')
        service = self.session.nav.getCurrentService()
        ts = service.timeshift() if service and callable(getattr(service, 'timeshift', None)) else None
        if ts and (ts.isTimeshiftActive() or (callable(getattr(ts, 'isTimeshiftEnabled', None)) and ts.isTimeshiftEnabled())):
            raise RuntimeError('Stop image-native timeshift before starting this independent beta')
        config = settings()
        from .receivercompat import is_dreambox_arm
        config['video_only'] = bool(is_dreambox_arm())
        if config['video_only']:
            log('DREAMOS23 video-only raw buffer enabled; video/PCR retained, native PVR audio omitted')
        try:
            from Components.config import config as image_config
            paths = []
            # DreamOS ConfigSubsection raises KeyError for absent settings,
            # whereas other images raise AttributeError. These preferences
            # are optional; the recorder still scans mounted storage.
            for section, option in (('timeshift', 'path'), ('usage', 'timeshift_path')):
                try:
                    path = getattr(getattr(image_config, section), option).value
                    if path and path not in paths:
                        paths.append(path)
                except (KeyError, AttributeError):
                    continue
            config['preferred_paths'] = paths
        except ImportError:
            pass
        self.live_ref = service_reference(ref.toString())
        self.recorder = RawRecorder(ref.toString(), None, config)
        self.started = time.monotonic()
        self.deadline = self.started + self.target_ms / 1000.0 + 25
        self.file_ref = None
        self.state = 'RECORDING'
        self.pending_seek = True
        self.eof = False
        _ACTIVE = self
        try:
            self.recorder.start()
        except Exception:
            self.recorder = None
            _ACTIVE = None
            self.state = 'LIVE'
            raise
        self.timer.start(250, False)
        log('BETA raw recorder started; main-thread native timeshift untouched')

    def _service(self):
        return self.session.nav.getCurrentService()

    def timeline(self):
        if not self.owns_current():
            return None
        service = self._service()
        seek = service.seek() if service else None
        if seek is None:
            return None
        length, position = (seek.getLength(), seek.getPlayPosition())
        if length and position and (not length[0]) and (not position[0]) and (length[1] > 0) and (0 <= position[1] <= length[1]):
            return (seek, length[1], position[1])
        return None

    def actual_delay_ms(self):
        timeline = self.timeline()
        return (timeline[1] - timeline[2]) / 90.0 if timeline else None

    def _no_audio(self, wait_for_decoder=False):
        from .backgroundaudio import _set_enigma_service_audio, _is_dreambox_arm_receiver
        if video_only_service(self.session):
            return _set_enigma_service_audio(self.session, False)
        if wait_for_decoder and _is_dreambox_arm_receiver():
            from .backgroundaudio import _dreamos_borrow_audio_fd
            try:
                descriptor = _dreamos_borrow_audio_fd()
            except RuntimeError as error:
                if str(error) == 'DreamOS main audio descriptor was not found':
                    return self._native_wait('audio-decoder', 'opening')
                raise
            else:
                os.close(descriptor)
        if not _set_enigma_service_audio(self.session, False):
            raise RuntimeError('PVR service cannot release its audio PID; beta refuses global mute')
        return True

    def _pause_file(self):
        if not self.owns_current():
            return False
        if self.file_paused:
            return True
        service = self._service()
        pause = service.pause() if service else None
        if pause is None:
            return self._native_wait('pause-interface', None)
        result = pause.pause()
        if result not in (None, 0):
            return self._native_wait('pause', result)
        self.file_paused = True
        self.last_native_wait = None
        self.audio_due = time.monotonic() + 0.4
        return True

    def _native_wait(self, operation, result):
        marker = (operation, result)
        if marker != self.last_native_wait:
            log('PVR not ready yet: ' + operation + ' result=' + str(result) + '; waiting within transition deadline')
            self.last_native_wait = marker
        return False

    def _resume_file(self):
        service = self._service()
        pause = service.pause() if service else None
        if pause is None:
            return self._native_wait('resume-interface', None)
        result = pause.unpause()
        if result not in (None, 0):
            return self._native_wait('resume', result)
        self.file_paused = False
        self.last_native_wait = None
        try:
            from Screens.InfoBar import InfoBar
            bar = InfoBar.instance
            if bar is not None:
                bar.seekstate = bar.SEEK_STATE_PLAY
        except Exception:
            pass
        self.audio_due = time.monotonic() + 0.4
        return True

    def _play(self, reference, force=False):
        self.switching = True
        try:
            try:
                result = self.session.nav.playService(reference, forceRestart=force, adjust=False)
            except TypeError:
                result = self.session.nav.playService(reference)
            if result is False or (isinstance(result, int) and (not isinstance(result, bool)) and (result != 0)):
                raise RuntimeError('Receiver rejected service playback')
        finally:
            self.switching = False

    def _open_file(self, reopen=False):
        storage = self.recorder.storage
        if not storage or not os.path.isfile(storage.path):
            raise RuntimeError('Raw buffer file disappeared')
        reference = service_reference(1, 0, storage.path)
        reference.setName(gui_text('Alkuds FLASHBACK BETA3'))
        self.file_ref = reference
        self.state = 'OPENING'
        self.deadline = time.monotonic() + 12
        self._no_audio()
        self.file_audio_ready = False
        self._play(reference, force=reopen)
        if self.owns_current():
            self.file_audio_ready = self._no_audio(wait_for_decoder=True)
        self.file_paused = False
        self.last_native_wait = None
        self.reader_probe = None
        self.pending_seek = True
        self.state = 'SEEKING'
        self.audio_due = time.monotonic() + 0.4 if self.file_audio_ready else 0
        log('PVR opened from raw file; source socket remains open')

    def _seek_target(self):
        # DreamOS creates the PVR decoder asynchronously after playService.
        # No pause/seek/resume until its own audio STOP has been acknowledged.
        if not self.file_audio_ready:
            self.file_audio_ready = self._no_audio(wait_for_decoder=True)
            if not self.file_audio_ready:
                return False
        if not self.pending_seek:
            if not self._resume_file():
                return False
            self.eof = False
            self.state = 'PLAYING'
            return True
        timeline = self.timeline()
        if timeline is None:
            return False
        seek, length, position = timeline
        required = int(self.target_ms * 90)
        if length < required + 9000:
            return False
        if not self._pause_file():
            return False
        result = seek.seekTo(max(0, length - required))
        if result not in (None, 0):
            return self._native_wait('seek', result)
        self.pending_seek = False
        if not self._resume_file():
            return False
        self.eof = False
        self.state = 'PLAYING'
        log('one explicit/rebuffer file seek issued; requested_ms=' + str(self.target_ms))
        return True

    def _reader_eof_confirmed(self, now, snapshot):
        if not self.vu_reader_check:
            return self.eof
        if not self.eof:
            self.reader_probe = None
            return False
        position = None
        try:
            service = self._service()
            seek = service.seek() if service else None
            value = seek.getPlayPosition() if seek else None
            if value and (not value[0]) and (value[1] >= 0):
                position = value[1]
        except Exception:
            pass
        if position is None:
            self.reader_probe = None
            return False
        if self.reader_probe is None:
            self.reader_probe = (now, position, snapshot['bytes'])
            log('Vu+ COUNTER2 EOF check started; decoder_pts=%d captured_bytes=%d' % (position, snapshot['bytes']))
            return False
        since, previous, byte_count = self.reader_probe
        if position != previous:
            self.eof = False
            self.reader_probe = None
            log('Vu+ COUNTER2 EOF ignored: decoder still advancing; no pause, seek or reopen')
            return False
        if now - since < 3.0:
            return False
        log('Vu+ COUNTER2 stopped decoder confirmed; stopped_s=%.2f growth_bytes=%d' % (now - since, snapshot['bytes'] - byte_count))
        self.reader_probe = None
        return True

    def _tick_safe(self):
        try:
            self._tick()
        except Exception as error:
            log('session error: ' + str(error))
            try:
                self.stop(restore=True)
            except Exception:
                log('stop after session error failed')
            self._notify(str(error))

    def _notify(self, message):
        if not self.closed:
            self.audio_recovery_timer.start(650, True)
        try:
            self.on_error(message)
        except Exception:
            log('could not display beta error')

    def _recover_audio(self):
        self.audio_recovery_timer.stop()
        if self.closed:
            return
        try:
            from .backgroundaudio import recover_video_delay_audio
            recover_video_delay_audio(recover_sink=True)
            log('audio-only recovery after beta startup/transition error')
        except Exception as error:
            log('audio-only recovery failed: ' + str(error))

    def _tick(self):
        if self.stopping:
            self._cleanup()
            return
        if not self.active:
            self.timer.stop()
            return
        now = time.monotonic()
        snapshot = self.recorder.snapshot()
        current = current_reference(self.session)
        if not current:
            if self.empty_since is None:
                self.empty_since = now
            if now - self.empty_since > 3:
                self.stop(restore=False)
                return
        else:
            self.empty_since = None
        if self.state == 'RECORDING':
            if current and current != self.live_ref.toString():
                self.stop(restore=False)
                return
        elif not self.owns_current():
            if self.state in ('OPENING', 'SEEKING') and now < self.deadline and (current in ('', self.live_ref.toString())):
                return
            self.stop(restore=False)
            return
        if snapshot['error']:
            raise RuntimeError(snapshot['error'])
        if self.state == 'RECORDING':
            if now > self.deadline:
                raise RuntimeError('No usable clear-video/PCR buffer before startup timeout; check local 8001 streaming')
            if snapshot['media_ms'] >= self.target_ms + 300 and snapshot['clear_video'] and (now - snapshot['last_progress'] < 2):
                self._open_file()
        elif self.state == 'SEEKING':
            if now > self.deadline:
                raise RuntimeError('PVR decoder/timeline was not ready within 12 seconds; last operation=' + str(self.last_native_wait))
            self._seek_target()
        elif self.state == 'PLAYING':
            gap = self.actual_delay_ms()
            if self._reader_eof_confirmed(now, snapshot) or (not self.vu_reader_check and gap is not None and (gap < 400) and (now - snapshot['last_progress'] > 0.8)):
                self.hold_media = snapshot['media_ms']
                self.hold_gap = gap or 0
                self._pause_file()
                self.state = 'REFILLING'
                log('file underflow: waiting for media refill, no automatic drift correction')
        elif self.state == 'REFILLING':
            if snapshot['media_ms'] - self.hold_media >= max(300, self.target_ms - self.hold_gap) and now - snapshot['last_progress'] < 2:
                if self.eof:
                    self._open_file(reopen=True)
                else:
                    self.state = 'SEEKING'
                    self.deadline = now + 12
                    self.pending_seek = True
        if self.audio_due and now >= self.audio_due:
            self.audio_due = 0
            from .backgroundaudio import recover_video_delay_audio
            recover_video_delay_audio(recover_sink=True)

    def stop(self, restore=True, stop_owned=False):
        if self.recorder is None:
            return
        if self.stopping:
            return
        self.stopping = True
        self.state = 'STOPPING'
        self.pending_seek = False
        self.audio_due = 0
        was_owned = self.owns_current()
        try:
            if restore and self.live_ref and (was_owned or (not current_reference(self.session) and self.file_ref)):
                self._play(self.live_ref)
                from .backgroundaudio import _set_enigma_service_audio, recover_video_delay_audio
                _set_enigma_service_audio(self.session, False)
                recover_video_delay_audio(recover_sink=True)
                from .backgroundaudio import _LOCK, _STATE
                with _LOCK:
                    _STATE['last_service'] = current_reference(self.session)
            elif stop_owned and was_owned:
                self.session.nav.stopService()
        except Exception as error:
            log('restore live failed; buffer retained while in use: ' + str(error))
            self._notify('Live restore failed; select a satellite channel manually')
        finally:
            self.recorder.stop(cleanup=not self.owns_current())
        self.cleanup_after = time.monotonic() + 0.5
        self.timer.start(250, False)

    def _cleanup(self):
        global _ACTIVE
        if not self.recorder or not self.recorder.done.is_set() or self.owns_current() or (time.monotonic() < self.cleanup_after):
            return
        storage = self.recorder.storage
        removed = storage.cleanup() if storage else True
        log('owned buffer cleanup ' + ('complete' if removed else 'partial; unrelated files retained'))
        self.recorder = None
        self.file_ref = None
        self.state = 'LIVE'
        self.stopping = False
        if _ACTIVE is self:
            _ACTIVE = None
        self.timer.stop()
        if self.closed:
            self._unhook()

    def _unhook(self):
        if self.hooked:
            try:
                self.session.nav.event.remove(self._event)
            except (ValueError, AttributeError):
                pass
            self.hooked = False

    def close(self):
        self.closed = True
        self.audio_recovery_timer.stop()
        if self.recorder:
            self.stop(restore=True)
        else:
            self.timer.stop()
            self._unhook()

    def status(self):
        snapshot = self.recorder.snapshot() if self.recorder else {}
        gap = self.actual_delay_ms()
        actual = '%.2f s' % (gap / 1000.0) if gap is not None else '--'
        return 'BETA ' + self.state + ' | Target %.2f s | Actual %s' % (self.target_ms / 1000.0, actual)
