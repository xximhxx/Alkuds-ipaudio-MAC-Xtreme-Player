# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import threading
from . import shoofmax
from .arabseedui import Alkuds_ArabSeed_Browser

class Alkuds_ShoofMax_Browser(Alkuds_ArabSeed_Browser):
    provider = shoofmax
    site_name = u'شوف ماكس Shoof Max'

    def _load_worker(self):
        if self.level == 'sections':
            self._result = [{'name': u'البحث في هذا القسم', 'action': 'search'}, {'name': u'الأحدث حسب سنة الإنتاج', 'order': 'latest'}, {'name': u'الأكثر مشاهدة', 'order': 'views'}, {'name': u'ترتيب عناوين الصفحة أ–ي', 'order': 'az'}, {'name': u'ترتيب عناوين الصفحة ي–أ', 'order': 'za'}]
            self._done = True
        else:
            Alkuds_ArabSeed_Browser._load_worker(self)

    def _set_rows(self):
        order = self.parent.get('order')
        if self.level == 'items' and order in ('az', 'za') and (not self.parent.get('episode_query')):
            self.entries.sort(key=lambda x: x['name'], reverse=order == 'za')
        Alkuds_ArabSeed_Browser._set_rows(self)

    def open_current(self):
        if self._loading or self._closed:
            return
        index = self._index()
        if not 0 <= index < len(self.entries):
            return
        item = dict(self.entries[index])
        if item.get('action') == 'search':
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(self._search_done, VirtualKeyBoard, title=u'بحث شوف ماكس', text='')
            return
        if self.level == 'items' and (not item.get('is_series')):
            self._selected_index = index
            self._operation, self._loading, self._done = ('resolve', True, False)
            self._result, self._error = (None, '')
            self._update_title(u' - جاري تجهيز الفيديو...')
            worker = threading.Thread(target=self._resolve_worker, args=(item,))
            worker.daemon = True
            worker.start()
            self._timer.start(120, False)
            return
        Alkuds_ArabSeed_Browser.open_current(self)
