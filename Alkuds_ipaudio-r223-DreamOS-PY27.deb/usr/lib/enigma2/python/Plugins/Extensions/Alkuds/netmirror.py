# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""NetMirror NewTV adapter; normal activation and clear HLS playback only."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
import copy
from .py2compat import ipaddress
from .py2compat import json
from .py2compat import os
from .py2compat import re
from .py2compat import threading
from .py2compat import time
from .py2compat import futures
ThreadPoolExecutor = futures.ThreadPoolExecutor
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlsplit = urllib.parse.urlsplit
from .py2compat import requests
BOOTSTRAPS = ('https://mobiledetects.com', 'https://mobiledetect.app', 'https://mobidetect.art', 'https://mobidetect.cc')
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0 /OS.GatuNewTV v1.0'
HEADERS = {'User-Agent': UA, 'X-Requested-With': 'NetmirrorNewTV v1.0', 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache', 'Expires': '0'}
SESSION = '/etc/enigma2/alkuds/netmirror_session.json'
ACTIVATION_CODE = '111111'
LOCK = threading.RLock()
AUTH_LOCK = threading.RLock()
CACHE = {}
API = ''
API_AT = 0
TOKEN = None
ACTIVATED_AT = 0
PAGE_SIZE = 12
NAMES = {'nf': 'Netflix', 'pv': 'Prime Video', 'hs': 'Disney / Hotstar'}

def refresh():
    global API_AT
    with LOCK:
        compat_clear(CACHE)
        API_AT = 0

def _url(value):
    value = str(value or '')
    parsed = urlsplit(value)
    if parsed.scheme not in ('https', 'http') or not parsed.hostname or parsed.username or parsed.password:
        raise RuntimeError(u'المصدر أعاد رابطًا غير صالح')
    if parsed.hostname.lower() in ('localhost', 'localhost.localdomain'):
        raise RuntimeError(u'المصدر أعاد رابطًا محليًا غير صالح')
    try:
        address = ipaddress.ip_address(parsed.hostname)
    except ValueError:
        address = None
    if address and (not address.is_global):
        raise RuntimeError(u'المصدر أعاد رابطًا محليًا غير صالح')
    return value

def _get(url, headers=None, params=None, limit=4 * 1024 * 1024):
    try:
        with requests.get(_url(url), headers=headers or HEADERS, params=params, timeout=(4, 12), stream=True) as response:
            response.raise_for_status()
            raw = bytearray()
            for chunk in response.iter_content(32768):
                raw.extend(chunk)
                if len(raw) > limit:
                    raise RuntimeError(u'استجابة المصدر أكبر من الحد الآمن')
            return (bytes(raw), response.url)
    except requests.RequestException as error:
        code = getattr(getattr(error, 'response', None), 'status_code', None)
        raise RuntimeError(u'تعذر الاتصال بمصدر نت ميرور' + (u' — ' + str(code) if code else ''))

def _json(url, headers=None, params=None):
    raw, final = _get(url, headers, params)
    try:
        value = json.loads(raw.decode('utf-8-sig'))
    except (ValueError, UnicodeError):
        raise RuntimeError(u'المصدر لم يُرجع بيانات صالحة؛ حاول التحديث لاحقًا')
    if not isinstance(value, dict):
        raise RuntimeError(u'استجابة المصدر غير متوقعة')
    return value

def _cached(key, fetch, ttl=300):
    with LOCK:
        hit = CACHE.get(key)
    if hit and time.monotonic() - hit[0] < ttl:
        return copy.deepcopy(hit[1])
    value = fetch()
    with LOCK:
        if len(CACHE) >= 300:
            compat_clear(CACHE)
        CACHE[key] = (time.monotonic(), copy.deepcopy(value))
    return value

def _base():
    global API, API_AT
    with LOCK:
        if API and time.monotonic() - API_AT < 3600:
            return API
        for host in BOOTSTRAPS:
            try:
                data = _json(host + '/checknewtv.php')
                value = str(data.get('token_hash') or '')
                decoded = base64.b64decode(value + '=' * (-len(value) % 4)).decode('utf8').rstrip('/')
                _url(decoded)
                if not decoded.startswith('https://') or urlsplit(decoded).query:
                    continue
                API, API_AT = (decoded, time.monotonic())
                return API
            except (RuntimeError, ValueError, UnicodeError):
                continue
    raise RuntimeError(u'تعذر العثور على مصدر نت ميرور؛ حاول التحديث لاحقًا')

def _token():
    global TOKEN
    with AUTH_LOCK:
        if TOKEN is None:
            try:
                with open(SESSION, encoding='utf8') as handle:
                    TOKEN = str(json.load(handle).get('usertoken') or '')
            except (OSError, ValueError, TypeError):
                TOKEN = ''
        return TOKEN

def _activate(rejected=''):
    global TOKEN, ACTIVATED_AT
    with AUTH_LOCK:
        current = _token()
        if current and current != rejected:
            return current
        if ACTIVATED_AT and time.monotonic() - ACTIVATED_AT < 30:
            raise RuntimeError(u'طلب المصدر إعادة التفعيل؛ حاول بعد قليل')
        ACTIVATED_AT = time.monotonic()
        data = _json(_base() + '/newtv/otp.php', dict(HEADERS, Otp=ACTIVATION_CODE))
        token = data.get('usertoken')
        if data.get('status') != 'ok' or not isinstance(token, str) or (not token):
            raise RuntimeError(u'المصدر لم يقبل رمز التفعيل؛ يلزم رمز صالح من التطبيق')
        TOKEN = token
        try:
            os.makedirs(os.path.dirname(SESSION), exist_ok=True)
            temporary = SESSION + '.tmp'
            descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 384)
            with os.fdopen(descriptor, 'w', encoding='utf8') as handle:
                json.dump({'usertoken': TOKEN}, handle)
            os.chmod(temporary, 384)
            os.replace(temporary, SESSION)
        except OSError:
            pass
        return TOKEN

def _api(route, ott='nf', params=None, page=None):
    if route not in ('ott', 'navbar', 'main', 'post', 'episodes', 'player', 'search'):
        raise ValueError(u'قسم غير معروف')
    if ott not in NAMES:
        raise ValueError(u'منصة غير معروفة')
    token = _token() or _activate()
    for attempt in range(2):
        headers = dict(HEADERS, Ott=ott, Usertoken=token)
        if page is not None:
            headers['Page'] = page
        data = _json(_base() + '/newtv/' + route + '.php', headers, params)
        if data.get('status') == 'otp':
            if attempt:
                raise RuntimeError(u'انتهت جلسة التفعيل؛ أعد المحاولة لاحقًا')
            token = _activate(token)
            continue
        if data.get('status') not in ((None, 'ok', 'y', 'n') if route == 'search' else (None, 'ok')):
            raise RuntimeError(u'المصدر لم يتمكن من جلب هذا المحتوى')
        return data

def platforms():
    data = _cached(('ott',), lambda: _api('ott'))
    return [{'name': NAMES[row['value']], 'ott': row['value'], 'image': row.get('img', ''), 'view': 'navigation'} for row in data.get('ott', []) if isinstance(row, dict) and row.get('value') in NAMES]

def navigation(parent):
    ott = parent['ott']
    flags = _cached(('nav', ott), lambda: _api('navbar', ott))
    result = [dict(parent, name=u'الرئيسية', view='rows', page_code='all')]
    if flags.get('show'):
        result.append(dict(parent, name=u'المسلسلات', view='rows', page_code='show'))
    if flags.get('movie'):
        result.append(dict(parent, name=u'الأفلام', view='rows', page_code='movie'))
    result.append(dict(parent, name=u'بحث', action='search'))
    return result

def sections(parent):
    from .adultfilter import adult
    ott, code = (parent['ott'], parent.get('page_code', 'all'))
    data = _cached(('main', ott, code), lambda: _api('main', ott, page=code))
    result = []
    for row in data.get('post', []):
        if not isinstance(row, dict) or adult({'name': row.get('cate', '')}):
            continue
        ids = [x.strip() for x in str(row.get('ids') or '').split(',') if x.strip()]
        if ids:
            result.append({'name': row.get('cate') or u'قسم', 'ids': ids, 'ott': ott, 'view': 'titles', 'poster_template': data.get('imgcdn_v') or data.get('imgcdn', '')})
    return result

def detail(ott, ident):
    if not re.fullmatch('[A-Za-z0-9_-]{1,160}', str(ident)):
        raise RuntimeError(u'معرّف العمل غير صالح')
    return _cached(('post', ott, str(ident)), lambda: _api('post', ott, {'id': ident}))

def _entry(ott, ident, data):
    return {'id': str(ident), 'ott': ott, 'name': data.get('title') or data.get('title_name') or str(ident), 'type': data.get('type', 'm'), 'image': data.get('main_poster', ''), 'description': data.get('desc', ''), 'view': 'seasons' if data.get('type') == 't' else 'play', 'action': '' if data.get('type') == 't' else 'play'}

def titles(parent, number=1):
    from .adultfilter import adult
    ids = parent.get('ids') or []
    number = max(1, int(number))
    batch = ids[(number - 1) * PAGE_SIZE:number * PAGE_SIZE]
    ott = parent['ott']

    def load(ident):
        data = detail(ott, ident)
        return _entry(ott, ident, data)
    with ThreadPoolExecutor(max_workers=4) as pool:
        result = list(pool.map(load, batch))
    return {'entries': [row for row in result if not adult(row)], 'page': number, 'last_page': max(1, (len(ids) + PAGE_SIZE - 1) // PAGE_SIZE)}

def seasons(parent):
    data = detail(parent['ott'], parent['id'])
    result = []
    for row in data.get('season') or []:
        if isinstance(row, dict) and row.get('id'):
            result.append({'name': row.get('s') or u'موسم', 'id': str(row['id']), 'ott': parent['ott'], 'show_name': parent['name'], 'image': parent.get('image', ''), 'view': 'episodes'})
    return result

def episodes(parent, number=1):
    ott, ident = (parent['ott'], parent['id'])
    number = max(1, int(number))
    data = _cached(('episodes', ott, ident, number), lambda: _api('episodes', ott, {'id': ident, 'page': number}))
    result = []
    for row in data.get('episodes') or []:
        if not isinstance(row, dict) or not row.get('id'):
            continue
        result.append({'name': str(row.get('ep') or '') + u' — ' + str(row.get('t') or u'حلقة'), 'id': str(row['id']), 'ott': ott, 'type': 't', 'action': 'play', 'image': parent.get('image', ''), 'description': row.get('ep_desc', ''), 'show_name': parent.get('show_name', '')})
    more = bool(data.get('nextPageShow') and data.get('nextPage'))
    return {'entries': result, 'page': number, 'last_page': number + 1 if more else number}

def search(ott, query):
    data = _api('search', ott, {'s': query})
    rows = data.get('searchResult') or data.get('search') or data.get('result') or []
    if not isinstance(rows, list):
        raise RuntimeError(u'صيغة نتائج البحث غير مدعومة')
    ids = [str(row.get('id')) for row in rows if isinstance(row, dict) and row.get('id')]
    return {'name': u'نتائج البحث: ' + query, 'ott': ott, 'ids': ids, 'view': 'titles'}

def attributes(line):
    return {m.group(1): m.group(2).strip('"') for m in re.finditer('([A-Z0-9-]+)=("[^"]*"|[^,]+)', line)}

def variants(text, stream):
    if not text.lstrip().startswith('#EXTM3U'):
        raise RuntimeError(u'المصدر لم يُرجع فيديو صالحًا')
    if re.search('METHOD=(?:SAMPLE-AES|SAMPLE-AES-CTR)|KEYFORMAT="(?:urn:uuid|com\\.)', text, re.I):
        raise RuntimeError(u'هذا الفيديو محمي وغير مدعوم في المشغل')
    subtitles = []
    qualities = []
    audio = []
    for line in text.splitlines():
        if line.startswith('#EXT-X-MEDIA:'):
            value = attributes(line)
            if value.get('TYPE') == 'SUBTITLES' and value.get('URI'):
                subtitles.append({'name': value.get('NAME') or value.get('LANGUAGE', 'Subtitle'), 'language': value.get('LANGUAGE', ''), 'url': _url(urljoin(stream['url'], value['URI'])), 'headers': dict(stream['headers']), 'hls_subtitle': True})
            elif value.get('TYPE') == 'AUDIO':
                audio.append(value.get('LANGUAGE', ''))
        elif line.startswith('#EXT-X-STREAM-INF:'):
            value = attributes(line)
            resolution = value.get('RESOLUTION', '').split('x')
            label = resolution[-1] + 'p' if len(resolution) == 2 else value.get('BANDWIDTH', 'Auto')
            qualities.append(dict(stream, quality=label, relay_options={'hls_variant': line}))
    for value in qualities:
        value['subtitles'] = copy.deepcopy(subtitles)
        value['audio_languages'] = list(audio)
    return qualities or [dict(stream, subtitles=subtitles, audio_languages=audio)]

def resolve(item):
    data = _api('player', item['ott'], {'id': item['id']})
    if data.get('drm') or data.get('license'):
        raise RuntimeError(u'هذا الفيديو محمي وغير مدعوم في المشغل')
    url = _url(data.get('video_link'))
    headers = {'User-Agent': UA, 'X-Requested-With': HEADERS['X-Requested-With'], 'Referer': str(data.get('referer') or '')}
    raw, final = _get(url, headers, limit=1024 * 1024)
    stream = {'url': final, 'headers': headers, 'relay': True, 'mediatype': 'hls', 'quality': 'Auto', 'source': 'netmirror'}
    return dict(item, name=data.get('title') or item['name'], url=url, streams=variants(raw.decode('utf-8-sig'), stream))

def subtitle_bytes(track, cancelled=lambda: False):
    """Selected external HLS VOD captions; no downloads before user selection."""
    headers = track.get('headers') or {}
    url = track['url']
    raw, final = _get(url, headers)
    if cancelled():
        raise RuntimeError(u'تم إغلاق المشغل')
    if raw.lstrip().startswith(b'WEBVTT'):
        return raw
    text = raw.decode('utf-8-sig')
    if not text.startswith('#EXTM3U') or '#EXT-X-ENDLIST' not in text:
        raise RuntimeError(u'صيغة ترجمة المصدر غير مدعومة')
    uris = [line.strip() for line in text.splitlines() if line.strip() and (not line.startswith('#'))]
    if len(uris) != 1 or '#EXT-X-KEY:' in text:
        raise RuntimeError(u'اختر الترجمة المدمجة لهذا المسار')
    raw, final = _get(urljoin(final, uris[0]), headers)
    if cancelled():
        raise RuntimeError(u'تم إغلاق المشغل')
    if not raw.lstrip().startswith(b'WEBVTT'):
        raise RuntimeError(u'المصدر لم يُرجع ترجمة صالحة')
    return raw
