# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Full backups explicitly authorized by the owner; opt-in destination only."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import hashlib
from .py2compat import datetime_module as datetime
from .py2compat import json
from .py2compat import os
from .py2compat import re
from .py2compat import threading
from .py2compat import time
from .py2compat import urllib
from .py2compat import urllib
import sys
from .py2compat import urllib
urlsplit = urllib.parse.urlsplit
parse_qs = urllib.parse.parse_qs
from .subscriptionprefs import atomic
CONFIG = '/etc/enigma2/remote_backup_config.json'
QUEUE = '/etc/enigma2/alkuds/backup_queue.json'
LOCK = threading.RLock()
WORKER = None
RETRY = None
STOP = threading.Event()
JOB = None
STATUS = '/etc/enigma2/alkuds/subscription_status.json'
DELIVERED = '/etc/enigma2/alkuds/backup_delivered.json'
PAUSE_ACCOUNT_BACKUPS = True

def _account_backup(item):
    name = str(item.get('name') or '').lower()
    caption = str(item.get('caption') or '').lower().strip()
    first = str(item.get('content') or '').split('\n', 1)[0].lower().strip()
    return item.get('kind') in ('xtream', 'mac') or name.startswith(('backup_xtreme', 'backup_xtream', 'backup_mac', 'alkuds_xtream', 'alkuds_mac')) or caption in ('backup xtreme', 'backup xtream', 'backup mac') or (first in ('backup xtreme', 'backup xtream', 'backup mac'))

def _eligible(item):
    return not (PAUSE_ACCOUNT_BACKUPS and _account_backup(item))

def _read(path):
    try:
        with open(path, encoding='utf8') as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return {}

def configuration():
    data = _read(CONFIG)
    if not isinstance(data, dict):
        return {}
    return {'enabled': bool(data.get('enabled', False)), 'token': str(data.get('token') or data.get('bot_token') or ''), 'recipient': str(data.get('recipient') or data.get('chat_id') or '')}

def configure(token='', recipient='', enabled=False):
    with LOCK:
        old = configuration()
        token = token.strip() or old.get('token', '')
        recipient = recipient.strip() or old.get('recipient', '')
        if enabled and (not re.fullmatch('[0-9]+:[A-Za-z0-9_-]{20,}', token) or not re.fullmatch('-?[0-9]{3,24}', recipient)):
            raise ValueError(u'تحقق من رمز الوجهة ورقم المحادثة')
        atomic(CONFIG, json.dumps({'enabled': bool(enabled), 'token': token, 'recipient': recipient}).encode())
        if old.get('recipient') != recipient or old.get('token') != token or (not enabled):
            atomic(QUEUE, json.dumps({'pending': [], 'sent': []}).encode())
    flush_pending_async()

def status():
    data = configuration()
    return bool(data.get('enabled') and data.get('token') and data.get('recipient'))

def subscription_key(kind, account):
    info = account.get('playlist_info') or account
    if kind == 'mac':
        info = account.get('_raw') or account
    host = str(info.get('host') or info.get('portal') or account.get('portal') or info.get('domain') or '').strip().rstrip('/')
    if kind not in ('xtream', 'mac'):
        host = str(info.get('url') or host)
    try:
        parsed = urlsplit(host if '://' in host else '//' + host)
    except ValueError:
        parsed = urlsplit('')
    authority = parsed.netloc.lower() or host.lower()
    if kind == 'xtream':
        values = ['xtream', authority, str(info.get('username') or ''), str(info.get('password') or '')]
    elif kind == 'mac':
        path = re.sub('/(?:c|server/load[.]php|portal[.]php)/?$', '', parsed.path.rstrip('/'))
        values = ['mac', authority + path, re.sub('[^0-9A-Fa-f]', '', str(info.get('mac') or account.get('mac') or '')).upper()]
    else:
        token = str(info.get('token') or parse_qs(parsed.query).get('token', [''])[0])
        if not token and info.get('username') and info.get('password'):
            token = str(info['username']) + '_' + str(info['password'])
        family = 'orange' if kind in ('orange_audio', 'orange_goradio') else kind
        values = [family, authority, token or host]
    return 'subscription:' + hashlib.sha256(json.dumps(values, ensure_ascii=True).encode()).hexdigest()

def queue_document(name, content, force=False, caption='', mode='document', subscription_id=None, legacy_ids=()):
    if not _eligible({'name': name, 'content': content, 'caption': caption}):
        return False
    if not status() or STOP.is_set():
        return False
    if not isinstance(content, str):
        content = content.decode('utf8')
    if len(content.encode('utf8')) > 512 * 1024:
        return False
    digest = subscription_id or hashlib.sha256((mode + '\n' + name + '\n' + content).encode()).hexdigest()
    with LOCK:
        data = _read(QUEUE)
        pending = data.get('pending', [])
        sent = data.get('sent', [])
        if subscription_id:
            delivered = _read(DELIVERED)
            if subscription_id in delivered:
                return False
            if any((marker in sent for marker in legacy_ids)):
                delivered[subscription_id] = int(time.time())
                atomic(DELIVERED, json.dumps(delivered).encode())
                return False
            if any((item.get('subscription_id', item.get('id')) == subscription_id for item in pending)):
                return False
            force = False
        existing = next((item for item in pending if item.get('id') == digest), None)
        if existing:
            if force:
                existing['attempts'] = 0
                existing['retry_at'] = 0
                data['pending'] = pending
                atomic(QUEUE, json.dumps(data).encode())
                flush_pending_async()
            return bool(force)
        if not force and digest in sent:
            return False
        if len(pending) >= 256 or sum((len(item.get('content', '').encode('utf8')) for item in pending)) + len(content.encode('utf8')) > 8 * 1024 * 1024:
            return False
        pending.append({'id': digest, 'name': name, 'content': content, 'attempts': 0, 'caption': caption, 'mode': mode, 'subscription_id': subscription_id})
        data.update(pending=pending, sent=sent[-100:])
        atomic(QUEUE, json.dumps(data).encode())
    flush_pending_async()
    return True

def _send(config, item):
    if not _eligible(item):
        return False
    if item.get('mode') == 'text':
        data = json.dumps({'chat_id': config['recipient'], 'text': item['content']}, ensure_ascii=False).encode('utf8')
        request = urllib.request.Request('https://api.telegram.org/bot' + config['token'] + '/sendMessage', data=data, headers={'Content-Type': 'application/json; charset=utf-8'})
        with urllib.request.urlopen(request, timeout=12) as response:
            result = json.loads(response.read(65536))
        if result.get('ok') is not True:
            raise ValueError('Backup delivery failed')
        return
    boundary = 'alkuds' + byte_hex(os.urandom(12))
    name = re.sub('[^a-zA-Z0-9_.-]', '_', item['name'])[:80]
    body = ('--' + boundary + '\r\nContent-Disposition: form-data; name="chat_id"\r\n\r\n' + config['recipient'] + '\r\n--' + boundary + '\r\nContent-Disposition: form-data; name="caption"\r\n\r\n' + item.get('caption', '') + '\r\n--' + boundary + '\r\nContent-Disposition: form-data; name="document"; filename="' + name + '"\r\nContent-Type: application/octet-stream\r\n\r\n' + item['content'] + '\r\n--' + boundary + '--\r\n').encode('utf8')
    req = urllib.request.Request('https://api.telegram.org/bot' + config['token'] + '/sendDocument', data=body, headers={'Content-Type': 'multipart/form-data; boundary=' + boundary})
    with urllib.request.urlopen(req, timeout=12) as response:
        result = json.loads(response.read(65536))
    if result.get('ok') is not True:
        raise ValueError('Backup delivery failed')

def _work():
    global WORKER, RETRY
    try:
        for unused in range(24):
            with LOCK:
                config = configuration()
                data = _read(QUEUE)
                pending = data.get('pending', [])
                if STOP.is_set() or not config.get('enabled') or (not pending):
                    return
                item = next((entry for entry in pending if _eligible(entry)), None)
                if item is None:
                    return
                if item.get('retry_at', 0) > time.time():
                    return
            success = False
            failure = ''
            try:
                _send(config, item)
                success = True
            except urllib.error.HTTPError as error:
                failure = 'HTTP ' + str(error.code)
            except Exception as error:
                failure = type(error).__name__
            with LOCK:
                if configuration() != config:
                    return
                data = _read(QUEUE)
                pending = data.get('pending', [])
                index = next((index for index, entry in enumerate(pending) if entry.get('id') == item['id']), None)
                if index is None:
                    continue
                if success:
                    if item.get('subscription_id'):
                        delivered = _read(DELIVERED)
                        delivered[item['subscription_id']] = int(time.time())
                        atomic(DELIVERED, json.dumps(delivered).encode())
                    pending.pop(index)
                    data.setdefault('sent', []).append(item['id'])
                    data['sent'] = data['sent'][-100:]
                else:
                    pending[index]['attempts'] = pending[index].get('attempts', 0) + 1
                    if pending[index]['attempts'] >= 3:
                        pending.pop(index)
                    else:
                        pending[index]['retry_at'] = time.time() + 60
                data['last'] = {'ok': success, 'at': int(time.time()), 'error': failure}
                data['pending'] = pending
                atomic(QUEUE, json.dumps(data).encode())
            if not success:
                return
    finally:
        with LOCK:
            WORKER = None
            if RETRY:
                RETRY.cancel()
                RETRY = None
            data = _read(QUEUE)
            pending = [item for item in data.get('pending', []) if _eligible(item)]
            if pending and status() and (not STOP.is_set()):
                delay = max(1, min(60, pending[0].get('retry_at', 0) - time.time()))
                RETRY = threading.Timer(delay, flush_pending_async)
                RETRY.daemon = True
                RETRY.start()

def flush_pending_async():
    global WORKER
    with LOCK:
        if STOP.is_set() or not status() or (WORKER and WORKER.is_alive()):
            return False
        WORKER = threading.Thread(target=_work, name='AlkudsBackup', daemon=True)
        WORKER.start()
        return True

def shutdown():
    global RETRY
    STOP.set()
    with LOCK:
        if RETRY:
            RETRY.cancel()
            RETRY = None

def backup_audio_config(force=False):
    from . import audioconfig
    with audioconfig.LOCK:
        audioconfig.ensure(audioconfig.PATH, mirror=audioconfig.HDD_PATH)
        data = audioconfig.load(audioconfig.PATH)
        data = {kind: entries for kind, entries in data.items() if kind not in ('anis_audio', 'fox_audio')}
    queued = False
    for kind, entries in data.items():
        if kind in AUDIO_TITLES:
            for entry in entries:
                queued = queue_audio_message(kind, entry.get('name') or '', entry.get('url') or '', entry, force=force) or queued
        elif entries:
            queued = queue_document('alkuds_' + kind + '.json', json.dumps(entries, ensure_ascii=False, indent=2), force=force, caption=u'نسخة الصوتيات') or queued
    return queued

def backup_xtream_connected(playlist):
    return backup_accounts('xtream', [playlist], force=False)

def backup_stalker_connected(portal):
    return backup_accounts('mac', [portal], force=False)
AUDIO_TITLES = {'best_audio': 'backup best', 'sat_family': 'backup sat family', 'orange_audio': 'backup orange', 'orange_goradio': 'backup orange'}
AUDIO_HOSTS = {'best_audio': 'http://radio.best-audio.org', 'sat_family': 'http://stereofm.live', 'orange_audio': 'http://radio.orange-audio.top', 'orange_goradio': 'http://goradio.top'}

def audio_message(kind, name, subscription_url, entry):
    from .accountinfo import account_fields
    fields = account_fields(entry)
    for key in ('expiry', 'active', 'maximum'):
        if entry.get(key) not in (None, ''):
            fields[key] = entry[key]
    url = str(entry.get('url') or subscription_url or AUDIO_HOSTS.get(kind, ''))
    try:
        parts = urlsplit(url)
        host = parts.scheme + '://' + parts.netloc if parts.netloc else url
        token = str(entry.get('token') or parse_qs(parts.query).get('token', [''])[0])
    except ValueError:
        host = url
        token = str(entry.get('token') or '')
    lines = [AUDIO_TITLES[kind]]
    if name or entry.get('name'):
        lines.append('Name: ' + str(entry.get('name') or name))
    lines.extend(('Host: ' + host, 'Username: ' + _value(entry.get('username')), 'Password: ' + _value(entry.get('password'))))
    if token:
        lines.append('Token: ' + token)
    if url and url.rstrip('/') != host.rstrip('/'):
        lines.append('URL: ' + url)
    lines.extend(('Expiry: ' + _expiry(fields.get('expiry')), 'Connections: ' + _value(fields.get('active')), 'Max connections: ' + _value(fields.get('maximum'))))
    return '\n'.join(lines)

def queue_audio_message(kind, name, url, entry, force=False):
    content = audio_message(kind, name, url, entry)
    mode = 'text' if len(content.encode('utf-16-le')) // 2 <= 3500 else 'document'
    entry = dict(entry)
    entry['url'] = entry.get('url') or url or AUDIO_HOSTS.get(kind, '')
    marker = subscription_key(kind, entry)
    legacy = hashlib.sha256((mode + '\n' + kind + '.txt\n' + content).encode()).hexdigest()
    return queue_document(kind + '.txt', content, caption=AUDIO_TITLES[kind], mode=mode, subscription_id=marker, legacy_ids=(legacy,))

def backup_audiofeed_connected(kind, name, subscription_url, channel_count=None, subscription_entry=None):
    if kind in ('anis_audio', 'fox_audio') or not subscription_entry:
        return False
    if kind in AUDIO_TITLES:
        return queue_audio_message(kind, name, subscription_url, subscription_entry)
    return queue_document('audio.json', json.dumps({'kind': kind, 'name': name, 'entry': subscription_entry}, ensure_ascii=False, indent=2))

def _metadata(kind, account):
    from .accountinfo import account_fields
    from .subscriptionprefs import identity
    entry = _read(STATUS).get(identity(kind, account), {})
    fields = dict(entry.get('fields') or {})
    fields.update(account_fields(account))
    for source in (account, account.get('account_info') or {}):
        for key in ('expiry', 'active', 'maximum'):
            if source.get(key) not in (None, ''):
                fields[key] = source[key]
    return fields

def _expiry(value):
    if value in (None, ''):
        return u'غير متوفر'
    if str(value).strip() == '0':
        return u'غير محدود'
    from .accountinfo import _expiry_timestamp
    timestamp = _expiry_timestamp(value)
    if timestamp is not None:
        try:
            return datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d')
        except (ValueError, OSError, OverflowError):
            pass
    return str(value)

def _value(value):
    return u'غير متوفر' if value in (None, '') else str(value)

def account_message(kind, account):
    fields = _metadata(kind, account)
    info = account.get('playlist_info') or account
    if kind == 'xtream':
        return '\n'.join(('backup xtreme', 'Host: ' + str(info.get('host') or info.get('domain') or ''), 'Username: ' + str(info.get('username') or ''), 'Password: ' + str(info.get('password') or ''), 'Expiry: ' + _expiry(fields.get('expiry')), 'Connections: ' + _value(fields.get('active')), 'Max connections: ' + _value(fields.get('maximum'))))
    raw = account.get('_raw') or account
    return '\n'.join(('backup mac', 'Host: ' + str(raw.get('host') or raw.get('portal') or account.get('portal') or ''), 'MAC: ' + str(raw.get('mac') or account.get('mac') or ''), 'Expiry: ' + _expiry(fields.get('expiry'))))

def backup_accounts(kind, accounts, force=True):
    """Readable backup messages; account metadata never gates saving credentials."""
    if PAUSE_ACCOUNT_BACKUPS and kind in ('xtream', 'mac'):
        return False
    if kind not in ('xtream', 'mac') or not status() or STOP.is_set():
        return False
    queued = False
    seen = set()
    for account in accounts:
        info = account.get('playlist_info') or account
        raw = account.get('_raw') or account
        if kind == 'xtream':
            valid = bool((info.get('host') or info.get('domain')) and info.get('username') and info.get('password'))
        else:
            valid = bool((raw.get('host') or raw.get('portal') or account.get('portal')) and (raw.get('mac') or account.get('mac')))
        marker = subscription_key(kind, account)
        if not valid or marker in seen:
            continue
        seen.add(marker)
        content = account_message(kind, account)
        mode = 'text' if len(content.encode('utf-16-le')) // 2 <= 3500 else 'document'
        stem = 'backup_xtreme' if kind == 'xtream' else 'backup_mac'
        legacy = hashlib.sha256((mode + '\n' + stem + '-1.txt\n' + content).encode()).hexdigest()
        queued = queue_document(stem + '.txt', content, caption='backup xtreme' if kind == 'xtream' else 'backup mac', mode=mode, subscription_id=marker, legacy_ids=(legacy,)) or queued
    return queued

def _text(path):
    try:
        with open(path, 'rb') as handle:
            raw = handle.read(8 * 1024 * 1024 + 1)
        if len(raw) > 8 * 1024 * 1024:
            return ''
        return raw.decode('utf-8-sig')
    except (OSError, UnicodeError):
        return ''

def saved_accounts(kind):
    """Read saved files only; never probe or discover external accounts."""
    plugin = sys.modules.get(__package__ + '.plugin')
    cfg = getattr(plugin, 'cfg', None)
    if kind == 'xtream':
        playlist = getattr(getattr(cfg, 'playlist_file', None), 'value', '/etc/enigma2/alkuds/playlists.txt')
        cache = getattr(getattr(cfg, 'playlists_json', None), 'value', '/etc/enigma2/alkuds/x-playlists.json')
        rows = []
        for line in _text(playlist).splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            try:
                url, title = (line.split(' #', 1) + [''])[:2] if ' #' in line else (line, '')
                parts = urlsplit(url.split()[0])
                query = parse_qs(parts.query)
                if parts.scheme not in ('http', 'https'):
                    continue
                user = query.get('username', [''])[0]
                password = query.get('password', [''])[0]
                if user and password:
                    rows.append({'host': parts.scheme + '://' + parts.netloc, 'username': user, 'password': password, 'output': query.get('output', ['ts'])[0], 'name': title})
            except ValueError:
                continue
        if os.path.isfile(playlist):
            cached = _read(cache)
            if isinstance(cached, list):
                for row in rows:
                    for old in cached:
                        info = old.get('playlist_info') or {}
                        if str(info.get('host', '')).rstrip('/') == row['host'].rstrip('/') and info.get('username') == row['username'] and (info.get('password') == row['password']):
                            for key in ('user_info', 'account_info'):
                                if isinstance(old.get(key), dict):
                                    row[key] = old[key]
                            break
            return rows
        try:
            values = json.loads(_text(cache))
            return values if isinstance(values, list) else []
        except ValueError:
            return []
    if kind == 'mac':
        stalker = sys.modules.get(__package__ + '.stalker')
        if stalker and hasattr(stalker, '_load_portals'):
            return stalker._load_portals()
        import glob
        paths = ['/media/hdd/MultiStalkerPro.json', '/media/usb/MultiStalkerPro.json', '/media/mmc/MultiStalkerPro.json', '/media/cf/MultiStalkerPro.json']
        paths += sorted(glob.glob('/media/*/MultiStalkerPro.json')) + sorted(glob.glob('/media/*/*/MultiStalkerPro.json'))
        paths += ['/etc/enigma2/MultiStalkerPro.json', '/etc/enigma2/alkuds/MultiStalkerPro.json']
        rows = []
        for path in dict.fromkeys(paths):
            try:
                data = json.loads(_text(path))
            except ValueError:
                continue
            if isinstance(data, list):
                rows = [row for row in data if isinstance(row, dict) and row.get('mac') and (row.get('host') or row.get('portal'))]
            if rows:
                break
        from .localimport import read_store, identity
        store = read_store()
        hidden = set(store.get('removed_stalker') or [])
        rows = [row for row in rows if identity('stalker', row) not in hidden]
        seen = {identity('stalker', row) for row in rows}
        for row in store.get('stalker') or []:
            marker = identity('stalker', row)
            if marker not in seen and marker not in hidden:
                rows.append(row)
                seen.add(marker)
        return rows
    return []

def request_saved_backup(kind='all', accounts=None):
    """No on-screen notifications. Files and captions are sent to the saved destination."""
    global JOB
    if kind not in ('all', 'xtream', 'mac', 'audio') or not status() or STOP.is_set():
        return False
    with LOCK:
        if JOB and JOB.is_alive():
            return False
        captured = json.loads(json.dumps(accounts)) if accounts is not None else None

        def run():
            global JOB
            try:
                for selected in ('xtream', 'mac', 'audio') if kind == 'all' else (kind,):
                    if STOP.is_set():
                        break
                    if selected == 'audio':
                        backup_audio_config(force=True)
                    else:
                        backup_accounts(selected, captured if captured is not None else saved_accounts(selected), force=True)
            except Exception:
                pass
            finally:
                with LOCK:
                    JOB = None
        JOB = threading.Thread(target=run, name='AlkudsBackupSnapshot', daemon=True)
        JOB.start()
        return True
