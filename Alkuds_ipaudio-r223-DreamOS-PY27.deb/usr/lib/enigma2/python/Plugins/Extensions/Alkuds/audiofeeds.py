# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from . import audioconfig
from .py2compat import os
from .py2compat import re
from .py2compat import threading
from .py2compat import time
try:
    from .py2compat import urllib
    quote = urllib.parse.quote
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
    parse_qsl = urllib.parse.parse_qsl
    unquote = urllib.parse.unquote
except ImportError:
    from urllib import quote, unquote
    from urlparse import urljoin, urlparse, parse_qsl
from .py2compat import requests
from requests.adapters import HTTPAdapter, Retry
from Components.ActionMap import ActionMap
from .xStaticText import List as PlainList
from .audiolistinfo import AudioList as List, audio_list_skin, audio_row, watch_epg
from .xStaticText import ChoiceBox
from .xStaticText import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from enigma import eTimer
from .plugin import cfg
from .xStaticText import StaticText
from .uihelpers import channel_row, server_row
STORE_ETC = '/etc/enigma2/best_family_audio_sources.json'
STORE_HDD = '/media/hdd/best_family_audio_sources.json'
LEGACY_STORES = ('/etc/enigma2/alkuds_audio_sources.json', '/media/hdd/alkuds_audio_sources.json', '/media/usb/alkuds_audio_sources.json')
KIND_LABELS = {'best_audio': 'Best Audio', 'sat_family': 'Sat Family Audio', 'orange_audio': 'Radio Orange (radio.orange-audio.top)', 'orange_goradio': 'GoRadio (goradio.top)', 'free_audio': 'Free IPAUDIO', 'anis_audio': 'Anis Free Audio', 'fox_audio': 'FoX Free Audio'}
TOKEN_KINDS = ('sat_family', 'orange_goradio')
TOKEN_ONLY_KINDS = ('orange_audio', 'best_audio')
DIRECT_KINDS = ('free_audio', 'anis_audio', 'fox_audio')
IMMUTABLE_KINDS = ('anis_audio', 'fox_audio')
MAX_PLAYLIST_BYTES = 6 * 1024 * 1024
BUILTIN_AUDIO = {'anis_audio': [{'name': 'Anis FM', 'url': 'http://anisfm.pp.ua/Mx1', 'builtin': True}], 'fox_audio': [{'name': 'FoX FM Live 1', 'url': 'http://foxfm.xyz:8080/live1', 'builtin': True}, {'name': 'FoX FM Live 2', 'url': 'http://foxfm.xyz:8080/live2', 'builtin': True}, {'name': 'FoX FM Live 3', 'url': 'http://foxfm.xyz:8080/live3', 'builtin': True}, {'name': 'FoX FM Live 4', 'url': 'http://foxfm.xyz:8080/live4', 'builtin': True}, {'name': 'FoX FM 1', 'url': 'http://foxfm.xyz/1', 'builtin': True}, {'name': 'FoX FM 2', 'url': 'http://foxfm.xyz/2', 'builtin': True}, {'name': 'FoX FM 3', 'url': 'http://foxfm.xyz/3', 'builtin': True}, {'name': 'FoX FM 4', 'url': 'http://foxfm.xyz/4', 'builtin': True}, {'name': 'FoX FM 5', 'url': 'http://foxfm.xyz/5', 'builtin': True}, {'name': 'FoX FM 6', 'url': 'http://foxfm.xyz/6', 'builtin': True}, {'name': 'FoX FM 7', 'url': 'http://foxfm.xyz/7', 'builtin': True}, {'name': 'FoX FM 8', 'url': 'http://foxfm.xyz/8', 'builtin': True}, {'name': 'FoX FM 9', 'url': 'http://foxfm.xyz/9', 'builtin': True}, {'name': 'FoX FM Xtra 1', 'url': 'http://foxfm.xyz:8080/xtra1', 'builtin': True}, {'name': 'FoX FM Xtra 2', 'url': 'http://foxfm.xyz:8080/xtra2', 'builtin': True}, {'name': 'FoX FM Xtra 3', 'url': 'http://foxfm.xyz:8080/xtra3', 'builtin': True}, {'name': 'FoX FM EN 1', 'url': 'http://foxfm.xyz:8080/en1', 'builtin': True}, {'name': 'FoX FM EN 2', 'url': 'http://foxfm.xyz:8080/en2', 'builtin': True}, {'name': 'FoX FM FR 1', 'url': 'http://foxfm.xyz:8080/fr1', 'builtin': True}, {'name': 'FoX FM FR 2', 'url': 'http://foxfm.xyz:8080/fr2', 'builtin': True}, {'name': 'FoX FM StarzPlay 1', 'url': 'http://foxfm.xyz:8080/starzplay1', 'builtin': True}, {'name': 'FoX FM StarzPlay 2', 'url': 'http://foxfm.xyz:8080/starzplay2', 'builtin': True}, {'name': 'FoX FM Shasha 1', 'url': 'http://foxfm.xyz:8080/shasha1', 'builtin': True}, {'name': 'FoX FM Shasha 2', 'url': 'http://foxfm.xyz:8080/shasha2', 'builtin': True}, {'name': 'FoX FM Thmanyah 1', 'url': 'http://foxfm.xyz:8080/thmanyah1', 'builtin': True}, {'name': 'FoX FM Thmanyah 2', 'url': 'http://foxfm.xyz:8080/thmanyah2', 'builtin': True}, {'name': 'FoX FM Thmanyah 3', 'url': 'http://foxfm.xyz:8080/thmanyah3', 'builtin': True}, {'name': 'FoX FM Shahid 1', 'url': 'http://foxfm.xyz:8080/shahid1', 'builtin': True}, {'name': 'FoX FM Shahid 2', 'url': 'http://foxfm.xyz:8080/shahid2', 'builtin': True}, {'name': 'FoX FM Alkass 5', 'url': 'http://foxfm.xyz:8080/alkass5', 'builtin': True}, {'name': 'FoX FM Alkass 6', 'url': 'http://foxfm.xyz:8080/alkass6', 'builtin': True}, {'name': 'FoX FM Alkass 7', 'url': 'http://foxfm.xyz:8080/alkass7', 'builtin': True}, {'name': 'FoX FM Alkass 8', 'url': 'http://foxfm.xyz:8080/alkass8', 'builtin': True}]}
ANIS_TOKEN_BOT = '@AnisFM_Tokens_bot'
ANIS_CHANNELS = [('Anis Max 1', 'mx/1'), ('Anis Max 2', 'mx/2'), ('Anis Max 3', 'mx/3'), ('Anis Max 4', 'mx/4'), ('Anis Max 5', 'mx/5'), ('Anis Max 6', 'mx/6'), ('Anis Sport 1', 'pn/1'), ('Anis Sport 2', 'pn/2'), ('Anis Sport 3', 'pn/3'), ('Anis Sport 4', 'pn/4'), ('Anis Sport 5', 'pn/5'), ('Anis Sport 6', 'pn/6'), ('Anis Sport 7', 'pn/7'), ('Anis Sport 8', 'pn/8'), ('Anis Sport 9', 'pn/9'), ('Anis Italy 1', 'it/1'), ('Anis Italy 2', 'it/2'), ('Anis DE 1', 'gr/1'), ('Anis DE 2', 'gr/2'), ('Anis Thm8h 1', 'sa/1'), ('Anis Thm8h 2', 'sa/2'), ('Anis Thm8h 3', 'sa/3'), ('Anis Shasha', 'sha/1'), ('Anis Shahid', 'sha/2'), ('Anis EN 1', 'pn/1EN'), ('Anis EN 2', 'pn/2EN'), ('Anis FR 1', 'pn/1FR'), ('Anis FR 2', 'pn/2FR'), ('Anis Xtra 1', 'sha/XR1'), ('Anis Xtra 2', 'sha/XR2'), ('Anis Al Kass 1', 'sha/K1'), ('Anis Al Kass 2', 'sha/K2'), ('Anis Max 1 Low', 'mx/1L'), ('Anis Max 2 Low', 'mx/2L'), ('Anis Max 3 Low', 'mx/3L'), ('Anis Max 4 Low', 'mx/4L'), ('Anis Max 5 Low', 'mx/5L'), ('Anis Max 6 Low', 'mx/6L')]

def build_anis_channels(token):
    """Build the fixed Anis FM catalogue from the one-time bot token."""
    token = str(token or '').strip()
    if not token:
        return []
    channels = []
    for name, path in ANIS_CHANNELS:
        channels.append({'name': name, 'url': 'http://radio.anisfm.vip/live/%s?token=%s#' % (path, token), 'group': 'Anis Free Audio'})
    return channels
PROVIDER_HOSTS = {'sat_family': 'http://stereofm.live', 'best_audio': 'http://radio.best-audio.org', 'orange_audio': 'http://radio.orange-audio.top', 'orange_goradio': 'http://goradio.top'}
PROVIDER_CHANNELS = {'sat_family': [('SatFamily-4k-Match', 'SF4K-Match'), ('SatFamily-4k-1', 'SF4K-1'), ('SatFamily-4k-2', 'SF4K-2'), ('SatFamily-4k-3', 'SF4K-3'), ('SatFamily-4k-4', 'SF4K-4'), ('SatFamily-4k-5', 'SF4K-5'), ('SatFamily-4k-6', 'SF4K-6'), ('SatFamily-4k-7', 'SF4K-7'), ('SatFamily-4k-8', 'SF4K-8'), ('SatFamily-4k-9', 'SF4K-9'), ('SatFamily-4k-Xtra-1', 'SF4K-XTRA1'), ('SatFamily-4k-Xtra-2', 'SF4K-XTRA2'), ('SatFamily-4k-Xtra-3', 'SF4K-XTRA3'), ('SatFamily-4k-Xtra-4', 'SF4K-XTRA4'), ('SatFamily-4k-Xtra-5', 'SF4K-XTRA5'), ('SatFamily-4k-Xtra-6', 'SF4K-XTRA6'), ('SatFamily-4k-Ad-1', 'SF4K-AD1'), ('SatFamily-4k-Ad-2', 'SF4K-AD2'), ('SatFamily-4K-Alrabiaa-Sports-1', 'SF4K-4K-Alrabiaa-Sports-1'), ('SatFamily-4K-Alrabiaa-Sports-2', 'SF4K-4K-Alrabiaa-Sports-2'), ('SatFamily-4K-Shasha-Sport-1', 'SF4K-4K-Shasha-1')], 'orange_audio': [('Orange AD Prem 1', 'Orange-Ad1'), ('Orange AD Prem 2', 'Orange-Ad2'), ('Orange Live', 'Orange-live'), ('Orange ON FM', 'Orange-ONFM'), ('Orange Audio 1', 'Orange-Audio1'), ('Orange Audio 2', 'Orange-Audio2'), ('Orange Audio 3', 'Orange-Audio3'), ('Orange Audio 4', 'Orange-Audio4'), ('Orange Audio 5', 'Orange-Audio5'), ('Orange Audio 6', 'Orange-Audio6'), ('Orange Audio 7', 'Orange-Audio7'), ('Orange Audio 8', 'Orange-Audio8'), ('Orange Audio 9', 'Orange-Audio9'), ('Orange Xtra 1', 'Orange-Xtra1'), ('Orange Xtra 2', 'Orange-Xtra2'), ('Orange Xtra 3', 'Orange-Xtra3'), ('Orange Xtra 4', 'Orange-Xtra4'), ('Orange Xtra 5', 'Orange-Xtra5'), ('Orange Xtra 6', 'Orange-Xtra6'), ('Orange EN 1', 'Orange-EN1'), ('Orange EN 2', 'Orange-EN2'), ('Orange FR 1', 'Orange-FR1'), ('Orange FR 2', 'Orange-FR2'), ('Orange thmanyah 1', 'Orange-thmanyah1'), ('Orange thmanyah 2', 'Orange-thmanyah2')]}

def _template_data():
    return {'best_audio': [{'name': 'Best Audio 1', 'url': ''}, {'name': 'Best Audio 2', 'url': ''}, {'name': 'Best Audio 3', 'url': ''}], 'sat_family': [{'name': 'Sat Family Audio 1', 'username': '', 'password': ''}, {'name': 'Sat Family Audio 2', 'username': '', 'password': ''}, {'name': 'Sat Family Audio 3', 'username': '', 'password': ''}], 'orange_audio': [{'name': 'Radio Orange 1', 'token': ''}], 'orange_goradio': [{'name': 'GoRadio 1', 'username': '', 'password': ''}], 'free_audio': [{'name': 'Free IPAUDIO 1', 'url': ''}, {'name': 'Free IPAUDIO 2', 'url': ''}, {'name': 'Free IPAUDIO 3', 'url': ''}]}

def _write_json_file(path, data, overwrite=True):
    try:
        parent = os.path.dirname(path)
        if not os.path.isdir(parent):
            return False
        if not os.access(parent, os.W_OK):
            return False
        if not overwrite and os.path.exists(path):
            return True
        tmp = path + '.tmp'
        with open(tmp, 'w') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write('\n')
        try:
            os.chmod(tmp, 384)
        except Exception:
            pass
        os.rename(tmp, path)
        try:
            os.chmod(path, 384)
        except Exception:
            pass
        return True
    except Exception:
        return False

def _ensure_template_files():
    """Create easy-to-edit 3-slot source files without overwriting user data."""
    template = _template_data()
    _write_json_file(STORE_ETC, template, overwrite=False)
    _write_json_file(STORE_HDD, template, overwrite=False)

def _normalise_entry(item, default_name, kind=''):
    if not isinstance(item, dict):
        return None
    entry = {'name': str(item.get('name') or default_name).strip() or default_name}
    for key in ('url', 'token', 'username', 'password'):
        value = str(item.get(key) or '').strip()
        if value:
            entry[key] = value
    if entry.get('url') or entry.get('token') or (kind in TOKEN_KINDS and entry.get('username') and entry.get('password')):
        return entry
    return None

def _entry_identity(kind, entry):
    if kind == 'anis_audio' and entry.get('token'):
        return 'token\x00%s' % str(entry.get('token'))
    if kind in TOKEN_KINDS and entry.get('username') and entry.get('password'):
        return 'account\x00%s\x00%s' % (entry.get('username'), entry.get('password'))
    return 'url\x00%s' % str(entry.get('url') or '')

def _load_one(path):
    try:
        if not os.path.isfile(path) or os.path.getsize(path) <= 0:
            return None
        with open(path, 'r') as f:
            obj = json.load(f)
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None

def _load_legacy_store():
    _ensure_template_files()
    data = dict(((key, []) for key in KIND_LABELS))
    seen = dict(((key, set()) for key in KIND_LABELS))
    paths = [STORE_ETC, STORE_HDD] + list(LEGACY_STORES)
    for path in paths:
        obj = _load_one(path)
        if not obj:
            continue
        for key in data:
            entries = obj.get(key)
            if not isinstance(entries, list):
                continue
            label = KIND_LABELS.get(key, 'Audio')
            for i, item in enumerate(entries):
                ent = _normalise_entry(item, '%s %d' % (label, i + 1), key)
                if not ent:
                    continue
                identity = _entry_identity(key, ent)
                if identity in seen[key]:
                    continue
                seen[key].add(identity)
                data[key].append(ent)
    for key, entries in BUILTIN_AUDIO.items():
        if not data.get(key):
            data[key] = [dict(item) for item in entries]
    return data

def _load_store():
    audioconfig.ensure()
    raw = audioconfig.load()
    data = {kind: [] for kind in KIND_LABELS}
    for kind in data:
        for index, item in enumerate(raw.get(kind, [])):
            entry = _normalise_entry(item, KIND_LABELS[kind] + ' ' + str(index + 1), kind)
            if entry:
                data[kind].append(entry)
    for kind, rows in BUILTIN_AUDIO.items():
        if not data[kind]:
            data[kind] = [dict(row) for row in rows]
    return data

def source_file_label():
    return 'File: ' + audioconfig.PATH + ' | ' + audioconfig.HDD_PATH

def _source_skin(skin):
    from .py2compat import ElementTree as ET
    from enigma import getDesktop
    screen = ET.fromstring(skin)
    listing = next((n for n in screen.findall('widget') if n.get('source') == 'list'))
    x, y = map(int, listing.get('position').split(','))
    width, height = map(int, listing.get('size').split(','))
    h = 78 if getDesktop(0).size().height() >= 1080 else 64
    listing.set('position', '%d,%d' % (x, y + h))
    listing.set('size', '%d,%d' % (width, height - h))
    ET.SubElement(screen, 'widget', {'source': 'source_files', 'render': 'Label', 'position': '%d,%d' % (x + 12, y), 'size': '%d,%d' % (width - 24, h), 'font': 'alkudsregular;' + ('24' if h == 78 else '20'), 'foregroundColor': '#ffffff', 'backgroundColor': '#1a0b2e', 'zPosition': '3'})
    return ET.tostring(screen, encoding='unicode')

def _orange_radio_token(value):
    value = str(value or '').strip()
    if value.lower().startswith(('http://', 'https://')):
        parsed = urlparse(value)
        if (parsed.hostname or '').lower() != 'radio.orange-audio.top':
            raise ValueError('Use a Radio Orange token or a radio.orange-audio.top URL.')
        value = dict(parse_qsl(parsed.query)).get('token', '')
    if not value:
        raise ValueError('Enter the Radio Orange token.')
    return value

def _token_provider_entry(kind, value, name=''):
    """Accept an opaque token, a provider stream, or its complete playlist URL."""
    if kind not in TOKEN_ONLY_KINDS:
        raise ValueError('Unsupported token provider')
    value = str(value or '').strip()
    if not value or any((char in value for char in ('\r', '\n', '\x00'))):
        raise ValueError('Enter a token or a full subscription URL')
    host = PROVIDER_HOSTS[kind]
    entry = {'name': name or KIND_LABELS[kind], 'url': host}
    if value.lower().startswith(('http://', 'https://')):
        parsed = urlparse(value)
        expected = urlparse(host).hostname
        if (parsed.hostname or '').lower() != expected:
            raise ValueError('This link belongs to a different provider')
        token = dict(parse_qsl(parsed.query, keep_blank_values=True)).get('token', '')
        if not token:
            raise ValueError('The provider URL has no token')
        if not parsed.path.rstrip('/').lower().endswith('/mpegts'):
            entry['url'] = value
            return entry
        value = token
    entry['token'] = value
    return entry

def template_channels(kind, token):
    if kind == 'orange_goradio':
        encoded = quote(str(token), safe='')
        return [{'name': name, 'url': PROVIDER_HOSTS[kind] + '/' + path + '/mpegts?token=' + encoded, 'group': KIND_LABELS[kind]} for name, path in PROVIDER_CHANNELS['orange_audio']]
    if kind in TOKEN_ONLY_KINDS:
        parsed_entry = _token_provider_entry(kind, token)
        if not parsed_entry.get('token'):
            raise ValueError('A playlist URL must be opened as a subscription, not used as a token')
        token = parsed_entry['token']
    names = {'sat_family': 'SATFAMILY', 'orange_audio': 'Orange', 'best_audio': 'Best', 'anis_audio': 'Anis FM'}
    with open(os.path.join(os.path.dirname(__file__), 'audio_provider_templates.json'), encoding='utf8') as stream:
        templates = json.load(stream)
    rows = []
    for item in templates.get(names.get(kind, ''), []):
        base = item['base_url']
        url = base.replace('{TOKEN}', quote(str(token), safe='')) if '{TOKEN}' in base else base + quote(str(token), safe='')
        rows.append({'name': item['name'], 'url': url, 'group': KIND_LABELS[kind]})
    return rows

def _padded_for_file(data):
    """Keep at least three ready-to-paste slots for each provider type."""
    out = dict(((key, []) for key in _template_data()))
    if 'anis_audio' in data:
        out['anis_audio'] = []
    for key in out:
        label = KIND_LABELS.get(key, 'Audio')
        entries = []
        for i, item in enumerate(list(data.get(key) or [])):
            ent = _normalise_entry(item, '%s %d' % (label, i + 1), key)
            if ent:
                entries.append(ent)
        if key == 'anis_audio':
            out[key] = entries[:1]
            continue
        while len(entries) < 3:
            n = len(entries) + 1
            if key in TOKEN_ONLY_KINDS:
                entries.append({'name': '%s %d' % (label, n), 'token': ''})
            elif key in TOKEN_KINDS:
                entries.append({'name': '%s %d' % (label, n), 'username': '', 'password': ''})
            else:
                entries.append({'name': '%s %d' % (label, n), 'url': ''})
        out[key] = entries
    return out

def _save_store(data):
    clean = {kind: [entry for entry in entries if not entry.get('builtin')] for kind, entries in data.items()}
    audioconfig.save(clean)
    return audioconfig.PATH

def add_free_audio_source(name, url):
    """Mirror a stream into Free IPAUDIO and sync the shared ETC/HDD files.

    This public helper is also used by the IPAudio Pro/legacy export buttons so
    one channel selection is visible in both the external plugin and Alkuds.
    """
    value = str(url or '').strip()
    if not _is_stream_url(value):
        raise ValueError('Please enter a full stream URL.')
    display = _safe_name(name, 'Free IPAUDIO')
    data = _load_store()
    entries = list(data.get('free_audio') or [])
    added = True
    for entry in entries:
        if isinstance(entry, dict) and str(entry.get('url') or '').strip() == value:
            added = False
            if not str(entry.get('name') or '').strip():
                entry['name'] = display
            break
    if added:
        entries.append({'name': display, 'url': value})
    data['free_audio'] = entries
    path = _save_store(data)
    return (path, added)

def _masked_url(url):
    """Display useful location data without exposing query tokens/credentials."""
    value = str(url or '')
    try:
        p = urlparse(value)
        host = p.hostname or ''
        port = ':' + str(p.port) if p.port else ''
        path = p.path or ''
        if len(path) > 42:
            path = '...' + path[-39:]
        return '%s://%s%s%s' % (p.scheme or 'http', host, port, path)
    except Exception:
        return value.split('?', 1)[0]

def _is_stream_url(value):
    return str(value or '').strip().lower().startswith(('http://', 'https://', 'rtmp://', 'rtsp://', 'udp://', 'rtp://'))

def _provider_token(username, password):
    return '%s_%s' % (str(username or ''), str(password or ''))

def build_provider_channels(kind, username, password):
    """Build Family/Orange streams from username + password credentials."""
    if kind not in TOKEN_KINDS:
        return []
    username = str(username or '').strip()
    password = str(password or '').strip()
    if not username or not password:
        return []
    return template_channels(kind, _provider_token(username, password))

def _entry_display(kind, entry):
    if entry.get('token'):
        return 'token configured'
    if kind in TOKEN_KINDS and entry.get('username') and entry.get('password'):
        return 'account configured'
    return _masked_url(entry.get('url'))

def _safe_name(text, default='Channel'):
    value = str(text or '').strip()
    value = value.replace('\x00', '')
    return value or default

def _m3u_attr(line, key):
    m = re.search('(?:^|[ ,])%s="([^"]*)"' % re.escape(key), line, re.I)
    return m.group(1).strip() if m else ''

def _clean_headers(values):
    allowed = dict(((key.lower(), key) for key in ('User-Agent', 'X-User-Agent', 'Referer', 'Origin', 'Cookie', 'Authorization', 'Accept')))
    result = {}
    if isinstance(values, dict):
        for key, value in values.items():
            canonical = allowed.get(str(key).lower())
            value = str(value or '').strip()
            if canonical and value and (not any((c in value for c in ('\r', '\n', '\x00')))):
                result[canonical] = value
    return result

def _stream_parts(value, headers=None):
    url, separator, directives = str(value or '').strip().partition('|')
    result = _clean_headers(headers)
    if separator:
        result.update(_clean_headers(dict(parse_qsl(directives, keep_blank_values=True))))
    return (url, result)

def playback_headers(item):
    headers = {'User-Agent': str(cfg.useragent.value)}
    headers.update(_clean_headers(item.get('headers')))
    headers['_AudioFeedHeaders'] = True
    return headers

def resume_headers(context, index, defaults=None):
    headers = dict(defaults or {})
    if context.get('source') in KIND_LABELS:
        entries = context.get('channel_headers') or []
        if 0 <= index < len(entries):
            headers.update(_clean_headers(entries[index]))
        headers['_AudioFeedHeaders'] = True
    return headers

def _parse_m3u(text, base_url):
    lines = [x.strip() for x in str(text or '').replace('\r', '').split('\n')]
    hls_markers = ('#EXT-X-TARGETDURATION', '#EXT-X-MEDIA-SEQUENCE', '#EXT-X-STREAM-INF')
    if any((any((line.startswith(marker) for marker in hls_markers)) for line in lines)):
        return []
    out = []
    pending_name = ''
    pending_group = ''
    pending_headers = {}
    for line in lines:
        if not line:
            continue
        if line.startswith('#EXTINF'):
            comma_name = line.split(',', 1)[1].strip() if ',' in line else ''
            pending_name = _m3u_attr(line, 'tvg-name') or comma_name or 'Channel'
            pending_group = _m3u_attr(line, 'group-title')
            continue
        if line.startswith('#EXTGRP:'):
            pending_group = line.split(':', 1)[1].strip()
            continue
        if line.startswith('#EXTHTTP:'):
            try:
                pending_headers.update(_clean_headers(json.loads(line.split(':', 1)[1])))
            except (ValueError, TypeError):
                pass
            continue
        if line.startswith('#EXTVLCOPT:'):
            option, _, value = line.split(':', 1)[1].partition('=')
            key = {'http-user-agent': 'User-Agent', 'http-referrer': 'Referer', 'http-referer': 'Referer', 'http-origin': 'Origin', 'http-cookie': 'Cookie'}.get(option.lower())
            if key:
                pending_headers.update(_clean_headers({key: value}))
            continue
        if line.startswith('#'):
            continue
        low = line.lower()
        if low.startswith(('http://', 'https://', 'rtmp://', 'rtsp://', 'udp://', 'rtp://')) or '://' not in line:
            line, item_headers = _stream_parts(line, pending_headers)
            url = urljoin(base_url, line) if not re.match('^[a-z][a-z0-9+.-]*://', line, re.I) else line
            name = pending_name or (urlparse(url).path.rsplit('/', 1)[-1] or 'Channel')
            if pending_group and pending_group.lower() not in name.lower():
                pass
            out.append({'name': _safe_name(name), 'url': str(url), 'group': pending_group, 'headers': item_headers})
            pending_name = ''
            pending_group = ''
            pending_headers = {}
    return out

def _walk_json(obj, result):
    if isinstance(obj, dict):
        url = obj.get('url') or obj.get('stream_url') or obj.get('stream') or obj.get('link') or obj.get('cmd')
        if isinstance(url, str) and url.strip():
            name = obj.get('display_name') or obj.get('name') or obj.get('title') or obj.get('channel') or 'Channel'
            result.append({'name': _safe_name(name), 'url': url.strip(), 'group': str(obj.get('group') or obj.get('group_title') or ''), 'headers': _clean_headers(obj.get('headers'))})
        for key in ('streams', 'channels', 'playlist', 'items', 'data', 'results', 'Playlist'):
            if key in obj:
                _walk_json(obj.get(key), result)
        if not url:
            for key, value in obj.items():
                if key not in ('streams', 'channels', 'playlist', 'items', 'data', 'results', 'Playlist') and isinstance(value, (dict, list)):
                    _walk_json(value, result)
    elif isinstance(obj, list):
        for item in obj:
            _walk_json(item, result)

def _dedupe(channels):
    seen = set()
    out = []
    for item in channels:
        try:
            url, headers = _stream_parts(item.get('url'), item.get('headers'))
            identity = (url, tuple(sorted(headers.items())))
            if not _is_stream_url(url) or identity in seen:
                continue
            seen.add(identity)
            out.append({'name': _safe_name(item.get('name')), 'url': url, 'group': str(item.get('group') or ''), 'headers': headers})
        except Exception:
            pass
    return out

class _AudioPlaylistPageError(RuntimeError):
    pass

def _has_provider_credentials(kind, entry):
    return bool(kind in ('sat_family', 'orange_audio', 'orange_goradio', 'best_audio', 'anis_audio') and entry.get('token') or (kind in TOKEN_KINDS and entry.get('username') and entry.get('password')))

def _provider_catalogue(kind, entry):
    if entry.get('token'):
        return template_channels(kind, entry['token'])
    return build_provider_channels(kind, entry.get('username'), entry.get('password'))

def _prefer_provider_catalogue(kind, entry, url):
    if not _has_provider_credentials(kind, entry):
        return False
    if not url:
        return True
    try:
        parsed = urlparse(url)
        return parsed.scheme in ('http', 'https') and bool(parsed.hostname) and (parsed.path in ('', '/')) and (not parsed.query)
    except ValueError:
        return False

def _load_audio_subscription(kind, entry, url, name, metadata=None):
    if kind in TOKEN_ONLY_KINDS and url:
        try:
            parsed = urlparse(url)
            stream_link = (parsed.hostname or '').lower() == urlparse(PROVIDER_HOSTS[kind]).hostname and parsed.path.rstrip('/').lower().endswith('/mpegts')
        except ValueError:
            stream_link = False
        if stream_link:
            entry = _token_provider_entry(kind, url, name)
            url = entry['url']
    if _prefer_provider_catalogue(kind, entry, url):
        return _provider_catalogue(kind, entry)
    try:
        return fetch_playlist(url, name, metadata)
    except _AudioPlaylistPageError:
        if _has_provider_credentials(kind, entry):
            return _provider_catalogue(kind, entry)
        raise

def fetch_playlist(subscription_url, default_name='Audio Stream', metadata=None):
    """Load a remote channel list without ever logging the secret URL/token."""
    url, source_headers = _stream_parts(subscription_url)
    if not url.lower().startswith(('http://', 'https://')):
        raise ValueError('Only http:// and https:// subscription URLs are supported.')
    retries = Retry(total=1, backoff_factor=0.3, status_forcelist=[429, 500, 502, 503, 504])
    sess = requests.Session()
    sess.mount('http://', HTTPAdapter(max_retries=retries))
    sess.mount('https://', HTTPAdapter(max_retries=retries))
    headers = {'User-Agent': str(cfg.useragent.value)}
    headers.update(source_headers)
    r = None
    chunks, total = ([], 0)
    response_url = url
    try:
        r = sess.get(url, headers=headers, timeout=(8, 15), stream=True, allow_redirects=True)
        if r.status_code >= 400:
            raise RuntimeError('Audio source returned HTTP %s. Check the subscription and provider access.' % r.status_code)
        response_url = r.url or url
        ctype = str(r.headers.get('Content-Type', '') or '').lower().split(';', 1)[0]
        if ctype.startswith('audio/') and 'mpegurl' not in ctype or ctype in ('video/mp2t', 'video/mpegts'):
            return [{'name': default_name, 'url': url, 'group': '', 'headers': source_headers}]
        for chunk in r.iter_content(chunk_size=65536):
            if not chunk:
                continue
            chunks.append(chunk)
            total += len(chunk)
            sample = b''.join(chunks)[:2048]
            if b'\x00' in sample or (len(sample) >= 377 and sample[0:1] == b'G' and (sample[188:189] == b'G') and (sample[376:377] == b'G')) or sample.startswith(b'ID3'):
                return [{'name': default_name, 'url': url, 'group': '', 'headers': source_headers}]
            if total > MAX_PLAYLIST_BYTES:
                raise RuntimeError('Audio playlist exceeds the supported size.')
    except requests.RequestException:
        raise RuntimeError('Could not connect to the audio source. Check network and subscription URL.')
    finally:
        if r is not None:
            r.close()
        sess.close()
    raw = b''.join(chunks)
    if not raw:
        raise RuntimeError('The subscription returned an empty response.')
    if b'\x00' in raw[:2048] or (raw[0:1] == b'G' and len(raw) >= 188):
        return [{'name': default_name, 'url': url, 'group': '', 'headers': source_headers}]
    text = raw.decode('utf-8', 'replace').lstrip(u'\ufeff').strip()
    if re.search('<(?:!doctype\\s+html|html|body)(?:\\s|>)', text[:2048], re.I):
        raise _AudioPlaylistPageError('This URL returned a website, not an audio playlist. Configure the provider token or username/password, or use a full playlist URL.')
    if not text:
        return [{'name': default_name, 'url': url, 'group': '', 'headers': source_headers}]
    channels = []
    if text.startswith('{') or text.startswith('['):
        try:
            obj = json.loads(text)
            if metadata is not None:
                from .accountinfo import account_fields
                metadata.update(account_fields(obj))
            _walk_json(obj, channels)
        except Exception:
            channels = []
    if not channels and ('#EXTM3U' in text.upper() or '#EXTINF' in text.upper()):
        channels = _parse_m3u(text, response_url)
        if not channels and '#EXT-X-' in text.upper():
            return [{'name': default_name, 'url': url, 'group': '', 'headers': source_headers}]
    if not channels:
        for line in text.replace('\r', '').split('\n'):
            s = line.strip()
            if not s or s.startswith('#'):
                continue
            name = ''
            candidate = s
            for sep in ('|', ',', '\t'):
                if sep in s:
                    left, right = s.split(sep, 1)
                    if right.strip().lower().startswith(('http://', 'https://')):
                        name, candidate = (left.strip(), right.strip())
                        break
            if candidate.lower().startswith(('http://', 'https://')):
                channels.append({'name': name or 'Channel %d' % (len(channels) + 1), 'url': candidate, 'group': ''})
    channels = _dedupe(channels)
    if not channels:
        raise RuntimeError('The audio source returned no playable channels. Check the subscription format.')
    for item in channels:
        merged = dict(source_headers)
        merged.update(item.get('headers') or {})
        item['headers'] = merged
    return channels

def _schedule_backup_after_start(kind, name, source_url, channel_count, active_name=None, subscription_entry=None):
    """Back up direct/token sources only after the audio backend is alive."""
    expected_active_name = str(active_name if active_name is not None else name)

    def worker():
        for _attempt in range(120):
            time.sleep(0.5)
            try:
                from .backgroundaudio import background_audio_status
                active, active_name, backend = background_audio_status()
                if active and str(active_name) == expected_active_name and (backend not in ('starting', 'restarting', '')):
                    from .remote_backup import backup_audiofeed_connected
                    backup_audiofeed_connected(kind, name, source_url, channel_count, subscription_entry=subscription_entry)
                    return
                if not active and _attempt >= 7:
                    return
            except Exception:
                pass
    try:
        thread = threading.Thread(target=worker)
        thread.daemon = True
        thread.start()
    except Exception:
        pass

def _skin():
    try:
        from .stalker import _channels_skin
        return _channels_skin()
    except Exception:
        return '<screen name="AlkudsAudioFeeds" position="80,60" size="1120,600" backgroundColor="#191020" />'

class Alkuds_AudioFeed_Manager(Screen):

    def __init__(self, session, kind='best_audio'):
        Screen.__init__(self, session)
        self.skin = audio_list_skin(_source_skin(_skin()))
        self['source_files'] = StaticText(audioconfig.PATH + '\n' + audioconfig.HDD_PATH)
        self.session = session
        self.kind = kind if kind in KIND_LABELS else 'best_audio'
        self.label = KIND_LABELS[self.kind]
        self.entries = []
        self['title'] = StaticText('')
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('Play' if self.kind in DIRECT_KINDS else 'Open')
        if self.kind == 'anis_audio':
            self['key_yellow'] = StaticText('Change Token')
            self['key_blue'] = StaticText('')
        else:
            self['key_yellow'] = StaticText('' if self.kind in IMMUTABLE_KINDS else 'User / Pass' if self.kind in TOKEN_KINDS else 'Add URL')
            self['key_blue'] = StaticText('' if self.kind in IMMUTABLE_KINDS else 'Delete')
        if self.kind in TOKEN_ONLY_KINDS:
            self['key_yellow'] = StaticText('Add Token / URL')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions', 'MenuActions'], {'cancel': self.close, 'red': self.close, 'green': self.open_selected, 'ok': self.open_selected, 'yellow': self.add_url, 'blue': self.delete_selected, 'menu': self.options_menu, 'info': self.show_schedule, 'epg': self.show_schedule, 'stop': self.stop_all}, -10)
        self.onLayoutFinish.append(self.refresh)
        self.onFirstExecBegin.append(self._show_anis_token_prompt)
        if self.kind in DIRECT_KINDS:
            watch_epg(self, self.refresh)

    def refresh(self):
        try:
            data = _load_store()
        except Exception:
            self['title'].setText(self.label + ' | ' + source_file_label())
            self.entries = []
            self['list'].setList([('Check configuration file: ' + audioconfig.PATH, -1)])
            self.session.open(MessageBox, 'Unable to read audio configuration. Check section names and file format:\n' + audioconfig.PATH, MessageBox.TYPE_ERROR, timeout=10)
            return
        if self.kind == 'anis_audio':
            saved = list(data.get('anis_audio') or [])
            token = str(saved[0].get('token') or '').strip() if saved and isinstance(saved[0], dict) else ''
            self._anis_token = token
            self.entries = template_channels('anis_audio', token) if token else list(data.get('anis_audio') or [])
        else:
            self.entries = list(data.get(self.kind) or [])
        rows = []
        for idx, item in enumerate(self.entries):
            name = str(item.get('name') or '%s %d' % (self.label, idx + 1))
            rows.append(audio_row(server_row(name, _entry_display(self.kind, item)), idx, name, item, self.kind) if self.kind in DIRECT_KINDS else (server_row(name, _entry_display(self.kind, item)), idx))
        if not rows:
            prompt = 'token' if self.kind in TOKEN_ONLY_KINDS else 'account' if self.kind in TOKEN_KINDS else 'URL'
            rows = [('No entries. Press YELLOW to add an %s.' % prompt, -1)]
        self['list'].setList(rows)
        self['title'].setText(self.label)

    def _index(self):
        cur = self['list'].getCurrent()
        try:
            return int(cur[1]) if cur else -1
        except Exception:
            return -1

    def show_schedule(self):
        index = self._index()
        if self.kind not in DIRECT_KINDS or not 0 <= index < len(self.entries):
            return
        item = self.entries[index]
        from .sportsguide import open_schedule
        open_schedule(self.session, item.get('name', 'Audio'), item, self.kind)

    def _show_anis_token_prompt(self):
        if self.kind != 'anis_audio' or getattr(self, '_anis_prompted', False):
            return
        self._anis_prompted = True
        if getattr(self, '_anis_token', ''):
            return
        self.session.openWithCallback(self._anis_notice_closed, MessageBox, u'للحصول على توكن صوتيات أنيس، اذهب إلى بوت رابط التفعيل:\n%s\n\nبعد الحصول على التوكن أدخله هنا.' % ANIS_TOKEN_BOT, MessageBox.TYPE_INFO, timeout=0)

    def _anis_notice_closed(self, result=None):
        if self.kind != 'anis_audio' or getattr(self, '_anis_token', ''):
            return
        self.session.openWithCallback(self._anis_token_entered, VirtualKeyBoard, title='Enter Anis FM token', text='')

    def _change_anis_token(self):
        self.session.openWithCallback(self._anis_token_entered, VirtualKeyBoard, title='Enter new Anis FM token', text='')

    def _anis_token_entered(self, value=None):
        token = str(value or '').strip()
        if not token:
            return
        data = _load_store()
        data['anis_audio'] = [{'name': 'Anis FM', 'token': token}]
        try:
            _save_store(data)
            self._anis_token = token
            self.refresh()
            self.session.open(MessageBox, 'Anis FM token saved.\n%s channels are ready.' % len(ANIS_CHANNELS), MessageBox.TYPE_INFO, timeout=5)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to save Anis FM token:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=7)

    def _provider_token_entered(self, value=None):
        if not value:
            return
        try:
            data = _load_store()
            entries = list(data.get(self.kind) or [])
            entry = _token_provider_entry(self.kind, value, '%s %d' % (self.label, len(entries) + 1))
            identity = (entry.get('url'), entry.get('token'))
            if any(((row.get('url'), row.get('token')) == identity for row in entries)):
                return
            entries.append(entry)
            data[self.kind] = entries
            self._save_and_refresh(data, 'Subscription saved.')
        except Exception:
            self.session.open(MessageBox, "Could not save subscription. Use this provider's token, channel URL or full playlist URL.", MessageBox.TYPE_ERROR, timeout=7)

    def _orange_token_entered(self, value=None):
        return self._provider_token_entered(value)

    def add_url(self):
        if self.kind in TOKEN_ONLY_KINDS:
            self.session.openWithCallback(self._provider_token_entered, VirtualKeyBoard, title='%s - token / channel URL / playlist URL' % self.label, text='')
            return
        if self.kind == 'anis_audio':
            self._change_anis_token()
            return
        if self.kind in IMMUTABLE_KINDS:
            return
        if self.kind in TOKEN_KINDS:
            self.add_account()
            return
        self.session.openWithCallback(self._url_entered, VirtualKeyBoard, title='Add %s URL' % self.label, text='https://')

    def add_account(self):
        self.session.openWithCallback(self._username_entered, VirtualKeyBoard, title='%s username' % self.label, text='')

    def _username_entered(self, value=None):
        username = str(value or '').strip()
        if not username:
            return
        self._new_username = username
        self.session.openWithCallback(self._password_entered, VirtualKeyBoard, title='%s password' % self.label, text='')

    def _password_entered(self, value=None):
        password = str(value or '').strip()
        username = str(getattr(self, '_new_username', '') or '').strip()
        self._new_username = ''
        if not username or not password:
            return
        data = _load_store()
        entries = list(data.get(self.kind) or [])
        candidate = {'name': '%s Account %d' % (self.label, len(entries) + 1), 'username': username, 'password': password}
        if self.kind == 'orange_goradio':
            candidate.update(url=PROVIDER_HOSTS[self.kind], token=_provider_token(username, password))
        identity = _entry_identity(self.kind, candidate)
        if any((_entry_identity(self.kind, x) == identity for x in entries if isinstance(x, dict))):
            self.session.open(MessageBox, 'This account is already saved.', MessageBox.TYPE_INFO, timeout=5)
            return
        entries.append(candidate)
        data[self.kind] = entries
        self._save_and_refresh(data, 'Account saved.')

    def _save_and_refresh(self, data, message):
        try:
            path = _save_store(data)
            self.refresh()
            self.session.open(MessageBox, '%s\n%s' % (message, path), MessageBox.TYPE_INFO, timeout=5)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to save entry:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=7)

    def _url_entered(self, value=None):
        if not value:
            return
        url = str(value).strip()
        if not _is_stream_url(url):
            self.session.open(MessageBox, 'Please enter a full stream URL.', MessageBox.TYPE_ERROR, timeout=6)
            return
        if self.kind in DIRECT_KINDS:
            self._new_direct_url = url
            data = _load_store()
            number = len(list(data.get(self.kind) or [])) + 1
            self.session.openWithCallback(self._direct_name_entered, VirtualKeyBoard, title='Enter a name for this audio stream', text='Free IPAUDIO %d' % number)
            return
        self._save_url_entry(url)

    def _direct_name_entered(self, value=None):
        url = str(getattr(self, '_new_direct_url', '') or '').strip()
        self._new_direct_url = ''
        if not url:
            return
        self._save_url_entry(url, str(value or '').strip())

    def _save_url_entry(self, url, custom_name=''):
        data = _load_store()
        entries = list(data.get(self.kind) or [])
        if any((str(x.get('url') or '').strip() == url for x in entries if isinstance(x, dict))):
            self.session.open(MessageBox, 'This URL is already saved.', MessageBox.TYPE_INFO, timeout=5)
            return
        name = custom_name or '%s %d' % (self.label, len(entries) + 1)
        entries.append({'name': name, 'url': url})
        data[self.kind] = entries
        self._save_and_refresh(data, 'URL saved.')

    def open_selected(self):
        idx = self._index()
        if idx < 0 or idx >= len(self.entries):
            return
        item = self.entries[idx]
        if self.kind in DIRECT_KINDS and (not item.get('token')):
            self._play_direct(idx, item)
            return
        self.session.openWithCallback(self._child_closed, Alkuds_AudioFeed_Channels, self.kind, str(item.get('name') or self.label), str(item.get('url') or ''), dict(item))

    def _play_direct(self, idx, item):
        name = str(item.get('name') or self.label)
        url = str(item.get('url') or '')
        try:
            from .backgroundaudio import start_background_audio_direct
            cached = [(str(x.get('name') or 'Free Audio'), str(x.get('url') or '')) for x in self.entries]
            context = {'source': self.kind, 'channels': cached, 'selected_index': idx, 'channel_name': name, 'mode': 'iptv'}
            start_background_audio_direct(self.session, url, name, headers=playback_headers(item), resume_context=context)
            _schedule_backup_after_start(self.kind, name, url, 1)
            self.close('ipaudio-started')
        except Exception as e:
            self.session.open(MessageBox, 'Unable to start IPAUDIO:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def _child_closed(self, result=None):
        if result == 'ipaudio-started':
            self.close('ipaudio-started')

    def delete_selected(self):
        if self.kind in IMMUTABLE_KINDS:
            return
        idx = self._index()
        if idx < 0 or idx >= len(self.entries):
            return
        self._delete_index = idx
        name = str(self.entries[idx].get('name') or self.label)
        self.session.openWithCallback(self._delete_confirmed, MessageBox, 'Delete %s subscription?' % name, MessageBox.TYPE_YESNO)

    def _delete_confirmed(self, answer=False):
        if not answer:
            return
        idx = getattr(self, '_delete_index', -1)
        data = _load_store()
        entries = list(data.get(self.kind) or [])
        if 0 <= idx < len(entries):
            entries.pop(idx)
            data[self.kind] = entries
            try:
                _save_store(data)
            except Exception as e:
                self.session.open(MessageBox, 'Unable to delete subscription:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=6)
        self.refresh()

    def options_menu(self):
        if self.kind == 'anis_audio':
            self.session.openWithCallback(self._option, ChoiceBox, title='Anis FM', list=[('Play selected channel', 'open'), (u'جدول القناة - توقيت الرسيفر', 'schedule'), ('Change Anis FM token', 'change_token'), ('Cancel', 'cancel')])
            return
        if self.kind in IMMUTABLE_KINDS:
            self.session.openWithCallback(self._option, ChoiceBox, title=self.label, list=[('Play selected channel', 'open'), (u'جدول القناة - توقيت الرسيفر', 'schedule'), ('Cancel', 'cancel')])
            return
        options = [('Play stream' if self.kind in DIRECT_KINDS else 'Open subscription', 'open')]
        if self.kind in TOKEN_ONLY_KINDS:
            options.append(('Add token / channel link / playlist URL', 'add'))
        elif self.kind in TOKEN_KINDS:
            options += [('Add username + password (Virtual Keyboard)', 'add'), ('Add full playlist URL (R30 compatibility)', 'add_legacy')]
        else:
            options.append(('Add URL', 'add'))
        if self.kind in DIRECT_KINDS:
            options.append((u'جدول القناة - توقيت الرسيفر', 'schedule'))
        options += [('Delete selected entry', 'delete'), ('Cancel', 'cancel')]
        self.session.openWithCallback(self._option, ChoiceBox, title=self.label, list=options)

    def _option(self, answer=None):
        if not answer or len(answer) < 2:
            return
        if answer[1] == 'schedule':
            self.show_schedule()
        elif answer[1] == 'open':
            self.open_selected()
        elif answer[1] == 'change_token':
            self._change_anis_token()
        elif answer[1] == 'add':
            self.add_url()
        elif answer[1] == 'add_legacy':
            self.session.openWithCallback(self._url_entered, VirtualKeyBoard, title='Add full %s playlist URL' % self.label, text='https://')
        elif answer[1] == 'delete':
            self.delete_selected()

    def stop_all(self):
        try:
            from .backgroundaudio import stop_ipaudio_and_timeshift
            stop_ipaudio_and_timeshift(session=self.session, close_plugin=True)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to stop IPAUDIO / Timeshift:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=6)

class Alkuds_AudioFeed_Channels(Screen):

    def __init__(self, session, kind, subscription_name, subscription_url, subscription_entry=None):
        Screen.__init__(self, session)
        from .stalker import _channels_skin
        from .accountinfo import account_fields, account_text
        self.skin = audio_list_skin(_source_skin(_channels_skin(account_info=True)))
        self['source_files'] = StaticText(audioconfig.PATH + '\n' + audioconfig.HDD_PATH)
        self.account_info = account_fields(subscription_entry or {})
        self['account_info'] = StaticText(account_text(self.account_info, compact=True))
        self.session = session
        self.kind = kind if kind in KIND_LABELS else 'best_audio'
        self.label = KIND_LABELS[self.kind]
        self.subscription_name = str(subscription_name or self.label)
        self.subscription_url = str(subscription_url or '')
        self.subscription_entry = dict(subscription_entry or {})
        self.original_channels = []
        self.channels = []
        self.sort_mode = 'az'
        self._loading = False
        self._done = False
        self._result = None
        self._error = ''
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll)
        except Exception:
            self._timer.callback.append(self._poll)
        self['title'] = StaticText('')
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('IP Audio')
        self['key_yellow'] = StaticText('Sort')
        self['key_blue'] = StaticText('Reload')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions', 'MenuActions'], {'cancel': self.back, 'red': self.back, 'green': self.play, 'ok': self.play, 'yellow': self.sort_menu, 'blue': self.load, 'menu': self.options_menu, 'info': self.show_schedule, 'epg': self.show_schedule, 'stop': self.stop_all}, -10)
        self.onFirstExecBegin.append(self.load)
        watch_epg(self, self._refresh_epg)
        self._update_title()

    def _update_title(self):
        sort = {'az': 'A-Z', 'za': 'Z-A', 'server': 'Server'}.get(self.sort_mode, 'A-Z')
        self['title'].setText(self.label)

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._done = False
        self._result = None
        self._error = ''
        self['list'].setList([('Loading playlist...', -1)])
        if _prefer_provider_catalogue(self.kind, self.subscription_entry, self.subscription_url):
            self._result = _provider_catalogue(self.kind, self.subscription_entry)
            self._done = True
            self._poll()
            return
        if not self.subscription_url:
            self._error = 'No subscription URL or account credentials were found.'
            self._done = True
            self._poll()
            return
        t = threading.Thread(target=self._worker)
        t.daemon = True
        t.start()
        self._timer.start(100, False)

    def _worker(self):
        try:
            self._result = _load_audio_subscription(self.kind, self.subscription_entry, self.subscription_url, self.subscription_name, self.account_info)
            from .accountinfo import xtream_api_from_url, fetch_xtream_account, account_fields
            api = xtream_api_from_url(self.subscription_url)
            if api:
                try:
                    self.account_info.update(account_fields(fetch_xtream_account(api, cfg.useragent.value)))
                except Exception:
                    pass
        except Exception as e:
            self._error = str(e)
        self._done = True

    def _poll(self):
        if not self._done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._error:
            self['list'].setList([('Load failed - press BLUE to retry', -1)])
            self.session.open(MessageBox, 'Unable to load %s playlist:\n%s' % (self.label, self._error), MessageBox.TYPE_ERROR, timeout=8)
            return
        self.original_channels = list(self._result or [])
        from .accountinfo import account_text
        self['account_info'].setText(account_text(self.account_info, compact=True))
        if self.subscription_url:
            try:
                from .remote_backup import backup_audiofeed_connected
                backup_audiofeed_connected(self.kind, self.subscription_name, self.subscription_url, len(self.original_channels), subscription_entry=self.subscription_entry)
            except Exception:
                pass
        self._apply_sort()

    def _refresh_epg(self):
        if self._loading or self._closed:
            return
        index = self._index()
        name = self.channels[index].get('name') if 0 <= index < len(self.channels) else None
        self._apply_sort(keep_name=name)

    def _apply_sort(self, keep_name=None):
        self.channels = list(self.original_channels)
        if self.sort_mode == 'az':
            self.channels.sort(key=lambda x: str(x.get('name') or '').lower())
        elif self.sort_mode == 'za':
            self.channels.sort(key=lambda x: str(x.get('name') or '').lower(), reverse=True)
        rows = []
        selected = 0
        for idx, item in enumerate(self.channels):
            name = str(item.get('name') or 'Channel')
            rows.append(audio_row(channel_row(idx, name), idx, name, item, self.kind))
            if keep_name is not None and name == keep_name:
                selected = idx
        if not rows:
            rows = [('No channels were found in this playlist.', -1)]
        self['list'].setList(rows)
        if rows and rows[0][1] >= 0:
            try:
                self['list'].setIndex(selected)
            except Exception:
                pass
        self._update_title()

    def _index(self):
        cur = self['list'].getCurrent()
        try:
            return int(cur[1]) if cur else -1
        except Exception:
            return -1

    def back(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass
        self.close()

    def show_schedule(self):
        index = self._index()
        if not 0 <= index < len(self.channels):
            return
        item = self.channels[index]
        from .sportsguide import open_schedule
        open_schedule(self.session, item.get('name', 'Audio'), item, self.kind)

    def sort_menu(self):
        self.session.openWithCallback(self._sort_selected, ChoiceBox, title='Channel sorting', list=[('Alphabetical A - Z', 'az'), ('Alphabetical Z - A', 'za'), ('Original playlist order', 'server')])

    def _sort_selected(self, answer=None):
        if not answer or len(answer) < 2:
            return
        idx = self._index()
        keep = self.channels[idx].get('name') if 0 <= idx < len(self.channels) else None
        self.sort_mode = str(answer[1])
        self._apply_sort(keep)

    def play(self):
        idx = self._index()
        if idx < 0 or idx >= len(self.channels):
            return
        item = self.channels[idx]
        name = str(item.get('name') or 'Channel')
        url = str(item.get('url') or '')
        try:
            from .backgroundaudio import start_background_audio_direct
            cached = [(str(x.get('name') or 'Channel'), str(x.get('url') or '')) for x in self.channels]
            context = {'source': self.kind, 'channels': cached, 'channel_headers': [_clean_headers(x.get('headers')) for x in self.channels], 'selected_index': idx, 'channel_name': name, 'mode': 'iptv', 'subscription_name': self.subscription_name}
            start_background_audio_direct(self.session, url, name, headers=playback_headers(item), resume_context=context)
            if self.kind in ('best_audio', 'sat_family', 'orange_audio', 'orange_goradio'):
                backup_url = self.subscription_url or (str(self.original_channels[0].get('url') or url) if self.original_channels else url)
                _schedule_backup_after_start(self.kind, self.subscription_name, backup_url, len(self.channels), active_name=name, subscription_entry=self.subscription_entry)
            self.close('ipaudio-started')
        except Exception as e:
            self.session.open(MessageBox, 'Unable to start IPAUDIO:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def export_ipaudio(self, kind='pro'):
        idx = self._index()
        if idx < 0 or idx >= len(self.channels):
            return
        item = self.channels[idx]
        name = str(item.get('name') or 'Channel')
        url = str(item.get('url') or '')
        try:
            from .ipaudioexport import export_channel
            path, added = export_channel(kind, name, url)
            target = 'IPAudio Pro' if str(kind) == 'pro' else 'IPAudio'
            msg = ('Added %s to %s.\n%s' if added else '%s already exists in %s.\n%s') % (name, target, path)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to add channel:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def options_menu(self):
        self.session.openWithCallback(self._option, ChoiceBox, title='%s channel options' % self.label, list=[(u'جدول القناة - توقيت الرسيفر', 'schedule'), ('Add to IPAudio Pro', 'add_pro'), ('Add to IPAudio', 'add_old'), ('Sort: A - Z', 'az'), ('Sort: Z - A', 'za'), ('Original playlist order', 'server'), ('Reload playlist', 'reload'), ('Cancel', 'cancel')])

    def _option(self, answer=None):
        if not answer or len(answer) < 2:
            return
        action = answer[1]
        if action == 'schedule':
            self.show_schedule()
        elif action == 'add_pro':
            self.export_ipaudio('pro')
        elif action == 'add_old':
            self.export_ipaudio('legacy')
        elif action == 'reload':
            self.load()
        elif action in ('az', 'za', 'server'):
            idx = self._index()
            keep = self.channels[idx].get('name') if 0 <= idx < len(self.channels) else None
            self.sort_mode = action
            self._apply_sort(keep)

    def stop_all(self):
        try:
            from .backgroundaudio import stop_ipaudio_and_timeshift
            stop_ipaudio_and_timeshift(session=self.session, close_plugin=True)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to stop IPAUDIO / Timeshift:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=6)
