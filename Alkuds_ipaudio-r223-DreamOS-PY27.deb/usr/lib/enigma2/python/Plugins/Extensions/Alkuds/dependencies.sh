#!/bin/sh
# Alkuds IPAUDIO R31P7 dependency bootstrapper
# Installs only from the receiver's configured package feeds. This avoids
# mixing foreign image binaries/ABIs on Enigma2 boxes.

# Serialize automatic and manual runs. Never delete another package manager lock.
DEPS_LOCK=/tmp/alkuds-dependencies.lock
if ! mkdir "$DEPS_LOCK" 2>/dev/null; then
    echo "Alkuds dependency check is already running. See /tmp/ipaudio-dependencies.log"
    exit 0
fi
trap 'rmdir "$DEPS_LOCK" 2>/dev/null' EXIT
trap 'exit 1' HUP INT TERM
LOG=/tmp/ipaudio-dependencies.log
MODE="${1:-manual}"
: > "$LOG" 2>/dev/null || true
# Keep output visible in the Enigma2 Console; individual messages are also appended.

say() { echo "[IPAudio deps] $*"; echo "[IPAudio deps] $*" >> "$LOG" 2>/dev/null || true; }
has_cmd() { command -v "$1" >/dev/null 2>&1; }

# Bound plugin discovery: damaged registries/drivers must not hang setup.
gst_has() {
    has_cmd gst-inspect-1.0 || return 1
    if has_cmd timeout; then
        timeout 8 gst-inspect-1.0 "$1" >/dev/null 2>&1
        return $?
    fi
    gst-inspect-1.0 "$1" >/dev/null 2>&1 &
    inspect_pid=$!
    (sleep 8; kill "$inspect_pid" 2>/dev/null) &
    timer_pid=$!
    wait "$inspect_pid"; inspect_result=$?
    kill "$timer_pid" 2>/dev/null || true
    wait "$timer_pid" 2>/dev/null || true
    return "$inspect_result"
}

PY=""
for candidate in "${ALKUDS_PYTHON:-python2.7}" python2.7 python; do
    if has_cmd "$candidate"; then PY="$candidate"; break; fi
done
PYMAJOR=""
if [ -n "$PY" ]; then
    PYMAJOR="$($PY -c 'import sys; print(sys.version_info[0])' 2>/dev/null || true)"
fi

say "mode=$MODE"
say "date=$(date 2>/dev/null || true)"
say "python=${PY:-missing} major=${PYMAJOR:-unknown}"
[ -r /etc/image-version ] && { say "image-version:"; sed 's/^/  /' /etc/image-version; }
[ -r /etc/issue ] && say "issue=$(head -n 1 /etc/issue 2>/dev/null)"
if [ -r /proc/stb/info/model ]; then say "model=$(cat /proc/stb/info/model 2>/dev/null)"; fi
if [ -r /proc/stb/info/boxtype ]; then say "boxtype=$(cat /proc/stb/info/boxtype 2>/dev/null)"; fi
if has_cmd opkg; then say "opkg architectures:"; opkg print-architecture 2>/dev/null | sed 's/^/  /'; fi

test_py() {
    [ -n "$PY" ] && "$PY" -c "$1" >/dev/null 2>&1
}

PKGMGR=""
if has_cmd apt-get; then PKGMGR=apt; elif has_cmd opkg; then PKGMGR=opkg; fi

pkg_update() {
    case "$PKGMGR" in
        opkg) opkg update || true ;;
        apt) DEBIAN_FRONTEND=noninteractive apt-get update || true ;;
    esac
}

try_install() {
    # Try candidate package names until the caller's test succeeds.
    TEST_KIND="$1"; TEST_VALUE="$2"; shift 2
    for PKG in "$@"; do
        [ -n "$PKG" ] || continue
        case "$TEST_KIND" in
            cmd) has_cmd "$TEST_VALUE" && return 0 ;;
            py) test_py "$TEST_VALUE" && return 0 ;;
            gst) gst_has "$TEST_VALUE" && return 0 ;;
        esac
        say "trying package: $PKG"
        case "$PKGMGR" in
            opkg) opkg install "$PKG" || true ;;
            apt) DEBIAN_FRONTEND=noninteractive apt-get -y install "$PKG" || true ;;
            *) return 1 ;;
        esac
    done
    case "$TEST_KIND" in
        cmd) has_cmd "$TEST_VALUE" ;;
        py) test_py "$TEST_VALUE" ;;
        gst) gst_has "$TEST_VALUE" ;;
        *) return 1 ;;
    esac
}

if [ -z "$PKGMGR" ]; then
    say "No supported package manager found (opkg/apt-get)."
    exit 0
fi

say "Updating configured image feeds..."
pkg_update

# HTTPS trust store: required by requests/curl/wget against modern portals.
case "$PKGMGR" in
  opkg) opkg install ca-certificates >/dev/null 2>&1 || true ;;
  apt) DEBIAN_FRONTEND=noninteractive apt-get -y install ca-certificates >/dev/null 2>&1 || true ;;
esac

# Python runtime libraries used directly by Alkuds.
if [ "$PYMAJOR" = "3" ]; then
    test_py 'import requests' || try_install py 'import requests' python3-requests python3-requests-pyc
    test_py 'from PIL import Image' || try_install py 'from PIL import Image' python3-pillow python3-pil
    test_py 'import six' || try_install py 'import six' python3-six
    test_py 'from multiprocessing.pool import ThreadPool' || try_install py 'from multiprocessing.pool import ThreadPool' python3-multiprocessing
    test_py 'import twisted' || try_install py 'import twisted' python3-twisted
    test_py 'import pkg_resources' || try_install py 'import pkg_resources' python3-setuptools
else
    test_py 'import requests' || try_install py 'import requests' python-requests
    test_py 'from PIL import Image' || try_install py 'from PIL import Image' python-image python-imaging python-pillow
    test_py 'import six' || try_install py 'import six' python-six
    test_py 'from multiprocessing.pool import ThreadPool' || try_install py 'from multiprocessing.pool import ThreadPool' python-multiprocessing
    test_py 'import twisted' || try_install py 'import twisted' python-twisted
    test_py 'import pkg_resources' || try_install py 'import pkg_resources' python-setuptools
fi

# Core media dependency for IPAUDIO Local Remux/background audio.
has_cmd ffmpeg || try_install cmd ffmpeg ffmpeg

# Vu+ path: ServiceApp/ExtEplayer3 is preferred because it writes through the
# DVB playback path. OE-Alliance's exteplayer3 package itself depends on ffmpeg.
# Package names vary between images, so try the common names harmlessly.
if [ ! -x /usr/bin/exteplayer3 ]; then
    try_install cmd exteplayer3 exteplayer3 enigma2-plugin-systemplugins-serviceapp serviceapp || true
fi

# ServiceApp gstplayer is useful on Vu+ images and also pulls in the image's
# own GStreamer/DVB sink integration on several feeds.
if [ ! -x /usr/bin/gstplayer ] && [ ! -x /usr/bin/gstplayer_gst-1.0 ]; then
    try_install cmd gstplayer gstplayer enigma2-plugin-systemplugins-serviceapp || true
fi

# R24's preferred Vu+ native-timeshift backend needs the hardware DVB audio
# GStreamer sink.  Package names differ slightly between OE families.
if has_cmd gst-inspect-1.0; then
    if ! gst_has dvbaudiosink; then
        say "dvbaudiosink missing; trying image-feed packages"
        case "$PKGMGR" in
            opkg)
                for p in gstreamer1.0-plugin-dvbmediasink gstreamer1.0-plugin-multibox-dvbmediasink gstreamer1.0-plugin-dreambox-dvbmediasink; do
                    opkg install "$p" >/dev/null 2>&1 || true
                    gst_has dvbaudiosink && break
                done
                ;;
        esac
    fi
fi

# Background-audio fallback used by receivers where independent PCM works.
if ! has_cmd gst-launch-1.0 || ! has_cmd gst-inspect-1.0; then
    try_install cmd gst-launch-1.0 gstreamer1.0-tools gstreamer1.0 gstreamer1.0-plugins-base || true
fi
has_cmd gst-inspect-1.0 || try_install cmd gst-inspect-1.0 gstreamer1.0-tools gstreamer1.0 || true

# Install the actual missing elements rather than every codec collection.
# Package alternatives are resolved exclusively through this image's feeds.
# Keep space for settings and the GUI. A missing package remains visible below.
optional_free_kb=$(df -Pk /usr 2>/dev/null | awk 'NR==2 {print $4}')
case "$optional_free_kb" in ''|*[!0-9]*) optional_free_kb=0 ;; esac
install_element() {
    element="$1"; shift
    gst_has "$element" && return 0
    optional_free_kb=$(df -Pk /usr 2>/dev/null | awk 'NR==2 {print $4}')
    case "$optional_free_kb" in ''|*[!0-9]*) optional_free_kb=0 ;; esac
    if [ "$optional_free_kb" -lt 16384 ]; then
        say "$element: insufficient free space for optional packages"
        return 1
    fi
    try_install gst "$element" "$@" || true
}
if has_cmd gst-inspect-1.0; then
    install_element tsdemux gstreamer1.0-plugins-bad-mpegtsdemux gstreamer1.0-plugins-bad
    install_element aacparse gstreamer1.0-plugins-good-audioparsers gstreamer1.0-plugins-good
    install_element mpegaudioparse gstreamer1.0-plugins-good-audioparsers gstreamer1.0-plugins-good
    install_element rawaudioparse gstreamer1.0-plugins-base-rawparse gstreamer1.0-plugins-base
    install_element audioconvert gstreamer1.0-plugins-base-audioconvert gstreamer1.0-plugins-base
    install_element audioresample gstreamer1.0-plugins-base-audioresample gstreamer1.0-plugins-base
    install_element playbin gstreamer1.0-plugins-base-playback gstreamer1.0-plugins-base
    install_element udpsrc gstreamer1.0-plugins-good-udp gstreamer1.0-plugins-good
    install_element souphttpsrc gstreamer1.0-plugins-good-soup gstreamer1.0-plugins-good
    install_element qtdemux gstreamer1.0-plugins-good-isomp4 gstreamer1.0-plugins-good
    install_element hlsdemux gstreamer1.0-plugins-bad-hls gstreamer1.0-plugins-bad-adaptivedemux2 gstreamer1.0-plugins-bad
    # Any one software AAC decoder is sufficient; do not install three decoders.
    if ! gst_has avdec_aac && ! gst_has avdec_aac_fixed && ! gst_has faad && ! gst_has fdkaacdec; then
        install_element avdec_aac gstreamer1.0-libav
        if ! gst_has avdec_aac && ! gst_has avdec_aac_fixed; then
            install_element faad gstreamer1.0-plugins-bad-faad gstreamer1.0-plugins-bad
        fi
    fi
fi

# R31P7 Vu+ path: render IPTV sound through ALSA, independently from the
# Broadcom DVB decoder that OpenATV pauses during native Timeshift.
if has_cmd gst-inspect-1.0 && ! gst_has alsasink; then
    say "alsasink missing; trying image-feed packages"
    case "$PKGMGR" in
        opkg)
            for p in gstreamer1.0-plugins-base-alsa gstreamer1.0-plugin-alsa gstreamer1.0-alsa alsa-plugins; do
                opkg install "$p" >/dev/null 2>&1 || true
                gst_has alsasink && break
            done
            ;;
        apt)
            DEBIAN_FRONTEND=noninteractive apt-get -y install gstreamer1.0-alsa >/dev/null 2>&1 || true
            ;;
    esac
fi

has_cmd aplay || try_install cmd aplay alsa-utils-aplay alsa-utils || true
has_cmd curl || try_install cmd curl curl || true
has_cmd wget || try_install cmd wget wget || true
# Used to decode the short-lived public links returned by Elahmad.
has_cmd openssl || try_install cmd openssl openssl || true

say "--- final dependency report ---"
for element in alsasink tsdemux aacparse mpegaudioparse rawaudioparse audioconvert audioresample playbin udpsrc souphttpsrc qtdemux hlsdemux avdec_aac avdec_aac_fixed faad fdkaacdec; do
    if gst_has "$element"; then say "GStreamer $element: OK"; else say "GStreamer $element: unavailable"; fi
done
say "Only image-feed packages were used. Missing elements or ALSA hardware routing may still need image support."
for c in ffmpeg exteplayer3 gstplayer gstplayer_gst-1.0 gst-launch-1.0 gst-inspect-1.0 aplay curl wget openssl; do
    if has_cmd "$c"; then say "$c: $(command -v "$c")"; else say "$c: MISSING"; fi
done
if has_cmd gst-inspect-1.0 && gst_has alsasink; then
    say "GStreamer alsasink: OK"
else
    say "GStreamer alsasink: MISSING"
fi
[ -r /proc/asound/pcm ] && { say "ALSA playback devices:"; sed 's/^/  /' /proc/asound/pcm; }
if [ -n "$PY" ]; then
    for spec in 'requests:import requests' 'PIL:from PIL import Image' 'six:import six' 'multiprocessing:from multiprocessing.pool import ThreadPool' 'twisted:import twisted' 'pkg_resources:import pkg_resources'; do
        NAME=${spec%%:*}; CODE=${spec#*:}
        if test_py "$CODE"; then say "python $NAME: OK"; else say "python $NAME: MISSING"; fi
    done
fi

# A simple marker prevents ambiguity when diagnosing whether auto-install ran.
mkdir -p /etc/enigma2 2>/dev/null || true
{
    echo "completed=$(date +%s 2>/dev/null || echo 0)"
    echo "ffmpeg=$(command -v ffmpeg 2>/dev/null || true)"
    echo "exteplayer3=$(command -v exteplayer3 2>/dev/null || true)"
    echo "gst=$(command -v gst-launch-1.0 2>/dev/null || true)"
    echo "gstplayer=$(command -v gstplayer 2>/dev/null || command -v gstplayer_gst-1.0 2>/dev/null || true)"
    echo "openssl=$(command -v openssl 2>/dev/null || true)"
    if command -v gst-inspect-1.0 >/dev/null 2>&1 && gst_has dvbaudiosink; then
        echo "dvbaudiosink=OK"
    else
        echo "dvbaudiosink=MISSING"
    fi
    if command -v gst-inspect-1.0 >/dev/null 2>&1 && gst_has alsasink; then
        echo "alsasink=OK"
    else
        echo "alsasink=MISSING"
    fi
    echo "aplay=$(command -v aplay 2>/dev/null || true)"
    echo "dvb_audio_nodes=$(ls /dev/dvb/adapter*/audio* 2>/dev/null | tr '\n' ' ')"
    echo "alsa_pcm_nodes=$(ls /dev/snd/pcmC*D*p 2>/dev/null | tr '\n' ' ')"
} > /etc/enigma2/dependency_status.txt 2>/dev/null || true

say "Done. Log: $LOG"
exit 0
