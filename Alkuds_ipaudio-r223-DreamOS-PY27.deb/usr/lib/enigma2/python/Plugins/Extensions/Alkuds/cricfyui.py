# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import cricfy
from .sportacityui import Alkuds_Sportacity_Browser

class Alkuds_Cricfy_Browser(Alkuds_Sportacity_Browser):
    provider = cricfy
    site_name = u'Cricfy TV - الوقت بتوقيت الجهاز'
