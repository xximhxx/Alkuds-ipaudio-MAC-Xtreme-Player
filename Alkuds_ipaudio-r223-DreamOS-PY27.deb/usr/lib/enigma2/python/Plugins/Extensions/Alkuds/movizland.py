# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""MovizLand public archives, seasons and advertised watch servers."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import re
from .py2compat import time
from .py2compat import requests
from . import arabseed as a
from . import sitecatalogue as c
BASE = 'https://www.moviz.land/'
HOSTS = ('www.moviz.land', 'moviz.land')
SECTION_MAP = {'browse': (u'تصفح الموقع', 'free/'), 'movies': (u'الأفلام', 'category/movies/'), 'series': (u'المسلسلات', 'category/series/')}

def _local(value):
    return c.local(BASE, HOSTS, value)

def _get(session, value):
    html, final, mime = c.get(session, _local(value), BASE)
    _local(final)
    return (html, final)

def groups():
    return [{'name': u'البحث في كل الأقسام', 'section': 'browse', 'action': 'search'}, {'name': u'الأفلام', 'section': 'movies', 'node': 'sections'}, {'name': u'المسلسلات', 'section': 'series', 'node': 'sections'}, {'name': u'المضاف حديثاً / تصفح الموقع', 'section': 'browse', 'node': 'sections'}, {'name': u'النوع', 'section': 'filter:genre', 'node': 'sections'}, {'name': u'سنة الإنتاج', 'section': 'filter:release-year', 'node': 'sections'}, {'name': u'الجودة', 'section': 'filter:quality', 'node': 'sections'}, {'name': u'الدولة', 'section': 'filter:country', 'node': 'sections'}, {'name': u'أنمي', 'section': u'archive:/genre/انمي/', 'node': 'sections'}, {'name': u'أطفال', 'section': 'archive:/category/kids/', 'node': 'sections'}]

def _options(section):
    with requests.Session() as session:
        if section in ('movies', 'series'):
            html, page = _get(session, section + '/')
            root = a.Document(html).root
            rows = []
            for holder in root.find(css='movie-section'):
                links = holder.find('a', 'movie-view-all')
                headings = holder.find('h2')
                if links and headings:
                    rows.append((headings[0].text(), links[0].attrs.get('href')))
        else:
            html, page = _get(session, 'category/movies/')
            root = a.Document(html).root
            prefix = '/' + section.split(':', 1)[1] + '/'
            rows = [(n.text(), n.attrs.get('value')) for s in root.find('select') for n in s.find('option') if prefix in (n.attrs.get('value') or '')]
    result, seen = ([], set())
    for label, value in rows:
        if not value or not label:
            continue
        url = _local(value)
        key = c.unquote(c.urlparse(url).path).rstrip('/')
        if key in seen:
            continue
        seen.add(key)
        result.append({'name': label, 'section': 'archive:' + key + '/', 'node': 'sections', 'content_kind': section if section in ('movies', 'series') else ''})
    return result

def sections(section, parent):
    search = [{'name': u'البحث في هذا القسم', 'action': 'search'}]
    if section.startswith('filter:'):
        return _options(section)
    display = [{'name': u'عرض جميع الصفحات بترتيب الموقع', 'node': 'items'}, {'name': u'ترتيب عناوين الصفحة أ–ي', 'node': 'items', 'order': 'az'}, {'name': u'ترتيب عناوين الصفحة ي–أ', 'node': 'items', 'order': 'za'}]
    return search + display + (_options(section) if section in ('movies', 'series') else [])

def _cards(root, page, section, parent=None):
    result, seen = ([], set())
    for block in root.find(css='archive-card') + root.find(css='movie-slide') + root.find(css='search-card'):
        links = block.find('a')
        href = block.attrs.get('data-url') or (links[0].attrs.get('href') if links else '')
        if not href:
            continue
        url = _local(href)
        if url in seen:
            continue
        title = block.attrs.get('data-title') or c.text(block, 'archive-card-title') or c.text(block, 'movie-slide-title') or c.text(block, 'search-card-title')
        if not title:
            continue
        seen.add(url)
        path = c.unquote(c.urlparse(url).path)
        series = path.startswith('/series/') or u'مسلسل' in title or bool(re.search(u'(?:الحلقة|الموسم|الجزء)[-\\s]', path))
        wanted = (parent or {}).get('content_kind') or (section if section in ('movies', 'series') else '')
        if wanted == 'movies' and series or (wanted == 'series' and (not series)):
            continue
        name = c.series_name(title) if series else title
        name = re.sub(u'^مشاهدة\\s+', '', name).strip()
        if series and u'مدبلج' in title and (u'مدبلج' not in name):
            name += u' — مدبلج'
        result.append({'name': name, 'title': title, 'url': url, 'id': url, 'image': block.attrs.get('data-image') or c.image(block, page), 'is_series': series, 'series_key': name.lower() if series else '', 'quality': block.attrs.get('data-quality', ''), 'category': block.attrs.get('data-genres', ''), 'description': block.attrs.get('data-story', ''), 'section': section})
    return result

def fetch_items(section, page=1, query='', order='latest', parent=None):
    parent = parent or {}
    path = section.split(':', 1)[1] if section.startswith('archive:') else SECTION_MAP[section][1]
    url = _local(path)
    if query:
        url = BASE + '?' + c.urlencode({'s': query.encode('utf8')})
    url = c.page_url(url, page, wordpress=True)
    with requests.Session() as session:
        html, final = _get(session, url)
    root = a.Document(html).root
    rows = _cards(root, final, section, parent)
    if not rows and (not query):
        raise RuntimeError(u'موفيز لاند لم يعرض محتوى في هذا القسم حالياً.')
    return {'entries': rows, 'page': int(page), 'last_page': c.last_page(root, page), 'total': len(rows)}

def _number(value, kind):
    value = c.unquote(value)
    m = re.search((u'(?:الحلقة|حلقة)' if kind == 'episode' else u'(?:الموسم|موسم)') + '[-\\s]*(\\d+)', value)
    return int(m.group(1)) if m else 0

def seasons(item):
    with requests.Session() as session:
        html, page = _get(session, item['url'])
    root = a.Document(html).root
    rows, seen = ([], set())
    for node in root.find('a', 'mita-single-season-card'):
        url = _local(node.attrs.get('href', ''))
        if url in seen:
            continue
        seen.add(url)
        number = _number(c.urlparse(url).path, 'season') or _number(node.text(), 'season')
        rows.append(dict(item, name=u'الموسم %d' % number if number else node.text(), url=url, season=url, series_title=item['name'], is_series=False, season_number=number))
    if not rows and root.find('a', 'episode-card'):
        rows = [dict(item, name=u'حلقات المسلسل', season=page, url=page, series_title=item['name'], is_series=False, season_number=0)]
    if not rows:
        raise RuntimeError(u'موفيز لاند لم يعرض مواسم أو حلقات لهذا المسلسل.')
    rows.sort(key=lambda n: n['season_number'])
    return rows

def episodes(item, page=1):
    with requests.Session() as session:
        html, final = _get(session, item.get('season') or item['url'])
    root = a.Document(html).root
    rows, seen = ([], set())
    for node in root.find('a', 'episode-card'):
        url = _local(node.attrs.get('href', ''))
        if url in seen:
            continue
        seen.add(url)
        number = _number(c.urlparse(url).path, 'episode') or _number(node.attrs.get('aria-label', ''), 'episode')
        label = u'الحلقة %d' % number if number else node.attrs.get('aria-label') or node.text()
        rows.append(dict(item, url=url, name=label, title=label, episode_number=number, is_series=False))
    rows.sort(key=lambda n: n['episode_number'] if n['episode_number'] else 10 ** 9)
    if not rows:
        raise RuntimeError(u'موفيز لاند لم يعرض حلقات لهذا الموسم.')
    return {'entries': rows, 'page': 1, 'last_page': 1, 'total': len(rows)}

def servers(item):
    with requests.Session() as session:
        html, page = _get(session, item['url'])
        root = a.Document(html).root
        if not root.find('button', 'server-card'):
            links = [n for n in root.find('a') if '/watch/' in n.attrs.get('href', '')]
            url = _local(links[0].attrs['href']) if links else _local(item['url'].rstrip('/') + '/watch/')
            url = url.replace('//watch/', '/watch/')
            html, page = _get(session, url)
            root = a.Document(html).root
    result = []
    for index, node in enumerate(root.find('button', 'server-card')):
        value = node.attrs.get('data-src')
        if not value:
            continue
        url = c.urljoin(page, c.unescape(value))
        if c.urlparse(url).scheme not in ('http', 'https'):
            continue
        holders = node.find(css='server-text')
        strong = holders[0].find('strong') if holders else []
        label = (strong[0].text() if strong else '') or node.attrs.get('aria-label', '').replace(u'تشغيل ', '') or u'سيرفر'
        title = (item.get('series_title', '') + u' — ' if item.get('series_title') else '') + item['name']
        result.append(dict(item, name=u'%02d — %s' % (index + 1, label), title=title, server_url=url, referer=page, quality_server=node.attrs.get('data-quality') == '1'))
    if not result:
        raise RuntimeError(u'موفيز لاند لم يعرض سيرفرات مشاهدة لهذا العنصر.')
    return result

def resolve(item):
    if not item.get('quality_server'):
        return c.resolve(item)
    with requests.Session() as session:
        response = session.get(BASE + 'get_quality.php', params={'url': item['server_url'], '_': int(time.time() * 1000)}, headers=c.headers(item['referer']), timeout=(5, 18))
        try:
            response.raise_for_status()
            values = response.json()
        finally:
            response.close()
    if not isinstance(values, list):
        raise RuntimeError(u'موفيز لاند لم يرجع قائمة جودات صالحة.')
    streams = []
    for value in values:
        if not isinstance(value, dict) or not value.get('url'):
            continue
        row = dict(item, server_url=c.urljoin(BASE, value['url']), quality_server=False)
        try:
            resolved = c.resolve(row)
        except (requests.RequestException, RuntimeError):
            continue
        for stream in resolved['streams']:
            stream['quality'] = str(value.get('quality') or stream.get('quality') or 'Original')
            streams.append(stream)
    if not streams:
        raise RuntimeError(u'موفيز لاند لم يعرض جودات لهذا السيرفر. اختر سيرفراً آخر.')
    return dict(item, name=item.get('title') or item['name'], streams=streams)
