from __future__ import absolute_import
from Plugins.Extensions.Alkuds._vendor.future.utils import PY3

if not PY3:
    __future_module__ = True
