# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import sirfbs
from .sportacityui import Alkuds_Sportacity_Browser
from .generaltvui import Alkuds_GeneralTV_Browser

class Alkuds_SirTV_Browser(Alkuds_Sportacity_Browser):
    provider = sirfbs
    site_name = u'سير تيفي Sir TV - الوقت بتوقيت الجهاز'

    def _auto_scores(self):
        if not self._error:
            self.refresh_scores()

    def __init__(self, session, section='matches', level='groups', parent=None, page=1):
        Alkuds_GeneralTV_Browser.__init__(self, session, section, level, parent, page)
        self['key_blue'].setText(u'التالي / تحديث')
        from Components.ActionMap import ActionMap
        self['sirfbs_refresh'] = ActionMap(['InfobarEPGActions'], {'showEventInfo': self.refresh_scores}, -3)
        if level == 'items' and (not (parent or {}).get('_match')):
            from enigma import eTimer
            self._scores_timer = eTimer()
            try:
                self._scores_connection = self._scores_timer.timeout.connect(self._auto_scores)
            except Exception:
                self._scores_timer.callback.append(self._auto_scores)
            self.onShown.append(lambda: self._scores_timer.start(30000, False))
            self.onHide.append(self._scores_timer.stop)
            self.onClose.append(self._scores_timer.stop)
