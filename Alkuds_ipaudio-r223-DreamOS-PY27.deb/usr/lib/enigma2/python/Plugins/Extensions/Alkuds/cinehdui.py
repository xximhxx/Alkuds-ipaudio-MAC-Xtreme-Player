# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from . import cinehd
from .arabseedui import Alkuds_ArabSeed_Browser

def compact_quality(label):
    """Resolution first; drop repeated host and verbose provider annotations."""
    text = str(label or 'Auto').strip()
    text = re.sub('^Nxsha\\s*\\|\\s*', '', text, flags=re.I)
    resolutions = re.findall('(?<!\\d)(\\d{3,4})\\s*p\\b', text, re.I)
    quality = resolutions[-1] + 'p' if resolutions else 'Auto'
    provider = re.split('\\s*[|\\u00b7]\\s*', text, 1)[0]
    provider = re.sub('\\[[^\\]]*\\]', '', provider).strip(' -')
    if re.search('\\d{3,4}\\s*p\\b', provider, re.I):
        provider = ''
    languages = []
    for name, short in (('English', 'EN'), ('Hindi', 'HI'), ('Arabic', 'AR'), ('Tamil', 'TA'), ('Telugu', 'TE')):
        if re.search('\\b' + name + '\\b', text, re.I):
            languages.append(short)
    details = '/'.join(languages) if languages else 'Multi' if re.search('multi.?lang', text, re.I) else ''
    if re.search('HEVC|x265|H[ .]?265', text, re.I):
        details = (details + ' H265').strip()
    elif re.search('WEB[ -]?DL', text, re.I):
        details = (details + ' WEB-DL').strip()
    parts = [quality]
    if provider:
        parts.append(provider[:16].rstrip())
    if details:
        parts.append(details)
    return ' | '.join(parts)[:38].rstrip(' |')

class Alkuds_CineHD_Browser(Alkuds_ArabSeed_Browser):
    provider = cinehd
    site_name = u'CineHD'

    def _start_resolved(self, item):
        display = dict(item)
        display['streams'] = [dict(stream, quality=compact_quality(stream.get('quality'))) for stream in item['streams']]
        return Alkuds_ArabSeed_Browser._start_resolved(self, display)

    def open_current(self):
        index = self._index()
        if self.level == 'groups' and (not self._loading) and (not self._closed) and (0 <= index < len(self.entries)):
            if self.entries[index].get('action') == 'search':
                from Screens.VirtualKeyBoard import VirtualKeyBoard
                self.session.openWithCallback(self._search_done, VirtualKeyBoard, title=u'بحث CineHD', text='')
                return
        Alkuds_ArabSeed_Browser.open_current(self)

    def _search_done(self, value):
        if not self._closed and value and value.strip():
            self.session.open(type(self), self.section, 'items', {'query': value.strip()}, 1)
