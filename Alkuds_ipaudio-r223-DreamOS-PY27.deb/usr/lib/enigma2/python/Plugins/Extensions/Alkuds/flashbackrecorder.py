# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""FLASHBACK BETA3 ONLY. Raw localhost TS capture; no Enigma/UI operations here."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
import io
from .py2compat import configparser
from .py2compat import os
from .py2compat import re
import select
from .py2compat import shutil
from .py2compat import socket
import stat
import tempfile
from .py2compat import threading
from .py2compat import time
from .py2compat import urllib
quote = urllib.parse.quote
PACKET = 188
BLOCK = PACKET * 256
MiB = 1024 * 1024
CONFIG = '/etc/enigma2/alkuds_flashback_beta.ini'
LOG = '/tmp/alkuds-flashback-beta.log'

def log(message):
    try:
        with open(LOG, 'a', encoding='utf8') as stream:
            stream.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' ' + str(message) + '\n')
    except OSError:
        pass

def settings():
    parser = configparser.ConfigParser(interpolation=None)
    parser.read(CONFIG, encoding='utf-8-sig')
    return {'username': parser.get('stream', 'username', fallback=''), 'password': parser.get('stream', 'password', fallback=''), 'path': parser.get('buffer', 'path', fallback=''), 'allow_tmp': parser.getboolean('buffer', 'allow_tmp', fallback=True)}

def canonical_dvb_reference(value):
    """Separate the optional name from the path, as eServiceReference does.

    Ten numeric service fields are followed by path and optional display name.
    Native channels have an empty path; a name after the next colon is valid.
    Never turn a type-1 file/URL, marker or group into a live tuner request.
    """
    fields = str(value or '').strip().split(':', 11)
    try:
        if len(fields) < 10 or fields[0] != '1':
            return ''
        flags = int(fields[1], 10)
        if flags < 0 or flags & (1 | 2 | 64 | 128 | 256):
            return ''
        numbers = [int(part or '0', 16) for part in fields[2:10]]
        if any((number < 0 or number > 4294967295 for number in numbers)) or numbers[1] == 0:
            return ''
        if len(fields) > 10 and fields[10]:
            return ''
        return '1:%d:%s:' % (flags, ':'.join(('%x' % number for number in numbers)))
    except (TypeError, ValueError):
        return ''

def native_dvb_reference(value):
    return bool(canonical_dvb_reference(value))

class Storage(object):
    """An exclusive owned directory. Never remove other timeshift/user files."""

    def __init__(self, parent, cap, reserve):
        self.parent = os.path.realpath(parent)
        self.directory = tempfile.mkdtemp(prefix='.alkuds_flashback-', dir=self.parent)
        try:
            os.chmod(self.directory, 448)
        except OSError:
            pass
        self.path = os.path.join(self.directory, '.alkuds_pvr_buffer.ts')
        self.cap, self.reserve = (int(cap), int(reserve))
        self.identity = os.lstat(self.directory).st_ino
        try:
            with self.open() as probe:
                probe.write(b'G' * PACKET)
                os.fsync(probe.fileno())
            os.unlink(self.path)
        except OSError:
            self.cleanup()
            raise

    def open(self):
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(self.path, flags, 384)
        # Python 2's file.write returns None, not the written byte count.
        return io.open(fd, 'wb', buffering=0)

    def room(self):
        return shutil.disk_usage(self.directory).free >= self.reserve

    def cleanup(self):
        try:
            info = os.lstat(self.directory)
            if not stat.S_ISDIR(info.st_mode) or info.st_ino != self.identity or os.path.realpath(self.directory) != self.directory:
                return False
            if os.path.dirname(self.directory) != self.parent:
                return False
            for suffix in ('', '.meta', '.ap', '.sc', '.cuts'):
                candidate = self.path + suffix
                try:
                    if not stat.S_ISDIR(os.lstat(candidate).st_mode):
                        os.unlink(candidate)
                except FileNotFoundError:
                    pass
            os.rmdir(self.directory)
            return True
        except FileNotFoundError:
            return not os.path.lexists(self.directory)
        except OSError:
            return False

def mount_table():
    entries = []
    try:
        with open('/proc/mounts') as stream:
            for line in stream:
                fields = line.split()
                if len(fields) >= 4:
                    path = fields[1].replace('\\040', ' ').replace('\\011', '\t').replace('\\134', '\\')
                    entries.append((os.path.realpath(path), fields[2], fields[3].split(',')))
    except OSError:
        pass
    return entries

def filesystem_for(path, entries):
    path = os.path.realpath(path)
    matches = [entry for entry in entries if entry[0] == '/' or path == entry[0] or path.startswith(entry[0].rstrip('/') + '/')]
    return max(matches, key=lambda entry: len(entry[0])) if matches else None

def external_disk_mount(path):
    """A separately exposed SATA/USB/NVMe disk may also host the root image.

    Trust the kernel mount source, not the /media directory name alone. Internal
    MTD/eMMC and root-only folders remain excluded from this exception.
    """
    try:
        with open('/proc/mounts') as stream:
            for line in stream:
                fields = line.split()
                if len(fields) < 4:
                    continue
                mount = fields[1].replace('\\040', ' ').replace('\\011', '\t').replace('\\134', '\\')
                if os.path.realpath(mount) != path:
                    continue
                device = os.path.realpath(fields[0])
                if re.fullmatch('/dev/(?:sd[a-z]+[0-9]*|hd[a-z]+[0-9]*|vd[a-z]+[0-9]*|nvme[0-9]+n[0-9]+(?:p[0-9]+)?)', device):
                    return True
    except OSError:
        pass
    return False

def memory_available():
    try:
        with open('/proc/meminfo') as stream:
            values = {line.split(':')[0]: int(line.split()[1]) * 1024 for line in stream if ':' in line}
        return values.get('MemAvailable', values.get('MemFree', 0) + values.get('Cached', 0) + values.get('Buffers', 0))
    except (OSError, ValueError):
        return 0

def select_storage(allow_tmp=True, preferred_paths=()):
    entries = mount_table()
    root = os.stat('/').st_dev
    candidates = [(path, True) for path in preferred_paths if path]
    candidates += [(path, False) for path in ('/media/hdd', '/media/usb')]
    candidates += [(entry[0], False) for entry in entries if entry[0] != '/']
    seen = set()
    reasons = []
    for mount, direct in candidates:
        try:
            actual = os.path.realpath(mount)
            if actual in seen:
                continue
            seen.add(actual)
            ancestor = actual
            while not os.path.isdir(ancestor) and ancestor != '/':
                ancestor = os.path.dirname(ancestor)
            entries = mount_table()
            filesystem = filesystem_for(ancestor, entries)
            blocked = ('tmpfs', 'ramfs', 'autofs', 'proc', 'sysfs', 'devtmpfs', 'devpts', 'cgroup', 'cgroup2', 'securityfs', 'debugfs', 'tracefs', 'pstore', 'squashfs', 'jffs2', 'ubifs', 'overlay', 'rootfs', 'mtd')
            system_path = any((actual == prefix or actual.startswith(prefix + '/') for prefix in ('/proc', '/sys', '/dev', '/boot', '/usr', '/etc', '/var/log')))
            shares_root = os.stat(ancestor).st_dev == root
            exposed_disk = bool(shares_root and filesystem and (filesystem[0] != '/') and external_disk_mount(filesystem[0]))
            if system_path or (shares_root and (not exposed_disk)) or (not filesystem) or (filesystem[0] == '/') or (filesystem[1].lower() in blocked):
                reasons.append(actual + ': system/flash/unmounted volume')
                continue
            if 'ro' in filesystem[2]:
                reasons.append(actual + ': read-only volume')
                continue
            free = shutil.disk_usage(ancestor).free
            reserve = 512 * MiB if exposed_disk else 32 * MiB
            minimum = reserve + 64 * MiB if exposed_disk else 96 * MiB
            if free < minimum:
                reasons.append(actual + ': free=' + str(free // MiB) + ' MiB (need ' + str(minimum // MiB) + ')')
                continue
            parent = actual if direct else os.path.join(actual, 'timeshift')
            os.makedirs(parent, exist_ok=True)
            cap = free - max(reserve + 16 * MiB, free // 20 if exposed_disk else 0)
            if filesystem and filesystem[1].lower() in ('vfat', 'msdos', 'fat', 'fat32'):
                cap = min(cap, 4096 * MiB - PACKET)
            storage = Storage(parent, cap, reserve)
            storage.limit_reason = 'Recording capacity reached (available disk space or file-system file limit); returning to live'
            log('storage selected external=' + storage.directory + ' free_MiB=' + str(free // MiB) + ' cap_MiB=' + str(cap // MiB) + ' shares_root=' + str(exposed_disk) + ' reserve_MiB=' + str(reserve // MiB))
            return storage
        except OSError as error:
            reasons.append(str(mount) + ': ' + type(error).__name__ + ' errno=' + str(error.errno))
    log('external storage unavailable: ' + '; '.join(reasons))
    if allow_tmp:
        try:
            available = memory_available()
            free = shutil.disk_usage('/tmp').free
            filesystem = filesystem_for('/tmp', entries)
            cap = min(64 * MiB, available // 4, free - 16 * MiB)
            if filesystem and filesystem[1] in ('tmpfs', 'ramfs') and (available >= 32 * MiB) and (cap >= 8 * MiB):
                storage = Storage('/tmp', cap, 16 * MiB)
                storage.limit_reason = 'RAM buffer safety capacity reached; use HDD/USB for longer recording; returning to live'
                log('storage selected RAM=' + storage.directory + ' cap_MiB=' + str(cap // MiB))
                return storage
            reasons.append('/tmp: RAM filesystem required; available_MiB=' + str(available // MiB) + ' free_MiB=' + str(free // MiB))
        except OSError as error:
            reasons.append('/tmp: ' + type(error).__name__)
    log('storage rejected: ' + '; '.join(reasons))
    raise RuntimeError('No usable HDD/USB or RAM buffer. See /tmp/alkuds-flashback-beta.log for paths/free space')

class Framer(object):

    def __init__(self):
        self.pending = b''
        self.discarded = 0
        self.locked = False

    def feed(self, data):
        data = self.pending + data
        octets = bytearray(data)  # Socket str indexing returns characters on Py2.
        if not self.locked:
            if len(data) < PACKET * 3:
                self.pending = data
                return b''
            offset = next((n for n in range(len(data) - PACKET * 2) if octets[n] == octets[n + PACKET] == octets[n + PACKET * 2] == 71), None)
            if offset is None:
                self.discarded += len(data) - PACKET * 2
                self.pending = data[-PACKET * 2:]
                return b''
            self.discarded += offset
            data = data[offset:]
            octets = octets[offset:]
            self.locked = True
        end = len(data) // PACKET * PACKET
        for offset in range(0, end, PACKET):
            if octets[offset] != 71:
                end = offset
                self.locked = False
                break
        self.pending = data[end:]
        return data[:end]

class ClockIndex(object):
    """PAT/PMT-selected PCR; detect clock gaps without rewriting any TS packet."""

    def __init__(self, sid):
        self.sid = sid
        self.pmt_pid = None
        self.pcr_pid = None
        self.video_pids = set()
        self.sections = {}
        self.cc = {}
        self.last_pcr = None
        self.duration_ms = 0.0
        self.discontinuities = 0
        self.clear_video = 0
        self.scrambled_video = 0

    def _section(self, pid, payload, pusi, cc):
        if not payload:
            return
        if pusi:
            skip = payload[0] + 1
            if skip >= len(payload):
                return
            payload = payload[skip:]
            self.sections[pid] = bytearray()
        elif pid not in self.sections:
            return
        elif cc != self.cc.get(pid, cc - 1) + 1 & 15:
            self.sections.pop(pid, None)
            return
        self.cc[pid] = cc
        buffer = self.sections.get(pid, bytearray()) + payload
        if len(buffer) < 3:
            self.sections[pid] = buffer
            return
        size = 3 + ((buffer[1] & 15) << 8) + buffer[2]
        if size > 4096:
            self.sections.pop(pid, None)
            return
        if len(buffer) < size:
            self.sections[pid] = buffer
            return
        self.sections.pop(pid, None)
        section = buffer[:size]
        if section[0] == 0 and pid == 0:
            for n in range(8, len(section) - 4, 4):
                program = section[n] << 8 | section[n + 1]
                if program == self.sid:
                    self.pmt_pid = (section[n + 2] & 31) << 8 | section[n + 3]
        elif section[0] == 2 and pid == self.pmt_pid and (len(section) >= 16):
            self.pcr_pid = (section[8] & 31) << 8 | section[9]
            n = 12 + ((section[10] & 15) << 8) + section[11]
            while n + 5 <= len(section) - 4:
                kind = section[n]
                element = (section[n + 1] & 31) << 8 | section[n + 2]
                if kind in (1, 2, 16, 27, 36, 66):
                    self.video_pids.add(element)
                n += 5 + ((section[n + 3] & 15) << 8) + section[n + 4]

    def scan(self, data):
        data = bytearray(data)
        for offset in range(0, len(data), PACKET):
            packet = data[offset:offset + PACKET]
            if packet[1] & 128:
                continue
            pid = (packet[1] & 31) << 8 | packet[2]
            afc = packet[3] >> 4 & 3
            pos = 4
            if afc in (2, 3):
                length = packet[4]
                if length > 183:
                    continue
                if pid == self.pcr_pid and length >= 7 and packet[5] & 16:
                    b = packet[6:12]
                    pcr = (b[0] << 25 | b[1] << 17 | b[2] << 9 | b[3] << 1 | b[4] >> 7) * 300 + ((b[4] & 1) << 8) + b[5]
                    if self.last_pcr is not None:
                        delta = (pcr - self.last_pcr) % (2 ** 33 * 300) / 27000.0
                        if packet[5] & 128 or delta > 2000:
                            self.discontinuities += 1
                        else:
                            self.duration_ms += delta
                    self.last_pcr = pcr
                pos = 5 + length
            if afc in (1, 3) and pos < PACKET:
                if pid in (0, self.pmt_pid):
                    self._section(pid, packet[pos:], bool(packet[1] & 64), packet[3] & 15)
                if pid in self.video_pids:
                    if packet[3] & 192:
                        self.scrambled_video += 1
                    else:
                        self.clear_video += 1

class RawRecorder(object):

    def __init__(self, reference, storage, config=None):
        reference = canonical_dvb_reference(reference)
        if not reference:
            raise ValueError('Only a native DVB channel is supported')
        self.reference = reference
        self.storage = storage
        self.config = config or {}
        self.index = ClockIndex(int(reference.split(':')[3], 16))
        self.video_filter = None
        if self.config.get('video_only'):
            from .videopmt import VideoOnlyPMT
            self.video_filter = VideoOnlyPMT(self.index.sid)
        self.framer = Framer()
        self.stop_event = threading.Event()
        self.done = threading.Event()
        self.cleanup_requested = threading.Event()
        self.lock = threading.RLock()
        self.sock = None
        self.state = {'bytes': 0, 'media_ms': 0, 'last_data': 0.0, 'last_progress': 0.0, 'error': '', 'phase': 'CONNECTING', 'gaps': 0, 'clear_video': 0}
        self.thread = threading.Thread(target=self._run, name='AlkudsFlashbackRawTS')
        self.thread.daemon = True

    def start(self):
        self.thread.start()

    def snapshot(self):
        with self.lock:
            return dict(self.state)

    def stop(self, cleanup=False):
        if cleanup:
            self.cleanup_requested.set()
        self.stop_event.set()
        with self.lock:
            connection = self.sock
        if connection:
            try:
                connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    def _recv(self, connection, deadline=None):
        while not self.stop_event.is_set():
            if deadline is not None and time.monotonic() > deadline:
                raise RuntimeError('Local HTTP header timeout')
            readable, _, _ = select.select([connection], [], [], 0.25)
            if readable:
                data = connection.recv(BLOCK)
                if not data:
                    raise RuntimeError('Local stream closed; no automatic reconnect or retune')
                return data
        return b''

    def _run(self):
        connection = None
        try:
            if self.storage is None:
                preferred = [self.config.get('path', '')] + list(self.config.get('preferred_paths', ()))
                self.storage = select_storage(self.config.get('allow_tmp', True), preferred)
            connection = socket.create_connection(('127.0.0.1', 8001), timeout=3)
            connection.setblocking(False)
            with self.lock:
                self.sock = connection
            request = 'GET /' + quote(self.reference, safe=':') + ' HTTP/1.0\r\nHost: 127.0.0.1:8001\r\nConnection: close\r\n'
            if self.config.get('username'):
                credentials = (self.config['username'] + ':' + self.config.get('password', '')).encode('utf8')
                request += 'Authorization: Basic ' + base64.b64encode(credentials).decode('ascii') + '\r\n'
            connection.setblocking(True)
            connection.settimeout(3)
            connection.sendall((request + '\r\n').encode('ascii'))
            connection.setblocking(False)
            header = b''
            deadline = time.monotonic() + 8
            while b'\r\n\r\n' not in header and (not self.stop_event.is_set()):
                if time.monotonic() > deadline or len(header) > 16384:
                    raise RuntimeError('Local HTTP header timeout')
                header += self._recv(connection, deadline)
            if self.stop_event.is_set():
                return
            header, data = header.split(b'\r\n\r\n', 1)
            status = int(header.split(b' ', 2)[1])
            if status == 401:
                raise RuntimeError('Port 8001 requires credentials in alkuds_flashback_beta.ini; authentication was not changed')
            if status != 200:
                raise RuntimeError('Local stream HTTP status ' + str(status))
            if b'transfer-encoding: chunked' in header.lower():
                raise RuntimeError('Chunked local stream unsupported in beta3')
            last_space = 0
            with self.storage.open() as output:
                with open(self.storage.path + '.meta', 'x', encoding='utf8') as meta:
                    meta.write(self.reference + '\nAlkuds FLASHBACK BETA3\nIndependent raw TS buffer\n' + str(int(time.time())) + '\n')
                while not self.stop_event.is_set():
                    aligned = self.framer.feed(data)
                    if self.framer.discarded > 2 * MiB:
                        raise RuntimeError('Local stream is not valid 188-byte MPEG-TS')
                    if aligned:
                        if self.video_filter is not None:
                            aligned = self.video_filter.feed(aligned)
                        if self.state['bytes'] + len(aligned) > self.storage.cap:
                            raise RuntimeError(getattr(self.storage, 'limit_reason', 'Recording capacity reached; returning to live'))
                        now = time.monotonic()
                        if now - last_space > 1:
                            if not self.storage.room():
                                raise RuntimeError('Low buffer disk/RAM space; returning to live')
                            last_space = now
                        previous = self.index.duration_ms
                        written = output.write(aligned)
                        if written != len(aligned):
                            raise RuntimeError('Short buffer write')
                        self.index.scan(aligned)
                        with self.lock:
                            self.state.update(bytes=self.state['bytes'] + written, media_ms=self.index.duration_ms, last_data=now, phase='RECORDING', gaps=self.index.discontinuities, clear_video=self.index.clear_video)
                            if self.index.duration_ms > previous:
                                self.state['last_progress'] = now
                    data = self._recv(connection)
        except Exception as error:
            if not self.stop_event.is_set():
                with self.lock:
                    self.state.update(error=str(error), phase='FAILED')
                log('recorder failed: ' + str(error))
        finally:
            if connection:
                try:
                    connection.close()
                except OSError:
                    pass
            with self.lock:
                self.sock = None
            if self.cleanup_requested.is_set() and self.storage:
                self.storage.cleanup()
            self.done.set()
