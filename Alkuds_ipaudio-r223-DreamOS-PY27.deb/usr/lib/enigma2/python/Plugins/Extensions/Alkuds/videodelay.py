# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""IPAudio numeric DVB video offset; native timeshift remains Enigma2 owned."""
from __future__ import absolute_import, division, print_function
from .py2compat import gui_text
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import time
from .py2compat import threading
from enigma import eTimer, eActionMap
from Screens.Screen import Screen
from .xStaticText import MessageBox
from Components.Input import Input
from .xStaticText import Label
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
_DELAY_SKIN_CACHE = {}

class VideoDelayBox(Screen):
    skin = '<screen name="AlkudsVideoDelay" position="center,center" size="620,564" flags="wfNoBorder" backgroundColor="#40341960"><widget name="audio_status" position="270,12" size="334,64" font="alkudsregular;25" foregroundColor="#ffffff" backgroundColor="#40341960" transparent="1" halign="center" valign="center" /><ePixmap position="16,12" size="240,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Alkuds/skin/fhd/common/logo-large.png" alphatest="blend" scale="1" /><widget name="channel_picon" position="306,88" size="208,34" alphatest="blend" scale="1" /><widget name="picon_number" position="530,88" size="50,34" font="alkudsregular;24" foregroundColor="#ffffff" transparent="1" halign="center" valign="center" /><widget name="channel" position="16,138" size="588,36" font="alkudsregular;24" foregroundColor="#ffffff" backgroundColor="#20762fb2" halign="center" valign="center" /><widget name="audio_event" position="16,180" size="588,48" font="alkudsregular;20" foregroundColor="#ffffff" backgroundColor="#40341960" halign="center" valign="center" /><widget name="delay_status" position="16,234" size="588,34" font="alkudsregular;22" foregroundColor="#ffffff" backgroundColor="#20762fb2" halign="center" valign="center" /><widget name="title" position="16,282" size="180,36" font="alkudsregular;25" foregroundColor="#ffffff" backgroundColor="#40341960" halign="center" valign="center" /><widget name="minus" position="200,278" size="90,44" font="alkudsregular;25" foregroundColor="#ffffff" backgroundColor="#20762fb2" halign="center" valign="center" /><widget name="value" position="300,278" size="150,46" font="alkudsregular;36" foregroundColor="#30134f" backgroundColor="#ffffff" halign="center" valign="center" /><widget name="plus" position="460,278" size="140,44" font="alkudsregular;25" foregroundColor="#ffffff" backgroundColor="#20762fb2" halign="center" valign="center" /><widget name="audio_title" position="16,336" size="220,36" font="alkudsregular;25" foregroundColor="#ffffff" backgroundColor="#40341960" halign="center" valign="center" /><widget name="audio_value" position="300,330" size="150,46" font="alkudsregular;34" foregroundColor="#30134f" backgroundColor="#ffffff" halign="center" valign="center" /><widget name="stop_title" position="16,386" size="284,40" font="alkudsregular;24" foregroundColor="#ffffff" backgroundColor="#20762fb2" halign="center" valign="center" /><widget name="restore_title" position="316,386" size="288,40" font="alkudsregular;24" foregroundColor="#ffffff" backgroundColor="#20762fb2" halign="center" valign="center" /><widget name="help" position="16,437" size="588,30" font="alkudsregular;20" foregroundColor="#ffffff" backgroundColor="#40341960" transparent="1" halign="center" valign="center" /><widget name="key_blue" position="20,478" size="24,27" font="alkudsregular;18" foregroundColor="#ffffff" backgroundColor="#2389ee" halign="center" valign="center" /><widget name="hint_blue" position="52,476" size="130,30" font="alkudsregular;23" foregroundColor="#ffffff" backgroundColor="#40341960" transparent="1" halign="center" valign="center" /><widget name="key_yellow" position="220,478" size="24,27" font="alkudsregular;18" foregroundColor="#ffffff" backgroundColor="#f2d13b" halign="center" valign="center" /><widget name="hint_yellow" position="252,476" size="130,30" font="alkudsregular;23" foregroundColor="#ffffff" backgroundColor="#40341960" transparent="1" halign="center" valign="center" /><widget name="key_green" position="420,478" size="24,27" font="alkudsregular;18" foregroundColor="#ffffff" backgroundColor="#31bd70" halign="center" valign="center" /><widget name="hint_green" position="452,476" size="130,30" font="alkudsregular;23" foregroundColor="#ffffff" backgroundColor="#40341960" transparent="1" halign="center" valign="center" /><widget name="key_red" position="20,522" size="24,27" font="alkudsregular;18" foregroundColor="#ffffff" backgroundColor="#eb4242" halign="center" valign="center" /><widget name="hint_red" position="52,520" size="130,30" font="alkudsregular;23" foregroundColor="#ffffff" backgroundColor="#40341960" transparent="1" halign="center" valign="center" /><widget name="key_info" position="205,522" size="50,27" font="alkudsregular;18" foregroundColor="#ffffff" backgroundColor="#7655b8" halign="center" valign="center" /><widget name="hint_info" position="261,520" size="150,30" font="alkudsregular;23" foregroundColor="#ffffff" backgroundColor="#40341960" transparent="1" halign="center" valign="center" /><widget name="key_ok" position="420,522" size="50,27" font="alkudsregular;18" foregroundColor="#ffffff" backgroundColor="#7655b8" halign="center" valign="center" /><widget name="hint_ok" position="476,520" size="130,30" font="alkudsregular;23" foregroundColor="#ffffff" backgroundColor="#40341960" transparent="1" halign="center" valign="center" /></screen>'

    def __init__(self, session, milliseconds=4500, audio_ms=None, on_nudge=None, on_stop=None, on_restore=None, on_shown=None, telemetry=None, on_switch=None):
        from enigma import getDesktop
        from .py2compat import re
        desktop = getDesktop(0).size()
        layout_key = (desktop.width(), desktop.height())
        if layout_key in _DELAY_SKIN_CACHE:
            self.skin = _DELAY_SKIN_CACHE[layout_key]
        else:
            scale = min(desktop.width() / 1280.0, desktop.height() / 720.0)
            self.skin = re.sub('(position|size)="(\\d+),(\\d+)"', lambda m: '%s="%d,%d"' % (m.group(1), round(int(m.group(2)) * scale), round(int(m.group(3)) * scale)), self.skin)
            self.skin = re.sub('alkudsregular;(\\d+)', lambda m: 'alkudsregular;%d' % round(int(m.group(1)) * scale), self.skin)
            panel_width = round(620 * scale)
            panel_height = round(564 * scale)
            self.skin = self.skin.replace('position="center,center"', 'position="%d,%d"' % (desktop.width() - panel_width - round(20 * scale), (desktop.height() - panel_height) // 2))
            if len(_DELAY_SKIN_CACHE) >= 4:
                _DELAY_SKIN_CACHE.pop(next(iter(_DELAY_SKIN_CACHE)))
            _DELAY_SKIN_CACHE[layout_key] = self.skin
        Screen.__init__(self, session)
        if audio_ms is None:
            from .backgroundaudio import configured_audio_delay_ms
            audio_ms = configured_audio_delay_ms()
        for name, value in (('value', milliseconds), ('audio_value', audio_ms)):
            text = ('%d.%03d' % (value // 1000, value % 1000)).rstrip('0')
            if text.endswith('.'):
                text += '0'
            self[name] = Input(text, maxSize=True, type=Input.NUMBER)
            self[name].currPos = 0
            if hasattr(self[name], 'allmarked'):
                self[name].allmarked = False
            if hasattr(self[name], 'allMarked'):
                self[name].allMarked = False
        self.active_field = 'value'
        self.integer_entry = ''
        self.entry_field = None
        self.entry_time = 0
        self.fraction_entry = False
        self.on_switch = on_switch
        self['channel'] = Label('<  Audio Channel  >')
        self['title'] = Label('Video Delay')
        self['audio_title'] = Label('Audio Delay')
        self.on_nudge, self.on_stop, self.on_restore = (on_nudge, on_stop, on_restore)
        self['minus'] = Label('<  -0.5')
        self['plus'] = Label('+0.5  >')
        self['stop_title'] = Label('Stop Timeshift')
        self['restore_title'] = Label('Restore Delay')
        self['help'] = Label(u'أعلى/أسفل: اختيار | يمين/يسار: تعديل | OK: تطبيق')
        for key, caption in (('blue', u'إيقاف'), ('yellow', u'جزء ثانية'), ('green', u'حفظ'), ('red', u'إغلاق'), ('info', u'إظهار / إخفاء'), ('ok', u'تطبيق')):
            self['key_' + key] = Label(key.upper() if key in ('info', 'ok') else '')
            self['hint_' + key] = Label(caption)
        actions = {'ok': self.ok, 'green': self.apply, 'cancel': lambda: self.close(None), 'red': lambda: self.close(None), 'left': lambda: self.move(-1), 'right': lambda: self.move(1), 'showEventInfo': lambda: self.close(None), 'yellow': self.extra_digit, 'up': lambda: self.cycle_field(-1), 'down': lambda: self.cycle_field(1), 'blue': self.stop_timeshift}
        for digit in range(10):
            actions[str(digit)] = lambda digit=digit: self.number(digit)
        self['delayActions'] = ActionMap(['OkCancelActions', 'ColorActions', 'DirectionActions', 'NumberActions', 'InfobarEPGActions'], actions, -2)
        self['audio_status'] = Label(u'جاري تحديث المعلومات...')
        self['channel_picon'] = Pixmap()
        self['picon_number'] = Label('')
        self['audio_event'] = Label(u'جاري جلب الحدث...')
        self['delay_status'] = Label('Actual Video Delay: --')
        self.telemetry = telemetry
        self._status_visible = False
        self.status_timer, self.status_connection = _timer(self.update_status)
        self.onShown.append(self.refresh_focus)
        if callable(on_shown):
            self.onShown.append(on_shown)
        self.onShown.append(self.show_status)
        self.onHide.append(self.hide_status)
        self.onClose.append(self.hide_status)

    def show_status(self):
        self._status_visible = True
        self.status_timer.start(150, True)

    def hide_status(self):
        self._status_visible = False
        self.status_timer.stop()

    def update_status(self):
        if not self._status_visible:
            return
        self.status_timer.start(2000, False)
        if not callable(self.telemetry):
            return
        try:
            status, metrics, delay = self.telemetry()
            self['audio_status'].setText(status.replace(' | ', '\n', 1))
            self['channel'].setText('<  ' + status.split(' | ', 1)[0] + '  >')
            from .audioepg import set_channel_logo
            from .backgroundaudio import background_audio_ui_status
            source = background_audio_ui_status().get('source', '')
            set_channel_logo(self, status.split(' | ', 1)[0], source)
            self['delay_status'].setText(delay)
        except Exception:
            self['delay_status'].setText('Actual Video Delay: --')
            self['audio_event'].setText(u'تعذر تحديث الحدث حالياً')
            return
        try:
            from .audioepg import current_event
            event = current_event(status.split(' | ', 1)[0], source=source)
            self['audio_event'].setText(event or u'لا يوجد حدث منشور حالياً')
        except Exception:
            self['audio_event'].setText(u'الحدث غير متاح حالياً')

    def refresh_focus(self):
        for name in ('value', 'audio_value'):
            self[name].update()
            if name != self.active_field:
                self[name].setMarkedPos(-1)
        focused = self.active_field
        for name, field in (('channel', 'channel'), ('title', 'value'), ('audio_title', 'audio_value'), ('stop_title', 'stop'), ('restore_title', 'restore')):
            selected = focused == field
            self._paint(name, 2363453 if selected else 16777215, 15913275 if selected else 6501533)
        for name in ('value', 'audio_value'):
            selected = focused == name
            self._paint(name, 2363453 if selected else 3150671, 15913275 if selected else 16777215)
        self['title'].setText('> Video Delay' if focused == 'value' else 'Video Delay')
        self['audio_title'].setText('> Audio Delay' if focused == 'audio_value' else 'Audio Delay')

    def _paint(self, name, foreground, background=None):
        instance = getattr(self[name], 'instance', None)
        if instance is None:
            return
        from enigma import gRGB
        instance.setForegroundColor(gRGB(foreground))
        if background is not None and hasattr(instance, 'setBackgroundColor'):
            instance.setBackgroundColor(gRGB(background))

    def select_field(self, name):
        self.integer_entry = ''
        self.entry_field = None
        self.fraction_entry = False
        self.active_field = name
        if name not in ('stop', 'restore', 'channel'):
            self[name].currPos = 0
        self.refresh_focus()

    def cycle_field(self, step):
        fields = ('channel', 'value', 'audio_value', 'stop', 'restore')
        self.select_field(fields[(fields.index(self.active_field) + step) % len(fields)])

    def set_video_value(self, milliseconds):
        text = ('%d.%03d' % (milliseconds // 1000, milliseconds % 1000)).rstrip('0')
        self['value'].setText(text + '0' if text.endswith('.') else text)
        self['value'].currPos = 0
        self.refresh_focus()

    def stop_timeshift(self):
        if callable(self.on_stop) and self.on_stop():
            self.set_video_value(0)

    def ok(self):
        if self.active_field == 'stop':
            self.stop_timeshift()
        elif self.active_field == 'restore':
            if callable(self.on_restore):
                value = self.on_restore()
                if value is not None:
                    self.set_video_value(value)
        elif self.active_field != 'channel':
            self.apply()

    def move(self, step):
        if self.active_field == 'channel':
            if callable(self.on_switch):
                self.on_switch(step)
            return
        if self.active_field == 'value':
            value = max(0, min(120000, int(round(float(self['value'].getText()) * 1000)) + step * 500))
            self.integer_entry = ''
            self.entry_field = None
            self.fraction_entry = False
            self.set_video_value(value)
            return
        if self.active_field in ('stop', 'restore', 'channel'):
            return
        field = self[self.active_field]
        pos = max(0, min(len(field.getText()) - 1, field.currPos + step))
        if field.getText()[pos] == '.':
            pos += step
        field.currPos = max(0, min(len(field.getText()) - 1, pos))
        field.update()
        self.refresh_focus()

    def number(self, digit):
        if self.active_field not in ('value', 'audio_value'):
            return
        field = self[self.active_field]
        whole, fraction = field.getText().split('.')
        now = time.monotonic()
        if self.fraction_entry:
            pos = max(len(whole) + 1, field.currPos)
            text = field.getText()
            field.setText(gui_text(text[:pos] + str(digit) + text[pos + 1:]))
            field.currPos = min(pos + 1, len(field.getText()) - 1)
        else:
            if self.entry_field != self.active_field or now - self.entry_time > 3.0:
                self.integer_entry = ''
            if len(self.integer_entry) >= 3:
                self.integer_entry = ''
            self.integer_entry += str(digit)
            field.setText(gui_text(str(int(self.integer_entry)) + '.' + fraction))
            field.currPos = len(field.getText().split('.')[0]) - 1
            self.entry_field = self.active_field
            self.entry_time = now
        self.refresh_focus()

    def extra_digit(self):
        if self.active_field not in ('value', 'audio_value'):
            return
        self.fraction_entry = not self.fraction_entry
        self.integer_entry = ''
        field = self[self.active_field]
        whole, fraction = field.getText().split('.')
        if self.fraction_entry:
            field.setText(gui_text(whole + '.' + fraction.ljust(3, '0')))
            field.currPos = len(whole) + 1
        else:
            field.currPos = 0
        self.refresh_focus()

    def apply(self):
        result = {}
        for name, key, limit in (('value', 'video_ms', 120000), ('audio_value', 'audio_ms', 120000)):
            whole, fraction = self[name].getText().split('.')
            result[key] = min(limit, int(whole) * 1000 + int((fraction + '000')[:3]))
        self.close(result)

def _timer(callback):
    timer = eTimer()
    try:
        connection = timer.timeout.connect(callback)
    except Exception:
        timer.callback.append(callback)
        connection = None
    return (timer, connection)

def _hold_log(message):
    try:
        from .backgroundaudio import _log
        _log(message)
    except Exception:
        pass

class VideoDelayController(object):
    """Issue native commands only for an explicit user request, then go idle."""

    def __init__(self, session):
        from .plugin import cfg
        self.session = session
        self.closed = False
        self.prompted = False
        self._foreground_samples = 0
        self._return_dialog_label = None
        self.dialog = None
        self.target_ms = self.restore_ms = int(cfg.ipaudiovideodelayms.value)
        self.video_applied = False
        self.service_ref = self.ref()
        self.service_gap_since = None
        self.pending = self.owns_pause = False
        self.switch_job = None
        self.last_flow_stamp = self.good_samples = 0
        self.audio_timer, self.audio_connection = _timer(self.restore_transition_audio)
        self.transition_audio_name = None
        self.timer, self.connection = _timer(self.tick)
        self.bound = False
        self.action_slot = None
        try:
            # DreamOS returns an owning eActionSlot; dropping it unbinds INFO.
            self.action_slot = eActionMap.getInstance().bindAction('', -2147483647, self.raw_info)
            self.bound = True
        except Exception:
            pass
        self.timer.start(250, False)

    def raw_info(self, key, flag):
        if key == 358 and flag == 0 and (not self.closed):
            if self.dialog is not None:
                self.dialog.close(None)
                return 1
            if self.foreground() and self.audio_ready():
                self.prompt()
                return 1
        return 0

    def prompt(self):
        if self.dialog is not None or self.closed:
            return
        self.prompted = True
        self.dialog = self.session.openWithCallback(self.answer, VideoDelayBox, self.target_ms, None, self.nudge, self.stop_timeshift, self.restore_delay, None, self.telemetry, self.switch_audio)

    def answer(self, value):
        self.dialog = None
        if self.closed or value is None or (not self.same_service()):
            return
        try:
            if isinstance(value, dict):
                from .plugin import cfg
                from Components.config import configfile
                from .backgroundaudio import apply_audio_delay, configured_audio_delay_ms
                video_ms = int(value['video_ms'])
                cfg.ipaudiovideodelayms.setValue(video_ms)
                cfg.ipaudiovideodelayms.save()
                configfile.save()
                self.apply(video_ms)
                if int(value['audio_ms']) != configured_audio_delay_ms():
                    apply_audio_delay(value['audio_ms'])
            else:
                self.apply(value)
        except Exception as error:
            self.fail(str(error))

    def audio_action(self, action):
        from .backgroundaudio import _set_enigma_service_audio
        _set_enigma_service_audio(self.session, False)
        try:
            return action()
        finally:
            _set_enigma_service_audio(self.session, False)
            from .backgroundaudio import background_audio_diagnostics
            self.transition_audio_name = background_audio_diagnostics().get('name')
            self.audio_timer.start(400, True)

    def restore_transition_audio(self):
        self.audio_timer.stop()
        if self.closed or not self.same_service():
            return
        from .backgroundaudio import background_audio_diagnostics, recover_video_delay_audio
        data = background_audio_diagnostics()
        if not self.transition_audio_name or data.get('name') != self.transition_audio_name:
            return
        if str(data.get('state', '')).lower() not in ('running', 'starting', 'connecting'):
            return
        try:
            recover_video_delay_audio(recover_sink=True)
        except Exception as error:
            _hold_log('R188 native transition audio recovery failed: %s' % error)

    def nudge(self, delta_ms):
        if self.closed or not self.same_service():
            return None
        try:
            base = self.target_ms if self.video_applied or self.pending else self.actual_delay_ms() or 0
            self.apply(max(0, min(120000, int(base) + int(delta_ms))))
            return self.target_ms
        except Exception as error:
            self.fail(str(error))
            return None

    def stop_timeshift(self):
        if self.closed or not self.same_service():
            return False
        try:
            from .backgroundaudio import _stop_native_timeshift
            self.pending = self.owns_pause = False
            if not self.audio_action(lambda: _stop_native_timeshift(self.session)):
                raise RuntimeError(u'تعذر إيقاف التايم شيفت من النظام')
            self.target_ms = 0
            self.video_applied = False
            self._idle()
            return True
        except Exception as error:
            self.fail(str(error))
            return False

    def restore_delay(self):
        if not self.read_timeline()[0]:
            self.fail(u'لا يوجد تايم شيفت نشط لاستعادة التأخير؛ ابدأه بواسطة OK.')
            return None
        try:
            self.apply(self.restore_ms)
            return self.target_ms
        except Exception as error:
            self.fail(str(error))
            return None

    def apply(self, milliseconds):
        requested = max(0, min(120000, int(milliseconds)))
        bar = self.bar()
        if not self.same_service() or bar is None or (not self.service_ref.startswith('1:')):
            raise RuntimeError(u'تأخير الفيديو يحتاج قناة ستلايت')
        if requested == 0:
            self.stop_timeshift()
            return
        self.target_ms = self.restore_ms = requested
        if self.pending:
            self.resume_at = self.pause_started + max(0, requested - self.pause_base_ms) / 1000.0
            return
        active, length, position, playing = self.read_timeline()
        if active:
            if length is None or position is None or (not 0 <= position <= length):
                raise RuntimeError(u'عداد التايم شيفت غير متاح الآن')
            actual = (length - position) / 90.0
            difference = requested - actual
            if abs(difference) <= 80:
                self.video_applied = True
                self._idle()
                return
            if difference < 0:
                seek = bar.getSeek()
                amount = min(int(-difference * 90), max(0, length - position - 90000))
                if not callable(getattr(seek, 'seekRelative', None)):
                    raise RuntimeError(u'النظام لا يدعم التقديم النسبي للتسجيل')
                result = seek.seekRelative(1, amount)
                if result not in (None, 0):
                    raise RuntimeError(u'رفض النظام التقديم النسبي')
                self.video_applied = True
                self._idle()
                return
            self.pause_base_ms = actual
            self.audio_action(bar.pauseService)
        else:
            self.pause_base_ms = 0
            self.audio_action(bar.startTimeshift)
        self.pause_started = time.monotonic()
        self.resume_at = self.pause_started + max(0, requested - self.pause_base_ms) / 1000.0
        self.pending = self.owns_pause = True
        self.timer.start(50, False)

    def tick(self):
        if self.closed:
            return
        try:
            if not self.same_service():
                self.close()
                return
            self.poll_audio_switch()
            if self.pending and time.monotonic() >= self.resume_at:
                self.resume_owned()
                self.pending = False
                self.video_applied = True
            if not self.prompted:
                if self.foreground() and self.audio_ready() and getattr(self.session.current_dialog, 'execing', True):
                    self._foreground_samples += 1
                    if self._foreground_samples >= 2:
                        self.prompt()
                else:
                    self._foreground_samples = 0
                    self.return_to_satellite()
            self._idle()
        except Exception as error:
            self.fail(str(error))

    def _idle(self):
        if not self.pending and self.switch_job is None and self.prompted:
            self.timer.stop()

    def resume_owned(self):
        if self.owns_pause:
            self.owns_pause = False
            if self.same_service():
                self.audio_action(self.bar().unPauseService)

    def fail(self, message):
        self.pending = False
        self.resume_owned()
        self.prompted = True
        self._idle()
        if not self.closed:
            current = getattr(self.session, 'current_dialog', None)
            if current is None or not getattr(current, 'execing', False):
                print('[Alkuds Video Delay] Dialog error: %s' % message)
                return
            try:
                self.session.open(MessageBox, 'Video Delay: ' + message, MessageBox.TYPE_ERROR, timeout=8)
            except RuntimeError:
                # Never escalate a screen-construction failure into a modal crash.
                print('[Alkuds Video Delay] Unable to show dialog error: %s' % message)

    def close(self):
        self.audio_timer.stop()
        self.transition_audio_name = None
        self.owns_pause = False
        self.closed = True
        self.pending = False
        self.switch_job = None
        self.timer.stop()
        if self.bound:
            unbind = getattr(eActionMap.getInstance(), 'unbindAction', None)
            if unbind is not None:
                unbind('', self.raw_info)
        self.action_slot = None
        self.bound = False
        if self.dialog is not None:
            dialog, self.dialog = (self.dialog, None)
            dialog.close(None)

    def ref(self):
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        return ref.toString() if ref else ''

    def bar(self):
        from Screens.InfoBar import InfoBar
        current = self.session.current_dialog
        if isinstance(current, InfoBar):
            return current
        for entry in reversed(getattr(self.session, 'dialog_stack', ())):
            dialog = entry[0] if isinstance(entry, (tuple, list)) else entry
            if isinstance(dialog, InfoBar):
                return dialog
        return InfoBar.instance

    def foreground(self):
        return self.same_service() and self.session.current_dialog is self.bar() and self.service_ref.startswith('1:')

    def same_service(self):
        current = self.ref()
        if current == self.service_ref:
            self.service_gap_since = None
            return True
        if current and (not current.startswith('1:')):
            from .backgroundaudio import _native_timeshift_enabled
            if _native_timeshift_enabled(self.session):
                self.service_gap_since = None
                return True
        if current and current.startswith('1:') and (current != self.service_ref):
            self.service_ref = current
            self.service_gap_since = None
            self.pending = self.owns_pause = False
            self.video_applied = False
            self.audio_timer.stop()
            self.transition_audio_name = None
            self._idle()
            return True
        if self.target_ms > 0 and getattr(self, 'video_applied', False):
            now = time.monotonic()
            if self.service_gap_since is None:
                self.service_gap_since = now
            if now - self.service_gap_since < 12.0:
                return True
        return False

    def return_to_satellite(self):
        dialog = self.session.current_dialog
        if dialog is self.bar():
            return
        module = getattr(dialog.__class__, '__module__', '') if dialog else ''
        label = module + '.' + (dialog.__class__.__name__ if dialog else '<none>')
        if label != self._return_dialog_label:
            self._return_dialog_label = label
            _hold_log('FIX7 delay panel return screen=' + label)
        if dialog is None or not getattr(dialog, 'execing', True):
            return
        browser = any((getattr(cls, '__name__', '') == 'PluginBrowser' and getattr(cls, '__module__', '') == 'Screens.PluginBrowser' for cls in type(dialog).__mro__))
        if module.startswith('Plugins.Extensions.Alkuds.'):
            dialog.close('ipaudio-started')
        elif browser or module == 'Screens.PluginBrowser':
            dialog.close()

    def telemetry(self):
        from .backgroundaudio import background_audio_diagnostics
        data = background_audio_diagnostics()
        state = str(data.get('state', 'starting')).upper()
        self.same_service()
        metrics = ''
        actual = self.actual_delay_ms()
        hold = 'NATIVE'
        delay = 'Requested: %.2f s | Actual: %s | Hold: %s' % (self.target_ms / 1000.0, '%.2f s' % (actual / 1000.0) if actual is not None else '--', hold)
        return ('%s | %s' % (data.get('name', 'IP AUDIO'), state), metrics, delay)

    def actual_delay_ms(self):
        service = self.session.nav.getCurrentService()
        ts = service and service.timeshift()
        if ts is None or not ts.isTimeshiftActive():
            return 0
        seek = self.bar().getSeek()
        if seek is None:
            return None
        length, position = (seek.getLength(), seek.getPlayPosition())
        if not length or length[0] or (not position) or position[0] or (length[1] <= 0) or (position[1] < 0) or (position[1] > length[1]):
            return None
        return (length[1] - position[1]) / 90.0

    def audio_ready(self):
        from .backgroundaudio import background_audio_ui_status
        return background_audio_ui_status().get('state') == 'running'

    def switch_audio(self, step):
        if self.closed or self.switch_job is not None or (not self.audio_ready()):
            return
        from .backgroundaudio import get_resume_context
        context = get_resume_context()
        channels = list(context.get('channels') or [])
        if len(channels) < 2:
            self.session.open(MessageBox, u'لا توجد صوتية أخرى في القائمة الحالية.', MessageBox.TYPE_ERROR, timeout=4)
            return
        index = (int(context.get('selected_index') or 0) + int(step)) % len(channels)
        item = channels[index]
        if isinstance(item, dict):
            name = str(item.get('name') or 'Audio')
            command = str(item.get('value') or item.get('url') or item.get('cmd') or '')
        else:
            name, command = (str(item[0]), str(item[1]))
        job = {'done': False, 'context': dict(context), 'index': index, 'name': name}
        self.switch_job = job

        def worker():
            try:
                from .plugin import cfg
                headers = {'User-Agent': str(cfg.useragent.value)}
                if context.get('source') in ('best_audio', 'orange_audio', 'orange_goradio', 'sat_family', 'anis_audio', 'fox_audio', 'free_audio'):
                    from .audiofeeds import resume_headers
                    headers = resume_headers(context, index, headers)
                url, retry = (command, None)
                if context.get('source') == 'stalker':
                    from .stalker import StalkerClient
                    client = StalkerClient(dict(context.get('portal') or {}))
                    url = client.create_link(command)
                    headers = dict(client.headers)
                    retry = lambda: client.create_link(command)
                if not url:
                    raise RuntimeError(u'لم يرجع المصدر رابط صوت صالحاً')
                job.update(url=url, headers=headers, retry=retry)
            except Exception as error:
                job['error'] = str(error)
            finally:
                job['done'] = True
        thread = threading.Thread(target=worker)
        thread.daemon = True
        thread.start()
        self.timer.start(250, False)

    def poll_audio_switch(self):
        job = self.switch_job
        if job is None or not job['done']:
            return
        self.switch_job = None
        if job.get('error'):
            self.session.open(MessageBox, u'تعذر تبديل الصوتية: ' + job['error'], MessageBox.TYPE_ERROR, timeout=6)
            return
        from .backgroundaudio import start_background_audio_direct
        context = job['context']
        context.update(selected_index=job['index'], channel_name=job['name'])
        start_background_audio_direct(self.session, job['url'], job['name'], headers=job['headers'], resume_context=context, retry_resolver=job['retry'], preserve_delay_controller=True)
        self.good_samples = self.last_flow_stamp = 0

    def read_timeline(self):
        service = self.session.nav.getCurrentService()
        ts = service and service.timeshift()
        active = bool(ts and ts.isTimeshiftActive())
        bar = self.bar()
        playing = bool(bar is not None and getattr(bar, 'seekstate', None) == getattr(bar, 'SEEK_STATE_PLAY', object()))
        if not active or bar is None:
            return (active, None, None, playing)
        seek = bar.getSeek()
        if seek is None:
            return (True, None, None, playing)
        length, position = (seek.getLength(), seek.getPlayPosition())
        if not length or length[0] or (not position) or position[0]:
            return (True, None, None, playing)
        return (True, length[1], position[1], playing)
_controller = None

def arm(session):
    global _controller
    stop()
    from .flashbackui import FlashbackController
    _controller = FlashbackController(session)

def stop():
    global _controller
    controller, _controller = (_controller, None)
    if controller is not None:
        controller.close()

def request_panel_after_audio_start(session):
    """Re-arm display after the root plugin/browser close callback completes."""
    controller = _controller
    if controller is None or controller.closed or controller.session is not session:
        return
    if controller.dialog is not None and session.current_dialog is controller.dialog:
        return
    controller.dialog = None
    controller.prompted = False
    controller._foreground_samples = 0
    controller._return_dialog_label = None
    controller.timer.start(150, False)
    _hold_log('FIX9 audio menu closed; waiting for live InfoBar and verified audio')
