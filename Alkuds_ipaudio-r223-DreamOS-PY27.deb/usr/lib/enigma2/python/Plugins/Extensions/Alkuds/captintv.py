# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Captin TV beIN-only live catalogue and player adapter. No movies, series or DRM keys."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
import copy
import hashlib
from .py2compat import json
from .py2compat import os
from .py2compat import re
from .py2compat import shutil
from .py2compat import subprocess
from .py2compat import threading
from .py2compat import time
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlsplit = urllib.parse.urlsplit
urlencode = urllib.parse.urlencode
unquote = urllib.parse.unquote
from .py2compat import requests
BASE = 'https://firestore.googleapis.com/v1/projects/cartin-tv/databases/(default)/documents/'
KEY = b'3p$Zv_+mU_oOqTys'
IV = b"!GP^GrRvVz'SG(R+"
UA = 'Mozilla/5.0'
SECTION_MAP = {'channels': (u'بين سبورت', 'categories')}
_FIELDS = {'category', 'channel', 'settings'}
_CACHE = {}
_LOCK = threading.RLock()
_TTL = 300

def refresh():
    with _LOCK:
        compat_clear(_CACHE)

def _cached(key, fetch):
    with _LOCK:
        entry = _CACHE.get(key)
    if entry and time.monotonic() - entry[0] < _TTL:
        return copy.deepcopy(entry[1])
    value = fetch()
    with _LOCK:
        _CACHE[key] = (time.monotonic(), copy.deepcopy(value))
    return value

def _request(session, url, body=None):
    try:
        response = session.request('POST' if body is not None else 'GET', url, json=body, headers={'User-Agent': UA, 'Accept': 'application/json,text/html,*/*'}, timeout=(5, 16), stream=True)
        try:
            response.raise_for_status()
            data = bytearray()
            for chunk in response.iter_content(32768):
                data.extend(chunk)
                if len(data) > 4 * 1024 * 1024:
                    raise RuntimeError(u'استجابة المصدر أكبر من الحد الآمن')
            return json.loads(bytes(data).decode('utf-8-sig'))
        finally:
            response.close()
    except requests.RequestException as error:
        code = getattr(getattr(error, 'response', None), 'status_code', None)
        raise RuntimeError(u'تعذر الاتصال بمصدر الكابتن' + (u' — ' + str(code) if code else ''))

def _decrypt_blocks(raw):
    try:
        from Crypto.Cipher import AES
        return AES.new(KEY, AES.MODE_CBC, IV).decrypt(raw)
    except ImportError:
        pass
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.backends import default_backend
        context = Cipher(algorithms.AES(KEY), modes.CBC(IV), default_backend()).decryptor()
        return context.update(raw) + context.finalize()
    except ImportError:
        pass
    executable = shutil.which('openssl')
    if not executable:
        raise RuntimeError(u'يلزم تثبيت أداة OpenSSL لقراءة مصدر الكابتن')
    process = subprocess.Popen([executable, 'enc', '-d', '-aes-128-cbc', '-nosalt', '-nopad', '-K', byte_hex(KEY), '-iv', byte_hex(IV)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        output, error = process.communicate(raw, timeout=12)
    except subprocess.TimeoutExpired:
        process.kill()
        process.communicate()
        raise RuntimeError(u'انتهت مهلة قراءة المصدر')
    if process.returncode:
        raise RuntimeError(u'تعذر قراءة بيانات مصدر الكابتن')
    return output

def decode_values(values):
    """One AES/OpenSSL operation per response, rather than a process per channel."""
    result = list(values)
    chunks = []
    indices = []
    for index, value in enumerate(values):
        if not isinstance(value, str):
            continue
        try:
            result[index] = json.loads(value)
            continue
        except (ValueError, TypeError):
            pass
        try:
            raw = base64.b64decode(value + '=' * (-len(value) % 4))
            if raw and len(raw) % 16 == 0:
                chunks.append(raw)
                indices.append(index)
        except (ValueError, TypeError):
            pass
    if not chunks:
        return result
    output = _decrypt_blocks(b''.join(chunks))
    offset = 0
    previous = IV
    for index, ciphertext in zip(indices, chunks):
        raw = bytearray(output[offset:offset + len(ciphertext)])
        offset += len(ciphertext)
        for pos in range(16):
            raw[pos] ^= previous[pos] ^ IV[pos]
        previous = ciphertext[-16:]
        padding = raw[-1]
        if not 1 <= padding <= 16 or raw[-padding:] != bytes([padding]) * padding:
            continue
        try:
            result[index] = json.loads(raw[:-padding].decode('utf8', 'replace'))
        except ValueError:
            pass
    return result

def decode_documents(documents):
    rows = []
    values = []
    targets = []
    for document in documents:
        row = {'_id': document.get('name', '').rsplit('/', 1)[-1]}
        rows.append(row)
        for field, value in document.get('fields', {}).items():
            row[field] = value.get('stringValue', value.get('integerValue', value.get('booleanValue', '')))
            if field in _FIELDS:
                targets.append((row, field))
                values.append(row[field])
    for (row, field), value in zip(targets, decode_values(values)):
        row[field] = value
    return rows

def _collection(name, cat_id=None):
    if name not in ('categories', 'channels'):
        raise ValueError(u'قسم غير معروف')

    def fetch():
        result = []
        token = ''
        cursor = ''
        with requests.Session() as session:
            for unused in range(50):
                if cat_id is None:
                    data = _request(session, BASE + name + '?' + urlencode(dict(dict({}, **{'pageSize': 100}), **{'pageToken': token} if token else {})))
                    docs = data.get('documents', [])
                    next_token = data.get('nextPageToken', '')
                else:
                    query = {'from': [{'collectionId': name}], 'where': {'fieldFilter': {'field': {'fieldPath': 'cat_id'}, 'op': 'EQUAL', 'value': {'stringValue': str(cat_id)}}}, 'orderBy': [{'field': {'fieldPath': '__name__'}, 'direction': 'ASCENDING'}], 'limit': 100}
                    if cursor:
                        query['startAt'] = {'values': [{'referenceValue': cursor}], 'before': False}
                    data = _request(session, BASE.rstrip('/') + ':runQuery', {'structuredQuery': query})
                    docs = [item['document'] for item in data if item.get('document')]
                    next_token = '' if len(docs) < 100 else docs[-1]['name']
                result.extend(decode_documents(docs))
                if not next_token:
                    break
                if cat_id is None:
                    if token == next_token:
                        raise RuntimeError(u'تكررت صفحة المصدر')
                    token = next_token
                else:
                    if cursor == next_token:
                        raise RuntimeError(u'تكررت صفحة المصدر')
                    cursor = next_token
            else:
                raise RuntimeError(u'القسم كبير جدًا؛ تعذر إكمال قراءته بأمان')
        return result
    return _cached(('collection', name, cat_id), fetch)

def settings():

    def fetch():
        with requests.Session() as session:
            doc = _request(session, BASE + 'settings/app')
        value = decode_documents([doc])[0].get('settings')
        if not isinstance(value, dict):
            raise RuntimeError(u'تعذر قراءة إعدادات مصدر الكابتن')
        return value
    return _cached(('settings',), fetch)

def _position(item):
    try:
        return int(item.get('position', 0))
    except (ValueError, TypeError):
        return 0

def _bein(name):
    compact = re.sub('[^a-z0-9\\u0600-\\u06ff]', '', str(name or '').lower())
    return compact.startswith(('beinsport', u'بينسبورت', u'بينالرياضية'))

def categories(section='channels'):
    if section != 'channels':
        return []
    result = []
    for row in _collection('categories'):
        item = row.get('category')
        if isinstance(item, dict) and _bein(item.get('name')):
            result.append(dict(item, id=row['_id'], section='channels', collection='channels', image=item.get('logo', '')))
    return sorted(result, key=_position)

def _items(parent):
    result = []
    for row in _collection('channels', parent['id']):
        item = row.get('channel')
        if not isinstance(item, dict) or not _bein(item.get('name')):
            continue
        entry = dict(item, id=row['_id'], image=item.get('logo', ''), section='channels', leaf=True)
        if servers(entry):
            result.append(entry)
    return sorted(result, key=_position)

def page(parent=None, number=1):
    if parent and (parent.get('section', 'channels') != 'channels' or parent.get('collection', 'channels') != 'channels'):
        return {'entries': [], 'page': 1, 'last_page': 1}
    rows = []
    seen = set()
    for category in categories('channels'):
        if parent and parent.get('id') and (category['id'] != parent['id']):
            continue
        for row in _items(category):
            if row['id'] not in seen:
                seen.add(row['id'])
                rows.append(row)
    rows.sort(key=_position)
    number = max(1, int(number))
    start = (number - 1) * 24
    return {'entries': rows[start:start + 24], 'page': number, 'last_page': max(1, (len(rows) + 23) // 24)}

def servers(item):
    if not _bein(item.get('name')) or item.get('section', 'channels') != 'channels':
        return []
    value = item.get('servers') or []
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError:
            value = []
    if not isinstance(value, list):
        return []
    result = []
    for index, server in enumerate(sorted([row for row in value if isinstance(row, dict)], key=_position)):
        if server.get('drm') or server.get('scheme') or server.get('license'):
            continue
        url = str(server.get('url') or '')
        if not url or not (url.startswith('stream=') or urlsplit(url).scheme in ('http', 'https')):
            continue
        result.append(dict(server, action='play', name=str(server.get('name') or u'سيرفر ' + str(index + 1)), title=item.get('name', u'بين سبورت'), section='channels', image=item.get('image', ''), drm=False))
    return result

def _headers(server):
    headers = {}
    for field in ('headers', 'otherHeaders'):
        data = server.get(field) or {}
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except ValueError:
                data = {}
        if isinstance(data, dict):
            headers.update({str(k): str(v) for k, v in data.items() if v is not None})
    for key, field in [('User-Agent', 'userAgent'), ('Referer', 'Referer')]:
        if server.get(field):
            headers[key] = str(server[field])
    headers.setdefault('User-Agent', settings().get('user_agent') or UA)
    headers.pop('streamKey', None)
    if any(('\r' in k + v or '\n' in k + v for k, v in headers.items())):
        raise ValueError(u'بيانات تشغيل غير صالحة')
    return headers

def _signed_stream(path, server):
    config = settings()
    with requests.Session() as session:
        response = session.get(_web_url(config.get('remote_url', '')), timeout=(5, 12))
        try:
            response.raise_for_status()
            remote = response.text.strip()
        finally:
            response.close()
    from .py2compat import ipaddress
    try:
        ipaddress.ip_address(remote)
    except ValueError:
        raise RuntimeError(u'تعذر تجهيز رابط البث من المصدر')
    raw = server.get('headers') or '{}'
    try:
        overrides = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        overrides = {}
    token = hashlib.md5((remote + ':' + str(overrides.get('streamKey') or config.get('stream_key', ''))).encode()).hexdigest()
    hosts = [x.strip().rstrip('/') for x in config.get('stream_hosts', '').split('|') if x.strip().startswith('https://')]
    if not hosts:
        raise RuntimeError(u'لم ينشر المصدر عنوان بث صالحًا')
    return [_web_url(host + '/' + path.lstrip('/') + '?' + urlencode({'token': token, 'ip': remote})) for host in hosts[:3]]

def _web_url(url):
    from .py2compat import ipaddress
    try:
        parsed = urlsplit(url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.hostname.lower() in ('localhost', 'localhost.localdomain'):
            raise ValueError()
        try:
            address = ipaddress.ip_address(parsed.hostname)
            if not address.is_global:
                raise RuntimeError(u'المصدر أعاد عنوانًا محليًا غير صالح للبث')
        except ValueError:
            pass
    except ValueError:
        raise RuntimeError(u'المصدر أعاد رابطًا غير صالح')
    return url

def resolve(server):
    if server.get('drm') or server.get('scheme') or server.get('license'):
        raise RuntimeError(u'هذا السيرفر محمي بـDRM وغير مدعوم على مشغلات الإنيجما المتاحة؛ اختر سيرفرًا آخر')
    url = str(server.get('url') or '')
    headers = _headers(server)
    if url.startswith('stream='):
        urls = _signed_stream(url[7:], server)
    elif urlsplit(url).scheme in ('http', 'https'):
        urls = [_web_url(url)]
    else:
        raise RuntimeError(u'رابط هذا السيرفر يحتاج مشغّل أندرويد ولم يُدعَم بعد')
    from .freeproviders import hls_variant_streams
    variants = []
    for url in urls:
        try:
            with requests.Session() as session:
                response = session.get(url, headers=headers, timeout=(5, 14), stream=True)
                try:
                    response.raise_for_status()
                    mime = response.headers.get('Content-Type', '').lower()
                    data = next(response.iter_content(65536), b'')
                    final = response.url
                finally:
                    response.close()
            if data.lstrip().startswith(b'#EXTM3U'):
                choices = hls_variant_streams({'url': final, 'headers': headers, 'relay': True, 'mediatype': 'hls', 'quality': server.get('name', 'Auto'), 'relay_options': {'livehd': True}})
                variants.extend(choices)
                break
            if mime.startswith(('video/', 'audio/')) or (len(data) >= 188 and data[0] == 71 and (len(data) < 376 or data[188] == 71)) or (len(data) > 8 and data[4:8] in (b'ftyp', b'styp')):
                variants.append({'url': final, 'headers': headers, 'relay': True, 'mediatype': 'ts' if len(data) >= 188 and data[0] == 71 and (len(data) < 376 or data[188] == 71) else 'mp4', 'quality': server.get('name', 'Original')})
                break
        except requests.RequestException:
            continue
    if not variants:
        raise RuntimeError(u'لم يُرجع السيرفر بث فيديو صالحًا؛ اختر سيرفرًا آخر')
    return {'name': server.get('title') or server.get('name', u'الكابتن'), 'url': urls[0], 'image': server.get('image', ''), 'streams': variants}
