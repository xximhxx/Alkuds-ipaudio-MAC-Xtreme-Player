# -*- coding: utf-8 -*-
"""DreamOS PVR audio isolation through PMT, without decoding or retiming TS."""
from __future__ import absolute_import, division
import struct

VIDEO = (1, 2, 16, 27, 36, 66)
NULL = b'\x47\x1f\xff\x10' + b'\xff' * 184

def raw(data):
    return struct.pack('%dB' % len(data), *data)

def crc(data):
    value = 0xffffffff
    for octet in bytearray(data):
        value ^= octet << 24
        for unused in range(8):
            value = ((value << 1) ^ (0x04c11db7 if value & 0x80000000 else 0)) & 0xffffffff
    return value

class VideoOnlyPMT(object):
    def __init__(self, sid):
        self.sid = sid
        self.pmt = None
        self.pending = {}
        self.cc = {}
        self.output_cc = 0
        self.ready = False
        self.removed = set()
        self.pcr = None

    def sections(self, pid, payload, start, cc):
        previous = self.cc.get(pid)
        self.cc[pid] = cc
        if previous is not None and cc != (previous + 1) & 15:
            self.pending.pop(pid, None)
        if start:
            if not payload or payload[0] + 1 > len(payload):
                self.pending.pop(pid, None)
                return []
            pointer = payload[0]
            prefix = self.pending.pop(pid, bytearray()) + payload[1:1 + pointer]
            data = payload[1 + pointer:]
        elif pid in self.pending:
            prefix = bytearray()
            data = self.pending.pop(pid) + payload
        else:
            return []
        result = []
        if len(prefix) >= 3:
            size = 3 + ((prefix[1] & 15) << 8) + prefix[2]
            if size <= len(prefix) and not crc(prefix[:size]):
                result.append(prefix[:size])
        while data and data[0] != 255:
            if len(data) < 3:
                self.pending[pid] = data
                break
            size = 3 + ((data[1] & 15) << 8) + data[2]
            if size > 4096 or size < 7:
                break
            if size > len(data):
                self.pending[pid] = data
                break
            if not crc(data[:size]):
                result.append(data[:size])
            data = data[size:]
        return result

    def rewrite(self, section):
        if len(section) < 16 or section[0] != 2 or (section[3] << 8 | section[4]) != self.sid or not section[5] & 1:
            return None
        if section[6] or section[7]:
            raise RuntimeError('DreamOS video-only PMT requires a single program section')
        start = 12 + ((section[10] & 15) << 8) + section[11]
        if start > len(section) - 4:
            raise RuntimeError('Invalid PMT program descriptors')
        output = section[:start]
        videos = 0
        removed = set()
        while start < len(section) - 4:
            if start + 5 > len(section) - 4:
                raise RuntimeError('Invalid PMT stream entry')
            end = start + 5 + ((section[start + 3] & 15) << 8) + section[start + 4]
            if end > len(section) - 4:
                raise RuntimeError('Invalid PMT stream descriptors')
            if section[start] in VIDEO:
                output.extend(section[start:end])
                videos += 1
            else:
                removed.add(((section[start + 1] & 31) << 8) | section[start + 2])
            start = end
        if not videos:
            return None
        self.removed = removed
        self.pcr = ((section[8] & 31) << 8) | section[9]
        # Keep the program PCR PID and all original PCR/video packets intact.
        size = len(output) + 4 - 3
        output[1] = (output[1] & 240) | (size >> 8)
        output[2] = size & 255
        output[5] = (output[5] & 193) | ((((output[5] >> 1) + 1) & 31) << 1)
        return raw(output) + struct.pack('>I', crc(output))

    def packets(self, section):
        payload = b'\x00' + section
        result = []
        first = True
        while payload:
            part, payload = payload[:184], payload[184:]
            header = raw([71, (self.pmt >> 8) | (64 if first else 0), self.pmt & 255, 16 | self.output_cc])
            self.output_cc = (self.output_cc + 1) & 15
            result.append(header + part + b'\xff' * (184 - len(part)))
            first = False
        return b''.join(result)

    def feed(self, data):
        output = []
        for offset in range(0, len(data), 188):
            packet = data[offset:offset + 188]
            if len(packet) != 188:
                raise ValueError('PMT filter requires aligned TS packets')
            b = bytearray(packet)
            pid = ((b[1] & 31) << 8) | b[2]
            if pid not in (0, self.pmt):
                if not self.ready:
                    output.append(NULL)
                elif pid in self.removed:
                    afc = (b[3] >> 4) & 3
                    if pid == self.pcr and afc in (2, 3) and 7 <= b[4] <= 183 and b[5] & 16:
                        # Retain PCR/adaptation bytes even if its PID carried
                        # audio; omit the PES payload, without changing PCR.
                        length = b[4]
                        output.append(raw(b[:3] + bytearray([32 | (b[3] & 15), 183]) + b[5:5 + length]) + b'\xff' * (183 - length))
                    else:
                        output.append(NULL)
                else:
                    output.append(packet)
                continue
            sections = []
            afc = (b[3] >> 4) & 3
            pos = 5 + b[4] if afc == 3 else 4
            if not b[1] & 128 and afc in (1, 3) and pos < 188:
                sections = self.sections(pid, b[pos:], bool(b[1] & 64), b[3] & 15)
            if pid == 0:
                for section in sections:
                    if section[0] == 0 and section[5] & 1:
                        for n in range(8, len(section) - 4, 4):
                            if (section[n] << 8 | section[n + 1]) == self.sid:
                                pmt = ((section[n + 2] & 31) << 8) | section[n + 3]
                                if self.pmt != pmt:
                                    self.ready = False
                                    self.pmt = pmt
                output.append(packet)
            else:
                rewritten = []
                for section in sections:
                    result = self.rewrite(section)
                    if result:
                        rewritten.append(self.packets(result))
                        self.ready = True
                # Never expose the source audio PMT, including partial sections.
                output.append(b''.join(rewritten) if rewritten else NULL)
        return b''.join(output)
