# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""EgyDead catalogue and MegaMax public player choices, Python 2/3."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import re
from .py2compat import requests
from . import arabseed as a
try:
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
    urlencode = urllib.parse.urlencode
    parse_qs = urllib.parse.parse_qs
except ImportError:
    from urlparse import urljoin, urlparse, parse_qs
    from urllib import urlencode
BASE = 'https://tv10.egydead.live/'
SECTIONS = [('browse', u'تصفح الموقع', 'h3/'), ('foreign_movies', u'أفلام أجنبية', 'category/english-movies/'), ('arabic_movies', u'أفلام عربية', u'category/افلام-عربي/'), ('turkish_movies', u'أفلام تركية', u'category/افلام-تركية/'), ('indian_movies', u'أفلام هندية', 'category/hindi-movies/'), ('asian_movies', u'أفلام آسيوية', u'category/افلام-اسيوية/'), ('cartoon_movies', u'أفلام كرتون', u'category/افلام-كرتون/'), ('anime_movies', u'أفلام أنمي', u'category/افلام-انمي/'), ('documentary_movies', u'أفلام وثائقية', u'category/افلام-وثائقية/'), ('dubbed_movies', u'أفلام أجنبية مدبلجة', u'category/english-movies/افلام-اجنبية-مدبلجة/'), ('egyptian_cartoon_movies', u'كرتون باللهجة المصرية', u'category/افلام-كرتون/افلام-كرتون-ديزني-باللهجة-المصرية/'), ('translated_movies', u'أفلام إسلام الجيزاوي', u'category/ترجمات-اسلام-الجيزاوي/'), ('all_series', u'المسلسلات الكاملة', 'serie/'), ('foreign_series', u'مسلسلات أجنبية', 'series-category/english-series/'), ('arabic_series', u'مسلسلات عربية', 'series-category/arabic-series/'), ('turkish_series', u'مسلسلات تركية', 'series-category/turkish-series/'), ('indian_series', u'مسلسلات هندية', 'series-category/indian-series/'), ('asian_series', u'مسلسلات آسيوية', 'series-category/asian-series/'), ('latino_series', u'مسلسلات لاتينية', 'series-category/latino-series/'), ('african_series', u'مسلسلات إفريقية', 'series-category/african-series/'), ('documentary_series', u'مسلسلات وثائقية', 'series-category/documentary-series/'), ('cartoon_series', u'مسلسلات كرتون', 'series-category/cartoon-series/'), ('anime_series', u'مسلسلات أنمي', 'series-category/anime-series/'), ('dubbed_anime_series', u'أنمي مدبلج', 'series-category/anime-series-dubbed/'), ('chinese_series', u'أنميات صينية', 'series-category/chinese-anime/'), ('korean_series', u'أنميات كورية', 'series-category/korean-anime/'), ('dubbed_foreign_series', u'مسلسلات أجنبية مدبلجة', 'series-category/english-series-dubbed/'), ('dubbed_turkish_series', u'مسلسلات تركية مدبلجة', 'series-category/turkish-series-dubbed/'), ('dubbed_cartoon_series', u'كرتون مدبلج', 'series-category/cartoon-series-dubbed/'), ('dubbed_latino_series', u'مسلسلات لاتينية مدبلجة', 'series-category/latino-series-dubbed/'), ('programs', u'برامج تلفزيونية', 'series-category/tv-shows/'), ('shows', u'ستاند أب وحفلات', u'category/عروض-وحفلات/'), ('sports', u'رياضة', u'category/رياضة/')]
SECTION_MAP = dict(((key, (name, path)) for key, name, path in SECTIONS))

def _local(url):
    url = urljoin(BASE, url)
    if urlparse(url).scheme not in ('https', 'http') or urlparse(url).hostname != urlparse(BASE).hostname:
        raise ValueError('Unexpected EgyDead catalogue address')
    return requests.utils.requote_uri(url)

def _get(session, url, referer=BASE):
    response = session.get(_local(url), headers=a._headers(referer), timeout=(6, 18), stream=True)
    try:
        raw = bytearray()
        for chunk in response.iter_content(32768):
            raw.extend(chunk)
            if len(raw) > 5 * 1024 * 1024:
                raise RuntimeError(u'صفحة إيجي ديد أكبر من الحجم المدعوم.')
        text = bytes(raw).decode('utf8', 'replace')
        if ('cf-chl-' in text or '_cf_chl_opt' in text) and (not 'movieItem' in text):
            raise RuntimeError(u'إيجي ديد يطلب تحقق Cloudflare من المتصفح (403). طلبات الرسيفر محجوبة حالياً؛ أعد المحاولة لاحقاً أو جرّب شبكة أخرى.')
        if response.status_code == 403:
            raise RuntimeError(u'إيجي ديد رفض الوصول إلى المحتوى (403). القائمة المحلية قد تظهر رغم حجب صفحات الموقع.')
        response.raise_for_status()
        _local(response.url)
        return (text, response.url)
    finally:
        response.close()

def groups():
    return [{'name': name, 'section': key} for key, name, path in SECTIONS]

def _series_title(title):
    title = re.split(u'\\s*(?:الموسم|الجزء|الحلقة|حلقه|حلقة)\\s*', title, 1)[0]
    title = re.sub(u'\\s+(?:مترجم|مدبلج|كامل|جميع المواسم).*$', '', title).strip()
    title = re.sub(u'^جميع مواسم\\s+', '', title)
    return re.sub('\\s+(?:19|20)\\d{2}$', '', title).strip()

def _cards(root, section, container='posts-list'):
    holders = root.find(css=container)
    result, seen = ([], set())
    for holder in holders:
        for block in holder.find(css='movieItem'):
            links = block.find('a')
            if not links:
                continue
            link = links[0]
            try:
                url = _local(link.attrs.get('href', ''))
            except ValueError:
                continue
            if url in seen:
                continue
            seen.add(url)
            title = link.attrs.get('title') or a._first_text(block, 'BottomTitle') or link.text()
            if not title:
                continue
            path = urlparse(url).path
            is_series = any((path.startswith('/' + kind + '/') for kind in ('serie', 'season', 'episode')))
            result.append({'url': url, 'name': title, 'image': a._image(block), 'category': a._first_text(block, 'cat_name'), 'section': section, 'is_series': is_series})
    return result

def _sort_key(item):
    title = re.sub(u'^(?:مشاهدة\\s+)?(?:فيلم|مسلسل|انمي|أنمي|برنامج)\\s+', '', item['name'])
    return title.lower()

def fetch_items(section, page=1, query='', order='latest'):
    name, path = SECTION_MAP[section]
    values = {'page': '%d/' % int(page)} if int(page) > 1 else {}
    if query:
        if section == 'browse':
            path = ''
        values['s'] = query.encode('utf-8')
    url = _local(path) + ('?' + urlencode(values) if values else '')
    session = requests.Session()
    try:
        html, page_url = _get(session, url)
    finally:
        session.close()
    root = a.Document(html).root
    entries = _cards(root, section)
    if not entries:
        entries = _cards(root, section, 'container')
    if section.endswith('_movies'):
        entries = [x for x in entries if not x['is_series']]
    elif section.endswith('_series'):
        entries = [x for x in entries if x['is_series']]
    grouped, seen = ([], set())
    for item in entries:
        if item['is_series']:
            item['name'] = _series_title(item['name'])
            if item['name'].lower() in seen:
                continue
            seen.add(item['name'].lower())
        grouped.append(item)
    entries = grouped
    if order in ('az', 'za'):
        entries.sort(key=_sort_key, reverse=order == 'za')
    pages = [int(page)]
    for link in root.find('a', 'page-numbers'):
        params = parse_qs(urlparse(link.attrs.get('href', '')).query)
        match = re.match('(\\d+)', params.get('page', [''])[0])
        if not match:
            match = re.search('/page/(\\d+)', link.attrs.get('href', ''))
        if match:
            pages.append(int(match.group(1)))
    return {'entries': entries, 'page': int(page), 'last_page': max(pages), 'total': len(entries)}

def _breadcrumb(root, kind):
    holders = [x for x in root.find('ul') if x.attrs.get('id') == 'breadcrumbs']
    for holder in holders:
        for link in holder.find('a'):
            if urlparse(link.attrs.get('href', '')).path.startswith('/' + kind + '/'):
                return _local(link.attrs['href'])
    return ''

def seasons(item):
    session = requests.Session()
    try:
        html, url = _get(session, item['url'])
        root = a.Document(html).root
        if urlparse(url).path.startswith('/episode/'):
            url = _breadcrumb(root, 'season')
            if not url:
                raise RuntimeError('EgyDead did not return the episode season')
            html, url = _get(session, url, item['url'])
            root = a.Document(html).root
        if urlparse(url).path.startswith('/season/'):
            series_url = _breadcrumb(root, 'serie')
            if series_url:
                html, url = _get(session, series_url, url)
                root = a.Document(html).root
        result = _cards(root, item['section'], 'seasons-list')
        if not result and urlparse(url).path.startswith('/season/'):
            result = [dict(item, url=url)]
        for row in result:
            row.update(season=row['url'], series_title=item['name'], is_series=False)
            match = re.search('(?:-|/)s(\\d+)(?:/|$)', urlparse(row['url']).path, re.I)
            if match:
                row['name'] = u'الموسم %d' % int(match.group(1))
        if not result:
            raise RuntimeError('EgyDead did not return seasons for this series')
        return result
    finally:
        session.close()

def episodes(item, page=1):
    session = requests.Session()
    try:
        html, url = _get(session, item['url'])
    finally:
        session.close()
    root = a.Document(html).root
    result, seen = ([], set())
    for holder in root.find(css='EpsList'):
        for link in holder.find('a'):
            href = link.attrs.get('href', '')
            if not urlparse(href).path.startswith('/episode/'):
                continue
            href = _local(href)
            if href in seen:
                continue
            seen.add(href)
            row = dict(item)
            label = link.text() or link.attrs.get('title') or u'حلقة'
            number = re.search('\\d+', label)
            row.update(url=href, name=u'الحلقة %d' % int(number.group()) if number else label, description=link.attrs.get('title', ''), episode_number=int(number.group()) if number else 0)
            result.append(row)
    result.sort(key=lambda x: x['episode_number'])
    return {'entries': result, 'page': 1, 'last_page': 1, 'total': len(result)}

def _megamax_servers(session, url, referer):
    html, final_url = a._get(session, url, referer)
    scripts = a.Document(html).root.find('script')
    page = next((json.loads(x.text()) for x in scripts if 'data-page' in x.attrs), None)
    if not page:
        raise RuntimeError('MegaMax did not return player data')
    headers = a._headers(final_url)
    headers.update({'X-Inertia': 'true', 'X-Inertia-Version': page.get('version', ''), 'X-Inertia-Partial-Component': page['component'], 'X-Inertia-Partial-Data': 'streams', 'X-Requested-With': 'XMLHttpRequest'})
    response = session.get(final_url, headers=headers, timeout=(8, 20))
    try:
        response.raise_for_status()
        streams = response.json().get('props', {}).get('streams', {})
    finally:
        response.close()
    if streams.get('status') != 'success':
        raise RuntimeError(streams.get('msg') or 'MegaMax video is unavailable')
    result = []
    for quality in streams.get('data', []):
        for mirror in quality.get('mirrors', []):
            link = urljoin(final_url, mirror.get('link', ''))
            if urlparse(link).scheme not in ('http', 'https'):
                continue
            result.append({'server_url': link, 'name': '%s | %s' % (mirror.get('driver', 'Player'), quality.get('label', 'Original')), 'quality': quality.get('label', 'Original'), 'referer': final_url})
    return result

def servers(item):
    session = requests.Session()
    try:
        url = _local(item['url'])
        response = session.post(url, data={'View': '1'}, headers=a._headers(url), timeout=(8, 25))
        try:
            response.raise_for_status()
            root = a.Document(response.content.decode('utf-8', 'replace')).root
            page_url = response.url
        finally:
            response.close()
        choices = []
        for holder in root.find(css='serversList'):
            for node in holder.find('li'):
                href = node.attrs.get('data-link')
                if not href:
                    continue
                href = urljoin(page_url, href)
                if urlparse(href).hostname == 'megamax.me':
                    choices.extend(_megamax_servers(session, href, page_url))
                else:
                    choices.append({'name': node.text(), 'server_url': href, 'referer': page_url})
        result = []
        for choice in choices:
            row = dict(item)
            row.update(choice)
            row['title'] = item.get('series_title', '') + u' - ' + item['name'] if item.get('series_title') else item['name']
            result.append(row)
        if not result:
            raise RuntimeError('EgyDead did not return any available players')
        return result
    finally:
        session.close()

def resolve(item):
    from .freeproviders import hls_variant_streams, _unpack_egybest_script
    session = requests.Session()
    try:
        media = a._resolve_page(session, item['server_url'], item['referer'])
        if not media:
            html, final_url = a._get(session, item['server_url'], item['referer'])
            html = (_unpack_egybest_script(html) or '') + '\n' + html
            html = html.replace('\\/', '/')
            for value in re.findall('["\\\']((?:https?:)?//[^"\\\']+\\.(?:mp4|m3u8)(?:\\?[^"\\\']*)?)["\\\']', html, re.I):
                media.append({'url': urljoin(final_url, value), 'referer': final_url, 'mediatype': a._media_type(value)})
        variants, seen = ([], set())
        for stream in media:
            candidate = {'url': stream['url'], 'relay': True, 'mediatype': stream['mediatype'], 'subtitles': stream.get('subtitles') or [], 'quality': stream.get('quality') or item.get('quality', 'Original'), 'headers': {'User-Agent': a.UA, 'Referer': a._referer(stream['referer'])}}
            for variant in hls_variant_streams(candidate):
                if variant['url'] not in seen:
                    seen.add(variant['url'])
                    variants.append(variant)
        if not variants:
            raise RuntimeError('This player did not expose a supported video link. Choose another player.')
        result = dict(item)
        result.update(name=item.get('title', item['name']), streams=variants)
        return result
    finally:
        session.close()
