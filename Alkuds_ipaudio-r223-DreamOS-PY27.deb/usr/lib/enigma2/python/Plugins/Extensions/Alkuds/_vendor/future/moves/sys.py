from __future__ import absolute_import

from Plugins.Extensions.Alkuds._vendor.future.utils import PY2

from sys import *

if PY2:
    from __builtin__ import intern
