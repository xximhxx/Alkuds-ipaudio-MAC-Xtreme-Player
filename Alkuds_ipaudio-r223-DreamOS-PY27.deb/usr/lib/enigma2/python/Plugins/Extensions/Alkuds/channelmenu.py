# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .py2compat import json
from time import time
try:
    from http.client import HTTPConnection
    HTTPConnection.debuglevel = 0
except:
    from httplib import HTTPConnection
    HTTPConnection.debuglevel = 0
from Components.ActionMap import ActionMap
from .xStaticText import List
from Screens.Screen import Screen
from .xStaticText import MessageBox
from . import _
from . import alkuds_globals as glob
from .plugin import skin_directory, cfg, version, downloads_json
from .xStaticText import StaticText
from . import processfiles as loadfiles

class Alkuds_ChannelMenu(Screen):
    ALLOW_SUSPEND = True
    instance = None

    def __init__(self, session, callfunc, posters_changed=None):
        Screen.__init__(self, session)
        self.session = session
        self.callfunc = callfunc
        self.posters_changed = posters_changed
        skin_path = os.path.join(skin_directory, cfg.skin.value)
        skin = os.path.join(skin_path, 'channelmenu.xml')
        with open(skin, 'r') as f:
            self.skin = f.read()
        self.list = []
        self.drawList = []
        self.playlists_all = self.playlists_all = loadfiles.process_files()
        self['list'] = List(self.drawList, enableWrapAround=True)
        self.setup_title = _('Menu')
        self.provider = glob.active_playlist['playlist_info']['name']
        self['provider'] = StaticText(self.provider)
        self['key_red'] = StaticText(_('Back'))
        self['key_green'] = StaticText(_('OK'))
        self['dialogactions'] = ActionMap(['AlkudsActions'], {'green': self.__next__, 'ok': self.__next__, 'up': self.goUp, 'down': self.goDown, 'left': self.pageUp, 'right': self.pageDown, '0': self.reset}, -1)
        self['version'] = StaticText()
        self['version'].setText(version)
        self.createSetup()
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def goUp(self):
        instance = self['list'].master.master.instance
        instance.moveSelection(instance.moveUp)

    def goDown(self):
        instance = self['list'].master.master.instance
        instance.moveSelection(instance.moveDown)

    def pageUp(self):
        instance = self['list'].master.master.instance
        instance.moveSelection(instance.pageUp)

    def pageDown(self):
        instance = self['list'].master.master.instance
        instance.moveSelection(instance.pageDown)

    def reset(self):
        self['list'].setIndex(0)

    def createSetup(self):
        self.provider = str(glob.active_playlist['playlist_info']['name'])
        self['provider'].setText(self.provider)
        self.list = []
        if self.callfunc in ('vod', 'series'):
            self.list.append([18, _('Hide movie/series posters') if cfg.channelcovers.value else _('Show movie/series posters')])
        if glob.active_playlist['player_info']['showlive'] and self.callfunc == 'live':
            self.list.append([5, _('Manual EPG Update')])
        if self.callfunc == 'live' and getattr(glob, 'current_level', 0) == 2 and getattr(glob, 'bg_audio_url', ''):
            self.list.append([14, 'Local Remux: IPTV + Satellite audio tracks'])
            self.list.append([15, 'Local Remux: IPTV audio only'])
            self.list.append([16, 'Local Remux: stop and restore satellite'])
            self.list.append([17, 'Local Remux: status'])
        self.list.append([6, _('Playlist Settings')])
        if glob.current_list:
            self.list.append([7, _('Show/Hide Channels')])
        if cfg.sidemenuaccountinfo.value:
            self.list.append([8, _('Account Info')])
        if len(self.playlists_all) > 1 and cfg.sidemenumanageplaylists.value:
            self.list.append([10, _('Manage Playlists')])
        self.list.append([11, _('Add New Playlist')])
        downloads_all = []
        if os.path.isfile(downloads_json) and os.stat(downloads_json).st_size > 0:
            try:
                with open(downloads_json, 'r') as f:
                    downloads_all = json.load(f)
            except Exception as e:
                print(e)
        if downloads_all:
            self.list.append([12, _('Download Manager')])
        self.list.append([13, _('Global Settings')])
        self.drawList = []
        self.drawList = [buildListEntry(x[0], x[1]) for x in self.list]
        self['list'].setList(self.drawList)

    def __next__(self):
        current = self['list'].getCurrent()
        if not current:
            return
        if current[0] == 18:
            from Components.config import configfile
            cfg.channelcovers.value = not cfg.channelcovers.value
            cfg.channelcovers.save()
            configfile.save()
            if self.posters_changed:
                self.posters_changed()
            self.createSetup()
            return
        choice = self['list'].getCurrent()[1]
        if self['list'].getCurrent():
            if choice == '':
                pass
            if choice == _('Manual EPG Update'):
                self.manualEPGUpdate()
            if choice == _('Playlist Settings'):
                self.playlistSettings()
            if choice == _('Show/Hide Channels'):
                self.showHidden()
            if choice == _('Account Info'):
                self.userInfo()
            if choice == _('Manage Playlists'):
                self.showPlaylists()
            if choice == _('Add New Playlist'):
                self.addPlaylist()
            if choice == _('Download Manager'):
                self.downloadManager()
            if choice == _('Global Settings'):
                self.mainSettings()
            if choice == 'Local Remux: IPTV + Satellite audio tracks':
                self.localRemuxStart('dual')
            if choice == 'Local Remux: IPTV audio only':
                self.localRemuxStart('iptv')
            if choice == 'Local Remux: stop and restore satellite':
                self.localRemuxStop()
            if choice == 'Local Remux: status':
                self.localRemuxStatus()

    def localRemuxStart(self, mode='dual'):
        name = str(getattr(glob, 'bg_audio_name', '') or 'Xtream IPTV')
        url = str(getattr(glob, 'bg_audio_url', '') or '')
        if not url:
            self.session.open(MessageBox, 'Select a Live channel first.', MessageBox.TYPE_INFO, timeout=4)
            return
        try:
            from .remux import start_local_remux
            cached_channels = []
            selected_index = 0
            try:
                for item in list(getattr(glob, 'current_list', []) or []):
                    if not isinstance(item, (list, tuple)) or len(item) <= 15:
                        continue
                    ch_name = str(item[1] or 'Channel')
                    ch_url = str(item[15] or '')
                    if not ch_url:
                        continue
                    if ch_url == url:
                        selected_index = len(cached_channels)
                    cached_channels.append((ch_name, ch_url))
            except Exception:
                cached_channels = [(name, url)]
                selected_index = 0
            if not cached_channels:
                cached_channels = [(name, url)]
            resume_context = {'source': 'xtream', 'channels': cached_channels, 'selected_index': int(selected_index), 'channel_name': name, 'mode': mode}
            start_local_remux(self.session, url, name, mode, iptv_headers={'User-Agent': str(cfg.useragent.value)}, resume_context=resume_context)
            self.closeDialog()
            text = 'Starting Local Remux: %s\n\nSatellite video is copied without re-encoding. IPTV audio will be inserted into one local MPEG-TS service.' % name
            if mode == 'dual':
                text += '\n\nDual-audio mode: IPTV + original satellite audio. Try the AUDIO key after playback starts.'
            else:
                text += '\n\nIPTV-only audio mode.'
            self.session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=7)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to start Local Remux:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def localRemuxStop(self):
        try:
            from .remux import stop_local_remux
            stopped = stop_local_remux(restore=True)
            msg = 'Local Remux stopped. Satellite service restored.' if stopped else 'Local Remux is not running.'
        except Exception as e:
            msg = 'Unable to stop Local Remux: %s' % str(e)
        self.closeDialog()
        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)

    def localRemuxStatus(self):
        try:
            from .remux import local_remux_status
            active, name, backend = local_remux_status()
            msg = 'Local Remux is running:\n%s\n%s' % (name, backend) if active else 'Local Remux is not running.'
        except Exception as e:
            msg = 'Unable to read Local Remux status: %s' % str(e)
        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)

    def manualEPGUpdate(self):
        self.closeDialog()
        recordings = ''
        next_rec_time = -1
        try:
            recordings = self.session.nav.getRecordings()
            if not recordings:
                next_rec_time = self.session.nav.RecordTimer.getNextRecordingTime()
        except Exception as e:
            print(e)
        if recordings or (next_rec_time > 0 and next_rec_time - time() < 360):
            self.session.open(MessageBox, _('Recordings in progress. EPG not downloaded.'), type=MessageBox.TYPE_INFO, timeout=5)
        else:
            self.session.openWithCallback(self.manualEPGUpdate2, MessageBox, _('EPGs downloading.'), type=MessageBox.TYPE_INFO, timeout=5)

    def manualEPGUpdate2(self, data=None):
        from . import update
        update.Alkuds_Update(self.session, 'manual')
        self.callback()

    def playlistSettings(self):
        self.closeDialog()
        from . import playsettings
        self.session.openWithCallback(self.callback, playsettings.Alkuds_Settings)

    def showHidden(self):
        self.closeDialog()
        from . import hidden
        self.session.openWithCallback(self.callback, hidden.Alkuds_HiddenCategories, glob.current_screen, glob.current_list, glob.current_level)

    def userInfo(self):
        self.closeDialog()
        from . import serverinfo
        if 'user_info' in glob.active_playlist:
            if 'auth' in glob.active_playlist['user_info']:
                if str(glob.active_playlist['user_info']['auth']) == '1':
                    self.session.openWithCallback(self.callback, serverinfo.Alkuds_UserInfo)

    def showPlaylists(self):
        self.closeDialog()
        from . import playlists
        self.session.openWithCallback(self.callback, playlists.Alkuds_Playlists)

    def addPlaylist(self):
        self.closeDialog()
        from . import server
        self.session.openWithCallback(self.callback, server.Alkuds_AddServer)

    def downloadManager(self):
        self.closeDialog()
        from . import downloadmanager
        self.session.openWithCallback(self.callback, downloadmanager.Alkuds_DownloadManager)

    def mainSettings(self):
        self.closeDialog()
        from . import settings
        self.session.openWithCallback(self.callback, settings.Alkuds_Settings)

    def callback(self, answer=None):
        if glob.ChoiceBoxDialog:
            glob.ChoiceBoxDialog['dialogactions'].execBegin()
            glob.ChoiceBoxDialog.show()
            self.createSetup()

    def closeDialog(self):
        if glob.ChoiceBoxDialog:
            glob.ChoiceBoxDialog.hide()
            glob.ChoiceBoxDialog['dialogactions'].execEnd()

    def exitDialog(self):
        if glob.ChoiceBoxDialog:
            glob.ChoiceBoxDialog.hide()
            glob.ChoiceBoxDialog['dialogactions'].execEnd()
            self.session.deleteDialog(glob.ChoiceBoxDialog)

def buildListEntry(index, choice):
    icon = None
    if choice == _('Live'):
        icon = u'\ue900'
    if choice == _('Vod'):
        icon = u'\ue901'
    if choice == _('Series'):
        icon = u'\ue902'
    if choice == _('Catchup'):
        icon = u'\ue903'
    if choice == _('Manual EPG Update'):
        icon = u'\ue904'
    if choice == _('Playlist Settings'):
        icon = u'\ue905'
    if choice == _('Show/Hide Channels'):
        icon = u'\ue906'
    if choice == _('Account Info'):
        icon = u'\ue907'
    if choice == 'Set As Default Playlist':
        icon = u'\ue908'
    if choice == _('Manage Playlists'):
        icon = u'\ue909'
    if choice == _('Add New Playlist'):
        icon = u'\ue90a'
    if choice == _('Download Manager'):
        icon = u'\ue90b'
    if choice == _('Global Settings'):
        icon = u'\ue90c'
    return (index, str(choice), icon)
