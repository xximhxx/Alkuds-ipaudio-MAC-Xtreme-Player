# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Public beIN MENA schedule, UTC timestamps displayed in receiver local time.

All HTTP runs in a worker, with compact disk cache. No audio/timeshift calls.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import datetime_module as datetime
import calendar
from .py2compat import json
from .py2compat import io_module as io
from .py2compat import ElementTree as ET
from .py2compat import os
from .py2compat import re
import ssl
from .py2compat import threading
from .py2compat import time
from .py2compat import urllib
urlencode = urllib.parse.urlencode
from .py2compat import urllib
Request = urllib.request.Request
urlopen = urllib.request.urlopen
CACHE_FILE = '/etc/enigma2/alkuds_sports_epg.json'
CHANNEL_FILE = os.path.join(os.path.dirname(__file__), 'bein_guide_channels.json')
SOURCE = 'https://www.beinsports.com/api/opta/tv-event'
XML_SOURCES = ('https://raw.githubusercontent.com/al7omed/bein-epg/main/docs/guide.xml', 'https://al7omed.github.io/bein-epg/guide.xml')
XML_LIMIT = 4 * 1024 * 1024
_primary_retry_at = 0
_lock = threading.RLock()
_state = {'loaded': False, 'busy': False, 'rows': {}, 'next_fetch': 0, 'revision': 0, 'error': '', 'window': None}

def parse_iso(value):
    match = re.fullmatch('(\\d{4}-\\d{2}-\\d{2})T(\\d{2}:\\d{2}:\\d{2})(?:\\.(\\d+))?(Z|[+-]\\d{2}:?\\d{2})', str(value))
    if not match:
        raise ValueError('Invalid guide timestamp')
    date, clock, fraction, zone = match.groups()
    stamp = calendar.timegm(datetime.datetime.strptime(date + ' ' + clock, '%Y-%m-%d %H:%M:%S').timetuple())
    if zone != 'Z':
        digits = zone[1:].replace(':', '')
        hours, minutes = (int(digits[:2]), int(digits[2:]))
        if hours > 23 or minutes > 59:
            raise ValueError('Invalid UTC offset')
        stamp -= (1 if zone[0] == '+' else -1) * (hours * 3600 + minutes * 60)
    return stamp + (float('0.' + fraction) if fraction else 0)

def day_bounds(offset=0):
    today = datetime.date.fromtimestamp(time.time()) + datetime.timedelta(days=offset)
    tomorrow = today + datetime.timedelta(days=1)
    return (time.mktime(datetime.datetime.combine(today, datetime.time()).timetuple()), time.mktime(datetime.datetime.combine(tomorrow, datetime.time()).timetuple()))

def _title(value):
    value = str(value or '').strip()
    if any((marker in value for marker in (u'Ã', u'Ø', u'Ù', u'ط§', u'ظ„', u'ظٹ'))):
        for encoding in ('latin1', 'cp1252', 'cp1256'):
            try:
                return value.encode(encoding).decode('utf8')
            except (UnicodeError, LookupError):
                pass
    return value

def parse_programs(payload, channels):
    result = {}
    for row in payload.get('rows', []) or []:
        try:
            key = channels.get(str(row.get('channelId') or '').upper())
            if not key:
                continue
            start, stop = (parse_iso(row['startDate']), parse_iso(row['endDate']))
            names = (row.get('data') or {}).get('Title') or {}
            name = names.get('Arabic') if isinstance(names, dict) else ''
            title = _title(name or row.get('title'))
            if not title or stop <= start:
                continue
            program = {'start': start, 'stop': stop, 'title': title, 'live': row.get('live') is True or str(row.get('live', '')).lower() == 'true'}
            result.setdefault(key, []).append(program)
        except (ValueError, TypeError, KeyError, OverflowError, AttributeError):
            continue
    for key, programs in result.items():
        unique = {(p['start'], p['stop'], p['title']): p for p in programs}
        result[key] = sorted(unique.values(), key=lambda p: p['start'])
    return result

def _request(url):
    request = Request(url, headers={'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/130.0 Safari/537.36', 'Accept': 'application/json', 'Accept-Language': 'ar,en;q=0.8', 'Referer': 'https://www.beinsports.com/'})
    context = ssl.create_default_context()
    try:
        import certifi
        context.load_verify_locations(cafile=certifi.where())
    except (ImportError, OSError, ssl.SSLError):
        pass
    with urlopen(request, timeout=15, context=context) as response:
        data = response.read(16 * 1024 * 1024 + 1)
    if len(data) > 16 * 1024 * 1024:
        raise ValueError('Guide response too large')
    return json.loads(data.decode('utf8'))

def fetch_programs(channels, start, stop):
    """Bound URLs and page through complete results without discarding a guide."""
    utc = lambda stamp: time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime(stamp))
    identifiers = list(channels)
    all_rows = []
    total_pages = 0
    for begin in range(0, len(identifiers), 8):
        batch = identifiers[begin:begin + 8]
        offset = 0
        seen = set()
        while True:
            query = [('startBefore', utc(stop)), ('endAfter', utc(start)), ('limit', '1000'), ('offset', str(offset))]
            query += [('channelIds', channel) for channel in batch]
            payload = _request(SOURCE + '?' + urlencode(query))
            total_pages += 1
            if not isinstance(payload, dict) or not isinstance(payload.get('rows'), list):
                raise ValueError('Invalid guide response')
            page = payload['rows']
            count = int(payload.get('count', len(page)))
            if count < 0:
                raise ValueError('Invalid guide count')
            marks = {json.dumps(row, sort_keys=True, ensure_ascii=True) for row in page}
            if not page and offset < count:
                raise ValueError('Incomplete guide response')
            if page and (not marks - seen):
                raise ValueError('Guide pagination did not advance')
            seen.update(marks)
            all_rows.extend(page)
            offset += len(page)
            if len(all_rows) > 12000 or total_pages > 24:
                raise ValueError('Guide response exceeds safe page limit')
            if offset >= count:
                break
    return parse_programs({'rows': all_rows}, channels)

def _xml_time(value):
    match = re.fullmatch('(\\d{14})\\s+([+-])(\\d{2})(\\d{2})', str(value or '').strip())
    if not match:
        raise ValueError('Invalid XMLTV timestamp')
    date, sign, hours, minutes = match.groups()
    hours, minutes = (int(hours), int(minutes))
    if hours > 23 or minutes > 59:
        raise ValueError('Invalid XMLTV timezone')
    stamp = calendar.timegm(datetime.datetime.strptime(date, '%Y%m%d%H%M%S').timetuple())
    return stamp - (1 if sign == '+' else -1) * (hours * 3600 + minutes * 60)

def parse_xml_programs(data, catalog, start, stop):
    if len(data) > XML_LIMIT:
        raise ValueError('XMLTV guide too large')
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
        raise ValueError('XMLTV declarations are not supported')
    normalize = lambda name: re.sub('[^A-Z0-9]', '', str(name).upper())
    by_name = {normalize(row['name']): row['key'] for row in catalog if row.get('key')}
    channels = {str(row['id']).upper(): row['key'] for row in catalog if row.get('key')}
    rows = {}
    count = 0
    root = None
    for event, node in ET.iterparse(io.BytesIO(data), events=('start', 'end')):
        if root is None:
            root = node
            if root.tag != 'tv':
                raise ValueError('Not an XMLTV guide')
        if event != 'end':
            continue
        if node.tag == 'channel':
            key = next((by_name.get(normalize(n.text)) for n in node.findall('display-name') if by_name.get(normalize(n.text))), None)
            if key:
                channels[str(node.get('id') or '').upper()] = key
            compat_clear(node)
            root.remove(node)
        elif node.tag == 'programme':
            count += 1
            if count > 16000:
                raise ValueError('XMLTV program limit exceeded')
            key = channels.get(str(node.get('channel') or '').upper())
            if key:
                try:
                    begin, end = (_xml_time(node.get('start')), _xml_time(node.get('stop')))
                    names = node.findall('title')
                    title = next((n.text for n in names if n.get('lang') == 'ar' and n.text), None)
                    title = _title(title or next((n.text for n in names if n.text), ''))
                    if title and end > begin and (end > start) and (begin < stop):
                        rows.setdefault(key, []).append({'start': begin, 'stop': end, 'title': title, 'live': node.find('live') is not None})
                except (ValueError, TypeError, OverflowError):
                    pass
            compat_clear(node)
            root.remove(node)
    for key, programs in rows.items():
        unique = {(p['start'], p['stop'], p['title']): p for p in programs}
        rows[key] = sorted(unique.values(), key=lambda p: p['start'])
    return rows

def _xml_request(url):
    request = Request(url, headers={'User-Agent': 'Alkuds-Guide/1.0', 'Accept': 'application/xml,text/xml'})
    context = ssl.create_default_context()
    try:
        import certifi
        context.load_verify_locations(cafile=certifi.where())
    except (ImportError, OSError, ssl.SSLError):
        pass
    with urlopen(request, timeout=15, context=context) as response:
        data = response.read(XML_LIMIT + 1)
    if len(data) > XML_LIMIT:
        raise ValueError('XMLTV guide too large')
    return data

def fetch_guide(catalog, channels, start, stop):
    global _primary_retry_at
    failure = None
    if time.monotonic() >= _primary_retry_at:
        try:
            rows = fetch_programs(channels, start, stop)
            if not rows:
                raise ValueError('Empty primary guide')
            return (rows, SOURCE)
        except Exception as error:
            failure = error
            if getattr(error, 'code', None) in (403, 429):
                _primary_retry_at = time.monotonic() + 6 * 3600
    today, tomorrow = day_bounds(0)
    for url in XML_SOURCES:
        try:
            rows = parse_xml_programs(_xml_request(url), catalog, start, stop)
            if not any((p['stop'] > today and p['start'] < tomorrow for programs in rows.values() for p in programs)):
                raise ValueError('XMLTV has no current day programs')
            return (rows, url)
        except Exception as error:
            if failure is None:
                failure = error
    raise failure if failure is not None else ValueError('Guide sources unavailable')

def error_caption():
    with _lock:
        error = _state['error']
    return u'تعذر جلب جدول beIN (%s) — اضغط MENU للمحاولة' % error if error else ''

def _load_cache():
    with _lock:
        if _state['loaded']:
            return
        _state['loaded'] = True
    try:
        with open(CACHE_FILE, encoding='utf8') as stream:
            saved = json.load(stream)
        if saved.get('schema') != 1 or not isinstance(saved.get('rows'), dict):
            return
        with _lock:
            _state['rows'] = saved['rows']
            _state['window'] = saved.get('window')
            _state['next_fetch'] = min(time.time() + 1800, float(saved.get('updated', 0)) + 1800)
            _state['revision'] += 1
    except (OSError, ValueError, TypeError):
        pass

def _fetch_worker():
    try:
        with open(CHANNEL_FILE, encoding='utf8') as stream:
            catalog = json.load(stream)
        channels = {str(row['id']).upper(): row['key'] for row in catalog if row.get('key')}
        start, _ = day_bounds(-1)
        _, stop = day_bounds(1)
        rows, source = fetch_guide(catalog, channels, start, stop)
        if not rows:
            raise ValueError('Guide has no programs in requested window')
        updated = time.time()
        saved = {'schema': 1, 'updated': updated, 'window': [start, stop], 'source': source, 'rows': rows}
        try:
            temporary = CACHE_FILE + '.tmp'
            with open(temporary, 'w', encoding='utf8') as stream:
                json.dump(saved, stream, ensure_ascii=False, separators=(',', ':'))
            os.replace(temporary, CACHE_FILE)
        except OSError:
            pass
        with _lock:
            _state.update(rows=rows, window=[start, stop], next_fetch=updated + 1800, error='')
            _state['revision'] += 1
    except Exception as error:
        with _lock:
            code = getattr(error, 'code', None)
            reason = getattr(error, 'reason', None)
            _state['error'] = 'HTTP ' + str(code) if code is not None else 'TLS' if isinstance(error, ssl.SSLError) or isinstance(reason, ssl.SSLError) else type(error).__name__
            _state['next_fetch'] = time.time() + 300
            _state['revision'] += 1
    finally:
        with _lock:
            _state['busy'] = False

def ensure_async(force=False):
    global _primary_retry_at
    _load_cache()
    with _lock:
        if _state['busy'] or (not force and time.time() < _state['next_fetch']):
            return
        if force:
            _primary_retry_at = 0
        _state['busy'] = True
    worker = threading.Thread(target=_fetch_worker)
    worker.daemon = True
    worker.start()

def revision():
    with _lock:
        return _state['revision']

def loading():
    with _lock:
        return _state['busy']

def programs(key, day_offset=0):
    ensure_async()
    start, stop = day_bounds(day_offset)
    with _lock:
        rows = list(_state['rows'].get(key, []))
    return [row for row in rows if row['stop'] > start and row['start'] < stop]

def caption(row):
    return time.strftime('%H:%M', time.localtime(row['start'])) + '-' + time.strftime('%H:%M', time.localtime(row['stop'])) + ' | ' + ('LIVE | ' if row.get('live') else '') + row['title']

def current_program(key):
    ensure_async()
    now = time.time()
    with _lock:
        row = next((p for p in _state['rows'].get(key, []) if p['start'] <= now < p['stop']), None)
        return dict(row) if row else None

def current_caption(key):
    ensure_async()
    now = time.time()
    with _lock:
        rows = list(_state['rows'].get(key, []))
    return next((caption(row) for row in rows if row['start'] <= now < row['stop']), '')

def open_schedule(session, name, item=None, source=''):
    from .audioepg import logical_key
    key = logical_key(name, item, source)
    from .sportschedulescreen import AudioSchedule
    session.open(AudioSchedule, name, key)
