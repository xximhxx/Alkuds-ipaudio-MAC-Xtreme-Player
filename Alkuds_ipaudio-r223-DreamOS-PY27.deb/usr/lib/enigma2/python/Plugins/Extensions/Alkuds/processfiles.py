# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from collections import OrderedDict
from .py2compat import json
import copy
from .py2compat import os
from .py2compat import re
try:
    from .py2compat import urllib
    urlparse = urllib.parse.urlparse
    parse_qs = urllib.parse.parse_qs
    urlencode = urllib.parse.urlencode
except ImportError:
    from urlparse import urlparse, parse_qs
    from urllib import urlencode
from .plugin import cfg

def dedupe_playlists(playlists):
    seen = set()
    unique = []
    for p in playlists:
        pi = p.get('playlist_info', {})
        key = (str(pi.get('host', pi.get('domain', ''))).rstrip('/').lower(), str(pi.get('username', '')).strip(), str(pi.get('password', '')).strip())
        if key in seen:
            continue
        seen.add(key)
        unique.append(p)
    return unique
_PROCESS_CACHE = None

def _process_signature():
    from .localimport import STORE
    result = [str(cfg.livetype.value), str(cfg.vodtype.value)]
    for path in (cfg.playlist_file.value, cfg.playlists_json.value, STORE):
        try:
            st = os.stat(path)
            result.append((path, st.st_size, getattr(st, 'st_mtime_ns', st.st_mtime), getattr(st, 'st_ctime_ns', st.st_ctime), st.st_ino))
        except OSError:
            result.append((path, None))
    return tuple(result)

def process_files():
    global _PROCESS_CACHE
    signature = _process_signature()
    if _PROCESS_CACHE is not None and _PROCESS_CACHE[0] == signature:
        return copy.deepcopy(_PROCESS_CACHE[1])
    result = _process_files_uncached()
    signature = _process_signature()
    if sum((row[1] or 0 for row in signature[2:])) <= 2 * 1024 * 1024:
        _PROCESS_CACHE = (signature, copy.deepcopy(result))
    else:
        _PROCESS_CACHE = None
    return result

def _write_changed(path, text):
    try:
        with open(path, 'r') as handle:
            if handle.read() == text:
                return False
    except IOError:
        pass
    with open(path, 'w') as handle:
        handle.write(text)
    return True

def _playlist_endpoint(line):
    """Reject a malformed server address without guessing or changing credentials."""
    try:
        parsed = urlparse(line.split(' #', 1)[0].strip())
        if parsed.scheme not in ('http', 'https'):
            return None
        domain = parsed.hostname
        port = parsed.port
        if not domain or any((char.isspace() for char in domain)):
            return None
        if port is not None and (not 1 <= port <= 65535):
            return None
        domain = domain.lower()
        authority = '[' + domain + ']' if ':' in domain else domain
        host = parsed.scheme + '://' + authority
        if port is not None:
            host += ':' + str(port)
        return (parsed, domain, port, host)
    except (ValueError, TypeError, AttributeError):
        return None

def _process_files_uncached():
    playlist_file = cfg.playlist_file.value
    playlists_json = cfg.playlists_json.value
    try:
        from .localimport import apply_xtream
        apply_xtream(playlist_file)
    except Exception:
        print('[Alkuds] Local account import was not applied')
    if not os.path.isfile(playlist_file):
        with open(playlist_file, 'a'):
            pass
    if not os.path.isfile(playlists_json):
        with open(playlists_json, 'a'):
            pass
    playlists_all = []
    if os.path.isfile(playlists_json):
        with open(playlists_json, 'r') as f:
            try:
                playlists_all = json.load(f)
            except ValueError:
                os.remove(playlists_json)
    with open(playlist_file, 'r', encoding='utf-8-sig') as f:
        lines = [line.strip().lstrip(u'\ufeff').strip() for line in f]
    index = 0
    livetype = cfg.livetype.value
    vodtype = cfg.vodtype.value
    for line in lines:
        port = ''
        username = ''
        password = ''
        media_type = ''
        output = ''
        livehidden = []
        channelshidden = []
        vodhidden = []
        vodstreamshidden = []
        serieshidden = []
        seriestitleshidden = []
        seriesseasonshidden = []
        seriesepisodeshidden = []
        catchuphidden = []
        catchupchannelshidden = []
        showlive = True
        showvod = True
        showseries = True
        showcatchup = True
        livefavourites = []
        vodfavourites = []
        seriesfavourites = []
        liverecents = []
        vodrecents = []
        vodwatched = []
        serieswatched = []
        live_streams = []
        serveroffset = 0
        catchupoffset = 0
        epgoffset = 0
        epgalternative = False
        epgalternativeurl = ''
        customsids = False
        fail_count = 0
        if line.lower().startswith(('http://', 'https://')):
            line = line.strip(' ')
            endpoint = _playlist_endpoint(line)
            if endpoint is None:
                print('[Alkuds] Skipped an invalid playlist server address')
                continue
            parsed_uri, domain, parsed_port, host = endpoint
            protocol = parsed_uri.scheme + '://'
            name = domain
            if line.partition(' #')[-1]:
                name = line.partition(' #')[-1].strip()
            port = parsed_port if parsed_port is not None else ''
            query = parse_qs(parsed_uri.query, keep_blank_values=True)
            if 'username' not in query or 'password' not in query:
                continue
            username = query['username'][0].strip()
            password = query['password'][0].strip()
            if 'type' in query:
                media_type = query['type'][0].strip()
            else:
                media_type = 'm3u_plus'
            if media_type not in ['m3u', 'm3u_plus']:
                media_type = 'm3u_plus'
            if 'output' in query:
                output = query['output'][0].strip()
            else:
                output = 'ts'
            if output not in ['ts', 'm3u8', 'mpegts', 'hls']:
                output = 'ts'
            if output == 'mpegts':
                output = 'ts'
            if output == 'hls':
                output = 'm3u8'
            if 'timeshift' in query:
                try:
                    epgoffset = int(query['timeshift'][0].strip())
                except ValueError:
                    pass
            credentials = urlencode({'username': username, 'password': password})
            player_api = host + '/player_api.php?' + credentials
            xmltv_api = host + '/xmltv.php?' + credentials
            full_url = host + '/get.php?' + credentials + '&type=' + media_type + '&output=' + output
            playlist_exists = False
            for playlist in playlists_all:
                if 'domain' in playlist['playlist_info'] and 'username' in playlist['playlist_info'] and ('password' in playlist['playlist_info']):
                    if str(playlist['playlist_info'].get('host') or '').rstrip('/').lower() == host.lower() and playlist['playlist_info']['username'] == username and (playlist['playlist_info']['password'] == password):
                        playlist_exists = True
                        default_values = {'player_info': {'channelshidden': channelshidden, 'vodstreamshidden': vodstreamshidden, 'seriestitleshidden': seriestitleshidden, 'seriesseasonshidden': seriesseasonshidden, 'seriesepisodeshidden': seriesepisodeshidden, 'catchuphidden': catchuphidden, 'catchupchannelshidden': catchupchannelshidden, 'serveroffset': serveroffset, 'catchupoffset': catchupoffset, 'epgoffset': epgoffset, 'epgalternative': epgalternative, 'epgalternativeurl': epgalternativeurl, 'liverecents': liverecents, 'vodrecents': vodrecents, 'vodwatched': vodwatched, 'serieswatched': serieswatched, 'seriesfavourites': seriesfavourites}, 'data': {'live_streams': live_streams, 'customsids': customsids, 'fail_count': fail_count}}
                        for key, value in default_values.items():
                            for sub_key, sub_value in value.items():
                                if sub_key not in playlist[key]:
                                    playlist[key][sub_key] = sub_value
                        playlist['playlist_info']['name'] = name
                        playlist['playlist_info']['type'] = media_type
                        playlist['playlist_info']['output'] = output
                        playlist['playlist_info']['full_url'] = full_url
                        playlist['playlist_info']['player_api'] = player_api
                        playlist['playlist_info']['index'] = index
                        playlist['data']['data_downloaded'] = False
                        playlist['player_info']['epgoffset'] = epgoffset
                        if playlist['player_info']['epgalternative'] is True:
                            if playlist['player_info']['epgalternativeurl']:
                                playlist['playlist_info']['xmltv_api'] = playlist['player_info']['epgalternativeurl']
                        else:
                            playlist['playlist_info']['xmltv_api'] = xmltv_api
                        index += 1
                        break
            if not playlist_exists:
                playlists_all.append({'playlist_info': {'index': index, 'name': name, 'protocol': protocol, 'domain': domain, 'port': port, 'username': username, 'password': password, 'type': media_type, 'output': output, 'host': host, 'player_api': player_api, 'xmltv_api': xmltv_api, 'full_url': full_url}, 'player_info': OrderedDict([('livetype', livetype), ('vodtype', vodtype), ('livehidden', livehidden), ('channelshidden', channelshidden), ('vodhidden', vodhidden), ('vodstreamshidden', vodstreamshidden), ('serieshidden', serieshidden), ('seriestitleshidden', seriestitleshidden), ('seriesseasonshidden', seriesseasonshidden), ('seriesepisodeshidden', seriesepisodeshidden), ('catchuphidden', catchuphidden), ('catchupchannelshidden', catchupchannelshidden), ('livefavourites', livefavourites), ('vodfavourites', vodfavourites), ('seriesfavourites', seriesfavourites), ('liverecents', liverecents), ('vodrecents', vodrecents), ('vodwatched', vodwatched), ('serieswatched', serieswatched), ('showlive', showlive), ('showvod', showvod), ('showseries', showseries), ('showcatchup', showcatchup), ('serveroffset', serveroffset), ('catchupoffset', catchupoffset), ('epgoffset', epgoffset), ('epgalternative', epgalternative), ('epgalternativeurl', epgalternativeurl)]), 'data': {'live_categories': [], 'vod_categories': [], 'series_categories': [], 'live_streams': [], 'catchup': False, 'customsids': False, 'epg_date': '', 'data_downloaded': False, 'fail_count': 0}})
                index += 1
    identities = set()
    for line in lines:
        if line.lower().startswith(('http://', 'https://')):
            endpoint = _playlist_endpoint(line)
            if endpoint is None:
                continue
            parsed, domain, parsed_port, host = endpoint
            query = parse_qs(parsed.query, keep_blank_values=True)
            identities.add((host.lower(), (query.get('username') or [''])[0].strip(), (query.get('password') or [''])[0].strip()))
    new_list = [playlist for playlist in playlists_all if (str(playlist['playlist_info'].get('host') or '').rstrip('/').lower(), str(playlist['playlist_info'].get('username') or ''), str(playlist['playlist_info'].get('password') or '')) in identities]
    for index, playlist in enumerate(new_list):
        playlist['playlist_info']['index'] = index
    playlists_all = new_list
    playlists_all = dedupe_playlists(playlists_all)
    _write_changed(playlists_json, json.dumps(playlists_all, indent=4))
    return playlists_all
