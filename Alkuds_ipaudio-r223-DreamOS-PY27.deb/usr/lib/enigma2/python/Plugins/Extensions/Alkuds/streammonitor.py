# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Lightweight fullscreen stream InfoBar and persistent IPAUDIO badge."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .py2compat import time
from .xStaticText import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Screens.Screen import Screen
from enigma import eTimer, getDesktop, iServiceInformation
from .streammetrics import AUDIO_BITRATE_PATHS, VIDEO_BITRATE_PATHS, classify_flow, format_rate, network_link_up, quality_label, read_decoder_bitrate_bytes, read_network_rx_bytes, TrafficCounter, traffic_text

def _desktop_size():
    try:
        size = getDesktop(0).size()
        return (int(size.width()), int(size.height()))
    except Exception:
        return (1280, 720)

def _stream_info_skin():
    width, height = _desktop_size()
    scale = max(0.75, float(width) / 1280.0)
    bar_h = int(176 * scale)
    y = max(0, height - bar_h)

    def s(value):
        return int(value * scale)
    return '<screen name="AlkudsStreamInfoBar" position="0,%d" size="%d,%d" backgroundColor="#78201228" flags="wfNoBorder" zPosition="20">\n        <widget name="channel" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#ffffff" transparent="1" noWrap="1" />\n        <widget name="clock" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#ffffff" transparent="1" halign="right" noWrap="1" />\n        <widget name="event" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#dde7f2" transparent="1" noWrap="1" />\n        <widget name="event_time" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#a77fff" transparent="1" halign="right" noWrap="1" />\n        <widget name="quality" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#ffffff" transparent="1" noWrap="1" />\n        <widget name="player" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#c28cff" transparent="1" noWrap="1" />\n        <widget name="video_rate" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#ffffff" transparent="1" noWrap="1" />\n        <widget name="audio_rate" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#ffffff" transparent="1" noWrap="1" />\n        <widget name="total_rate" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#ffffff" transparent="1" noWrap="1" />\n        <widget name="network" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#58d68d" transparent="1" noWrap="1" />\n        <widget name="flow" position="%d,%d" size="%d,%d" borderWidth="%d" borderColor="#ffffff" foregroundColor="#35c46a" backgroundColor="#382744" />\n        <widget name="diagnosis" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#dde7f2" transparent="1" halign="right" noWrap="1" />\n        <widget name="hint" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#b59fc8" transparent="1" halign="center" noWrap="1" />\n    </screen>' % (y, width, bar_h, s(30), s(10), s(820), s(35), s(26), s(1000), s(10), s(240), s(35), s(25), s(30), s(48), s(780), s(30), s(21), s(820), s(48), s(420), s(30), s(20), s(30), s(82), s(260), s(28), s(19), s(300), s(82), s(230), s(28), s(17), s(540), s(82), s(140), s(28), s(17), s(685), s(82), s(140), s(28), s(17), s(830), s(82), s(410), s(28), s(18), s(30), s(118), s(350), s(28), s(20), s(390), s(126), s(480), s(14), max(1, s(1)), s(880), s(118), s(360), s(28), s(18), s(30), s(148), s(1210), s(22), s(16))

def _ipaudio_badge_skin():
    width, _height = _desktop_size()
    scale = max(0.75, float(width) / 1280.0)

    def s(value):
        return int(value * scale)
    badge_w, badge_h = (s(250), s(82))
    x, y = (max(0, width - badge_w - s(18)), s(18))
    return '<screen name="AlkudsIPAudioBadge" position="%d,%d" size="%d,%d" backgroundColor="#ff000000" flags="wfNoBorder" zPosition="30">\n        <widget name="status" position="0,0" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#dedee4" transparent="1" valign="center" halign="right" noWrap="1" />\n        <widget name="indicator" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" />\n        <widget name="channel_picon" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" />\n        <widget name="picon_number" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#ffffff" transparent="1" valign="center" halign="center" />\n    </screen>' % (x, y, badge_w, badge_h, badge_w - s(24), s(28), s(14), badge_w - s(16), s(9), s(10), s(10), s(90), s(34), s(132), s(42), s(226), s(38), s(22), s(34), s(19))

def _timer_connect(timer, callback):
    try:
        return timer.timeout.connect(callback)
    except Exception:
        timer.callback.append(callback)
        return None

def available_player_types():
    values = [(4097, 'IPTV / ServiceMP3')]
    if os.path.isfile('/usr/bin/gstplayer'):
        values.append((5001, 'GStreamer / GstPlayer'))
    if os.path.isfile('/usr/bin/exteplayer3') or os.path.isfile('/usr/bin/exteplayer3.sh'):
        values.append((5002, 'ExtePlayer3'))
    if os.path.isfile('/usr/bin/apt-get'):
        values.append((8193, 'DreamOS GStreamer'))
    return values

def player_label(service_type):
    try:
        service_type = int(service_type)
    except Exception:
        service_type = 4097
    names = dict(available_player_types())
    return '%s (%d)' % (names.get(service_type, 'Player'), service_type)

def _safe_service_info(info, key_name):
    if not info:
        return 0
    key = getattr(iServiceInformation, key_name, None)
    if key is None:
        return 0
    try:
        value = int(info.getInfo(key))
        return value if value > 0 else 0
    except Exception:
        return 0

def _format_duration(seconds):
    try:
        seconds = max(0, int(seconds or 0))
    except Exception:
        seconds = 0
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return '%d:%02d:%02d' % (hours, minutes, secs)
    return '%02d:%02d' % (minutes, secs)

class AlkudsStreamInfoBar(Screen):
    skin = _stream_info_skin()

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.channel_name = ''
        self.service_type = 4097
        self._visible = False
        self._traffic = TrafficCounter()
        self._traffic_key = None
        self._last_rx = read_network_rx_bytes()
        self._last_rx_time = time.time()
        self._flow_history = []
        self._metric_timer = eTimer()
        self._metric_timer_conn = _timer_connect(self._metric_timer, self._update)
        self._hide_timer = eTimer()
        self._hide_timer_conn = _timer_connect(self._hide_timer, self.hide)
        for name in ('channel', 'clock', 'event', 'event_time', 'quality', 'player', 'video_rate', 'audio_rate', 'total_rate', 'network', 'diagnosis', 'hint'):
            self[name] = Label('')
        self['flow'] = ProgressBar()
        self['hint'].setText('MENU: player | OK/INFO: OSD | CH+/CH-: zap | Used: receiver network since channel opened')
        self.onShow.append(self._shown)
        self.onHide.append(self._hidden)
        self.onClose.append(self.stop)

    def set_context(self, channel_name, service_type, stream_key=None):
        self.channel_name = str(channel_name or 'Channel')
        try:
            self.service_type = int(service_type)
        except Exception:
            self.service_type = 4097
        self['channel'].setText(self.channel_name)
        self['player'].setText('Player: ' + player_label(self.service_type))
        key = stream_key if stream_key is not None else self.channel_name
        if key != self._traffic_key:
            self._traffic_key = key
            self._traffic.reset()
        self._last_rx = read_network_rx_bytes()
        self._last_rx_time = time.time()
        self._flow_history = []
        self._update()

    def show_for(self, milliseconds=0):
        self.show()
        try:
            self._hide_timer.stop()
        except Exception:
            pass

    def toggle(self):
        if self._visible:
            self.hide()
        else:
            self.show_for()

    def _shown(self):
        self._visible = True
        self._update()
        try:
            self._metric_timer.start(1000, False)
        except Exception:
            pass

    def _hidden(self):
        self._visible = False
        try:
            self._metric_timer.stop()
            self._hide_timer.stop()
        except Exception:
            pass

    def stop(self):
        for timer in (self._metric_timer, self._hide_timer):
            try:
                timer.stop()
            except Exception:
                pass

    def _event_details(self, info):
        try:
            event = info.getEvent(0) if info else None
        except Exception:
            event = None
        if not event:
            return self._guide_event_details()
        try:
            name = str(event.getEventName() or '--')
        except Exception:
            name = '--'
        try:
            begin = int(event.getBeginTime())
            duration = int(event.getDuration())
            now = int(time.time())
            if not name or name == '--' or (not begin <= now < begin + duration):
                return self._guide_event_details()
            elapsed = max(0, min(duration, now - begin))
            remaining = max(0, duration - elapsed)
            timing = 'Elapsed %s  |  Remaining %s' % (_format_duration(elapsed), _format_duration(remaining))
        except Exception:
            timing = ''
        return ('Event: ' + name, timing)

    def _guide_event_details(self):
        try:
            from .audioepg import iptv_event_details
            return iptv_event_details(self.channel_name)
        except Exception:
            return ('Event: --', '')

    def _set_network_colour(self, colour):
        values = {'red': 15158332, 'orange': 15965202, 'yellow': 16044095, 'green': 3523690}
        try:
            from enigma import gRGB
            rgb = gRGB(values.get(colour, values['green']))
            if self['network'].instance:
                self['network'].instance.setForegroundColor(rgb)
            if self['flow'].instance:
                self['flow'].instance.setForegroundColor(rgb)
        except Exception:
            pass

    def _update(self):
        if not self._visible:
            return
        traffic_rate, traffic_total = self._traffic.sample()
        now = time.time()
        current_rx = read_network_rx_bytes()
        elapsed = max(0.2, now - self._last_rx_time)
        rx_rate = max(0, int((current_rx - self._last_rx) / elapsed)) if current_rx >= self._last_rx else 0
        self._last_rx, self._last_rx_time = (current_rx, now)
        self._flow_history.append(rx_rate)
        self._flow_history = self._flow_history[-8:]
        service = None
        info = None
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
        except Exception:
            pass
        width = _safe_service_info(info, 'sVideoWidth')
        height = _safe_service_info(info, 'sVideoHeight')
        framerate = _safe_service_info(info, 'sFrameRate')
        if framerate > 1000:
            framerate = int((framerate + 500) / 1000)
        quality = quality_label(width, height)
        resolution = '%dx%d' % (width, height) if width and height else 'resolving...'
        fps = ' @ %dfps' % framerate if framerate else ''
        self['quality'].setText('Video: %s  %s%s' % (quality, resolution, fps))
        self['player'].setText('Player: ' + player_label(self.service_type))
        video_rate = read_decoder_bitrate_bytes(VIDEO_BITRATE_PATHS)
        audio_rate = read_decoder_bitrate_bytes(AUDIO_BITRATE_PATHS)
        self['video_rate'].setText('V: %s' % (format_rate(video_rate) if video_rate else 'N/A'))
        self['audio_rate'].setText('A: %s' % (format_rate(audio_rate) if audio_rate else 'N/A'))
        self['total_rate'].setText(traffic_text(traffic_rate, traffic_total))
        event, event_time = self._event_details(info)
        self['event'].setText(event)
        self['event_time'].setText(event_time)
        self['clock'].setText(time.strftime('%H:%M:%S'))
        label, percent, colour, diagnosis = classify_flow(rx_rate, height, self._flow_history, network_link_up())
        self['network'].setText('Internet/stream: ' + label)
        self['flow'].setValue(int(percent))
        self['diagnosis'].setText(diagnosis)
        self._set_network_colour(colour)

class AlkudsIPAudioBadge(Screen):
    skin = _ipaudio_badge_skin()

    def __init__(self, session):
        Screen.__init__(self, session)
        self['status'] = Label('')
        self['indicator'] = Pixmap()
        self['channel_picon'] = Pixmap()
        self['picon_number'] = Label('')
        self._badge_name = ''
        self._badge_state_text = ''
        self._badge_logo_available = False
        self._timer = eTimer()
        self._timer_conn = _timer_connect(self._timer, self._update)
        self.onShow.append(self._shown)
        self.onClose.append(self.stop)

    def _shown(self):
        self._update()
        try:
            self._timer.start(1000, False)
        except Exception:
            pass

    def stop(self):
        try:
            self._timer.stop()
        except Exception:
            pass

    def _set_colour(self, value):
        try:
            filename = {3523690: 'ipaudio-dot-green.png', 15158332: 'ipaudio-dot-red.png', 15965202: 'ipaudio-dot-amber.png', 16044095: 'ipaudio-dot-amber.png'}[value]
            if self['indicator'].instance:
                self['indicator'].instance.setPixmapFromFile(os.path.join(os.path.dirname(__file__), 'icons', filename))
        except Exception:
            pass

    def apply_visibility(self, values=None):
        if values is None:
            from .playbacksettings import load_audio_visibility
            values = load_audio_visibility()
        name = self._badge_name if values.get('show_name', True) else ''
        detail = self._badge_state_text
        text = name + (u' | ' + detail if name and detail else '') if name else detail
        self['status'].setText(text)
        if values.get('show_icon', True):
            if self._badge_logo_available:
                self['channel_picon'].show()
            self['picon_number'].show()
        else:
            self['channel_picon'].hide()
            self['picon_number'].hide()

    def _update(self):
        try:
            from .backgroundaudio import background_audio_diagnostics
            data = background_audio_diagnostics()
        except Exception:
            data = {'state': 'starting', 'name': ''}
        state = str(data.get('state') or 'stopped')
        name = str(data.get('name') or '')
        short_name = name if len(name) <= 28 else name[:27] + u'…'
        if state == 'running':
            text, colour = ('', 3523690)
        elif state == 'failed':
            text, colour = (u'تعذر التشغيل', 15158332)
        elif state == 'restarting':
            text, colour = (u'إعادة الاتصال', 15965202)
        elif state == 'starting':
            text, colour = (u'جاري الاتصال', 16044095)
        else:
            self.hide()
            return
        self._badge_name = short_name
        self._badge_state_text = text
        self._set_colour(colour)
        try:
            from .backgroundaudio import get_resume_context
            from .audioepg import set_channel_logo, picon_path
            source = get_resume_context().get('source', '')
            self._badge_logo_available = bool(picon_path(name, source))
            set_channel_logo(self, name, source)
        except Exception:
            pass
        self.apply_visibility()
_IPAUDIO_DIALOG = None

def refresh_ipaudio_visibility(values=None):
    if _IPAUDIO_DIALOG is not None:
        _IPAUDIO_DIALOG.apply_visibility(values)

def create_stream_info_dialog(session):
    try:
        dialog = session.instantiateDialog(AlkudsStreamInfoBar)
        dialog.hide()
        return dialog
    except Exception as error:
        print('[Alkuds] stream InfoBar unavailable: %s' % error)
        return None

def destroy_stream_info_dialog(session, dialog):
    if not dialog:
        return
    try:
        dialog.stop()
    except Exception:
        pass
    try:
        session.deleteDialog(dialog)
    except Exception:
        try:
            dialog.hide()
        except Exception:
            pass

def show_ipaudio_status(session):
    global _IPAUDIO_DIALOG
    if session is None:
        return None
    if _IPAUDIO_DIALOG is None:
        try:
            _IPAUDIO_DIALOG = session.instantiateDialog(AlkudsIPAudioBadge)
        except Exception as error:
            print('[Alkuds] IPAUDIO badge unavailable: %s' % error)
            _IPAUDIO_DIALOG = None
            return None
    try:
        _IPAUDIO_DIALOG.show()
    except Exception:
        pass
    return _IPAUDIO_DIALOG

def hide_ipaudio_status(session=None):
    global _IPAUDIO_DIALOG
    dialog = _IPAUDIO_DIALOG
    _IPAUDIO_DIALOG = None
    if dialog is None:
        return
    try:
        dialog.stop()
    except Exception:
        pass
    try:
        if session is not None:
            session.deleteDialog(dialog)
        else:
            dialog.hide()
    except Exception:
        try:
            dialog.hide()
        except Exception:
            pass
