# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
# --- r223 py27 fix: make the plugin self-sufficient when the image lacks python-requests / python-six ---
import sys as _sys, os as _os
def _alkuds_vendor_fallback():
    libs = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '_vendor', 'py2libs')
    try:
        import six  # noqa
        from requests.adapters import HTTPAdapter, Retry  # noqa
        import requests  # noqa
        return
    except Exception:
        pass
    if not _os.path.isdir(libs):
        return
    for name in list(_sys.modules):
        if name.split('.')[0] in ('requests', 'urllib3', 'chardet', 'idna', 'certifi', 'six'):
            del _sys.modules[name]
    if libs in _sys.path:
        _sys.path.remove(libs)
    _sys.path.insert(0, libs)
_alkuds_vendor_fallback()
del _alkuds_vendor_fallback
# --- end r223 py27 fix ---
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
from .py2compat import os
PluginLanguageDomain = 'Alkuds'
PluginLanguagePath = 'Extensions/Alkuds/locale'
isDreamOS = os.path.exists('/var/lib/dpkg/status')

def localeInit():
    if isDreamOS:
        lang = language.getLanguage()[:2]
        os.environ['LANGUAGE'] = lang
    gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))
if isDreamOS:

    def _(txt):
        return gettext.dgettext(PluginLanguageDomain, txt) if txt else ''
else:

    def _(txt):
        if gettext.dgettext(PluginLanguageDomain, txt):
            return gettext.dgettext(PluginLanguageDomain, txt)
        else:
            print('[%s] fallback to default translation for %s' % (PluginLanguageDomain, txt))
            return gettext.gettext(txt)
localeInit()
language.addCallback(localeInit)
