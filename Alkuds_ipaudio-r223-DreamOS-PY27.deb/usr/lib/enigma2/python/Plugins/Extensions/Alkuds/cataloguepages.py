# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Receiver pages contain unique titles, independently of source pagination."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import threading
from .py2compat import time
from .py2compat import re

class CataloguePages(object):

    def __init__(self, size=24, cancelled=None):
        self.size = size
        self.cancelled = cancelled or (lambda: False)
        self.pages = []
        self.pending = []
        self.seen = set()
        self.cursor = 1
        self.source_last = 1
        self.exhausted = False
        self.source_size = None

    def _key(self, item):
        if item.get('is_series'):
            return ('series', re.sub('\\s+', ' ', item.get('name', '')).strip().lower())
        return ('item', str(item.get('url') or item.get('id') or item.get('name')))

    def _accept(self, result):
        self.source_last = max(self.cursor, int(result.get('last_page') or self.cursor))
        if result.get('entries'):
            self.source_size = len(result['entries'])
        for item in result.get('entries') or []:
            key = self._key(item)
            if key not in self.seen:
                self.seen.add(key)
                self.pending.append(item)
        self.cursor += 1
        self.exhausted = self.cursor > self.source_last

    def get(self, page, fetch):
        page = max(1, int(page))
        while len(self.pages) < page:
            started = time.time()
            reads = 0
            while len(self.pending) < self.size and (not self.exhausted):
                if self.cancelled():
                    raise RuntimeError('Catalogue closed')
                needed = self.size - len(self.pending)
                count = min(2, (needed + self.source_size - 1) // self.source_size if self.source_size else 1, self.source_last - self.cursor + 1)
                numbers = list(range(self.cursor, self.cursor + count))
                results = {}

                def worker(number):
                    try:
                        results[number] = (fetch(number), None)
                    except Exception as error:
                        results[number] = (None, error)
                workers = [threading.Thread(target=worker, args=(n,)) for n in numbers]
                for task in workers:
                    task.daemon = True
                    task.start()
                for task in workers:
                    task.join()
                for number in numbers:
                    result, error = results[number]
                    if error:
                        raise error
                    self._accept(result)
                    reads += 1
                if reads >= 60 or time.time() - started >= 35:
                    break
            if self.pending:
                self.pages.append(self.pending[:self.size])
                del self.pending[:self.size]
            elif self.exhausted:
                break
            else:
                raise RuntimeError('No new titles in this batch. Press blue to continue loading.')
        actual = min(page, max(1, len(self.pages)))
        entries = self.pages[actual - 1] if self.pages else []
        complete = self.exhausted and (not self.pending)
        return {'entries': list(entries), 'page': actual, 'last_page': len(self.pages) if complete else max(page + 1, len(self.pages)), 'total': len(entries), 'pages_complete': complete}
