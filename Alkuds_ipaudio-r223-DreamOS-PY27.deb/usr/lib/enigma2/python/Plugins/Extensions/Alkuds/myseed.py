# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""MySeed's live category archives, seasons, episodes and advertised players."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .py2compat import requests
from . import arabseed as a
from . import sitecatalogue as c
BASE = 'https://m.myseed.tv/'
HOSTS = ('m.myseed.pics', 'myseed.pics', 'm.myseed.tv', 'myseed.tv')
SECTION_MAP = {'browse': (u'تصفح الموقع', 'recently/'), 'recently': (u'المضاف حديثاً', 'recently/'), 'trend': (u'تريند', 'trend/'), 'movies': (u'الأفلام', 'movies/'), 'series': (u'المسلسلات', 'series/')}

def _local(value):
    return c.local(BASE, HOSTS, value)

def _get(session, value):
    html, final, mime = c.get(session, _local(value), BASE)
    _local(final)
    return (html, final)

def groups():
    return [{'name': u'البحث في كل الأقسام', 'section': 'browse', 'action': 'search'}, {'name': u'تصفح الموقع — كل المحتوى', 'section': 'browse', 'node': 'sections'}, {'name': u'المضاف حديثاً', 'section': 'recently', 'node': 'sections'}, {'name': u'تريند', 'section': 'trend', 'node': 'sections'}, {'name': u'الأفلام', 'section': 'movies', 'node': 'sections'}, {'name': u'المسلسلات', 'section': 'series', 'node': 'sections'}, {'name': u'بقية أقسام الموقع', 'section': 'other', 'node': 'sections'}]

def categories(section):
    with requests.Session() as session:
        html, page = _get(session, 'series/' if section == 'series' else 'movies/')
    root = a.Document(html).root
    links = [x for n in root.find('h2') for x in n.find('a') if '/category/' in x.attrs.get('href', '')]
    links += [n for n in root.find('a') if '/category/' in n.attrs.get('href', '')]
    result, seen = ([], set())
    for node in links:
        label = node.text()
        url = _local(node.attrs['href'])
        key = c.unquote(c.urlparse(url).path).rstrip('/')
        movie = label.startswith(u'أفلام') or label.startswith(u'افلام')
        series = label.startswith(u'مسلسلات') or label.startswith(u'رمضان')
        if not label or key in seen:
            continue
        if section == 'movies' and (not movie):
            continue
        if section == 'series' and (not series):
            continue
        if section == 'other' and (movie or (series and (not label.startswith(u'رمضان')))):
            continue
        seen.add(key)
        result.append({'name': label, 'section': 'category:' + key + '/', 'node': 'sections'})
    return result

def sections(section, parent):
    if section in ('movies', 'series', 'other'):
        return [{'name': u'البحث في هذا القسم', 'action': 'search'}] + categories(section)
    return [{'name': u'البحث في هذا القسم', 'action': 'search'}, {'name': u'عرض جميع الصفحات بترتيب الموقع', 'node': 'items'}, {'name': u'ترتيب عناوين الصفحة أ–ي', 'node': 'items', 'order': 'az'}, {'name': u'ترتيب عناوين الصفحة ي–أ', 'node': 'items', 'order': 'za'}]

def _rows(root, page, section, grouped=True):
    blocks = root.find('a', 'movie__block')
    for box in root.find(css='series__box'):
        blocks.extend(box.find('a')[:1])
    result, seen = ([], set())
    for node in blocks:
        href = node.attrs.get('href')
        if not href:
            continue
        url = _local(href)
        if url in seen:
            continue
        title = node.attrs.get('title') or c.text(node, 'post__title')
        if not title:
            headings = node.find('h3') + node.find('h2')
            title = headings[0].text() if headings else node.text()
        if not title:
            continue
        seen.add(url)
        is_series = title.startswith(u'مسلسل') or '/selary/' in url
        name = c.series_name(title) if grouped and is_series else title
        if grouped and is_series and (u'مدبلج' in title) and (u'مدبلج' not in name):
            name += u' — مدبلج'
        row = {'id': url, 'url': url, 'name': name, 'title': title, 'section': section, 'is_series': bool(grouped and is_series), 'series_key': name.lower(), 'image': c.image(node, page), 'category': c.text(node, 'post__category'), 'quality': '' if grouped and is_series else c.text(node, '__quality'), 'description': c.text(node, 'post__info')}
        result.append(row)
    return result

def fetch_items(section, page=1, query='', order='latest', options=None):
    page = max(1, int(page))
    if query:
        scope = 'series' if section == 'series' or (section.startswith('category:') and 'series' in section) else 'movies' if section == 'movies' or (section.startswith('category:') and 'movies' in section) else ''
        url = c.page_url(BASE + 'find/', page, True) + '?' + c.urlencode({'word': query.encode('utf8'), 'type': scope})
    else:
        path = section[len('category:'):] if section.startswith('category:') else SECTION_MAP[section][1]
        url = c.page_url(_local(path), page, True)
    with requests.Session() as session:
        html, final = _get(session, url)
    root = a.Document(html).root
    rows = _rows(root, final, section)
    if query and section in ('movies', 'series'):
        rows = [x for x in rows if x['is_series'] == (section == 'series')]
    if order in ('az', 'za'):
        rows.sort(key=lambda x: x['name'].lower(), reverse=order == 'za')
    return {'entries': rows, 'page': page, 'last_page': c.last_page(root, page), 'total': len(rows)}

def seasons(item):
    with requests.Session() as session:
        html, final = _get(session, item['url'])
    root = a.Document(html).root
    lists = [n for n in root.find() if n.attrs.get('id') == 'seasons__list']
    result, seen = ([], set())
    for node in lists[0].find('li') if lists else []:
        value = node.attrs.get('data-url')
        if not value:
            continue
        url = _local(value)
        if url in seen:
            continue
        seen.add(url)
        row = dict(item)
        row.update(name=node.text(), season=True, season_url=url, series_title=item['name'], is_series=False)
        result.append(row)
    if not result:
        row = dict(item)
        row.update(name=u'حلقات المسلسل', season=True, season_url=final, series_title=item['name'], is_series=False)
        result.append(row)
    return result

def episodes(item, page=1):
    url = c.page_url(_local(item['season_url']), page, True)
    with requests.Session() as session:
        html, final = _get(session, url)
    root = a.Document(html).root
    containers = root.find(css='episodes__list')
    rows, seen = ([], set())
    for container in containers:
        for link in container.find('a'):
            value = link.attrs.get('href', '')
            if not value:
                continue
            label = link.text()
            number = re.search(u'(?:الحلقة|حلقة)\\s*(\\d+)', label)
            if not number:
                continue
            target = _local(value)
            if target in seen:
                continue
            seen.add(target)
            row = dict(item)
            row.update(name=u'الحلقة %d' % int(number.group(1)), episode=int(number.group(1)), title=item['series_title'] + u' — ' + label, url=target, is_series=False, season=False, episode_query=False)
            rows.append(row)
    if not rows and page == 1:
        raise RuntimeError(u'لم يعرض الموقع حلقات هذا الموسم حالياً.')
    rows.sort(key=lambda x: x['episode'])
    return {'entries': rows, 'page': int(page), 'last_page': c.last_page(root, page), 'total': len(rows)}

def _ajax(session, endpoint, html, page, values):
    token = re.search('[\'\\"]csrf__token[\'\\"]\\s*:\\s*[\'\\"]([^\'\\"]+)', html)
    post = re.search('[\'\\"]psot_id[\'\\"]\\s*:\\s*[\'\\"](\\d+)', html)
    if not token or not post:
        raise RuntimeError(u'لم يعرض الموقع بيانات طلب المشغل.')
    data = dict(values, post_id=post.group(1), csrf_token=token.group(1))
    response = session.post(_local(endpoint + '/'), data=data, headers=dict(c.headers(page), **{'X-Requested-With': 'XMLHttpRequest'}), timeout=(5, 15))
    try:
        response.raise_for_status()
        if len(response.content) > 1024 * 1024:
            raise RuntimeError('Player response too large')
        result = response.json()
        if result.get('type') != 'success':
            raise RuntimeError(u'الموقع لم يرجع المشغل المختار. أعد المحاولة.')
        return result
    finally:
        response.close()

def servers(item):
    with requests.Session() as session:
        html, final = _get(session, item['url'])
        root = a.Document(html).root
        watch = next((n.attrs['href'] for n in root.find('a', 'watch__btn') if n.attrs.get('href')), '')
        if watch:
            html, final = _get(session, watch)
            root = a.Document(html).root
        qualities = [n.attrs['data-quality'] for n in root.find('li') if n.attrs.get('data-quality')]
        selected = item.get('selected_quality')
        if not selected and len(set(qualities)) > 1:
            rows = []
            for quality in dict.fromkeys(qualities):
                row = dict(item)
                row.update(name=quality + ('p' if quality.isdigit() else ''), title=item.get('title') or item['name'], url=final, selected_quality=quality, node='servers')
                rows.append(row)
            return rows
        active = next((n.attrs.get('data-qu') for n in root.find('li') if n.attrs.get('data-link')), '')
        if selected and selected != active:
            value = _ajax(session, 'get__quality__servers', html, final, {'quality': selected})
            root = a.Document(value.get('html') or '').root
        result, values = ([], [])
        for node in root.find('li'):
            value, index = (node.attrs.get('data-link', ''), node.attrs.get('data-server'))
            if index is not None:
                quality = node.attrs.get('data-qu', '')
                row = dict(item)
                row.pop('node', None)
                row.pop('action', None)
                row.update(name=(node.attrs.get('data-server-name') or node.text()) + (u' | ' + quality + 'p' if quality.isdigit() else ''), title=item.get('title') or item['name'], server_index=index, quality_code=quality, server_url=c.urljoin(final, value) if value else '', referer=final, watch_url=final)
                result.append(row)
        if result:
            return result
        if not result:
            for frame in root.find('iframe'):
                if frame.attrs.get('id') == 'video_frame' and frame.attrs.get('src'):
                    values.append((u'المشغل الرئيسي', frame.attrs['src'], ''))
    return c.server_rows(values, item, final)

def resolve(item):
    from .freeproviders import hls_variant_streams
    item = dict(item)
    with requests.Session() as session:
        if item.get('server_index') is not None:
            html, final = _get(session, item['watch_url'])
            root = a.Document(html).root
            active = next((n.attrs.get('data-qu') for n in root.find('li') if n.attrs.get('data-link')), '')
            quality = item.get('quality_code', '')
            if quality and quality != active:
                value = _ajax(session, 'get__quality__servers', html, final, {'quality': quality})
                root = a.Document(value.get('html') or '').root
            selected = next((n for n in root.find('li') if n.attrs.get('data-server') == str(item['server_index']) and (not quality or n.attrs.get('data-qu') == quality)), None)
            link = selected.attrs.get('data-link') if selected is not None else ''
            if not link:
                value = _ajax(session, 'get__watch__server', html, final, {'server': item['server_index'], 'quality': quality})
                link = value.get('server')
            if not link:
                raise RuntimeError(u'الموقع لم يرجع رابط المشغل المختار.')
            item.update(server_url=c.urljoin(final, link), referer=final)
        found = c.media_sources(session, item['server_url'], item['referer'])
        for stream in found:
            request = requests.Request('GET', stream['url']).prepare()
            cookie = requests.cookies.get_cookie_header(session.cookies, request)
            if cookie:
                stream.setdefault('headers', {})['Cookie'] = cookie
    streams = []
    for stream in found:
        stream['relay'] = True
        if item.get('quality_code') and stream.get('quality') in (None, '', 'Original'):
            stream['quality'] = item['quality_code'] + 'p'
        streams.extend(hls_variant_streams(stream) if stream.get('mediatype') == 'hls' else [stream])
    if not streams:
        raise RuntimeError(u'هذا السيرفر لا يعرض رابطاً يدعمه الرسيفر. اختر سيرفراً آخر.')
    item.update(name=item.get('title') or item['name'], streams=streams)
    return item
