# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import sportacity
from .generaltvui import Alkuds_GeneralTV_Browser
from .freechannels import _prepared_stream_urls, _prepared_stream_labels, Alkuds_StreamChooser, selected_free_service_type
from .listpreview import open_list_player

class Alkuds_Sportacity_Browser(Alkuds_GeneralTV_Browser):
    provider = sportacity
    site_name = u'سبورتاسيتي Sportacity - بتوقيت القاهرة'

    def _catalogue_items(self, fetch):
        return fetch(self.page)

    def _poll(self):
        from .arabseedui import Alkuds_ArabSeed_Browser
        Alkuds_ArabSeed_Browser._poll(self)

    def open_current(self):
        preview = getattr(self, '_list_preview', None)
        if preview and preview.second_ok():
            return
        Alkuds_GeneralTV_Browser.open_current(self)

    def _start_resolved(self, item):
        prepared = _prepared_stream_urls(item)
        if len(prepared) == 1:
            from .freeplayer import Alkuds_FreeTV_Player
            open_list_player(self, None, Alkuds_FreeTV_Player, prepared, selected_free_service_type(), item['name'], 'Live', item.get('description', ''), item.get('image', ''), '')
        else:
            self.session.open(Alkuds_StreamChooser, prepared, _prepared_stream_labels(item), item, item['name'], 'Live', item.get('description', ''), item.get('image', ''), '', True)

    def next_or_refresh(self):
        if self._loading or self._closed:
            return
        if self.level == 'items' and self.page < self.last_page:
            self.page += 1
            self._selected_index = -1
        self.load()

    def refresh_scores(self):
        if not self._loading and (not self._closed):
            self._selected_index = self._index()
            self.load()

    def _set_rows(self):
        Alkuds_GeneralTV_Browser._set_rows(self)
        if 0 <= self._selected_index < len(self.entries):
            self['list'].setIndex(self._selected_index)

    def __init__(self, session, section='matches', level='groups', parent=None, page=1):
        Alkuds_GeneralTV_Browser.__init__(self, session, section, level, parent, page)
        self['key_blue'].setText(u'التالي / تحديث')
        from Components.ActionMap import ActionMap
        self['sportacity_refresh'] = ActionMap(['InfobarEPGActions'], {'showEventInfo': self.refresh_scores}, -3)
        if level == 'items':
            from enigma import eTimer
            self._scores_timer = eTimer()
            try:
                self._scores_connection = self._scores_timer.timeout.connect(self.refresh_scores)
            except Exception:
                self._scores_timer.callback.append(self.refresh_scores)
            self.onShown.append(lambda: self._scores_timer.start(60000, False))
            self.onHide.append(self._scores_timer.stop)
            self.onClose.append(self._scores_timer.stop)
