# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Nxsha's public web player API; no browser code execution or DRM processing."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
import hashlib
from .py2compat import json
from .py2compat import os
from .py2compat import re
from .py2compat import threading
from .py2compat import time
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlparse = urllib.parse.urlparse
from .generalaes import AESModeOfOperationCBC
from .matchqualities import qualities
from .subtitledata import normalise
_cache = {}
_lock = threading.RLock()

def key_iv(password, salt):
    value = b''
    previous = b''
    while len(value) < 48:
        previous = hashlib.md5(previous + password.encode('utf8') + salt).digest()
        value += previous
    return (value[:32], value[32:48])

def encode(value, password):
    value = dict(value, _req_ts=int(time.time() * 1000), _req_salt=byte_hex(os.urandom(6)))
    data = json.dumps(value, separators=(',', ':')).encode('utf8')
    pad = 16 - len(data) % 16
    data += bytes([pad]) * pad
    salt = os.urandom(8)
    key, iv = key_iv(password, salt)
    cipher = AESModeOfOperationCBC(key, iv=iv)
    raw = b'Salted__' + salt + b''.join((cipher.encrypt(data[n:n + 16]) for n in range(0, len(data), 16)))
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')

def decode(value, password):
    if not isinstance(value, str) or len(value) > 2 * 1024 * 1024:
        raise ValueError('Invalid Nxsha response')
    raw = base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))
    if not raw.startswith(b'Salted__') or len(raw) < 32 or len(raw) % 16:
        raise ValueError('Invalid Nxsha envelope')
    key, iv = key_iv(password, raw[8:16])
    cipher = AESModeOfOperationCBC(key, iv=iv)
    plain = b''.join((cipher.decrypt(raw[n:n + 16]) for n in range(16, len(raw), 16)))
    pad = plain[-1]
    if not 1 <= pad <= 16 or plain[-pad:] != bytes([pad]) * pad:
        raise ValueError('Invalid Nxsha padding')
    result = json.loads(plain[:-pad].decode('utf8'))
    if not isinstance(result, dict):
        raise ValueError('Invalid Nxsha payload')
    return result

def read(session, url, headers, limit=1024 * 1024):
    remaining = getattr(session, '_alkuds_nxsha_deadline', time.monotonic() + 12) - time.monotonic()
    if remaining <= 0:
        raise RuntimeError('Nxsha preparation timeout')
    with session.get(url, headers=headers, timeout=(min(4, remaining), min(8, remaining)), stream=True) as response:
        response.raise_for_status()
        data = bytearray()
        for chunk in response.iter_content(8192):
            data.extend(chunk)
            if is_media(data):
                break
            if time.monotonic() > getattr(session, '_alkuds_nxsha_deadline', float('inf')):
                raise RuntimeError('Nxsha preparation timeout')
            if len(data) > limit:
                raise ValueError('Nxsha response too large')
        return (bytes(data), response.url)

def configuration(session, embed, headers):
    origin = '{uri.scheme}://{uri.netloc}'.format(uri=urlparse(embed))
    with _lock:
        cached = _cache.get(origin)
    if cached and time.monotonic() - cached[0] < 1800:
        return (origin, cached[1])
    data, final = read(session, embed, headers)
    text = data.decode('utf8', 'replace')
    queue = [urljoin(final, x) for x in re.findall('<script[^>]+src=["\\\']([^"\\\']+)', text, re.I)][::-1]
    seen = set()
    total = 0
    for unused in range(18):
        if not queue:
            break
        url = queue.pop(0)
        if url in seen or urlparse(url).netloc != urlparse(origin).netloc:
            continue
        seen.add(url)
        try:
            data, _ = read(session, url, headers)
        except Exception:
            if time.monotonic() > getattr(session, '_alkuds_nxsha_deadline', float('inf')):
                raise
            continue
        total += len(data)
        if total > 5 * 1024 * 1024:
            break
        script = data.decode('utf8', 'replace')
        if '.AES.decrypt(' in script and '.AES.encrypt(' in script:
            match = re.search('(?:let|var|const)\\s+\\w+=["\\\']([a-fA-F0-9]{64})["\\\']', script)
            if match:
                with _lock:
                    _cache[origin] = (time.monotonic(), match.group(1))
                return (origin, match.group(1))
        paths = re.findall('["\\\'](static/chunks/[^"\\\']+\\.js)["\\\']', script)
        queue[:0] = [urljoin(origin + '/_next/', path) for path in reversed(paths)]
    raise RuntimeError(u'تعذر قراءة إعدادات Nxsha الحالية؛ جرّب التحديث لاحقًا')

def api(session, origin, path, value, password, headers):
    from .py2compat import urllib
    urlencode = urllib.parse.urlencode
    raw, _ = read(session, origin + path + '?' + urlencode({'q': encode(value, password)}), headers)
    return decode(json.loads(raw.decode('utf8'))['_hash'], password)

def is_media(data):
    return len(data) >= 564 and data[0] == data[188] == data[376] == 71 or b'ftyp' in data[:32] or data[4:8] in (b'styp', b'moof')

def quality_labels(text, base, streams):
    """Keep the provider's cropped 1080/720 tier alongside real dimensions."""
    variants = {}
    pending = None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('#EXT-X-STREAM-INF:'):
            pending = line
        elif line and (not line.startswith('#')) and pending:
            resolution = re.search('RESOLUTION=(\\d+)x(\\d+)', pending)
            tier = re.search('(?:^|/)(360|480|720|1080|1440|2160)(?:p)?(?:/|$)', urlparse(line).path, re.I)
            if resolution and tier:
                width, height = map(int, resolution.groups())
                nominal = int(tier.group(1))
                expected = {360: (640,), 480: (854, 856, 858), 720: (1280,), 1080: (1920,), 1440: (2560,), 2160: (3840,)}
                if width in expected[nominal] and 0 < height <= nominal:
                    label = '%dp' % nominal
                    if height != nominal:
                        label += ' (%dx%d)' % (width, height)
                    variants[urljoin(base, line)] = (pending, label)
            pending = None
    for stream in streams:
        entry = variants.get(stream['url'])
        selected = (stream.get('relay_options') or {}).get('hls_variant')
        if not entry and selected:
            entry = next((value for value in variants.values() if value[0] == selected), None)
        if entry:
            stream['quality'] = entry[1]
    return streams

def subtitle_tracks(session, origin, identity, password, headers):
    """The web player loads subtitle metadata separately from /api/sources."""
    payload = api(session, origin, '/api/subtitles', identity, password, headers)
    values = []
    for track in (payload.get('subtitles') or [])[:150]:
        if not isinstance(track, dict):
            continue
        values.append(dict(track, url=track.get('uri') or track.get('url') or track.get('file'), label=u'العربية' if str(track.get('language', '')).lower() in ('ar', 'ara') else track.get('title') or track.get('label') or track.get('language')))
    return normalise(values, origin + '/', headers)

def prepare(session, source, headers, referer):
    url = source.get('url') or ''
    if source.get('isEmbed') or urlparse(url).scheme not in ('https', 'http'):
        return []
    raw, final = read(session, url, headers)
    label = str(source.get('label') or source.get('quality') or 'Auto')
    stream = {'url': final, 'headers': headers, 'relay': True, 'relay_options': {'cinehd': True}, 'quality': label, 'subtitles': normalise(source.get('subtitles') or source.get('tracks') or [], referer, headers)}
    if raw.lstrip().startswith(b'#EXTM3U'):
        master = raw.decode('utf-8-sig', 'replace')
        text = master
        current = final
        for unused in range(4):
            if re.search('#EXT-X-KEY:.*METHOD=(?!NONE)', text):
                raise RuntimeError(u'هذا المصدر يحتاج مشغّل تشفير خاص')
            lines = [line.strip() for line in text.splitlines() if line.strip() and (not line.startswith('#'))]
            if not lines:
                raise ValueError('Empty HLS')
            target = urljoin(current, lines[0])
            if '#EXT-X-STREAM-INF:' in text:
                data, current = read(session, target, headers)
                text = data.decode('utf-8-sig', 'replace')
                continue
            with session.get(target, headers=headers, timeout=(4, 8), stream=True) as response:
                response.raise_for_status()
                sample = response.raw.read(188 * 32, decode_content=True)
            if not is_media(sample):
                raise ValueError('Source returned no video segment')
            result = quality_labels(master, final, qualities(master, dict(stream, mediatype='hls')))
            for row in result:
                row['quality'] = label + ' | ' + str(row.get('quality') or 'Auto')
            return result
        raise ValueError('HLS nesting limit')
    if is_media(raw):
        return [dict(stream, mediatype='mp4')]
    raise ValueError('Nxsha returned HTML instead of video')

def resolve(session, item, user_agent):
    session._alkuds_nxsha_deadline = time.monotonic() + 50
    embed = item['server_url']
    headers = {'User-Agent': user_agent, 'Referer': embed}
    origin, password = configuration(session, embed, headers)
    identity = {'tmdbId': int(item['id']), 'type': item['kind']}
    if item['kind'] == 'tv':
        identity.update(season=int(item['season_number']), episode=int(item['episode']))
    providers = api(session, origin, '/api/servers', identity, password, headers).get('servers') or []
    providers = [row for row in providers if row.get('web_support') is not False and (not row.get('isDisable')) and (row.get('scraper') != 'showbox-online')]
    providers.sort(key=lambda row: not row.get('default', False))
    collected = []
    seen_keys = set()
    tracks = None
    started = time.monotonic()
    for provider in providers[:4]:
        if collected and (time.monotonic() - started > 18 or len(collected) >= 10):
            break
        try:
            payload = api(session, origin, '/api/sources', dict(identity, provider=provider['scraper'], ex_lang=True), password, headers)
            sources = payload.get('sources') or []
            sources.sort(key=lambda row: ('english' not in str(row.get('label', '')).lower(), bool(re.search('hevc|x265', str(row.get('label', '')), re.I))))
            streams = []
            seen = set()
            for source in sources[:8]:
                if source.get('url') in seen:
                    continue
                seen.add(source.get('url'))
                source_headers = dict(headers)
                for key, value in (source.get('headers') or {}).items():
                    if str(key).lower() in ('user-agent', 'referer', 'origin', 'cookie') and (not re.search('[\\r\\n]', str(value))):
                        source_headers[key] = str(value)
                try:
                    streams.extend(prepare(session, source, source_headers, embed))
                except Exception:
                    continue
                if len(streams) >= 6:
                    break
            if streams:
                if tracks is None:
                    try:
                        tracks = subtitle_tracks(session, origin, identity, password, headers)
                    except Exception:
                        tracks = []
                name = str(provider.get('name') or provider.get('title') or provider.get('scraper') or '').strip()
                for stream in streams:
                    key = (stream.get('url'), str(stream.get('relay_options')))
                    if key in seen_keys:
                        continue
                    seen_keys.add(key)
                    existing = list(stream.get('subtitles') or [])
                    seen_urls = {track.get('url') for track in existing}
                    stream['subtitles'] = existing + [track for track in tracks if track['url'] not in seen_urls]
                    if name:
                        stream['quality'] = name + u' · ' + str(stream.get('quality') or 'Auto')
                    collected.append(stream)
        except Exception:
            continue
    if collected:
        return collected
    raise RuntimeError(u'لم يرجع Nxsha مقاطع فيديو قابلة للتشغيل الآن؛ جرّب سيرفرًا آخر')
