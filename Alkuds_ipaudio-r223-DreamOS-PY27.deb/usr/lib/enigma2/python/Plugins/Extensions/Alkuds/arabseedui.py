# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import threading
from . import arabseed
from .freechannels import Alkuds_Egybest_Browser, _list_entry
from .fajershowui import Alkuds_FajerShow_Qualities

class Alkuds_ArabSeed_Browser(Alkuds_Egybest_Browser):
    provider = arabseed
    site_name = u'عرب سيد ArabSeed'

    def __init__(self, session, section='browse', level='groups', parent=None, page=1):
        self.section = section
        Alkuds_Egybest_Browser.__init__(self, session, 'movie', level, parent, page)
        self.level = level
        self['key_green'].setText(u'فتح')
        self['key_yellow'].setText(u'السابق' if level == 'items' else '')
        self['key_blue'].setText(u'التالي' if level == 'items' else u'تحديث')
        self._update_title()

    def _label(self):
        name = self.parent.get('series_title') or self.parent.get('title') or self.provider.SECTION_MAP.get(self.section, (u'تصفح الموقع', ''))[0]
        return self.site_name + (u' - ' + name if self.level != 'groups' else '')

    def load(self):
        if self._loading or self._closed:
            return
        self._operation, self._loading, self._done = ('load', True, False)
        self._result, self._error = (None, '')
        self['list'].setList([_list_entry(u'جاري التحميل...', -1)])
        worker = threading.Thread(target=self._load_worker)
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _load_worker(self):
        try:
            if self.level == 'groups':
                self._result = self.provider.groups()
            elif self.level == 'sections':
                self._result = [{'name': u'بحث في هذا القسم', 'action': 'search'}, {'name': u'الأحدث', 'order': 'latest'}, {'name': u'الترتيب الأبجدي أ–ي', 'order': 'az'}, {'name': u'الترتيب الأبجدي ي–أ', 'order': 'za'}]
            elif self.level == 'seasons':
                self._result = self.provider.seasons(self.parent)
            elif self.level == 'servers':
                self._result = self.provider.servers(self.parent)
            elif self.parent.get('season') or self.parent.get('episode_query'):
                self._result = self.provider.episodes(self.parent, self.page)
            else:
                self._result = self._catalogue_items(lambda page: self.provider.fetch_items(self.section, page, self.parent.get('query', ''), self.parent.get('order', 'latest')))
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _set_rows(self):
        rows = []
        for index, item in enumerate(self.entries):
            name = item.get('name') or u'عنصر'
            if self.level == 'items':
                details = u' | '.join((x for x in (item.get('quality'), item.get('category')) if x))
                if details:
                    name += u'   |   ' + details
            rows.append(_list_entry(u'%03d   %s' % (index + 1, name), index))
        self['list'].setList(rows or [_list_entry(u'لا توجد عناصر متاحة حالياً.', -1)])

    def open_current(self):
        if self._loading or self._closed:
            return
        index = self._index()
        if not 0 <= index < len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if self.level == 'groups':
            self.session.open(type(self), item['section'], 'sections', item, 1)
            return
        if item.get('action') == 'search':
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(self._search_done, VirtualKeyBoard, title=u'بحث عرب سيد', text='')
            return
        if self.level == 'sections':
            self.session.open(type(self), self.section, 'items', item, 1)
            return
        if self.level == 'items' and item.get('is_series'):
            self.session.open(type(self), self.section, 'seasons', item, 1)
            return
        if self.level == 'seasons':
            self.session.open(type(self), self.section, 'items', item, 1)
            return
        if self.level != 'servers':
            self.session.open(type(self), self.section, 'servers', item, 1)
            return
        self._operation, self._loading, self._done = ('resolve', True, False)
        self._result, self._error = (None, '')
        self._update_title(u' - جاري تجهيز الفيديو...')
        worker = threading.Thread(target=self._resolve_worker, args=(item,))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _resolve_worker(self, item):
        try:
            self._result = self.provider.resolve(item)
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _search_done(self, value):
        if self._closed or not value or (not value.strip()):
            return
        self.session.open(type(self), self.section, 'items', {'query': value.strip()}, 1)

    def _start_resolved(self, item):
        category = 'Series' if self.section.endswith('_series') or item.get('series_title') else 'Movie'
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']}, item['name'], category, item.get('category', ''), item.get('image', ''), self.provider.BASE + ':' + item['url'])
