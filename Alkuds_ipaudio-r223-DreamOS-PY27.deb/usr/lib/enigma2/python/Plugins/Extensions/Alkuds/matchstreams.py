# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Ordinary media validation shared by the new match providers."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .py2compat import requests
from .sportacity import UA
from .matchqualities import qualities as _hls_qualities

def prepare(item, candidates):
    streams, seen, errors = ([], set(), [])
    for stream in candidates:
        if stream.get('url') in seen:
            continue
        seen.add(stream.get('url'))
        headers = stream.get('headers') or {'User-Agent': UA}
        try:
            with requests.get(stream['url'], headers=headers, timeout=(5, 12), stream=True) as response:
                response.raise_for_status()
                raw = response.raw.read(65536, decode_content=True)
                options = dict(stream.get('relay_options') or {}, live=True, livehd=True)
                stream = dict(stream, url=response.url, headers=headers, relay=True, relay_options=options)
            if raw.lstrip().startswith(b'#EXTM3U'):
                text = raw.decode('utf-8-sig', 'replace')
                if 'SAMPLE-AES' in text or re.search('KEYFORMAT="(?!identity")', text):
                    continue
                stream['mediatype'] = 'hls'
                streams.extend(_hls_qualities(text, stream))
            elif raw[:1] == b'G':
                streams.append(dict(stream, mediatype='ts', relay=False))
            elif b'ftyp' in raw[:32]:
                streams.append(dict(stream, mediatype='mp4', relay=False))
        except Exception as error:
            response = getattr(error, 'response', None)
            errors.append('HTTP %s' % response.status_code if response is not None else type(error).__name__)
    if not streams:
        reason = ' (' + ', '.join(sorted(set(errors))) + ')' if errors else ''
        raise RuntimeError(u'المشغل لم يرجع بثاً صالحاً الآن؛ اختر مشغلاً آخر.' + reason)
    return dict(item, name=item.get('match_name') or item['name'], url=streams[0]['url'], streams=streams, variants=streams)
