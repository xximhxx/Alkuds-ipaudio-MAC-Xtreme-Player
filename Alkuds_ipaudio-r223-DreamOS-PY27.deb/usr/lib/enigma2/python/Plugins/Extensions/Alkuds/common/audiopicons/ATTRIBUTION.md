# Audio channel picons

Original PNGs from https://github.com/tv-logo/tv-logos .
Per-file source URLs and SHA256 hashes: SOURCES.json. Images are included without modification.

This project is possible thanks to Creative Commons ShareAlike licenses, CC BY-SA and CC BY-NC-SA. By using the logos you have to agree with the following: The logo you are about to use is the intellectual property of the copyright, trademark holder and is offered to you as a convenience for lawful use.

EPG data is read from the receiver; this logo collection is not an EPG provider.

Additional original channel logos from the iptv-org logo catalog: https://iptv-org.github.io/api/logos.json . Per-image URLs are recorded in SOURCES.json. Channel marks remain the property of their owners.
