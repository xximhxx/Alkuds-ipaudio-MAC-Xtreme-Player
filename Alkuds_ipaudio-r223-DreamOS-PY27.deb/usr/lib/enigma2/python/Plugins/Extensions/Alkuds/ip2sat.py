# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Explicit Xtream category export to one native TV bouquet; no playback calls."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import hashlib
from .py2compat import os
import tempfile
from .py2compat import urllib
quote = urllib.parse.quote
urlsplit = urllib.parse.urlsplit
BOUQUET = 'userbouquet.alkuds_ip2sat.tv'
INDEX_LINE = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % BOUQUET

def clean_name(value):
    return ''.join((c for c in str(value or 'Channel') if ord(c) >= 32 and ord(c) != 127)).strip() or 'Channel'

def service_line(url):
    url = str(url)
    parts = urlsplit(url)
    if parts.scheme not in ('http', 'https') or not parts.netloc or any((ord(c) < 32 for c in url)):
        raise ValueError('Invalid channel URL')
    identity = hashlib.sha256(url.encode('utf-8')).hexdigest()
    return '#SERVICE 4097:0:1:%s:%s:%s:0:0:0:0:%s' % (identity[:4], identity[4:8], identity[8:12], quote(url, safe='/'))

def _read(path):
    if os.path.islink(path):
        raise ValueError('Refusing a linked bouquet file')
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return handle.read()
    except FileNotFoundError:
        return ''

def _atomic(path, text):
    fd, temporary = tempfile.mkstemp(prefix='.alkuds-ip2sat-', dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, 384)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)

def export_category(channels, category, directory='/etc/enigma2'):
    """Add without duplicates, retaining existing channels and all other bouquets.

    Write the bouquet before publishing its index entry. Repeating after a
    partial failure is safe. Do not expose URLs/credentials in return messages.
    """
    from .adultfilter import adult
    if adult({'name': category}):
        raise ValueError('Adult categories are blocked')
    channels = [(name, url) for name, url in channels if not adult({'name': name})]
    path = os.path.join(directory, BOUQUET)
    index_path = os.path.join(directory, 'bouquets.tv')
    old, index = (_read(path), _read(index_path))
    if old and old.splitlines()[0].strip() != '#NAME ip2sat':
        raise ValueError('Existing destination is not an ip2sat bouquet')
    existing = {line.strip() for line in old.splitlines() if line.startswith('#SERVICE ')}
    added = []
    for name, url in channels:
        line = service_line(url)
        if line in existing:
            continue
        existing.add(line)
        added.extend((line, '#DESCRIPTION ' + clean_name(name)))
    if not added and (not old):
        raise ValueError('No channels available to export')
    if added:
        text = old.rstrip('\n') + '\n' if old else '#NAME ip2sat\n'
        text += '#SERVICE 1:64:0:0:0:0:0:0:0:0:\n#DESCRIPTION ' + clean_name(category) + '\n'
        _atomic(path, text + '\n'.join(added) + '\n')
    if INDEX_LINE not in {line.strip() for line in index.splitlines()}:
        _atomic(index_path, (index.rstrip('\n') + '\n' if index else '#NAME Bouquets (TV)\n') + INDEX_LINE + '\n')
    return len(added) // 2
