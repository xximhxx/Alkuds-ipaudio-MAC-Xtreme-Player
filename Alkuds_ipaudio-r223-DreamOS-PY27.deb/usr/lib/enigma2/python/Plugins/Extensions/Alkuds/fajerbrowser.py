# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Optional native Fajer browser, isolated from catalogue and audio backends."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import importlib
import sys
URL = 'https://fajer.show/movies/'
LOG = '/tmp/alkuds-fajer-browser-test.log'

def _log(message):
    try:
        with open(LOG, 'a') as handle:
            handle.write('R139 ' + message + '\n')
    except Exception:
        pass

def _message(session, text):
    from .xStaticText import MessageBox
    session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=0)

def _audio_busy():
    audio = sys.modules.get(__package__ + '.backgroundaudio')
    if audio is None:
        return False
    with audio._LOCK:
        return bool(audio._STATE.get('wanted') or audio._STATE.get('procs') or audio._STATE.get('restarting'))

def open_fajer_browser(session):
    try:
        if _audio_busy():
            _message(session, u'أوقف IP AUDIO أولاً ثم افتح متصفح فجر شو، لتجنب تعارض الصوت.')
            return False
    except Exception:
        _log('Audio state unavailable; browser launch cancelled')
        _message(session, u'تعذر التحقق من حالة IP AUDIO. أوقف الصوتية وأعد تشغيل الواجهة قبل تجربة المتصفح.')
        return False
    from .receivercompat import is_vuplus
    if not is_vuplus():
        _log('No supported native browser adapter for this receiver')
        _message(session, u'لا يتوفر حالياً متصفح مدعوم لهذا الجهاز داخل القدس.\nمتصفح الفيو لا يثبت على الدريم أو الأوكتاجون.\nيمكنك متابعة استخدام قوائم فجر شو العادية عندما يسمح الاتصال بها.')
        return False
    try:
        config = importlib.import_module('Plugins.Extensions.WebkitHbbTV.vbcfg')
    except ImportError:
        _log('WebkitHbbTV missing; no automatic installation')
        _message(session, u'ثبت WebkitHbbTV من إضافات صورة الفيو ثم أعد تشغيل الواجهة.\nاسم الحزمة: enigma2-plugin-extensions-webkithbbtv')
        return False
    except Exception as error:
        _log('Native browser import failed: %s' % type(error).__name__)
        _message(session, u'تعذر تحميل متصفح الجهاز.\nالسجل: %s' % LOG)
        return False
    manager = getattr(config, 'g_main', None)
    opener = getattr(manager, 'start_hbbtv_application', None)
    if not callable(opener):
        _log('WebkitHbbTV manager not initialized')
        _message(session, u'المتصفح مثبت لكنه غير جاهز. أعد تشغيل واجهة Enigma2 وجرب ثانية.')
        return False
    try:
        _log('Opening official Fajer catalogue via native browser manager')
        opener(URL, None)
        return True
    except Exception as error:
        _log('Native launch failed: %s' % type(error).__name__)
        _message(session, u'تعذر فتح متصفح فجر شو: %s\nالسجل: %s' % (type(error).__name__, LOG))
        return False
