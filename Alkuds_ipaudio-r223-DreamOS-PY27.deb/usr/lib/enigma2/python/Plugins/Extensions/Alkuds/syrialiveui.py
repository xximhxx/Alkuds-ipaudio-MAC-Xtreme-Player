# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import syrialive
from .generaltvui import Alkuds_GeneralTV_Browser
from .fajershowui import Alkuds_FajerShow_Qualities

class Alkuds_SyriaLive_Browser(Alkuds_GeneralTV_Browser):
    provider = syrialive
    site_name = u'سيريا لايف - الوقت بتوقيت الجهاز'

    def refresh_scores(self):
        if self._loading or self._closed:
            return
        index = self._index()
        self._score_selection = self.entries[index].get('id') if 0 <= index < len(self.entries) else None
        self.load()

    def _set_rows(self):
        Alkuds_GeneralTV_Browser._set_rows(self)
        identity = getattr(self, '_score_selection', None)
        index = next((n for n, row in enumerate(self.entries) if row.get('id') == identity), None)
        if index is not None:
            self['list'].setIndex(index)

    def _auto_scores(self):
        if not self._error:
            self.refresh_scores()

    def __init__(self, session, section='browse', level='groups', parent=None, page=1):
        Alkuds_GeneralTV_Browser.__init__(self, session, section, level, parent, page)
        if level == 'groups':
            from enigma import eTimer
            self._scores_timer = eTimer()
            try:
                self._scores_connection = self._scores_timer.timeout.connect(self._auto_scores)
            except Exception:
                self._scores_timer.callback.append(self._auto_scores)
            self.onShown.append(lambda: self._scores_timer.start(30000, False))
            self.onHide.append(self._scores_timer.stop)
            self.onClose.append(self._scores_timer.stop)

    def _start_resolved(self, item):
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']}, item['name'], 'Live', item.get('when', ''), item.get('image', ''), '')
