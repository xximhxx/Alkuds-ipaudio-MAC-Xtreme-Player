# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Audio-only two-line rows: channel picon, name and current native EPG."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import ElementTree as ET
from .xStaticText import List as SourceList
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, getDesktop
from .freestyle import decorate, FONT
from .audioepg import current_event, picon_path, picon_key
_pixmaps = {}

def audio_row(caption, index, name, item=None, source=''):
    return (caption, index, '', 16777215, name, item or {}, source)

def audio_rows(rows):
    result = []
    for row in rows or []:
        decorated = decorate([row[:4]])[0]
        n = len(result)
        decorated = decorated[:4] + (2430016 if n % 2 == 0 else 3350618, 16777215 if n % 2 == 0 else 15985919) + decorated[6:]
        event, number = ('', '')
        if len(row) >= 7:
            path = picon_path(row[4], row[6])
            if path:
                if path not in _pixmaps:
                    try:
                        _pixmaps[path] = LoadPixmap(path)
                    except Exception:
                        _pixmaps[path] = None
                if _pixmaps[path] is not None:
                    decorated = decorated[:6] + (_pixmaps[path],) + decorated[7:]
            event = current_event(row[4], row[5], row[6])
            key = picon_key(row[4], row[6])
            number = key.rsplit('-', 1)[-1] if key.rsplit('-', 1)[-1].isdigit() else ''
        result.append(decorated + (event, number))
    return result

class AudioList(SourceList):

    def __init__(self, rows=None, *args, **kwargs):
        SourceList.__init__(self, audio_rows(rows), *args, **kwargs)

    def setList(self, rows):
        SourceList.setList(self, audio_rows(rows))

def audio_list_skin(xml):
    screen = ET.fromstring(xml)
    listing = next((node for node in screen.findall('widget') if node.get('source') == 'list'), None)
    if listing is None or listing.find('convert') is None:
        return xml
    height = getDesktop(0).size().height()
    item = 92 if height >= 1080 else 72 if height >= 720 else 58
    font = 32 if height >= 1080 else 25 if height >= 720 else 20
    epg_font = font - 5
    row_width = int(listing.get('size').split(',')[0]) - 24
    icon_width = 54 if height >= 1080 else 36 if height >= 720 else 30
    icon_height = 32 if height >= 1080 else 22 if height >= 720 else 18
    number_width = 22 if height >= 1080 else 16
    text_left = icon_width + number_width + 24
    text_width = max(80, row_width - text_left - 14)
    line_height = (item - 10) // 2
    template = '{"template":['
    template += 'MultiContentEntryText(pos=(0,2),size=(%d,%d),font=0,text=7,backcolor=0xff000004,backcolor_sel=0x6D3FC4),' % (row_width, item - 4)
    template += 'MultiContentEntryPixmapAlphaBlend(pos=(8,%d),size=(%d,%d),png=6),' % ((item - icon_height) // 2, icon_width, icon_height)
    template += 'MultiContentEntryText(pos=(%d,%d),size=(%d,%d),font=1,text=9,color=0xFFFFFF,color_sel=0xFFFFFF,flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER),' % (icon_width + 10, (item - icon_height) // 2, number_width, icon_height)
    template += 'MultiContentEntryText(pos=(%d,4),size=(%d,%d),font=0,text=0,color=0xff000005,color_sel=0xFFFFFF,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER),' % (text_left, text_width, line_height)
    template += 'MultiContentEntryText(pos=(%d,%d),size=(%d,%d),font=1,text=8,color=0xE9D5FF,color_sel=0xFFFFFF,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER)' % (text_left, line_height + 4, text_width, line_height)
    template += '],"fonts":[gFont("%s",%d),gFont("%s",%d)],"itemHeight":%d}' % (FONT, font, FONT, epg_font, item)
    listing.find('convert').text = template
    return ET.tostring(screen, encoding='unicode')

def watch_epg(screen, callback):
    timer = eTimer()
    last = [None, 0]

    def refresh():
        try:
            if getattr(screen, 'execing', False):
                from .py2compat import time
                from .sportsguide import revision, ensure_async
                ensure_async()
                stamp = revision()
                now = time.monotonic()
                if last[0] == stamp and now - last[1] < 30:
                    return
                last[:] = [stamp, now]
                index = screen['list'].getIndex()
                callback()
                screen['list'].setIndex(index)
        except Exception:
            pass
    try:
        connection = timer.timeout.connect(refresh)
    except Exception:
        timer.callback.append(refresh)
        connection = None
    screen._epg_watch = (timer, connection, refresh)
    screen.onShown.append(lambda: timer.start(1000, False))
    screen.onHide.append(timer.stop)
    screen.onClose.append(timer.stop)
