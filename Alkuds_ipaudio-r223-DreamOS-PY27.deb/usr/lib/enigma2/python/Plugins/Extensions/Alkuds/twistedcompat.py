# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Compatibility helpers for Twisted releases that dropped legacy APIs.

twisted.web.client.downloadPage was removed in Twisted 22.1, but many Enigma2
images (OpenATV 7.x, OpenPLi 8/9, ...) ship a newer Twisted.  Modules import
downloadPage from here: the genuine Twisted function is used whenever it
exists, otherwise a streaming replacement built on `requests` (a hard
dependency of the plugin) runs in Twisted's thread pool and returns a Deferred
with the same contract: callback on success, errback on failure.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
try:
    from twisted.web.client import downloadPage
except ImportError:
    from twisted.internet import threads
    _CHUNK = 64 * 1024

    def _download_blocking(url, filename, timeout, headers):
        from .py2compat import requests
        if isinstance(url, bytes):
            url = url.decode('utf-8', 'replace')
        if isinstance(filename, bytes):
            filename = filename.decode('utf-8', 'replace')
        part = filename + '.part'
        try:
            try:
                requests.packages.urllib3.disable_warnings()
            except Exception:
                pass
            if timeout:
                request_timeout = (min(float(timeout), 15.0), float(timeout))
            else:
                request_timeout = (15.0, 60.0)
            response = requests.get(url, headers=headers or None, stream=True, timeout=request_timeout, verify=False, allow_redirects=True)
            try:
                response.raise_for_status()
                with open(part, 'wb') as handle:
                    for chunk in response.iter_content(_CHUNK):
                        if chunk:
                            handle.write(chunk)
            finally:
                response.close()
            if os.path.exists(filename):
                os.remove(filename)
            os.rename(part, filename)
            return filename
        except BaseException:
            try:
                if os.path.exists(part):
                    os.remove(part)
            except OSError:
                pass
            raise

    def downloadPage(url, file, contextFactory=None, *args, **kwargs):
        """Drop-in for the removed twisted.web.client.downloadPage."""
        timeout = kwargs.get('timeout', 0)
        headers = kwargs.get('headers')
        return threads.deferToThread(_download_blocking, url, file, timeout, headers)
