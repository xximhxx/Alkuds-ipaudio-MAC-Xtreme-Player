# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Receive speed and session bytes for legacy Live/VOD/Series player skins."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .streammetrics import TrafficCounter, traffic_text

class PlayerTraffic(object):

    def __init__(self, screen):
        from .py2compat import ElementTree as ET
        from .xStaticText import Label
        from enigma import eTimer
        self.screen = screen
        self.counter = TrafficCounter()
        self.service_key = None
        root = ET.fromstring(screen.skin)
        width, height = [int(x) for x in root.attrib['size'].split(',')]
        scale = width / 1280.0
        ET.SubElement(root, 'widget', {'name': 'network_traffic', 'position': '%d,%d' % (int(20 * scale), int(height * 0.75 - 32 * scale)), 'size': '%d,%d' % (width - int(40 * scale), int(32 * scale)), 'font': 'AlkudsUnicode;%d' % int(20 * scale), 'foregroundColor': '#FFFFFF', 'backgroundColor': '#50281032', 'halign': 'right', 'noWrap': '1', 'zPosition': '5'})
        screen.skin = ET.tostring(root, encoding='utf-8').decode('utf-8')
        screen['network_traffic'] = Label('')
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.update)
        except Exception:
            self.timer.callback.append(self.update)
        screen.onFirstExecBegin.append(self.start)
        screen.onClose.append(self.stop)

    def start(self):
        self.update()
        self.timer.start(1000, False)

    def update(self):
        ref = self.screen.session.nav.getCurrentlyPlayingServiceReference()
        key = ref.toString() if ref else ''
        if key != self.service_key:
            self.service_key = key
            self.counter.reset()
        rate, total = self.counter.sample()
        self.screen['network_traffic'].setText(traffic_text(rate, total) + ' (receiver network)')

    def stop(self):
        self.timer.stop()

def attach_player_traffic(screen):
    screen._network_meter = PlayerTraffic(screen)
