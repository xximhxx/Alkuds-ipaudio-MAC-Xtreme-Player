# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Expose master variants without discarding separate audio renditions."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .plasmatv import _hls_qualities

def qualities(text, stream):
    if not any(('TYPE=AUDIO' in line and 'URI=' in line for line in text.splitlines() if line.startswith('#EXT-X-MEDIA:'))):
        return _hls_qualities(text, stream)
    variants, pending = ([], None)
    for line in text.splitlines():
        if line.startswith('#EXT-X-STREAM-INF:'):
            pending = line
        elif line.strip() and (not line.startswith('#')) and pending:
            height = re.search('RESOLUTION=\\d+x(\\d+)', pending)
            bandwidth = re.search('(?:^|,)BANDWIDTH=(\\d+)', pending.split(':', 1)[1])
            label = height.group(1) + 'p' if height else bandwidth.group(1) + ' bps' if bandwidth else 'Auto'
            options = dict(stream.get('relay_options') or {})
            options['hls_variant'] = pending
            variants.append(dict(stream, quality=label, relay=True, relay_options=options))
            pending = None
    return variants or [stream]

def select_variant(text, selected):
    if not selected or '#EXT-X-STREAM-INF:' not in text:
        return text
    lines, keep, pending = ([], True, False)
    for line in text.splitlines():
        if line.startswith('#EXT-X-STREAM-INF:'):
            keep = line == selected
            pending = True
            if keep:
                lines.append(line)
        elif pending and line.strip() and (not line.startswith('#')):
            if keep:
                lines.append(line)
            pending, keep = (False, True)
        else:
            lines.append(line)
    if selected not in lines:
        raise ValueError('Selected HLS quality is no longer available')
    return '\n'.join(lines) + '\n'
