# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Shoof Max: separate catalogues, canonical series, numbered episodes."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .py2compat import json
from .py2compat import requests
try:
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
    parse_qs = urllib.parse.parse_qs
except ImportError:
    from urlparse import urljoin, urlparse, parse_qs
from . import arabseed as a
from .subtitledata import extract
BASE = 'https://shoofmax.com/'
STATIC = 'https://shoofmax-static.b-cdn.net/v2/img/program/main/'
SECTION_MAP = {'browse': (u'البحث في كل الأقسام', ''), 'movies': (u'الأفلام', u'فيلم'), 'foreign_series': (u'المسلسلات', u'مسلسل')}

def decode(raw):
    try:
        return raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        return raw.decode('cp1256', 'replace')

def get(session, path, params=None):
    response = session.get(urljoin(BASE, path), params=params, headers={'User-Agent': a.UA, 'Referer': BASE}, timeout=(5, 15))
    response.raise_for_status()
    return (decode(response.content), response.url)

def groups():
    return [{'name': u'البحث في كل الأقسام', 'section': 'browse', 'action': 'search'}, {'name': u'الأفلام', 'section': 'movies'}, {'name': u'المسلسلات', 'section': 'foreign_series'}]

def series_name(title):
    title = re.sub(u'^\\s*مسلسل\\s+', '', title).strip()
    match = re.search(u'\\s+(?:الموسم|موسم|الجزء|جزء)\\s*(\\d+|الأول|الاول|الثاني|الثالث|الرابع|الخامس)\\s*$', title)
    if match:
        words = {u'الأول': 1, u'الاول': 1, u'الثاني': 2, u'الثالث': 3, u'الرابع': 4, u'الخامس': 5}
        number = words.get(match.group(1)) or int(match.group(1))
        return (title[:match.start()].strip(), number)
    match = re.search('\\s+([2-9])\\s*$', title)
    if match:
        return (title[:match.start()].strip(), int(match.group(1)))
    return (title, 1)

def row(value, section):
    count = int(value.get('pepisodes') or 0)
    series = section == 'foreign_series' or count > 0
    original = value.get('ptitle') or ''
    name, season_number = series_name(original) if series else (original, None)
    url = urljoin(BASE, 'program/%s' % value['pid'])
    return {'id': str(value['pid']), 'name': name, 'title': original, 'url': url, 'is_series': series, 'episode_count': count, 'season_number': season_number, 'image': STATIC + value['presbase'] + '-2.jpg' if value.get('presbase') else '', 'category': value.get('sgname') or (u'مسلسل' if series else u'فيلم')}

def search(session, query):
    html, page = get(session, 'search', {'q': query})
    entries = []
    for card in a.Document(html).root.find(css='generic-item'):
        links, titles = (card.find('a'), card.find(css='generic-item-title'))
        if not links or not titles:
            continue
        url = urljoin(page, links[0].attrs.get('href', ''))
        ident = re.search('/program/(\\d+)', url)
        if not ident:
            continue
        title_nodes = titles[0].find('span')
        title = title_nodes[0].text() if title_nodes else titles[0].text()
        series = 'ep' in parse_qs(urlparse(url).query) or u'مسلسل' in titles[0].text()
        name, season_number = series_name(title) if series else (title, None)
        images = card.find(css='generic-item-image')
        image = re.search('url\\(([^)]+)\\)', images[0].attrs.get('style', '')) if images else None
        entries.append({'id': ident.group(1), 'name': name, 'title': title, 'url': url, 'is_series': series, 'season_number': season_number, 'image': image.group(1) if image else '', 'category': u'مسلسل' if series else u'فيلم'})
    return entries

def fetch_items(section, page=1, query='', order='latest'):
    with requests.Session() as session:
        if query:
            entries = search(session, query) if page == 1 else []
            if section != 'browse':
                entries = [x for x in entries if x['is_series'] == (section == 'foreign_series')]
            last = 1
        else:
            genre = SECTION_MAP[section][1]
            if not genre:
                return {'entries': [], 'page': 1, 'last_page': 1, 'total': 0}
            html, url = get(session, u'genre/filter/%s/%d/%s' % (genre, page, 'views' if order == 'views' else 'yop'), {'country': '', 'subgenre': ''})
            values = json.loads(html)
            if not isinstance(values, list):
                raise RuntimeError('Shoof Max did not return the catalogue')
            entries = [row(v, section) for v in values if v.get('pid') and v.get('ptitle')]
            last = page + 1 if len(values) == 16 else page
    if order in ('az', 'za'):
        entries.sort(key=lambda x: x['name'], reverse=order == 'za')
    return {'entries': entries, 'page': page, 'last_page': last, 'total': len(entries)}

def seasons(item):
    with requests.Session() as session:
        matches = [x for x in search(session, item['name']) if x['is_series'] and x['name'] == item['name']]
    if not any((x['id'] == item['id'] for x in matches)):
        matches.append(dict(item))
    entries, seen = ([], set())
    for value in sorted(matches, key=lambda x: (x.get('season_number') or 1, x['id'])):
        if value['id'] in seen:
            continue
        seen.add(value['id'])
        value = dict(value)
        value.update(name=u'الموسم %d' % (value.get('season_number') or 1) if len(matches) > 1 else u'حلقات المسلسل', series_title=item['name'], is_series=False, episode_query=True)
        entries.append(value)
    return entries

def episodes(item, page=1):
    with requests.Session() as session:
        html, url = get(session, 'program/%s' % item['id'], {'ep': 1})
    root = a.Document(html).root
    select = root.find('select', 'episode-control-select')
    entries = []
    for option in select[0].find('option') if select else []:
        try:
            number = int(option.attrs.get('value') or '')
        except ValueError:
            continue
        episode = dict(item)
        episode.update(name=u'الحلقة %d' % number, episode=number, episode_query=False, url=urljoin(BASE, 'program/%s?ep=%d' % (item['id'], number)), title=item.get('series_title', item.get('title', '')) + u' — الحلقة %d' % number)
        entries.append(episode)
    if not entries:
        raise RuntimeError('Shoof Max did not return this series episodes')
    entries.sort(key=lambda x: x['episode'])
    return {'entries': entries, 'page': 1, 'last_page': 1, 'total': len(entries)}

def servers(item):
    return [dict(item)]

def sources(html, final_url):
    variables = dict(re.findall('var\\s+((?:backup_)?origin_link)\\s*=\\s*[\\x22\\x27]([^\\x22\\x27]+)', html))
    candidates, seen = ([], set())
    for block in re.findall('var\\s+(?:src|backupSrc)\\s*=\\s*\\{(.*?)\\}', html, re.S):
        for variable, path in re.findall('((?:backup_)?origin_link)\\s*\\+\\s*[\\x22\\x27]([^\\x22\\x27]+)', block):
            if variable in variables:
                url = urljoin(variables[variable] + '/', path)
                if url not in seen:
                    seen.add(url)
                    candidates.append(url)
        for url in re.findall('[\\x22\\x27](https?[^\\x22\\x27]+\\.(?:m3u8|mp4)(?:\\?[^\\x22\\x27]*)?)[\\x22\\x27]', block):
            if url not in seen:
                seen.add(url)
                candidates.append(url)
    return candidates

def resolve(item):
    from .freeproviders import hls_variant_streams
    with requests.Session() as session:
        html, page = get(session, item['url'])
        headers = {'User-Agent': a.UA, 'Referer': a._referer(page)}
        tracks = extract(html, page, headers)
        candidates = sources(html, page)
        streams = []
        for url in [x for x in candidates if '.m3u8' in x]:
            try:
                response = session.get(url, headers=headers, timeout=(4, 8))
                response.raise_for_status()
                if '#EXTM3U' not in response.text[:200]:
                    continue
                streams.extend(hls_variant_streams({'url': url, 'headers': headers, 'relay': True, 'mediatype': 'hls', 'subtitles': tracks, 'quality': 'Auto'}))
                break
            except Exception:
                continue
        if not streams:
            for url in [x for x in candidates if '.mp4' in x]:
                response = session.get(url, headers=headers, timeout=(4, 8), stream=True)
                try:
                    response.raise_for_status()
                    streams.append({'url': url, 'headers': headers, 'mediatype': 'mp4', 'relay': True, 'quality': '240p' if '240p' in url else 'Original', 'subtitles': tracks})
                except requests.RequestException:
                    continue
                finally:
                    response.close()
        if not streams:
            raise RuntimeError('Shoof Max did not return an available video')
    result = dict(item)
    result.update(name=item.get('title') or item['name'], streams=streams)
    return result
