# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""ArabSeed catalogue and public watch-page resolver (Python 2/3)."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import binascii
from .py2compat import re
from .py2compat import requests
from .py2compat import threading
from .py2compat import time
try:
    from HTMLParser import HTMLParser
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
    urlencode = urllib.parse.urlencode
except ImportError:
    from HTMLParser import HTMLParser
    from urlparse import urljoin, urlparse
    from urllib import urlencode
BASE = 'https://arabseed.trade/'
CATALOGUE_HOSTS = ('arabseed.trade', 'www.arabseed.trade', 'arabseed.college', 'www.arabseed.college')
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
SECTIONS = [('browse', u'تصفح الموقع', 'home/'), ('trend', u'الأكثر مشاهدة', 'trend/'), ('recently', u'أضيف حديثاً', 'recently/'), ('foreign_movies', u'أفلام أجنبية', u'category/افلام-اجنبي/'), ('turkish_movies', u'أفلام تركية', u'category/افلام-تركية/'), ('indian_movies', u'أفلام هندية', u'category/افلام-هندي/'), ('anime_movies', u'أفلام أنمي', u'category/افلام-انمي/'), ('anime_series', u'مسلسلات أنمي', u'category/مسلسلات-انمي/'), ('foreign_series', u'مسلسلات أجنبية', u'category/مسلسلات-اجنبي/'), ('turkish_series', u'مسلسلات تركية', u'category/مسلسلات-تركية/'), ('indian_series', u'مسلسلات هندية', u'category/مسلسلات-هندية/'), ('arabic_series', u'مسلسلات عربية', u'category/مسلسلات-عربي/')]
SECTION_MAP = dict(((key, (name, path)) for key, name, path in SECTIONS))

class Node(object):

    def __init__(self, tag='', attrs=None, parent=None):
        self.tag, self.attrs, self.parent = (tag, dict(attrs or []), parent)
        self.children, self.parts = ([], [])

    def find(self, tag=None, css=None):
        result = []
        for child in self.children:
            if (tag is None or child.tag == tag) and (css is None or css in child.attrs.get('class', '').split()):
                result.append(child)
            result.extend(child.find(tag, css))
        return result

    def text(self):
        value = ''.join((p.text() if isinstance(p, Node) else p for p in self.parts))
        return re.sub('\\s+', ' ', value).strip()

class Document(HTMLParser):

    def __init__(self, value):
        HTMLParser.__init__(self)
        self.root = Node()
        self.current = self.root
        self.feed(value)
        self.close()

    def handle_starttag(self, tag, attrs):
        child = Node(tag, attrs, self.current)
        self.current.children.append(child)
        self.current.parts.append(child)
        if tag not in ('area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'):
            self.current = child

    def handle_startendtag(self, tag, attrs):
        child = Node(tag, attrs, self.current)
        self.current.children.append(child)
        self.current.parts.append(child)

    def handle_endtag(self, tag):
        node = self.current
        while node.parent is not None:
            if node.tag == tag:
                self.current = node.parent
                return
            node = node.parent

    def handle_data(self, value):
        self.current.parts.append(value)

    def handle_entityref(self, name):
        try:
            self.handle_data(self.unescape('&%s;' % name))
        except AttributeError:
            from .py2compat import html
            unescape = html.unescape
            self.handle_data(unescape('&%s;' % name))

    def handle_charref(self, name):
        self.handle_entityref('#' + name)

def _local(url):
    value = urljoin(BASE, url)
    parsed = urlparse(value)
    if parsed.scheme not in ('http', 'https') or parsed.hostname not in CATALOGUE_HOSTS:
        raise ValueError('Unexpected ArabSeed catalogue address')
    return urljoin(BASE, parsed.path + ('?' + parsed.query if parsed.query else ''))

def groups():
    return [{'name': name, 'section': key, 'url': _local(path)} for key, name, path in SECTIONS]

def _referer(url):
    return requests.utils.requote_uri((url or BASE).split('#', 1)[0])

def _headers(referer=BASE, local=False):
    headers = {'User-Agent': UA, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8', 'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8', 'Cache-Control': 'no-cache', 'Pragma': 'no-cache', 'Referer': _referer(referer), 'Upgrade-Insecure-Requests': '1'}
    if local:
        headers.update({'Sec-Fetch-Dest': 'document', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'same-origin'})
    return headers
_cookie_lock = threading.Lock()
_cookie_cache = None
_cookie_time = 0

def _new_session():
    global _cookie_cache, _cookie_time
    session, response = (requests.Session(), None)
    with _cookie_lock:
        if _cookie_cache is not None and time.time() - _cookie_time < 300:
            session.cookies.update(_cookie_cache)
            return session
    try:
        response = session.get(BASE, headers=_headers(BASE, True), timeout=(8, 25))
        response.raise_for_status()
        if 'cf-chl-' in response.text and 'movie__block' not in response.text:
            raise RuntimeError('ArabSeed requires browser verification. Try again later.')
        with _cookie_lock:
            _cookie_cache = compat_copy(session.cookies)
            _cookie_time = time.time()
        return session
    except Exception:
        session.close()
        raise
    finally:
        if response is not None:
            response.close()

def _get(session, url, referer=BASE, local=False):
    response = session.get(requests.utils.requote_uri(url), headers=_headers(referer, local), timeout=(8, 35), allow_redirects=True)
    try:
        response.raise_for_status()
        if len(response.content) > 5 * 1024 * 1024:
            raise RuntimeError('ArabSeed page is too large')
        value = response.content.decode('utf-8', 'replace')
        if 'cf-chl-' in value and '<iframe' not in value and ('movie__block' not in value):
            raise RuntimeError('ArabSeed requires browser verification. Try again later.')
        return (value, response.url)
    finally:
        response.close()

def _image(node):
    images = node.find('img')
    return urljoin(BASE, images[0].attrs.get('data-src') or images[0].attrs.get('src') or '') if images else ''

def _first_text(node, css):
    values = node.find(css=css)
    return values[0].text() if values else ''

def _page_url(url, page):
    page = max(1, int(page or 1))
    if page == 1:
        return url
    parsed = urlparse(url)
    result = '%s://%s%s/page/%d/' % (parsed.scheme, parsed.netloc, parsed.path.rstrip('/'), page)
    return result + ('?' + parsed.query if parsed.query else '')

def fetch_items(section, page=1, query='', order='latest', grouped=True):
    if section not in SECTION_MAP:
        raise ValueError('Unknown ArabSeed section')
    name, path = SECTION_MAP[section]
    values = {}
    if query:
        path = ''
        values['s'] = query.encode('utf-8')
        values['type'] = 'series' if section.endswith('_series') else 'movies' if section.endswith('_movies') else 'all'
    if order in ('az', 'za'):
        values.update(orderby='title', order='ASC' if order == 'az' else 'DESC')
    url = _page_url(_local(path), page)
    if values:
        url += '?' + urlencode(values)
    session = _new_session()
    try:
        html, page_url = _get(session, url, BASE, True)
    finally:
        session.close()
    root = Document(html).root
    entries, seen = ([], set())
    for block in root.find('a', 'movie__block'):
        try:
            item_url = _local(block.attrs.get('href', ''))
        except Exception:
            continue
        if item_url in seen:
            continue
        title = block.attrs.get('title') or _first_text(block, 'post__title') or _first_text(block, 'movie__title')
        if not title:
            headings = block.find('h3') + block.find('h2')
            title = headings[0].text() if headings else block.text()
        title = re.sub('\\s+', ' ', title or '').strip()
        if not title:
            continue
        seen.add(item_url)
        entries.append({'id': item_url, 'url': item_url, 'name': title, 'image': _image(block), 'category': _first_text(block, 'post__category'), 'quality': _first_text(block, '__quality') or _first_text(block, 'quality'), 'description': _first_text(block, 'post__info'), 'section': section})
    pages = [int(page)]
    for link in root.find('a'):
        match = re.search('/page/(\\d+)/', link.attrs.get('href', ''))
        if match:
            pages.append(int(match.group(1)))
    if grouped:
        entries = group_series(entries)
    return {'entries': entries, 'page': int(page), 'last_page': max(pages), 'total': len(entries), 'name': name, 'url': page_url}

def _decode_hex(value):
    try:
        raw = binascii.unhexlify(value)
        return raw.decode('utf-8', 'replace') if not isinstance(raw, str) else raw
    except Exception:
        return ''

def _media_type(url):
    path = urlparse(url).path.lower()
    return 'hls' if '.m3u8' in path else 'mp4' if '.mp4' in path else ''

def series_name(title):
    return re.split(u'\\s*(?:الحلقة|حلقه|حلقة|Episode)\\s*', title, 1, flags=re.I)[0].strip()

def group_series(entries):
    result, seen = ([], set())
    for entry in entries:
        title = entry.get('name', '')
        is_series = entry.get('section', '').endswith('_series') or title.startswith(u'مسلسل')
        if is_series:
            entry = dict(entry)
            entry['name'] = series_name(title)
            entry['is_series'] = True
            entry['quality'] = ''
            key = entry['name'].lower()
            if key in seen:
                continue
            seen.add(key)
        result.append(entry)
    return result

def seasons(item):
    session = _new_session()
    try:
        html, page_url = _get(session, _local(item['url']), BASE, True)
        root = Document(html).root
        result = []
        for node in root.find():
            season = node.attrs.get('data-season')
            if season and season.isdigit() and ('season-item' in node.attrs.get('class', '').split()):
                row = dict(item)
                row.update(season=season, name=node.text(), series_title=item['name'], referer=page_url)
                result.append(row)
        if not result:
            raise RuntimeError('No seasons were returned by ArabSeed')
        return result
    finally:
        session.close()

def episodes(item, page=1):
    session = _new_session()
    try:
        response = session.post(BASE + 'wp-admin/admin-ajax.php', data={'action': 'load_episodes', 'season': item['season'], 'page': int(page)}, headers=_headers(item.get('referer', BASE), True), timeout=(8, 20))
        try:
            response.raise_for_status()
            root = Document(response.content.decode('utf-8', 'replace')).root
        finally:
            response.close()
        result, seen = ([], set())
        for link in root.find('a'):
            href = link.attrs.get('href', '')
            if '/watch' not in href:
                continue
            url = _local(href)
            if url in seen:
                continue
            seen.add(url)
            label = _first_text(link, 'epi__num') or link.text()
            row = dict(item)
            row.update(url=url, name=item.get('series_title', '') + u' - ' + label, is_series=False, quality='')
            result.append(row)
        return {'entries': result, 'page': int(page), 'last_page': int(page) + (1 if result else 0), 'total': len(result)}
    finally:
        session.close()

def _resolve_page(session, url, referer, depth=0, visited=None):
    if depth > 4:
        return []
    visited = visited if visited is not None else set()
    url = urljoin(referer, url)
    if url in visited:
        return []
    visited.add(url)
    if _media_type(url):
        return [{'url': url, 'referer': referer, 'mediatype': _media_type(url)}]
    html, final_url = _get(session, url, referer, False)
    from .freeproviders import _unpack_egybest_script
    unpacked = _unpack_egybest_script(html)
    if unpacked:
        html = unpacked + '\n' + html
    html = html.replace('\\/', '/')
    from .subtitledata import extract
    tracks = extract(html, final_url, {'User-Agent': UA, 'Referer': _referer(final_url)})
    found = []
    for block in re.findall('\\{[^{}]*\\bfile\\s*:[^{}]*\\}', html, re.I):
        media = re.search('\\bfile\\s*:\\s*["\\\'](https?[^"\\\']+)["\\\']', block, re.I)
        quality = re.search('\\blabel\\s*:\\s*["\\\']([^"\\\']+)["\\\']', block, re.I)
        if media and _media_type(media.group(1)):
            found.append({'url': media.group(1), 'referer': final_url, 'mediatype': _media_type(media.group(1)), 'quality': quality.group(1) if quality else 'Original'})
    for value in re.findall('\\bMohix\\s*=\\s*["\\\']([0-9a-fA-F]+)["\\\']', html, re.I):
        decoded = _decode_hex(value).strip()
        if decoded.startswith(('http://', 'https://')) and _media_type(decoded):
            found.append({'url': decoded, 'referer': final_url, 'mediatype': _media_type(decoded)})
    patterns = ['(?:file|source|src)\\s*[:=]\\s*["\\\'](https?[^"\\\']+\\.(?:m3u8|mp4)(?:\\?[^"\\\']*)?)["\\\']', '["\\\'](https?[^"\\\']+\\.(?:m3u8|mp4)(?:\\?[^"\\\']*)?)["\\\']']
    for pattern in patterns:
        for media_url in re.findall(pattern, html, re.I):
            media_url = media_url.replace('\\/', '/')
            found.append({'url': media_url, 'referer': final_url, 'mediatype': _media_type(media_url)})
    if not found:
        root = Document(html).root
        for iframe in root.find('iframe'):
            source = iframe.attrs.get('src') or iframe.attrs.get('data-src') or ''
            if source:
                try:
                    found.extend(_resolve_page(session, source, final_url, depth + 1, visited))
                except Exception:
                    continue
    result, keys = ([], set())
    for stream in found:
        if stream.get('url') and stream['url'] not in keys:
            if tracks and (not stream.get('subtitles')):
                stream['subtitles'] = tracks
            result.append(stream)
            keys.add(stream['url'])
    return result

def servers(item):
    session = _new_session()
    try:
        if urlparse(item['url']).path.rstrip('/').endswith('/watch'):
            detail_html, detail_url = ('', item['url'])
            watch_url = item['url']
        else:
            detail_html, detail_url = _get(session, _local(item['url']), BASE, True)
            watch_url = ''
        detail = Document(detail_html).root
        for link in detail.find('a'):
            href = link.attrs.get('href', '')
            if 'watch__btn' in link.attrs.get('class', '').split() or urlparse(href).path.rstrip('/').endswith('/watch'):
                watch_url = _local(href)
                break
        if not watch_url:
            watch_url = _local(item['url'].rstrip('/') + '/watch/')
        watch_html, watch_final = _get(session, watch_url, detail_url, True)
        watch = Document(watch_html).root
        servers = []
        for node in watch.find('li'):
            link = node.attrs.get('data-link') or node.attrs.get('data-url')
            if link:
                servers.append((node.text() or u'مشغل', urljoin(watch_final, link)))
        if not servers:
            for frame in watch.find('iframe'):
                link = frame.attrs.get('src') or frame.attrs.get('data-src')
                if link:
                    servers.append((u'المشغل الرئيسي', urljoin(watch_final, link)))
        result = []
        for label, server_url in servers:
            row = dict(item)
            row.update(name=label, title=item['name'], server_url=server_url, referer=watch_final)
            result.append(row)
        if not result:
            raise RuntimeError('ArabSeed did not return any players')
        return result
    finally:
        session.close()

def resolve(item):
    """Resolve only the player selected by the viewer, retaining HLS qualities."""
    from .freeproviders import hls_variant_streams
    session = _new_session()
    try:
        resolved = _resolve_page(session, item['server_url'], item['referer'])
        streams = []
        for stream in resolved:
            candidate = {'url': stream['url'], 'relay': True, 'mediatype': stream['mediatype'], 'quality': stream.get('quality', 'Original'), 'subtitles': stream.get('subtitles') or [], 'headers': {'User-Agent': UA, 'Referer': _referer(stream['referer'])}}
            streams.extend(hls_variant_streams(candidate))
        if not streams:
            raise RuntimeError('This player did not expose a playable link. Choose another player.')
        result = dict(item)
        result.update(name=item.get('title', item['name']), streams=streams)
        return result
    finally:
        session.close()
