# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Small text-only UI helpers that stay fast on low-memory receivers."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy

def first_letter(value, default='S'):
    text = str(value or '').strip()
    for char in text:
        if char.isalnum():
            return char.upper()
    return default

def server_row(name, host='', details=''):
    """Create a lightweight first-letter avatar without loading extra images."""
    title = str(name or 'Server').strip() or 'Server'
    pieces = [u'● %s' % first_letter(title), title]
    if host:
        pieces.append(u'‹%s›' % str(host))
    if details:
        pieces.append(str(details))
    return '   '.join(pieces)

def channel_row(number, name, playing=False):
    marker = u'▶' if playing else ' '
    return '%s %03d   %s' % (marker, int(number) + 1, str(name or 'Channel'))

class ChannelGuideBinding(object):
    """Refresh at most 17 nearby rows; never rebuild a whole channel list."""

    def __init__(self, screen):
        from enigma import eTimer
        self.screen = screen
        self.source = screen['list']
        self.visible = False
        self.closed = False
        self.original_set = self.source.setList
        self.source.setList = self.set_list
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.refresh)
        except Exception:
            self.timer.callback.append(self.refresh)
            self.connection = None
        self.source.onSelectionChanged.append(self.refresh)
        screen.onShown.append(self.show)
        screen.onHide.append(self.hide)
        screen.onClose.append(self.close)

    def set_list(self, rows):
        self.original_set(rows)
        if self.visible:
            self.timer.start(150, True)

    def show(self):
        if self.closed:
            return
        self.visible = True
        self.timer.start(150, True)

    def hide(self):
        self.visible = False
        self.timer.stop()

    def refresh(self):
        if self.closed or not self.visible:
            return
        try:
            from .audioepg import iptv_guide_key
            from . import sportsguide
            source = self.source
            rows = source.list or []
            index = max(0, source.getIndex())
            update = getattr(source, 'updateEntry', None) or getattr(source, 'modifyEntry', None)
            if not callable(update):
                return
            for i in range(max(0, index - 8), min(len(rows), index + 9)):
                row = rows[i]
                try:
                    number = int(row[1])
                    if number < 0:
                        continue
                    name = self.screen.channels[number][0]
                except (ValueError, TypeError, IndexError):
                    continue
                key = iptv_guide_key(name)
                if not key:
                    continue
                event = sportsguide.current_caption(key)
                base = channel_row(number, name, number == self.screen.playing_index)
                title = base + (' | ' + event if event else '')
                if title != row[0]:
                    update(i, (title,) + tuple(row[1:]))
        except Exception:
            pass
        finally:
            if self.visible and (not self.closed):
                self.timer.start(2000, True)

    def close(self):
        self.closed = True
        self.hide()
        if self.refresh in self.source.onSelectionChanged:
            self.source.onSelectionChanged.remove(self.refresh)
        if self.source.setList == self.set_list:
            self.source.setList = self.original_set
        self.connection = None

def install_channel_guide(screen):
    if not hasattr(screen, '_channel_guide'):
        screen._channel_guide = ChannelGuideBinding(screen)
