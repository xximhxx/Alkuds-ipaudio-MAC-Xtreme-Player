# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Public Egybest app catalogue; requests happen only inside UI workers."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
from .py2compat import json
from .py2compat import re
from .py2compat import threading
from .py2compat import time
from collections import OrderedDict
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlparse = urllib.parse.urlparse
quote = urllib.parse.quote
from .py2compat import requests
from .py2compat import html
unescape = html.unescape
from . import arabseed as web
from .subtitledata import normalise
BASE = 'https://hrrejhp.com/egybestV27/public/api/'
CODE = base64.b64decode('cDJsYmdXa0ZyeWtBNFF5VW1wSGloem1jNUJOeklBQnE=').decode('ascii')
SECTION_MAP = {'movies': (u'الأفلام', 'movie'), 'foreign_series': (u'المسلسلات', 'serie'), 'live_sports': (u'القنوات الرياضية المباشرة', 'live'), 'live': (u'كل قنوات اللايف', 'live')}
_cache = OrderedDict()
_lock = threading.RLock()

def diagnostic(stage, url='', error=None):
    try:
        from .py2compat import os
        path = '/tmp/alkuds-egyapp.log'
        status = getattr(getattr(error, 'response', None), 'status_code', '')
        with open(path, 'w' if os.path.exists(path) and os.path.getsize(path) > 65536 else 'a') as out:
            out.write('%s %s host=%s error=%s status=%s\n' % (time.strftime('%H:%M:%S'), stage, urlparse(url).hostname or '', type(error).__name__ if error else '', status))
    except Exception:
        pass

def get(path, params=None):
    key = (path, tuple(sorted((params or {}).items())))
    now = time.monotonic()
    with _lock:
        value = _cache.get(key)
        if value and now - value[0] < 90:
            return json.loads(value[1])
    with requests.get(urljoin(BASE, path), params=params, headers={'User-Agent': web.UA, 'Accept': 'application/json'}, timeout=(4, 10), stream=True) as r:
        r.raise_for_status()
        raw = bytearray()
        for chunk in r.iter_content(32768):
            raw.extend(chunk)
            if len(raw) > 2 * 1024 * 1024:
                raise ValueError('Catalogue response too large')
    value = json.loads(raw.decode('utf-8-sig'))
    packed = json.dumps(value, ensure_ascii=False)
    with _lock:
        if len(packed.encode('utf8')) <= 1024 * 1024:
            _cache[key] = (now, packed)
        while len(_cache) > 24 or sum((len(v[1].encode('utf8')) for v in _cache.values())) > 1024 * 1024:
            _cache.popitem(last=False)
    return value

def groups():
    return [{'name': name, 'section': key} for key, (name, kind) in SECTION_MAP.items()]

def sections(section):
    return [{'name': u'البحث', 'action': 'search'}, {'name': u'أضيف حديثًا', 'order': 'latest'}, {'name': u'الأعلى تقييمًا', 'order': 'rating'}, {'name': u'الأكثر مشاهدة', 'order': 'views'}]

def row(value, section):
    kind = SECTION_MAP[section][1]
    ident = str(value['id'])
    result = {'id': ident, 'name': value.get('title') or value.get('name') or ident, 'title': value.get('title') or value.get('name') or ident, 'kind': kind, 'section': section, 'is_series': kind == 'serie', 'url': BASE + ('series/show/' if kind == 'serie' else 'stream/show/' if kind == 'live' else 'media/detail/') + ident, 'image': value.get('poster_path') or value.get('still_path') or '', 'description': value.get('overview') or '', 'quality': value.get('subtitle') or ''}
    if kind == 'live' and value.get('videos'):
        result['videos'] = value['videos']
    return result

def fetch_items(section='movies', page=1, query='', order='latest'):
    if section in ('live', 'live_sports'):
        values = get('livetv/mostwatched/' + CODE).get('watched') or []
        if section == 'live_sports':
            values = [v for v in values if re.search(u'be\\s*in|sports?|الكأس|الكاس|رياضي|ssc|أبو\\s*ظبي|ابو\\s*ظبي|ثمانية|ثمانيه|dazn|tennis', str(v.get('name') or ''), re.I)]
        start = (max(1, int(page)) - 1) * 24
        last = max(1, (len(values) + 23) // 24)
        return {'entries': [row(v, section) for v in values[start:start + 24]], 'page': page, 'last_page': last, 'has_next': page < last}
    kind = SECTION_MAP[section][1]
    plural = 'series' if kind == 'serie' else 'movies'
    path = ('search/' + quote(query, safe='') if query else plural + '/' + {'latest': 'latestadded', 'rating': 'byrating', 'views': 'byviews'}.get(order, 'latestadded')) + '/' + CODE
    value = get(path, {'page': max(1, int(page))})
    values = value.get('data') or value.get('search') or value.get('results') or []
    entries = [row(v, section) for v in values if isinstance(v, dict) and v.get('id') and (not query or str(v.get('type') or kind).lower() in (kind, plural))]
    return {'entries': entries, 'page': page, 'last_page': int(value.get('last_page') or page), 'has_next': bool(value.get('next_page_url'))}

def detail(item):
    return get(('series/show/' if item['kind'] == 'serie' else 'stream/show/' if item['kind'] == 'live' else 'media/detail/') + item['id'] + '/' + CODE)

def seasons(item):
    result = []
    for value in detail(item).get('seasons') or []:
        result.append(dict(item, name=value.get('name') or u'الموسم ' + str(value.get('season_number') or ''), series_title=item['name'], season=value['id'], episode_query=True, is_series=False))
    return result

def episodes(item, page=1):
    value = get('series/season/' + str(item['season']) + '/' + CODE)
    entries = []
    for v in value.get('episodes') or []:
        entries.append(dict(item, id=str(v['id']), name=v.get('name') or u'الحلقة ' + str(v.get('episode_number') or ''), title=item.get('series_title') or item['name'], kind='episode', is_series=False, videos=v.get('videos') or [], subtitles=v.get('substitles') or [], url=BASE + 'series/episode/' + str(v['id']), image=v.get('still_path') or item.get('image', '')))
    return {'entries': entries, 'page': 1, 'last_page': 1, 'has_next': False}

def servers(item):
    value = item if 'videos' in item else detail(item)
    result = []
    for index, v in enumerate(value.get('videos') or []):
        if v.get('drm') or v.get('downloadonly') or (not v.get('link')):
            continue
        result.append(dict(item, name=v.get('server') or 'Server ' + str(index + 1), title=item.get('title') or item['name'], video=v, subtitles=value.get('substitles') or item.get('subtitles') or []))
    if not result:
        raise RuntimeError(u'لا توجد روابط مشاهدة متاحة لهذا العنوان حاليًا')
    return result

def unwrap_html(session, url, headers, label):
    from .cinenxsha import read
    raw, final = read(session, url, headers)
    if not raw.lstrip().lower().startswith((b'<!doctype', b'<html')):
        return []
    text = raw.decode('utf8', 'replace')
    none = bool(re.search('content=["\\\']none["\\\']|referrerpolicy=["\\\']no-referrer["\\\']', text, re.I))
    h = {k: v for k, v in headers.items() if not none or k.lower() not in ('referer', 'origin')}
    result = []
    for target in re.findall('<iframe\\b[^>]*\\bsrc=["\\\']([^"\\\']+)', text, re.I)[:3]:
        target = urljoin(final, unescape(target))
        if urlparse(target).scheme in ('http', 'https'):
            result.append({'url': target, 'label': label, 'direct': True, 'headers': h})
    return result

def live_json(session, url, headers=None, data=None):
    remaining = session._alkuds_nxsha_deadline - time.monotonic()
    if remaining <= 0:
        raise RuntimeError('Live preparation timeout')
    with session.request('POST' if data is not None else 'GET', url, headers=headers or {}, data=data, timeout=(min(4, remaining), min(8, remaining)), stream=True, allow_redirects=False) as response:
        response.raise_for_status()
        if response.is_redirect:
            raise ValueError('Unexpected live redirect')
        raw = bytearray()
        for chunk in response.iter_content(16384):
            raw.extend(chunk)
            if len(raw) > 1024 * 1024:
                raise ValueError('Live response too large')
            if time.monotonic() > session._alkuds_nxsha_deadline:
                raise RuntimeError('Live preparation timeout')
        return (json.loads(raw.decode('utf8')), response.url)

def live_sources(session, item):
    video = item['video']
    target = video['link']
    if item.get('kind') != 'live' or not video.get('supported_hosts') or urlparse(target).path != '/api/channels/show.php':
        return None
    configs = get('hosts/config')
    config = next((c for c in configs if c.get('host_id') == 'ostvapp' and c.get('enabled') and re.search(c.get('regex_pattern') or '(?!)', target, re.I)), None)
    if not config:
        raise RuntimeError(u'لا يتوفر إعداد محلّل القنوات من المصدر حاليًا')
    steps = json.loads(config['urlsite'])['steps']
    first = steps['step1_prepare']['force_url']
    last = steps['stepfinal']['force_url']
    base = 'https://flech.tn/scrapefinal/oscar/'
    if first != base + 'step1_prepare_oscar.php' or last != base + 'step_final_oscar.php':
        raise ValueError('Unsupported live configuration')
    prepared, unused = live_json(session, first, data={'url': target})
    provider = prepared.get('url') or ''
    parsed = urlparse(provider)
    if not prepared.get('header_for_next_step') or parsed.scheme != 'https' or (not parsed.hostname) or parsed.username:
        raise ValueError('Invalid live preparation')
    h = prepared.get('headers') or {}
    if not isinstance(h, dict) or len(h) > 32 or any((re.search('[\\r\\n]', str(k) + str(v)) for k, v in h.items())):
        raise ValueError('Invalid live headers')
    h = {k: str(v) for k, v in h.items() if k.lower() not in ('host', 'connection', 'content-length')}
    payload, resolved = live_json(session, provider, headers=h)
    final, unused = live_json(session, last, data={'response': json.dumps(payload, separators=(',', ':'), ensure_ascii=False), 'url': resolved})
    sources = []
    for value in (final.get('qualities') or [])[:6]:
        url = value.get('url') or ''
        if urlparse(url).scheme not in ('http', 'https'):
            continue
        headers = dict(value.get('headers') or {})
        if value.get('user_agent'):
            headers['User-Agent'] = value['user_agent']
        if value.get('cookies') and (not any((k.lower() == 'cookie' for k in headers))):
            headers['Cookie'] = value['cookies']
        if any((re.search('[\\r\\n]', str(k) + str(v)) for k, v in headers.items())):
            raise ValueError('Invalid playback headers')
        sources.append({'url': url, 'label': value.get('quality') or 'Auto', 'direct': True, 'headers': headers})
    if not sources:
        raise RuntimeError(u'لم يُرجع محلّل القناة رابط فيديو')
    diagnostic('live-prepared', target)
    return sources

def resolve(item):
    video = item['video']
    link = video['link']
    headers = {'User-Agent': video.get('useragent') or web.UA}
    raw_header = video.get('header') or ''
    if raw_header.startswith(('http://', 'https://')):
        headers['Referer'] = raw_header
    elif raw_header:
        for field in raw_header.split('|'):
            key, sep, value = field.partition(':')
            if sep and key.strip().lower() in ('referer', 'origin', 'user-agent') and (not re.search('[\\r\\n]', value)):
                headers[key.strip()] = value.strip()
    with requests.Session() as session:
        session._alkuds_nxsha_deadline = time.monotonic() + 30
        from .cinenxsha import prepare
        try:
            live = live_sources(session, item)
        except Exception as error:
            diagnostic('live-prepare-failed', link, error)
            raise RuntimeError(u'تعذر تجهيز القناة (%s). السجل: /tmp/alkuds-egyapp.log' % type(error).__name__)
        queue = live if live is not None else [{'url': link, 'label': video.get('server') or 'Original'}]
        streams = []
        seen = set()
        last_error = None
        diagnostic('resolve-start', link)
        for unused in range(8):
            if not queue or (streams and live is None) or time.monotonic() > session._alkuds_nxsha_deadline:
                break
            source = queue.pop(0)
            url = source['url']
            if url in seen:
                continue
            seen.add(url)
            try:
                if '/api/' in urlparse(url).path and (not re.search('\\.(?:m3u8|mp4)(?:\\?|$)', url, re.I)):
                    with session.get(url, headers=headers, timeout=(4, 8), stream=True) as response:
                        response.raise_for_status()
                        body = response.raw.read(1024 * 1024 + 1, decode_content=True)
                    if len(body) > 1024 * 1024:
                        raise ValueError('Source response too large')
                    payload = json.loads(body.decode('utf8'))
                    values = payload.get('data') or payload.get('sources') or []
                    if isinstance(values, dict):
                        values = [values]
                    for value in values[:8]:
                        if isinstance(value, dict):
                            nested = value.get('data')
                            nested = json.loads(nested) if isinstance(nested, str) else nested or value
                            if isinstance(nested, dict) and nested.get('url'):
                                queue.append({'url': nested['url'], 'label': value.get('name') or source['label'], 'direct': nested.get('isDirect', False)})
                    continue
                candidates = [source] if source.get('direct') or re.search('\\.(?:m3u8|mp4)(?:\\?|$)', url, re.I) else web._resolve_page(session, url, headers.get('Referer') or BASE)
                for candidate in candidates[:4]:
                    h = dict(source.get('headers', headers), **candidate.get('headers') or {})
                    if candidate.get('referer'):
                        h['Referer'] = candidate['referer']
                    try:
                        for stream in prepare(session, dict(candidate, label=source['label']), h, BASE):
                            if live is not None:
                                stream['quality'] = source['label']
                            stream['relay_options'] = {'egyapp': True}
                            if stream.get('mediatype') == 'mp4':
                                stream['relay_options']['media_type'] = 'mp4'
                            stream['subtitles'] = normalise(item.get('subtitles') or [], BASE, h)
                            streams.append(stream)
                            diagnostic('video-verified', stream['url'])
                    except Exception as error:
                        last_error = error
                        diagnostic('prepare-failed', candidate.get('url', ''), error)
                        if isinstance(error, ValueError):
                            try:
                                expanded = unwrap_html(session, candidate['url'], h, source['label'])
                                queue[:0] = expanded
                                if expanded:
                                    diagnostic('html-wrapper-followed', candidate['url'])
                            except Exception as nested:
                                last_error = nested
                                diagnostic('wrapper-failed', candidate['url'], nested)
            except requests.HTTPError as error:
                diagnostic('source-http-failed', url, error)
                if not queue:
                    raise RuntimeError(u'الخادم رفض الطلب (HTTP %s)؛ اختر خادمًا آخر' % error.response.status_code)
        if not streams:
            raise RuntimeError(u'تعذر تجهيز الفيديو (%s). السجل: /tmp/alkuds-egyapp.log' % (type(last_error).__name__ if last_error else 'NoVideo'))
    return dict(item, name=item.get('title') or item['name'], streams=streams)
