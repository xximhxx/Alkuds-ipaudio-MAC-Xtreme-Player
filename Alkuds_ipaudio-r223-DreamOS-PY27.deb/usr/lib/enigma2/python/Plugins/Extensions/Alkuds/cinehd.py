# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""CineHD catalogue and public player flow. Links are resolved on the receiver."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
from .py2compat import io_module as io
from .py2compat import json
from .py2compat import re
import sys
from .py2compat import time
import uuid
from .py2compat import requests
try:
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
    urlencode = urllib.parse.urlencode
except ImportError:
    from urlparse import urljoin, urlparse
    from urllib import urlencode
from . import arabseed as a
from .subtitledata import normalise
BASE = 'https://cinehd.vc/'
SECTIONS = [('browse', u'تصفح الموقع', 'all'), ('movies', u'الأفلام', 'movie'), ('foreign_series', u'المسلسلات', 'tv'), ('anime', u'أنمي', 'anime'), ('trending', u'الأكثر مشاهدة', 'all'), ('now_playing', u'أضيف حديثاً', 'movie')]
SECTION_MAP = dict(((key, (label, kind)) for key, label, kind in SECTIONS))
_common_cache = ('', 0)

def diagnostic(stage, error=None):
    try:
        from .py2compat import os
        path = '/tmp/alkuds_cinehd.log'
        mode = 'w' if os.path.exists(path) and os.path.getsize(path) > 32768 else 'a'
        status = getattr(getattr(error, 'response', None), 'status_code', '')
        with open(path, mode) as handle:
            handle.write('%s %s %s %s\n' % (time.strftime('%H:%M:%S'), stage, type(error).__name__ if error else 'OK', status))
    except Exception:
        pass

def fresh_url(url):
    return url + ('&' if '?' in url else '?') + urlencode({'_alkuds': uuid.uuid4().hex})

def get(session, url, referer=BASE, as_json=False):
    response = session.get(urljoin(BASE, url), headers={'User-Agent': a.UA, 'Referer': referer}, timeout=(5, 15))
    response.raise_for_status()
    return response.json() if as_json else response.content.decode('utf-8', 'replace')

def common(session):
    global _common_cache
    if _common_cache[0] and time.time() - _common_cache[1] < 1800:
        return _common_cache[0]
    home = get(session, 'home')
    path = re.search('src="([^\\x22]*chunks/common[^\\x22]+\\.js)"', home)
    if not path:
        raise RuntimeError('CineHD player configuration is unavailable')
    value = get(session, path.group(1))
    _common_cache = (value, time.time())
    return value

def groups():
    return [{'name': u'البحث في كل الأقسام', 'action': 'search', 'section': 'browse'}] + [{'name': label, 'section': key} for key, label, kind in SECTIONS]

def row(value, kind):
    kind = value.get('media_type') or kind
    kind = 'tv' if kind == 'tv' or value.get('name') else 'movie'
    title = value.get('title') or value.get('name') or ''
    return {'name': title, 'title': title, 'id': str(value['id']), 'kind': kind, 'url': urljoin(BASE, '%s/%s' % (kind, value['id'])), 'is_series': kind == 'tv', 'image': 'https://image.tmdb.org/t/p/w500' + value['poster_path'] if value.get('poster_path') else '', 'category': str(value.get('release_date') or value.get('first_air_date') or '')[:4], 'quality': str(value.get('vote_average') or '')}

def fetch_items(section='browse', page=1, query='', order='latest'):
    kind = SECTION_MAP.get(section, ('', 'all'))[1]
    params = {'type': 'all' if kind == 'anime' else kind, 'page': page, 'sort': 'popularity', 'genre': '16' if kind == 'anime' else 'all', 'year': 'all', 'watch_provider': 'all', 'country': 'all', 'rating': 'all', 'trending': 'true' if section == 'trending' else 'false', 'now_playing': 'true' if section == 'now_playing' else 'false'}
    if query:
        params['q'] = query
    with requests.Session() as session:
        value = get(session, 'api/search/discover?' + urlencode(params), as_json=True)
    entries = [row(x, kind) for x in value.get('results', []) if x.get('id') and (x.get('title') or x.get('name'))]
    if order in ('az', 'za'):
        entries.sort(key=lambda x: x['name'].lower(), reverse=order == 'za')
    return {'entries': entries, 'total': len(entries), 'page': page, 'last_page': int(value.get('total_pages') or page), 'has_next': page < int(value.get('total_pages') or page)}

def detail(session, item):
    text = get(session, item['url'])
    flight = ''
    for match in re.finditer('self\\.__next_f\\.push\\((\\[.*?\\])\\)</script>', text):
        try:
            part = json.loads(match.group(1))
            if len(part) > 1 and isinstance(part[1], str):
                flight += part[1]
        except ValueError:
            pass
    decoder = json.JSONDecoder()
    for match in re.finditer('\\{', flight):
        try:
            value, used = decoder.raw_decode(flight[match.start():])
            if isinstance(value, dict) and str(value.get('id')) == str(item['id']) and ('seasons' in value or 'imdb_id' in value):
                return value
        except ValueError:
            pass
    if item['kind'] == 'movie':
        key = re.search('api_key=[^\\x22]*\\x22\\)\\.concat\\(\\x22([0-9a-f]{32})\\x22', common(session))
        if key:
            return get(session, 'https://api.themoviedb.org/3/movie/%s?language=en-US&api_key=%s' % (item['id'], key.group(1)), as_json=True)
    raise RuntimeError('CineHD did not return the film/series details')

def seasons(item):
    with requests.Session() as session:
        value = detail(session, item)
    entries = []
    for season in sorted(value.get('seasons') or [], key=lambda x: x.get('season_number', 0)):
        if not season.get('episode_count'):
            continue
        result = dict(item)
        result.update(name=u'الموسم %d  |  %s' % (season['season_number'], season.get('name') or ''), season=season['season_number'], series_title=item['name'], is_series=False, episode_count=season['episode_count'], episode_query=True)
        entries.append(result)
    return entries

def episodes(item, page=1):
    with requests.Session() as session:
        script = common(session)
        key = re.search('api_key=[^\\x22]*\\x22\\)\\.concat\\(\\x22([0-9a-f]{32})\\x22', script)
        if not key:
            raise RuntimeError('CineHD episode configuration changed')
        url = 'https://api.themoviedb.org/3/tv/%s/season/%s?language=en-US&api_key=%s' % (item['id'], item['season'], key.group(1))
        value = get(session, url, as_json=True)
    entries = []
    for episode in sorted(value.get('episodes') or [], key=lambda x: x['episode_number']):
        result = dict(item)
        result.update(name=u'الحلقة %d  |  %s' % (episode['episode_number'], episode.get('name') or ''), title=item['series_title'], episode=episode['episode_number'], season=None, season_number=item['season'], episode_query=False, is_series=False, url=urljoin(BASE, 'tv/%s?season=%s&episode=%s' % (item['id'], item['season'], episode['episode_number'])))
        entries.append(result)
    return {'entries': entries, 'total': len(entries), 'page': 1, 'last_page': 1, 'has_next': False}

def servers(item):
    with requests.Session() as session:
        script = common(session)
        if item['kind'] == 'movie':
            value = detail(session, item)
            imdb = value.get('imdb_id') or ''
        else:
            imdb = ''
    start = script.index('L=[{name:"Max"') if item['kind'] == 'movie' else script.index('O=[{name:"Max"')
    block = script[start:script.index('}]', start) + 2]
    entries = []
    for obj in block[3:-1].split('},{'):
        fields = dict(re.findall('(name|url|idType|urlFormat|extraParams):"([^\\x22]*)"', obj))
        if not fields.get('url') or not fields.get('name'):
            continue
        ident = imdb if fields.get('idType') == 'imdb' else item['id']
        if not ident:
            continue
        url = fields['url']
        if item['kind'] == 'movie':
            url = url.replace('{id}', ident)
        else:
            season, ep = (item['season_number'], item['episode'])
            fmt = fields.get('urlFormat', '')
            suffix = re.sub('\\bid\\b', ident, fmt or 'id/season/episode')
            suffix = suffix.replace('season', str(season)).replace('episode', str(ep))
            url += suffix
        url += fields.get('extraParams', '')
        result = dict(item)
        result.update(name=fields['name'], title=item['name'], server_url=urljoin(BASE, url), referer=BASE)
        entries.append(result)
    return entries

def decode_urls(session, value, referer):
    urls = value.get('data', {}).get('stream_urls') or []
    if isinstance(urls, list):
        return urls
    if sys.version_info < (2, 7):
        raise RuntimeError('Max requires Python 2.7 or newer.')
    from .cinewasm import Runtime, ModuleDesc
    envelope = value.get('vs') or {}
    if envelope.get('wasm_url'):
        response = session.get(fresh_url(urljoin(referer, envelope['wasm_url'])), headers={'Referer': referer, 'User-Agent': a.UA, 'Cache-Control': 'no-cache'}, timeout=(5, 12))
        response.raise_for_status()
        wasm = response.content
    else:
        wasm = base64.b64decode(envelope.get('wasm') or '')
    if len(wasm) > 65536:
        raise RuntimeError('CineHD decoder exceeds supported size')
    if not wasm.startswith(b'\x00asm\x01\x00\x00\x00'):
        raise ValueError('CineHD returned an invalid decoder')
    module = ModuleDesc.from_reader(io.BytesIO(wasm))
    if module.imps or module.star >= 0 or any((m.limits.n > 64 for m in module.mems)):
        raise RuntimeError('Unsupported CineHD decoder')
    for memory in module.mems:
        memory.limits.m = min(memory.limits.m or 64, 64)
    runtime = Runtime()
    runtime.machine.alkuds_deadline = time.time() + 10
    instance = runtime.instance(module)
    encoded = base64.b64decode(urls)
    if len(encoded) > 65536:
        raise RuntimeError('CineHD response exceeds supported size')
    pointer = runtime.invocate(instance, 'alloc', [len(encoded)])[0]
    memory = runtime.exported_memory(instance, 'memory')
    memory.data[pointer:pointer + len(encoded)] = encoded
    length = runtime.invocate(instance, 'decrypt', [pointer, len(encoded)])[0]
    if not 0 <= length <= len(encoded) - 12:
        raise RuntimeError('Invalid CineHD URL response')
    result = bytes(memory.data[pointer + 12:pointer + 12 + length]).decode('utf-8').splitlines()
    if not result or any((not x.startswith(('https://', 'http://')) or any((ord(ch) < 32 for ch in x)) for x in result)):
        raise ValueError('Invalid CineHD URL response')
    return result

def playback_urls(session, source_api, player):
    for attempt in range(2):
        try:
            diagnostic('stream-data-%d' % (attempt + 1))
            value = get(session, fresh_url(source_api), player, True)
            urls = decode_urls(session, value, player)
            diagnostic('stream-data-decoded')
            return (value, urls)
        except (UnicodeError, ValueError) as error:
            diagnostic('stream-data-invalid', error)
            if attempt:
                raise RuntimeError('CineHD returned invalid playback data after refresh. See /tmp/alkuds_cinehd.log')

def resolve_max(session, item):
    page = get(session, item['server_url'], BASE)
    api = re.search('data-api="([^\\x22]+)"', page)
    if not api:
        raise RuntimeError('Max player changed')
    from .subtitledata import unescape
    inner = get(session, urljoin(item['server_url'], unescape(api.group(1))), item['server_url'], True)['src']
    page = get(session, inner, item['server_url'])
    cfg = json.loads(re.search('window.CFG\\s*=\\s*(\\{.*?\\});', page).group(1))
    player = urljoin(inner, cfg['playerUrl'])
    page = get(session, player, inner)
    cfg = json.loads(re.search('window.CONFIG\\s*=\\s*(\\{.*?\\});', page).group(1))
    source_api = cfg.get('api') or cfg['streamBase'] + '&season=%s&episode=%s&stream_urls' % (cfg['season'], cfg['episode'])
    value, urls = playback_urls(session, source_api, player)
    headers = {'Referer': a._referer(player), 'User-Agent': a.UA}
    tracks = normalise(value.get('default_subs') or value.get('data', {}).get('default_subs') or [], player, headers)
    from .freeproviders import hls_variant_streams
    streams = []
    for index, raw in enumerate(urls[:4]):
        if not raw.startswith(('https://', 'http://')):
            continue
        try:
            origin = urlparse(raw)
            token_text = get(session, '%s://%s/generate.php' % (origin.scheme, origin.netloc), player).strip()
            try:
                token = json.loads(token_text)
                token = token.get('token') or token.get('data', {}).get('token') if isinstance(token, dict) else str(token)
            except ValueError:
                token = token_text
            url = raw.replace('__TOKEN__', token) if '__TOKEN__' in raw else raw + ('&' if '?' in raw else '?') + urlencode({'token': token})
            check = session.get(url, headers=headers, timeout=(4, 8))
            check.raise_for_status()
            if '#EXTM3U' not in check.text[:200]:
                continue
            search = {'imdb': str(value.get('data', {}).get('imdb_id') or '').replace('tt', ''), 'season': cfg.get('season'), 'episode': cfg.get('episode')}
            candidate = {'url': url, 'headers': headers, 'relay': True, 'mediatype': 'hls', 'relay_options': {'cinehd': True}, 'quality': 'Auto', 'subtitles': tracks, 'subtitle_search': search}
            streams.extend(hls_variant_streams(candidate))
            if streams:
                break
        except Exception:
            continue
    return streams

def resolve_one(item):
    with requests.Session() as session:
        if item['name'] == 'Nxsha':
            from .cinenxsha import resolve as resolve_nxsha
            streams = resolve_nxsha(session, item, a.UA)
        elif item['name'] == 'Max':
            streams = resolve_max(session, item)
        else:
            from .freeproviders import hls_variant_streams
            streams = []
            for source in a._resolve_page(session, item['server_url'], item['referer']):
                candidate = dict(source)
                candidate.update(headers={'User-Agent': a.UA, 'Referer': a._referer(source['referer'])}, relay=True)
                streams.extend(hls_variant_streams(candidate))
    if not streams:
        raise RuntimeError('This CineHD player did not return an available stream. Choose Max or another player.')
    result = dict(item)
    result.update(name=item.get('title', item['name']), streams=streams)
    return result

def resolve(item):
    try:
        result = resolve_one(item)
        diagnostic('player-resolved')
        return result
    except Exception as original:
        diagnostic('selected-player-failed', original)
        try:
            base = dict(item, name=item.get('title') or item.get('name'))
            choices = servers(base)
        except Exception:
            raise RuntimeError(u'CineHD: تعذر تحديث قائمة المشغلات. راجع /tmp/alkuds_cinehd.log')
        for name in ('Nxsha', 'Max'):
            if name == item.get('name'):
                continue
            candidate = next((row for row in choices if row['name'] == name), None)
            if candidate is None:
                continue
            try:
                result = resolve_one(candidate)
                for stream in result['streams']:
                    stream['quality'] = name + ' | ' + str(stream.get('quality') or 'Auto')
                diagnostic('fallback-' + name + '-resolved')
                return result
            except Exception as error:
                diagnostic('fallback-' + name + '-failed', error)
        raise RuntimeError(u'CineHD: لم يرجع المشغّل أو البدائل فيديو صالحًا الآن. راجع /tmp/alkuds_cinehd.log')
