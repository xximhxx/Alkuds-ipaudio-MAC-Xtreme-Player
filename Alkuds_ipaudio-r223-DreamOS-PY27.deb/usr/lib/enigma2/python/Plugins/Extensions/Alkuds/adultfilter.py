# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Local, per-account adult bouquet visibility. No network or credentials stored."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import hashlib
from .py2compat import json
from .py2compat import os
from .py2compat import re
from .py2compat import threading
import unicodedata
STORE = '/etc/enigma2/alkuds/adult-block.json'
LOCK = threading.RLock()
WORDS = re.compile('(?<![a-z0-9])(?:xxx|porn(?:o|ography)?|adult(?:s|e|o|os)?|nsfw|erotic(?:a)?|erotik|playboy|penthouse|hustler|brazzers|redtube|xvideos|18\\s*(?:\\+|plus)|\\+\\s*18)(?![a-z0-9])', re.I)
ARABIC = re.compile(u'اباح|إباح|للكبار|جنس(?:ية|يه)|سكس|بورن')

def identity(kind, item):
    info = item.get('playlist_info', {}) if kind == 'xtream' else item
    keys = ('host', 'domain', 'username', 'password') if kind == 'xtream' else ('portal', 'mac')
    raw = json.dumps([kind] + [info.get(k, '') for k in keys], ensure_ascii=True)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()

def read_all():
    try:
        with open(STORE, 'r') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (IOError, ValueError):
        return {}

def _write(data):
    parent = os.path.dirname(STORE)
    if not os.path.isdir(parent):
        os.makedirs(parent)
    temporary = STORE + '.tmp'
    with open(temporary, 'w') as handle:
        json.dump(data, handle)
    os.chmod(temporary, 384)
    getattr(os, 'replace', os.rename)(temporary, STORE)

def enabled(kind, item):
    return True

def set_enabled(kind, item, value):
    with LOCK:
        data = read_all()
        entry = data.setdefault(identity(kind, item), {})
        entry['enabled'] = True
        _write(data)

def adult(row):
    if not isinstance(row, dict):
        return False
    for key in ('is_adult', 'adult', 'censored'):
        if str(row.get(key, '')).lower() in ('1', 'true', 'yes'):
            return True
    text = ' '.join((str(row.get(k, '') or '') for k in ('category_name', 'name', 'title', 'genre_name')))
    text = unicodedata.normalize('NFKC', text).replace('_', ' ')
    text = ''.join((c for c in text if unicodedata.category(c) not in ('Mn', 'Cf')))
    return bool(WORDS.search(text) or ARABIC.search(text))

def categories(kind, account, section, rows):
    rows = rows if isinstance(rows, list) else []
    if not enabled(kind, account):
        return rows
    ids = [str(row.get('category_id', row.get('id', row.get('genre_id', '')))) for row in rows if adult(row)]
    ids = [value for value in ids if value not in ('', '*', '0', '-1', '-2')]
    with LOCK:
        data = read_all()
        entry = data.setdefault(identity(kind, account), {'enabled': True})
        previous = entry.setdefault('categories', {}).get(section, [])
        if previous != ids:
            entry['categories'][section] = ids
            _write(data)
    return [row for row in rows if not adult(row)]

def items(kind, account, section, rows):
    if not isinstance(rows, list) or not enabled(kind, account):
        return rows
    with LOCK:
        blocked = set(read_all().get(identity(kind, account), {}).get('categories', {}).get(section, []))
    result = []
    for row in rows:
        if not isinstance(row, dict):
            result.append(row)
            continue
        values = row.get('category_ids') or [row.get('category_id', row.get('tv_genre_id', row.get('genre_id', '')))]
        if not isinstance(values, (list, tuple)):
            values = [values]
        if not adult(row) and (not any((str(value) in blocked for value in values))):
            result.append(row)
    return result
