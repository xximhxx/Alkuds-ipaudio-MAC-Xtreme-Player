# -*- coding: utf-8 -*-
"""Module-local Python 2 adapters. No system modules/builtins are modified."""
from __future__ import absolute_import, division, print_function
import __builtin__ as native
import os as _os
import time as _time
import re as _re
import shutil as _shutil
import subprocess as _subprocess
import threading as _threading
import socket as _socket
import json as _json
import math as _math
import io
import binascii
import base64
import ctypes
import collections
import hmac
import cgi
import HTMLParser
import urllib as _urllib
import urllib2
import urlparse
import Cookie
import BaseHTTPServer
import SocketServer
import ConfigParser as _configparser
import datetime as _datetime
import calendar
import xml.etree.ElementTree as _ElementTree
from Plugins.Extensions.Alkuds._vendor.future.types.newstr import newstr as str
from Plugins.Extensions.Alkuds._vendor.future.types.newbytes import newbytes as bytes
from Plugins.Extensions.Alkuds._vendor.future.types.newint import newint as int
from Plugins.Extensions.Alkuds._vendor.future.types.newrange import newrange as range
from Plugins.Extensions.Alkuds._vendor import ipaddress
from Plugins.Extensions.Alkuds._vendor import futures

class Proxy(object):
    def __init__(self,module,**values):
        self._module=module;self.__dict__.update(values)
    def __getattr__(self,name):return getattr(self._module,name)

def fullmatch(pattern,value,flags=0):
    match=_re.match(pattern,value,flags)
    return match if match and match.end()==len(value) else None

def makedirs(path,mode=0o777,exist_ok=False):
    try:_os.makedirs(path,mode)
    except OSError:
        if not exist_ok or not _os.path.isdir(path):raise

def monotonic():
    if _os.name=='nt':return _time.clock()
    class Timespec(ctypes.Structure):
        _fields_=[('tv_sec',ctypes.c_long),('tv_nsec',ctypes.c_long)]
    value=Timespec()
    for library in (None,'librt.so.1'):
        try:
            if ctypes.CDLL(library).clock_gettime(1,ctypes.byref(value))==0:
                return value.tv_sec+value.tv_nsec/1000000000.0
        except (AttributeError,OSError):pass
    return _time.time()

class TextFile(object):
    def __init__(self,handle):self.handle=handle
    def __enter__(self):return self
    def __exit__(self,*args):return self.handle.__exit__(*args)
    def __iter__(self):return iter(self.handle)
    def __getattr__(self,name):return getattr(self.handle,name)
    def write(self,value):
        if isinstance(value,native.str):value=value.decode('utf8')
        return self.handle.write(value)
    def writelines(self,values):
        for value in values:self.write(value)

def open(path,mode='r',buffering=-1,encoding=None,errors=None,newline=None,**kwargs):
    if 'x' in mode:
        descriptor=_os.open(path,_os.O_CREAT|_os.O_EXCL|_os.O_WRONLY,0o600)
        path,mode=descriptor,mode.replace('x','w')
        return TextFile(io.open(path,mode,buffering,encoding or 'utf8',errors or 'strict',newline))
    if 'b' in mode:return native.open(path,mode,buffering)
    return TextFile(io.open(path,mode,buffering,encoding or 'utf8',errors or 'strict',newline))

def fdopen(fd,mode='r',buffering=-1,encoding=None,errors=None,newline=None):
    if encoding or errors or newline is not None:
        return TextFile(io.open(fd,mode,buffering,encoding or 'utf8',errors or 'strict',newline))
    return _os.fdopen(fd,mode,buffering)

class Thread(_threading.Thread):
    def __init__(self,*args,**kwargs):
        daemon=kwargs.pop('daemon',None)
        _threading.Thread.__init__(self,*args,**kwargs)
        if daemon is not None:self.daemon=daemon

class StringIO(io.StringIO):
    def write(self,value):
        if isinstance(value,native.str):value=value.decode('utf8')
        return io.StringIO.write(self,value)

class ConfigParser(_configparser.RawConfigParser):
    def __init__(self,*args,**kwargs):
        kwargs.pop('interpolation',None);kwargs.pop('strict',None)
        _configparser.RawConfigParser.__init__(self,*args,**kwargs)
    def read_file(self,stream,source=None):return self.readfp(stream)
    def read(self,filenames,encoding=None):
        if isinstance(filenames,basestring):filenames=[filenames]
        result=[]
        for name in filenames:
            try:
                with open(name,encoding=encoding or 'utf-8-sig') as handle:self.readfp(handle)
                result.append(name)
            except (IOError,OSError):pass
        return result
    def get(self,section,option,raw=False,vars=None,**kwargs):
        if 'fallback' in kwargs and not self.has_option(section,option):return kwargs['fallback']
        return _configparser.RawConfigParser.get(self,section,option)
    def getboolean(self,section,option,raw=False,vars=None,**kwargs):
        if 'fallback' in kwargs and not self.has_option(section,option):
            return kwargs['fallback']
        return _configparser.RawConfigParser.getboolean(self,section,option)
    def getint(self,section,option,raw=False,vars=None,**kwargs):
        if 'fallback' in kwargs and not self.has_option(section,option):
            return kwargs['fallback']
        return _configparser.RawConfigParser.getint(self,section,option)
    def getfloat(self,section,option,raw=False,vars=None,**kwargs):
        if 'fallback' in kwargs and not self.has_option(section,option):
            return kwargs['fallback']
        return _configparser.RawConfigParser.getfloat(self,section,option)
    def write(self,stream):
        sections=[]
        if self._defaults:sections.append(('DEFAULT',self._defaults))
        sections.extend((name,self._sections[name]) for name in self._sections)
        for section,values in sections:
            stream.write(u'[%s]\n'%str(section))
            for key,value in values.items():
                if key=='__name__':continue
                stream.write(str(key)+u' = '+str(value or '').replace(u'\n',u'\n\t')+u'\n')
            stream.write(u'\n')

class TimeoutExpired(Exception):
    def __init__(self,cmd,timeout,output=None,stderr=None):
        self.cmd,self.timeout,self.output,self.stderr=cmd,timeout,output,stderr
        Exception.__init__(self,'Process timed out')

class Popen(_subprocess.Popen):
    def __init__(self,args,*positional,**kwargs):
        self.args=args
        if kwargs.pop('text',False):kwargs['universal_newlines']=True
        kwargs.pop('encoding',None);kwargs.pop('errors',None)
        session=kwargs.pop('start_new_session',False)
        keep=tuple(kwargs.pop('pass_fds',()))
        previous=kwargs.get('preexec_fn')
        if _os.name=='posix' and (keep or session):
            import fcntl
            descriptors=[]
            for name in _os.listdir('/proc/self/fd'):
                if not name.isdigit():continue
                descriptor=native.int(name)
                try:fcntl.fcntl(descriptor,fcntl.F_GETFD);descriptors.append(descriptor)
                except EnvironmentError:pass
            existing=tuple(descriptors)
            def child_setup():
                if session:_os.setsid()
                if previous:previous()
                for descriptor in existing:
                    if descriptor>2 and descriptor not in keep:
                        try:_os.close(descriptor)
                        except EnvironmentError:pass
                for descriptor in keep:
                    fcntl.fcntl(descriptor,fcntl.F_SETFD,fcntl.fcntl(descriptor,fcntl.F_GETFD)&~fcntl.FD_CLOEXEC)
            kwargs['preexec_fn']=child_setup;kwargs['close_fds']=False
        _subprocess.Popen.__init__(self,args,*positional,**kwargs)
    def communicate(self,input=None,timeout=None):
        if timeout is None and not hasattr(self,'_alkuds_communication'):
            return _subprocess.Popen.communicate(self,input)
        if not hasattr(self,'_alkuds_communication'):
            state={}
            def run():
                try:state['result']=_subprocess.Popen.communicate(self,input)
                except BaseException as error:state['error']=error
            task=Thread(target=run,daemon=True);self._alkuds_communication=(task,state);task.start()
        task,state=self._alkuds_communication;task.join(timeout)
        if task.is_alive():raise TimeoutExpired(self.args if hasattr(self,'args') else '',timeout)
        if 'error' in state:raise state['error']
        return state.get('result',(None,None))
    def wait(self,timeout=None):
        if timeout is None:return _subprocess.Popen.wait(self)
        deadline=monotonic()+timeout
        while self.poll() is None:
            if monotonic()>=deadline:raise TimeoutExpired('',timeout)
            _time.sleep(.02)
        return self.returncode

class CompletedProcess(object):
    def __init__(self,args,returncode,stdout=None,stderr=None):
        self.args,self.returncode,self.stdout,self.stderr=args,returncode,stdout,stderr

def run(args,**kwargs):
    timeout=kwargs.pop('timeout',None);check=kwargs.pop('check',False)
    input=kwargs.pop('input',None);capture=kwargs.pop('capture_output',False)
    text=kwargs.pop('text',False);kwargs.pop('encoding',None)
    if capture:kwargs.update(stdout=_subprocess.PIPE,stderr=_subprocess.PIPE)
    if input is not None:kwargs['stdin']=_subprocess.PIPE
    process=Popen(args,**kwargs)
    try:out,err=process.communicate(input,timeout)
    except TimeoutExpired:
        process.kill();process.communicate();raise
    if text:
        out=out.decode('utf8','replace') if out is not None else None
        err=err.decode('utf8','replace') if err is not None else None
    if check and process.returncode:raise _subprocess.CalledProcessError(process.returncode,args,out)
    return CompletedProcess(args,process.returncode,out,err)

def call(args,**kwargs):return run(args,**kwargs).returncode
def check_call(args,**kwargs):
    kwargs['check']=True
    return run(args,**kwargs).returncode
def check_output(args,**kwargs):
    kwargs.update(stdout=_subprocess.PIPE,check=True)
    return run(args,**kwargs).stdout

def which(command):
    for directory in _os.environ.get('PATH','').split(_os.pathsep):
        candidate=_os.path.join(directory,command)
        if _os.path.isfile(candidate) and _os.access(candidate,_os.X_OK):return candidate
    return None

def disk_usage(path):
    stat=_os.statvfs(path)
    return collections.namedtuple('usage','total used free')(
        stat.f_blocks*stat.f_frsize,(stat.f_blocks-stat.f_bfree)*stat.f_frsize,stat.f_bavail*stat.f_frsize)

def byte_hex(value):return binascii.hexlify(native.str(bytearray(value))).decode('ascii')
def to_bytes(value,length,byteorder='big',signed=False):return int(value).to_bytes(length,byteorder,signed=signed)
def clear(value):
    if hasattr(value,'clear'):return value.clear()
    del value[:]
def copy(value):return value.copy() if hasattr(value,'copy') else value[:]

class Socket(_socket.socket):
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

def if_nameindex():
    try:return list(enumerate(_os.listdir('/sys/class/net'),1))
    except OSError:return []

class ThreadingHTTPServer(SocketServer.ThreadingMixIn,BaseHTTPServer.HTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    def __enter__(self):return self
    def __exit__(self,*args):self.server_close()

class Html(object):
    @staticmethod
    def unescape(value):return HTMLParser.HTMLParser().unescape(value)
    @staticmethod
    def escape(value,quote=True):
        value=cgi.escape(value,quote)
        return value.replace("'",'&#x27;') if quote else value

class FixedOffset(_datetime.tzinfo):
    def __init__(self,seconds):self.offset=_datetime.timedelta(seconds=seconds)
    def utcoffset(self,dt):return self.offset
    def dst(self,dt):return _datetime.timedelta(0)
    def tzname(self,dt):return 'UTC'

class DateTime(_datetime.datetime):
    @classmethod
    def fromisoformat(cls,value):
        value=str(value).replace('Z','+00:00')
        match=_re.match(r'^(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d)(?::(\d\d)(?:\.(\d+))?)?([+-]\d\d:\d\d)?$',value)
        if not match:raise ValueError('Invalid ISO timestamp')
        year,month,day,hour,minute,second,micro,zone=match.groups()
        info=None
        if zone:
            offset=(native.int(zone[1:3])*60+native.int(zone[4:]))*60
            info=FixedOffset(-offset if zone[0]=='-' else offset)
        return cls(*[native.int(x) for x in (year,month,day,hour,minute,second or 0)],
                   microsecond=native.int(((micro or '')+'000000')[:6]),tzinfo=info)
    def timestamp(self):
        if self.tzinfo:return calendar.timegm(self.utctimetuple())+self.microsecond/1000000.0
        return _time.mktime(self.timetuple())+self.microsecond/1000000.0
    def astimezone(self,tz=None):
        if tz is None:
            stamp=self.timestamp();local=_time.localtime(stamp)
            tz=FixedOffset(-(_time.altzone if local.tm_isdst>0 and _time.daylight else _time.timezone))
        return _datetime.datetime.astimezone(self,tz)

def xml_tostring(element,encoding=None,**kwargs):
    if encoding=='unicode':return _ElementTree.tostring(element,encoding='utf-8',**kwargs).decode('utf8')
    return _ElementTree.tostring(element,encoding=encoding,**kwargs)

class Secrets(object):
    @staticmethod
    def token_hex(nbytes=32):return binascii.hexlify(_os.urandom(nbytes)).decode('ascii')
    @staticmethod
    def token_urlsafe(nbytes=32):return base64.urlsafe_b64encode(_os.urandom(nbytes)).rstrip('=')
    compare_digest=staticmethod(hmac.compare_digest)

def parse_qs(value,keep_blank_values=False,strict_parsing=False,max_num_fields=None,**kwargs):
    if max_num_fields is not None and len(_re.split('[&;]',value))>max_num_fields:
        raise ValueError('Too many fields')
    return urlparse.parse_qs(value,keep_blank_values,strict_parsing)

def _utf8(value):return value.encode('utf8') if isinstance(value,unicode) else value
def urlencode(value,doseq=False):
    values=value.items() if hasattr(value,'items') else value
    values=[(_utf8(k),[_utf8(x) for x in v] if doseq and isinstance(v,(list,tuple)) else _utf8(v)) for k,v in values]
    return _urllib.urlencode(values,doseq)
def quote(value,safe='/'):return _urllib.quote(_utf8(value),safe)
def quote_plus(value,safe=''):return _urllib.quote_plus(_utf8(value),safe)

class ResponseContext(object):
    def __init__(self,response):self.response=response
    def __enter__(self):return self.response
    def __exit__(self,*args):self.response.close()
    def __getattr__(self,name):return getattr(self.response,name)
    def __setattr__(self,name,value):
        if name == 'response':object.__setattr__(self,name,value)
        else:setattr(self.response,name,value)
def urlopen(*args,**kwargs):return ResponseContext(urllib2.urlopen(*args,**kwargs))

parse=Proxy(urlparse,quote=quote,quote_plus=quote_plus,unquote=_urllib.unquote,
            unquote_plus=_urllib.unquote_plus,urlencode=urlencode,parse_qs=parse_qs)
request=Proxy(urllib2,urlopen=urlopen)
urllib=Proxy(_urllib,parse=parse,request=request,error=urllib2)
html=Html();secrets=Secrets()
http_server=Proxy(BaseHTTPServer,ThreadingHTTPServer=ThreadingHTTPServer)
http_cookies=Proxy(Cookie)
time=Proxy(_time,monotonic=monotonic,perf_counter=monotonic)
os=Proxy(_os,makedirs=makedirs,replace=_os.rename,fdopen=fdopen)
re=Proxy(_re,fullmatch=fullmatch)
threading=Proxy(_threading,Thread=Thread)
subprocess=Proxy(_subprocess,Popen=Popen,run=run,call=call,check_call=check_call,check_output=check_output,TimeoutExpired=TimeoutExpired,
                 DEVNULL=native.open(_os.devnull,'r+b'))
shutil=Proxy(_shutil,which=which,disk_usage=disk_usage)
socket=Proxy(_socket,socket=Socket,if_nameindex=if_nameindex)
json=Proxy(_json,JSONDecodeError=ValueError)
math=Proxy(_math,inf=float('inf'),nan=float('nan'))
io_module=Proxy(io,StringIO=StringIO)
configparser=Proxy(_configparser,ConfigParser=ConfigParser)
ElementTree=Proxy(_ElementTree,tostring=xml_tostring)
datetime=DateTime
datetime_module=Proxy(_datetime,datetime=DateTime,timezone=Proxy(None,utc=FixedOffset(0)))
OSError=EnvironmentError
FileNotFoundError=EnvironmentError
PermissionError=EnvironmentError
ConnectionError=IOError
BrokenPipeError=IOError
BlockingIOError=IOError
TimeoutError=_socket.timeout


def gui_text(value):
    """UTF-8 native str for DreamOS Python 2 SWIG text boundaries only."""
    if value is None:
        return native.str('')
    if isinstance(value, native.unicode):
        return native.str.__str__(value.encode('utf-8', 'replace'))
    if isinstance(value, native.str):
        return native.str.__str__(value)
    if isinstance(value, bytearray):
        return native.str(value)
    return native.str(native.unicode(value).encode('utf-8', 'replace'))


def service_reference(*args):
    """Pass native Python 2 scalars into the receiver's SWIG constructor."""
    from enigma import eServiceReference
    values=[]
    for value in args:
        if isinstance(value, (native.str, native.unicode)):
            value=gui_text(value)
        elif isinstance(value, (native.int, native.long)):
            value=native.int('%d' % value)
        values.append(value)
    return eServiceReference(*values)


# Local requests facade: old DreamOS responses lack context-manager methods.
import requests as _requests
_CA_BUNDLE = _os.path.join(_os.path.dirname(__file__), 'dreamos-ca.pem')


class RequestsSession(_requests.Session):
    def __init__(self):
        _requests.Session.__init__(self)
        self.verify = _CA_BUNDLE
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def request(self, *args, **kwargs):
        kwargs.setdefault('verify', self.verify)
        if kwargs['verify'] is True:
            kwargs['verify'] = _CA_BUNDLE
        return ResponseContext(_requests.Session.request(self, *args, **kwargs))


def requests_request(method, url, **kwargs):
    session=RequestsSession()
    try:
        return session.request(method, url, **kwargs)
    finally:
        session.close()


def requests_get(url, **kwargs):return requests_request('GET', url, **kwargs)
def requests_post(url, **kwargs):return requests_request('POST', url, **kwargs)
requests=Proxy(_requests, Session=RequestsSession, session=RequestsSession,
               request=requests_request, get=requests_get, post=requests_post)
