# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Read-only native EPG and bundled channel logos; never tune to collect EPG."""
from __future__ import absolute_import, division, print_function
from .py2compat import service_reference, gui_text
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import configparser
from .py2compat import os
from .py2compat import re
from .py2compat import time
import unicodedata
import struct
MAPPING_PATH = '/etc/enigma2/alkuds_audio_epg.ini'
_services = {}
_services_until = 0
_events = {}
_aliases = {}
_aliases_stamp = None
_index_job = None
_index_timer = None
_index_connection = None
_logo_cache = {}

def _cached_logo(path):
    if path in _logo_cache:
        return _logo_cache[path]
    with open(path, 'rb') as stream:
        header = stream.read(24)
    width, height = struct.unpack('>II', header[16:24])
    from Tools.LoadPixmap import LoadPixmap
    try:
        picture = LoadPixmap(path, cached=False)
    except TypeError:
        picture = LoadPixmap(path)
    result = (width, height, picture)
    if len(_logo_cache) >= 24:
        _logo_cache.pop(next(iter(_logo_cache)))
    _logo_cache[path] = result
    return result

def ensure_mapping():
    """Create the commented example once, never overwrite a user's mappings."""
    if os.path.exists(MAPPING_PATH):
        return
    try:
        with open(os.path.join(os.path.dirname(__file__), 'audio_epg.example.ini'), encoding='utf8') as source:
            template = source.read()
        with open(MAPPING_PATH, 'x', encoding='utf8') as target:
            target.write(template)
    except OSError:
        pass

def normalized(value):
    value = unicodedata.normalize('NFKC', str(value or '')).lower()
    value = ''.join((str(unicodedata.digit(c)) if c.isdigit() else c for c in value))
    value = value.translate(str.maketrans(u'أإآ', u'ااا'))
    value = re.sub(u'(?u)' + u'[ً-ٟـ]', '', value)
    value = re.sub(u'(?u)' + u'\\b(hd|sd|fhd)([1-9])\\b', '\\1 \\2', value)
    return re.sub(u'(?u)' + u'[^\\w]+', ' ', value).strip()

def channel_key(name):
    text = normalized(name)
    if re.search(u'(?u)' + u'\\b(?:be\\s*in|بين|بي ان)\\b', text):
        if re.search(u'(?u)' + u'\\b(?:movies?|series|drama|gourmet|box office|افلام|مسلسلات)\\b', text):
            return ''
        number = re.search(u'(?u)' + u'\\b([1-9])\\b', text)
        if not number and re.search(u'(?u)' + u'\\b4k\\b', text):
            return 'bein-4k-hdr' if 'hdr' in text else 'bein-4k'
        if re.search(u'(?u)' + u'\\b(?:news|اخبار|الاخبارية)\\b', text):
            return 'bein-news'
        if 'nba' in text:
            return 'bein-nba'
        if not number:
            return 'bein'
        flavor = 'afc' if 'afc' in text else 'xtra' if re.search(u'(?u)' + u'\\b(?:xtra|extra|اكسترا)\\b', text) else 'max' if 'max' in text else 'premium' if 'premium' in text else 'english' if re.search(u'(?u)' + u'\\b(?:en|english)\\b', text) else 'french' if re.search(u'(?u)' + u'\\b(?:fr|french)\\b', text) else ''
        return 'bein-' + (flavor + '-' if flavor else '') + number.group(1)
    if re.search(u'(?u)' + u'(?:abu\\s*dhabi|abudhabi|ابو\\s*ظبي|\\bad\\b)', text):
        number = re.search(u'(?u)' + u'\\b([1-9])\\b', text)
        premium = bool(re.search(u'(?u)' + u'\\b(?:prem|premium|بريميوم)\\b', text))
        if not premium and (not re.search(u'(?u)' + u'\\b(?:sports?|الرياضية|الرياضيه|رياضة|رياضه)\\b', text)):
            return 'ad'
        return 'ad-' + ('premium-' if premium else 'sports-') + (number.group(1) if number else 'all')
    for family, pattern in (('alkass', u'(?:\\bal\\s*kass\\b|\\balkass\\b|الكاس|كاس)'), ('thmanyah', u'(?:\\bthmanyah\\b|\\bthm8h\\b|ثمانية|ثمانيه)'), ('ssc', '\\bssc\\b'), ('rabiaa', u'(?:alrabiaa|al rabiaa|الربيع|الرابعة|رابعه)')):
        if re.search(u'(?u)' + pattern, text):
            number = re.search(u'(?u)' + u'\\b(1[01]|[1-9])\\b', text)
            return family + ('-' + number.group(1) if number else '')
    if re.search(u'(?u)' + u'\\bmbc\\s*action\\b', text):
        return 'mbc-action'
    return ''

def picon_key(name, source=''):
    key = channel_key(name)
    text = normalized(name)
    if key == 'ad' and re.search(u'(?u)' + u'\\bad\\s*([1-9])\\b', text):
        return 'ad-premium-' + re.search(u'(?u)' + u'\\bad\\s*([1-9])\\b', text).group(1)
    if key:
        return key
    patterns = (u'^(?:best|orange|middle|delay|بيست|اورانج)(?:\\s+(?:low|audio|اوديو|صوت))*\\s*([1-9])$', u'^(?:sat\\s*family|سات\\s*فاميلي)(?:\\s+(?:4k|vip|low|audio))*\\s*([1-9])$', '^fox fm\\s*([1-9])$', '^anis sport\\s*([1-9])$')
    for pattern in patterns:
        match = re.match(u'(?u)' + pattern, text)
        if match:
            return 'bein-' + match.group(1)
    for family, pattern in (('bein-xtra', '\\b(?:xtra|extra)\\s*([1-9])\\b'), ('bein-english', '\\ben\\s*([1-9])\\b'), ('bein-french', '\\bfr\\s*([1-9])\\b'), ('bein-max', '\\bmax\\s*([1-9])\\b')):
        match = re.search(u'(?u)' + pattern, text)
        if match:
            return family + '-' + match.group(1)
    return ''

def picon_path(name, source=''):
    key = picon_key(name, source)
    if not key:
        return ''
    directory = os.path.join(os.path.dirname(__file__), 'common', 'audiopicons')
    family = key.split('-', 1)[0]
    candidates = (key, 'ad-sports-' + key.rsplit('-', 1)[-1] if key.startswith('ad-premium-') else key, family, 'alkass-1' if family == 'alkass' else family)
    return next((os.path.join(directory, candidate + '.png') for candidate in candidates if os.path.isfile(os.path.join(directory, candidate + '.png'))), '')

def set_channel_logo(screen, name, source='', picon_widget='channel_picon', number_widget='picon_number'):
    """Fit an original PNG in its widget rectangle, without stretching the logo."""
    path = picon_path(name, source)
    key = picon_key(name, source)
    number = key.rsplit('-', 1)[-1] if key.rsplit('-', 1)[-1].isdigit() else ''
    pixmap = screen[picon_widget]
    number_label = screen[number_widget]
    number_label.setText(number)
    instance = getattr(pixmap, 'instance', None)
    if instance is None:
        return
    if not path:
        pixmap.hide()
        return
    if getattr(pixmap, '_channel_path', None) == path:
        pixmap.show()
        return
    if not hasattr(pixmap, '_channel_box'):
        pos, size = (instance.position(), instance.size())
        pixmap._channel_box = (pos.x(), pos.y(), size.width(), size.height())
    try:
        width, height, picture = _cached_logo(path)
        x, y, bw, bh = pixmap._channel_box
        scale = min(float(bw) / width, float(bh) / height)
        width, height = (max(1, int(width * scale)), max(1, int(height * scale)))
        from enigma import eSize, ePoint
        instance.resize(eSize(width, height))
        instance.move(ePoint(x + (bw - width) // 2, y + (bh - height) // 2))
        if picture is not None and hasattr(instance, 'setPixmap'):
            instance.setPixmap(picture)
        else:
            instance.setPixmapFromFile(path)
        pixmap._channel_path = path
        pixmap.show()
    except Exception:
        pixmap.hide()

def _load_aliases():
    global _aliases, _aliases_stamp
    ensure_mapping()
    try:
        info = os.stat(MAPPING_PATH)
        stamp = (getattr(info, 'st_mtime_ns', info.st_mtime), info.st_size)
    except OSError:
        stamp = None
    if stamp == _aliases_stamp:
        return _aliases
    _aliases_stamp = stamp
    _aliases = {}
    if stamp is not None:
        try:
            parser = configparser.ConfigParser(interpolation=None)
            parser.optionxform = str
            parser.read(MAPPING_PATH, encoding='utf-8-sig')
            if parser.has_section('channels'):
                _aliases = {normalized(k): v.strip() for k, v in parser.items('channels') if v.strip()}
        except Exception:
            pass
    return _aliases

def _service_index():
    global _index_job, _index_timer, _index_connection
    now = time.monotonic()
    if now < _services_until or _index_job is not None:
        return _services
    _index_job = {'listing': None, 'center': None, 'rows': {}}
    try:
        if _index_timer is None:
            from enigma import eTimer
            _index_timer = eTimer()
            try:
                _index_connection = _index_timer.timeout.connect(_index_slice)
            except Exception:
                _index_timer.callback.append(_index_slice)
        _index_timer.start(150, True)
    except Exception:
        _finish_index(False)
    return _services

def _finish_index(success):
    global _index_job, _services, _services_until
    if success and _index_job is not None:
        _services = _index_job['rows']
    _services_until = time.monotonic() + (600 if success else 60)
    _index_job = None
    if _index_timer is not None:
        _index_timer.stop()

def _index_slice():
    job = _index_job
    if job is None:
        return
    try:
        if job['listing'] is None:
            from enigma import eServiceCenter, eServiceReference
            job['center'] = eServiceCenter.getInstance()
            job['listing'] = job['center'].list(service_reference('1:7:1:0:0:0:0:0:0:0:(type == 1) || (type == 17) || (type == 25) || (type == 31) || (type == 134) || (type == 195) ORDER BY name'))
            if job['listing'] is None:
                _finish_index(False)
                return
        started = time.monotonic()
        for _ in range(32):
            reference = job['listing'].getNext()
            if reference is None or not reference.valid():
                _finish_index(True)
                return
            info = job['center'].info(reference)
            name = info.getName(reference) if info else ''
            ref = reference.toString()
            key = channel_key(name)
            exact = normalized(name)
            if key or exact:
                if key:
                    job['rows'].setdefault(key, []).append(ref)
                job['rows'].setdefault('name:' + exact, []).append(ref)
            if time.monotonic() - started >= 0.008:
                break
        _index_timer.start(25, True)
    except Exception:
        _finish_index(False)

def native_current_event(name, item=None):
    item = item or {}
    target = str(item.get('epg_ref') or item.get('epg_name') or _load_aliases().get(normalized(name)) or name)
    explicit = bool(re.match(u'(?u)' + u'^1:[0-9a-fA-F:]+:$', target))
    index = {} if explicit else _service_index()
    key = channel_key(target)
    refs = [target] if explicit else index.get('name:' + normalized(target)) or (index.get(key) if key not in ('ad', 'bein') else []) or []
    if not refs:
        return ''
    try:
        from enigma import eEPGCache, eServiceReference
        cache = eEPGCache.getInstance()
        now = int(time.time())
        for ref in refs:
            cached = _events.get(ref)
            if cached and cached[0] > time.monotonic() and (cached[1] > now):
                return cached[2]
            event = cache.lookupEventTime(service_reference(ref), now, 0)
            if not event:
                continue
            begin, duration = (event.getBeginTime(), event.getDuration())
            title = event.getEventName()
            if title and begin <= now < begin + duration:
                caption = time.strftime('%H:%M', time.localtime(begin)) + ' | ' + str(title)
                _events[ref] = (time.monotonic() + 30, begin + duration, caption)
                return caption
    except Exception:
        pass
    return ''

def logical_key(name, item=None, source=''):
    item = item or {}
    target = item.get('epg_name') or _load_aliases().get(normalized(name)) or name
    return channel_key(target) or picon_key(target, source)

def current_event(name, item=None, source=''):
    key = logical_key(name, item, source)
    if key.startswith('bein'):
        from .sportsguide import current_caption, loading, error_caption
        caption = current_caption(key)
        if caption:
            return caption
        native = native_current_event(name, item)
        if native:
            return native
        return u'جاري جلب جدول beIN...' if loading() else error_caption() or u'لا يوجد حدث منشور حالياً'
    return native_current_event(name, item)

def iptv_guide_key(name):
    """Conservative MENA video matching; never use numbered audio aliases."""
    text = normalized(name)
    brand = re.search(u'(?u)' + u'\\b(?:be\\s*in|بين|بي\\s*ان)\\b', text)
    if not brand:
        return ''
    if re.search(u'(?u)' + u'\\b(?:movies?|series|drama|افلام|مسلسلات)(?=\\s|\\d|$)', text):
        return ''
    if 'mena' not in text and re.search(u'(?u)' + u'\\b(?:fr|french|france|us|usa|uk|tr|turkey|au|australia|th|thailand|id|indonesia|hk|sg|singapore|canada|ca)(?=\\s|\\d|$)', text):
        return ''
    if 'mena' not in text and re.search(u'(?u)' + u'\\b(?:en|english|uk)\\b', text[:brand.start()]):
        return ''
    tail = text[brand.end():]
    tail = re.sub(u'(?u)' + u'(sports?|afc|xtra|max|premium|en|fr|english|french|سبورتس?)(\\d+)\\b', '\\1 \\2', tail)
    if re.search(u'(?u)' + u'\\b(?:sports?|afc|xtra|max)\\s+(?:1[0-9]|[2-9][0-9])\\b', tail):
        return ''
    if len(set(re.findall(u'(?u)' + u'\\b[1-9]\\b', tail))) > 1:
        return ''
    if re.search(u'(?u)' + u'\\b(?:premium|بريميوم)\\b', tail):
        return ''
    key = channel_key('bein ' + tail)
    if key == 'bein' and re.sub(u'(?u)' + u'\\b(?:sports?|hd|sd|fhd|uhd|ar|arabic|عربي|الرياضية|سبورت|سبورتس|mena|qatar|hq)\\b', '', tail).strip():
        return ''
    if re.fullmatch(u'bein(?:-(?:[1-9]|(?:max|afc|xtra)-[1-9]|(?:english|french)-[12]|news|nba|4k(?:-hdr)?))?', key):
        return key
    return ''

def iptv_event_details(name):
    key = iptv_guide_key(name)
    if not key:
        return ('Event: --', '')
    from .sportsguide import current_program
    row = current_program(key)
    if not row:
        return ('Event: --', '')
    return ('Event: ' + row['title'], time.strftime('%H:%M', time.localtime(row['start'])) + ' - ' + time.strftime('%H:%M', time.localtime(row['stop'])))

def open_iptv_schedule(screen):
    current = screen['list'].getCurrent()
    try:
        name = screen.channels[int(current[1])][0] if current and int(current[1]) >= 0 else ''
    except (IndexError, TypeError, ValueError):
        name = ''
    key = iptv_guide_key(name)
    if not key:
        from .xStaticText import MessageBox
        screen.session.open(MessageBox, u'الجدول البديل متاح لقنوات beIN المطابقة فقط؛ لم يتم تحديد هذه القناة بشكل موثوق.', MessageBox.TYPE_INFO, timeout=7)
        return
    from .sportschedulescreen import AudioSchedule
    screen.session.open(AudioSchedule, name, key)
