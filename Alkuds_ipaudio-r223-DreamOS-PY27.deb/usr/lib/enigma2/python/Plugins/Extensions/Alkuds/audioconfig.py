# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Human editable provider sections; safe one-time import from old JSON stores."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import configparser
from .py2compat import json
from .py2compat import io_module as io
from .py2compat import os
from .py2compat import shutil
from .py2compat import threading
from functools import wraps
LOCK = threading.RLock()

def locked(function):

    @wraps(function)
    def call(*args, **kwargs):
        with LOCK:
            return function(*args, **kwargs)
    return call
try:
    from .py2compat import urllib
    urlparse = urllib.parse.urlparse
except ImportError:
    from urlparse import urlparse
PATH = '/etc/enigma2/alkuds_audio.ini'
HDD_PATH = '/media/hdd/alkuds_audio.ini'
KINDS = ('best_audio', 'sat_family', 'orange_audio', 'orange_goradio', 'free_audio', 'anis_audio', 'fox_audio')
LEGACY = ('/etc/enigma2/best_family_audio_sources.json', '/media/hdd/best_family_audio_sources.json', '/etc/enigma2/alkuds_audio_sources.json', '/media/hdd/alkuds_audio_sources.json', '/media/usb/alkuds_audio_sources.json')

def orange_section(kind, entry):
    if kind != 'orange_audio':
        return kind
    try:
        host = (urlparse(str(entry.get('url') or '')).hostname or '').lower()
    except ValueError:
        host = ''
    if host in ('goradio.top', 'www.goradio.top') or (not entry.get('url') and entry.get('username') and entry.get('password')):
        return 'orange_goradio'
    return kind

def load(path=PATH):
    parser = configparser.ConfigParser(interpolation=None)
    with open(path, encoding='utf-8-sig') as stream:
        parser.read_file(stream)
    data = {kind: [] for kind in KINDS}
    for section in parser.sections():
        kind = section.split(':', 1)[0]
        if kind not in data:
            continue
        entry = {k: parser.get(section, k, fallback='').strip() for k in ('name', 'url', 'username', 'password', 'token')}
        unused_host = kind in ('orange_audio', 'orange_goradio') and entry['url'].rstrip('/') in ('http://goradio.top', 'http://radio.orange-audio.top') and (not (entry['token'] or entry['username'] or entry['password']))
        if not unused_host and (entry['url'] or entry['token'] or (entry['username'] and entry['password'])):
            data[orange_section(kind, entry)].append({k: v for k, v in entry.items() if v})
    return data

def _mtime(path):
    stat = os.stat(path)
    return getattr(stat, 'st_mtime_ns', int(stat.st_mtime * 1000000000))

def _render(data, source=None):
    routed = {kind: [] for kind in KINDS}
    for kind in KINDS:
        for entry in data.get(kind) or []:
            routed[orange_section(kind, entry)].append(dict(entry))
    parser = configparser.ConfigParser(interpolation=None)
    if source and os.path.isfile(source):
        with open(source, encoding='utf-8-sig') as stream:
            parser.read_file(stream)
        for section in list(parser.sections()):
            if section.split(':', 1)[0] in KINDS:
                parser.remove_section(section)
    hosts = {'orange_audio': 'http://radio.orange-audio.top', 'orange_goradio': 'http://goradio.top'}
    for kind in KINDS:
        entries = list(routed[kind]) or [{}]
        for number, entry in enumerate(entries, 1):
            section = kind + ':' + str(number)
            parser.add_section(section)
            for key in ('name', 'url', 'username', 'password', 'token'):
                value = entry.get(key) or (hosts.get(kind, '') if key == 'url' else '')
                parser.set(section, key, str(value))
    stream = io.StringIO()
    stream.write('# Alkuds IP Audio - configuration format 2.\n# Both copies use the most recently modified file.\n# Internal: /etc/enigma2/alkuds_audio.ini\n# HDD: /media/hdd/alkuds_audio.ini\n# orange_goradio: fixed goradio.top; enter username + password.\n# orange_audio: fixed radio.orange-audio.top; enter token only.\n# sat_family also accepts username + password.\n# More subscriptions: copy a section and change :1 to :2, :3, etc.\n# Keep this file private; it contains credentials.\n\n')
    parser.write(stream)
    return stream.getvalue().encode('utf8')

def _same_bytes(path, payload):
    try:
        with open(path, 'rb') as stream:
            return stream.read() == payload
    except OSError:
        return False

def _write_config(path, payload):
    if _same_bytes(path, payload):
        return False
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + '.tmp'
    with open(tmp, 'wb') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(tmp, 384)
    os.replace(tmp, path)
    return True

def _copy_config(source, target):
    if os.path.isfile(target):
        with open(source, 'rb') as stream:
            if _same_bytes(target, stream.read()) and _mtime(source) == _mtime(target):
                return False
    os.makedirs(os.path.dirname(target), exist_ok=True)
    shutil.copy2(source, target + '.tmp')
    os.chmod(target + '.tmp', 384)
    os.replace(target + '.tmp', target)
    return True

def _persist(data, path, mirror, source=None):
    payload = _render(data, source=source or path)
    if source and (not _same_bytes(source, payload)):
        backup = source + '.pre-update.bak'
        if not os.path.exists(backup):
            shutil.copy2(source, backup)
            os.chmod(backup, 384)
    _write_config(path, payload)
    if mirror and mirror != path and os.path.isdir(os.path.dirname(mirror)):
        _copy_config(path, mirror)

@locked
def save(data, path=PATH, mirror=HDD_PATH):
    if os.path.exists(path):
        load(path)
    _persist(data, path, mirror)

@locked
def ensure(path=PATH, legacy=LEGACY, mirror=HDD_PATH):
    candidates = [candidate for candidate in (path, mirror) if candidate and os.path.isfile(candidate)]
    if candidates:
        selected = max(candidates, key=lambda candidate: (_mtime(candidate), candidate == path))
        data = load(selected)
        _persist(data, path, mirror, source=selected)
        return path
    data = {kind: [] for kind in KINDS}
    seen = {kind: set() for kind in KINDS}
    for old in legacy:
        if not os.path.isfile(old):
            continue
        with open(old, encoding='utf-8-sig') as stream:
            raw = json.load(stream)
        if not isinstance(raw, dict):
            raise ValueError('Invalid legacy audio file: ' + old)
        for kind in KINDS:
            for entry in raw.get(kind, []):
                if not isinstance(entry, dict):
                    continue
                ent = {k: str(entry.get(k) or '') for k in ('name', 'url', 'username', 'password', 'token')}
                if not (ent['url'] or ent['token'] or (ent['username'] and ent['password'])):
                    continue
                identity = tuple((ent[k] for k in ('url', 'username', 'password', 'token')))
                if identity not in seen[kind]:
                    data[kind].append(ent)
                    seen[kind].add(identity)
    save(data, path, mirror)
    return path
if __name__ == '__main__':
    ensure()
