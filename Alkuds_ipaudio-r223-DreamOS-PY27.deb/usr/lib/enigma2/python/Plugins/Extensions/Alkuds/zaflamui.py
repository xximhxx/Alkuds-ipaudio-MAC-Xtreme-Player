# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import zaflam
from .sitecatalogueui import Alkuds_SiteCatalogue_Browser

class Alkuds_Zaflam_Browser(Alkuds_SiteCatalogue_Browser):
    provider = zaflam
    site_name = u'زي أفلام Zaflam'
