# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Public subtitle metadata and SRT/WebVTT cues; no receiver dependencies."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import bisect
from .py2compat import json
from .py2compat import re
try:
    from .py2compat import html
    unescape = html.unescape
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
except ImportError:
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape
    from urlparse import urljoin
_registry = {}

def remember(url, tracks):
    if tracks:
        if len(_registry) > 100:
            compat_clear(_registry)
        _registry[url] = list(tracks)

def recalled(url):
    return list(_registry.get(url) or [])

def normalise(values, base='', headers=None):
    result, seen = ([], set())
    for value in values or []:
        if not isinstance(value, dict):
            continue
        kind = str(value.get('kind') or '').lower()
        if kind and kind not in ('subtitles', 'captions', 'subtitle'):
            continue
        url = value.get('url') or value.get('file') or value.get('src')
        if not url:
            continue
        url = urljoin(base, unescape(url.replace('\\/', '/')))
        if not url.startswith(('http://', 'https://')) or url in seen:
            continue
        seen.add(url)
        result.append({'url': url, 'name': value.get('label') or value.get('name') or value.get('language') or value.get('lang') or value.get('srclang') or 'Subtitle', 'language': value.get('srclang') or value.get('language') or '', 'encoding': value.get('encoding') or 'utf-8-sig', 'headers': dict(value.get('headers') or headers or {})})
    return result

def extract(text, base, headers=None):
    values = []
    for tag in re.findall('<track\\b[^>]*>', text, re.I):
        values.append(dict(((key.lower(), unescape(value)) for key, quote, value in re.findall('([\\w-]+)\\s*=\\s*([\\x22\\x27])(.*?)\\2', tag))))
    for match in re.finditer('\\{[^{}]{0,1800}\\}', text):
        obj = match.group(0)
        if not re.search('\\.(?:srt|vtt)(?:[?\\x22\\x27])|kind\\s*:\\s*[\\x22\\x27](?:captions|subtitles)', obj, re.I):
            continue
        try:
            values.append(json.loads(obj))
        except ValueError:
            values.append(dict(((key, value) for key, quote, value in re.findall('[\\x22\\x27]?(file|src|url|kind|label|srclang|language)[\\x22\\x27]?\\s*:\\s*([\\x22\\x27])(.*?)\\2', obj))))
    return normalise(values, base, headers)

def timestamp(value):
    parts = value.strip().replace(',', '.').split(':')
    return sum((float(x) * 60 ** i for i, x in enumerate(reversed(parts))))

def parse_cues(raw, encoding='utf-8-sig'):
    if isinstance(raw, bytes):
        if raw.startswith((b'\xff\xfe', b'\xfe\xff')):
            text = raw.decode('utf-16')
        else:
            try:
                text = raw.decode(encoding or 'utf-8-sig', 'replace')
            except LookupError:
                text = raw.decode('utf-8-sig', 'replace')
    else:
        text = raw
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    cues = []
    for block in re.split('\\n\\s*\\n', text):
        lines = block.strip().split('\n')
        for index, line in enumerate(lines):
            m = re.match('\\s*((?:\\d+:)?\\d{2}:\\d{2}[.,]\\d{3})\\s*-->\\s*((?:\\d+:)?\\d{2}:\\d{2}[.,]\\d{3})', line)
            if not m:
                continue
            start, end = (timestamp(m.group(1)), timestamp(m.group(2)))
            label = unescape(re.sub('<[^>]*>|\\{\\\\[^}]*\\}', '', '\n'.join(lines[index + 1:]))).strip()
            if label and end > start:
                cues.append((start, end, label))
            break
    return sorted(cues)

class CueTimeline(object):

    def __init__(self, cues):
        self.cues = list(cues)
        self.starts = [c[0] for c in cues]
        self.duration = max([c[1] - c[0] for c in cues] or [0])

    def at(self, seconds):
        right = bisect.bisect_right(self.starts, seconds)
        left = bisect.bisect_left(self.starts, seconds - self.duration)
        return '\n'.join((c[2] for c in self.cues[left:right] if c[0] <= seconds < c[1]))
