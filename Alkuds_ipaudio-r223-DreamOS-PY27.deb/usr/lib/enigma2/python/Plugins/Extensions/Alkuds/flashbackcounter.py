# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Read-only Flashback PVR counter. No audio, pause, seek or navigation calls."""
from __future__ import absolute_import, division, print_function
from .py2compat import gui_text
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from Screens.Screen import Screen
from .xStaticText import Label
from enigma import eTimer, getDesktop

def clock(milliseconds):
    if milliseconds is None:
        return '--:--.--'
    ticks = max(0, int(round(milliseconds / 10.0)))
    seconds, fraction = divmod(ticks, 100)
    minutes, seconds = divmod(seconds, 60)
    return '%02d:%02d.%02d' % (minutes, seconds, fraction)

def read_counter(owner):
    if owner is None or not owner.active:
        return None
    timeline = owner.timeline()
    if timeline is None:
        return {'actual': None, 'position': None, 'length': None, 'target': owner.target_ms, 'state': owner.state}
    _, length, position = timeline
    return {'actual': (length - position) / 90.0, 'position': position / 90.0, 'length': length / 90.0, 'target': owner.target_ms, 'state': owner.state}

class DelayEstimate(object):
    """Display-only median. Preserve raw readings; never lock to target."""

    def __init__(self):
        self.key = None
        self.samples = []

    def observe(self, data):
        key = (data.get('generation'), data['target'], data['state'])
        if key != self.key:
            self.key = key
            self.samples = []
        if data['actual'] is None or data['state'] != 'PLAYING':
            self.samples = []
            return {'value': None, 'count': 0, 'jitter': False, 'low': None, 'high': None}
        self.samples.append(float(data['actual']))
        self.samples = self.samples[-5:]
        ordered = sorted(self.samples)
        count = len(ordered)
        median = None if count < 3 else ordered[count // 2] if count % 2 else (ordered[count // 2 - 1] + ordered[count // 2]) / 2.0
        return {'value': median, 'count': count, 'jitter': count >= 3 and ordered[-1] - ordered[0] >= 500, 'low': ordered[0], 'high': ordered[-1]}

def estimate_text(estimate):
    if estimate['value'] is None:
        return 'measuring...'
    return '~%.1f s' % (estimate['value'] / 1000.0)

class FlashbackCounter(Screen):

    def __init__(self, session, owner):
        desktop = getDesktop(0).size()
        scale = min(desktop.width() / 1280.0, desktop.height() / 720.0)

        def n(value):
            return round(value * scale)
        widgets = []
        for name, x, width, y, height, font, color in (('delay_title', 8, 150, 2, 17, 13, '#4ee276'), ('play_title', 164, 150, 2, 17, 13, '#ffffff'), ('record_title', 320, 152, 2, 17, 13, '#ff6565'), ('delay', 8, 150, 19, 24, 20, '#4ee276'), ('play', 164, 150, 19, 24, 20, '#ffffff'), ('record', 320, 152, 19, 24, 20, '#ff6565'), ('status', 8, 464, 45, 16, 12, '#e2d3f7')):
            widgets.append('<widget name="%s" position="%d,%d" size="%d,%d" font="alkudsregular;%d" foregroundColor="%s" transparent="1" halign="center" valign="center" />' % (name, n(x), n(y), n(width), n(height), n(font), color))
        self.skin = '<screen name="AlkudsFlashbackCounter" position="%d,%d" size="%d,%d" flags="wfNoBorder" backgroundColor="#2024103d" zPosition="6">%s</screen>' % ((desktop.width() - n(480)) // 2, n(24), n(480), n(64), ''.join(widgets))
        self.skin = gui_text(self.skin)
        Screen.__init__(self, session)
        self.owner = owner
        self.stopped = False
        self.estimate = DelayEstimate()
        self.dismissed = True
        self.present = False
        self.auto_started = False
        for name, text in (('delay_title', 'VIDEO DELAY'), ('play_title', 'PLAYBACK'), ('record_title', 'RECORDED'), ('delay', '--:--.--'), ('play', '--:--.--'), ('record', '--:--.--'), ('status', '')):
            self[name] = Label(text)
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.refresh)
        except Exception:
            self.timer.callback.append(self.refresh)
        self.hide_timer = eTimer()
        try:
            self.hide_connection = self.hide_timer.timeout.connect(self.dismiss)
        except Exception:
            self.hide_timer.callback.append(self.dismiss)
        self.onClose.append(self.stop)
        # Session applies the skin after construction. Hide only once the
        # native window exists (DreamOS does not allow early hide calls).

    def refresh(self):
        if self.stopped or self.dismissed:
            return
        try:
            data = read_counter(self.owner)
            if data is None:
                self.estimate = DelayEstimate()
                self.present = False
                self.timer.stop()
                self.hide()
                return
            data['generation'] = id(getattr(self.owner, 'recorder', self.owner))
            estimate = self.estimate.observe(data)
            self['delay_title'].setText('ESTIMATED DELAY')
            self.last_estimate_text = estimate_text(estimate)
            self['delay'].setText(self.last_estimate_text)
            self['play'].setText(clock(data['position']).split('.')[0])
            self['record'].setText(clock(data['length']).split('.')[0])
            raw = '--' if data['actual'] is None else '%.2f s' % (data['actual'] / 1000.0)
            state = 'PVR JITTER' if estimate['jitter'] else 'COLLECTING' if estimate['value'] is None and data['actual'] is not None else data['state']
            self['status'].setText('Target: %.1f s | %s | OK: hide / INFO: show' % (data['target'] / 1000.0, 'PVR ESTIMATE VARIES' if estimate['jitter'] else state))
            self.show()
            self.present = True
        except Exception:
            self.present = False
            self.hide()

    def is_displayed(self):
        return self.present and (not self.dismissed) and (not self.stopped)

    def dismiss(self):
        self.dismissed = True
        self.present = False
        self.timer.stop()
        self.hide_timer.stop()
        self.hide()

    def reveal(self):
        if self.stopped:
            return
        if self.dismissed:
            self.estimate = DelayEstimate()
        self.dismissed = False
        self.auto_started = False
        self.hide_timer.stop()
        self['delay'].setText('measuring...')
        self['play'].setText('--:--')
        self['record'].setText('--:--')
        self['status'].setText('Updating every 1s | OK: hide / INFO: show')
        self.present = bool(self.owner and self.owner.active)
        if self.present:
            self.refresh()
            self.timer.start(1000, False)
        else:
            self.hide()
            self.timer.stop()

    def stop(self):
        self.stopped = True
        self.timer.stop()
        self.dismiss()

def create_counter(session, owner):
    try:
        dialog = session.instantiateDialog(FlashbackCounter, owner)
        dialog.hide()
        return dialog
    except Exception as error:
        from .flashbackrecorder import log
        log('counter overlay unavailable (%s): %s' % (type(error).__name__, error))
        return None

def destroy_counter(session, dialog):
    if dialog is None:
        return
    try:
        dialog.stop()
    except Exception:
        pass
    try:
        session.deleteDialog(dialog)
    except Exception:
        pass
