# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Check only accounts already saved by the user; persist no credentials here."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import hashlib
from .py2compat import json
from .py2compat import os
from .py2compat import threading
from .py2compat import time
from .accountinfo import account_fields, account_text, _expiry_timestamp
STORE = '/etc/enigma2/alkuds/subscription_status.json'
LOCK = threading.Lock()

def identity(kind, item):
    info = item.get('playlist_info', {}) if kind == 'xtream' else item
    keys = ('host', 'domain', 'username', 'password') if kind == 'xtream' else ('portal', 'mac')
    raw = json.dumps([kind] + [info.get(k, '') for k in keys], ensure_ascii=True)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()

def read_all():
    try:
        with open(STORE, 'r') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def record(kind, item, status, fields):
    with LOCK:
        data = read_all()
        key = identity(kind, item)
        previous = data.get(key, {}).get('fields', {})
        previous.update(fields or {})
        data[key] = {'status': status, 'fields': previous, 'checked': int(time.time())}
        parent = os.path.dirname(STORE)
        if not os.path.isdir(parent):
            os.makedirs(parent)
        temporary = STORE + '.tmp'
        with open(temporary, 'w') as handle:
            json.dump(data, handle)
        os.chmod(temporary, 384)
        getattr(os, 'replace', os.rename)(temporary, STORE)

def xtream_status(payload):
    info = payload.get('user_info') or {}
    status = str(info.get('status', '')).strip().lower()
    auth = str(info.get('auth') if info.get('auth') is not None else '').strip().lower()
    expiry = _expiry_timestamp(info.get('exp_date'))
    if status == 'expired' or (expiry and expiry < time.time()):
        return 'Expired'
    if status in ('disabled', 'banned', 'inactive') or auth in ('0', 'false'):
        return 'Inactive'
    if status == 'active' and auth in ('', '1', 'true') or (not status and auth in ('1', 'true')):
        return 'Active'
    return 'Unconfirmed'

def details(kind, item):
    entry = read_all().get(identity(kind, item), {})
    status = entry.get('status', 'Not checked')
    fields = entry.get('fields') or account_fields(item)
    expiry = _expiry_timestamp(fields.get('expiry'))
    if status == 'Active' and expiry and (expiry < time.time()):
        status = 'Expired'
    color = 4513160 if status == 'Active' else 15696518 if status in ('Expired', 'Inactive') else 14071929
    return (status + ' | ' + account_text(fields), color)

def check_one(kind, item):
    if kind == 'xtream':
        from .accountinfo import fetch_xtream_account
        from .plugin import cfg
        try:
            from .py2compat import urllib
            urlencode = urllib.parse.urlencode
        except ImportError:
            from urllib import urlencode
        info = item.get('playlist_info') or {}
        url = info.get('player_api') or str(info.get('host', '')).rstrip('/') + '/player_api.php?' + urlencode({'username': info.get('username', ''), 'password': info.get('password', '')})
        payload = fetch_xtream_account(url, cfg.useragent.value)
        status, fields = (xtream_status(payload), account_fields(payload))
    else:
        from .stalker import StalkerClient
        client = StalkerClient(item)
        client.suppress_backup = True
        try:
            client.connect()
            genres = client.get_genres()
            fields = client.get_account_info()
            expiry = _expiry_timestamp(fields.get('expiry'))
            status = 'Expired' if expiry and expiry < time.time() else 'Active' if genres else 'Unconfirmed'
        finally:
            client.session.close()
    record(kind, item, status, fields)
    if status == 'Active':
        try:
            from .remote_backup import backup_xtream_connected, backup_stalker_connected
            if kind == 'xtream':
                backup_xtream_connected(item)
            else:
                backup_stalker_connected(item)
        except Exception:
            pass
    return status

def offer_delete(manager, kind, accounts, since=None):
    from .subscriptionprefs import removable
    from .xStaticText import MessageBox
    candidates = removable(kind, accounts, read_all(), since)
    if not candidates:
        manager.session.open(MessageBox, u'لا توجد اشتراكات ثبت توقفها أو انتهاء صلاحيتها. نتائج تعذر الاتصال لا تُحذف.', MessageBox.TYPE_INFO, timeout=7)
        return

    def remove(answer):
        if not answer:
            return
        try:
            count = manager.delete_checked_accounts(candidates)
            manager.session.open(MessageBox, u'تم حذف %d اشتراك متوقف من القائمة، مع حفظ نسخة محلية للتراجع.' % count, MessageBox.TYPE_INFO, timeout=7)
        except Exception:
            manager.session.open(MessageBox, u'تعذر إكمال الحذف. تحقق من مساحة التخزين وملفات الاشتراكات.', MessageBox.TYPE_ERROR)
    manager.session.openWithCallback(remove, MessageBox, u'حذف %d اشتراك ثبت توقفه أو انتهاء صلاحيته؟ لن تُحذف نتائج تعذر الفحص.' % len(candidates), MessageBox.TYPE_YESNO, default=False)

def show_menu(manager, kind, items):
    from .xStaticText import ChoiceBox
    from .xStaticText import MessageBox
    from .subscriptionprefs import is_favourite, toggle, removable
    current = manager['list'].getCurrent()
    index = current[1] if current and len(current) > 1 else -1
    account = items[index] if isinstance(index, int) and 0 <= index < len(items) else None
    choices = [(u'فحص الاشتراكات', 'check')]
    if account is not None:
        choices.insert(0, (u'إزالة من المفضلة' if is_favourite(kind, account) else u'إضافة إلى المفضلة', 'favourite'))
    if removable(kind, items, read_all()):
        choices.append((u'حذف الاشتراكات المتوقفة بعد الفحص', 'delete'))
    choices.append((u'حجب المحتوى الإباحي مفعّل إجباريًا', 'blocked'))

    def selected(choice):
        if not choice:
            return
        if choice[1] == 'check':
            started = int(time.time())

            def finished(result=None):
                manager.reload()
                if result and removable(kind, items, read_all(), started):
                    offer_delete(manager, kind, items, started)
            manager.session.openWithCallback(finished, SubscriptionCheck, kind, list(items))
        elif choice[1] == 'favourite' and account is not None:
            try:
                toggle(kind, account)
                manager.reload()
            except Exception:
                manager.session.open(MessageBox, u'تعذر حفظ المفضلة.', MessageBox.TYPE_ERROR)
        elif choice[1] == 'delete':
            offer_delete(manager, kind, items)
        elif choice[1] == 'blocked':
            manager.session.open(MessageBox, u'يُحجب المحتوى المصنف للكبار وأسماء الباقات الإباحية في كل الاشتراكات، ولا يوجد خيار لإلغاء الحجب.', MessageBox.TYPE_INFO, timeout=8)
    manager.session.openWithCallback(selected, ChoiceBox, title=u'خيارات الاشتراك', list=choices)
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from .xStaticText import Label
from enigma import eTimer

def _run_checks(kind, items, state, cancelled):
    """The worker owns plain data, never a Screen that Enigma2 may destroy."""
    from .remote_backup import subscription_key
    seen = {}
    try:
        for index, item in enumerate(items):
            if cancelled.is_set():
                break
            marker = subscription_key(kind, item)
            if marker in seen:
                status, fields = seen[marker]
                try:
                    record(kind, item, status, fields)
                except Exception:
                    pass
                state['progress'] = (index + 1, u'تم تخطي الاشتراك المكرر')
                continue
            state['progress'] = (index, u'جاري فحص الاشتراك %d' % (index + 1))
            try:
                status = check_one(kind, item)
            except Exception:
                status = 'Check failed'
                try:
                    record(kind, item, status, {})
                except Exception:
                    status = 'Could not save result'
            fields = read_all().get(identity(kind, item), {}).get('fields') or {}
            seen[marker] = (status, fields)
            state['progress'] = (index + 1, status)
    finally:
        state['done'] = True

class SubscriptionCheck(Screen):
    skin = u'<screen position="center,center" size="650,190" title="فحص الاشتراكات"><widget name="status" position="20,20" size="610,150" font="AlkudsUnicode;24" /></screen>'

    def __init__(self, session, kind, items):
        Screen.__init__(self, session)
        self.kind, self.check_accounts = (kind, items)
        self.cancelled = threading.Event()
        self._state = {'done': False, 'progress': (0, u'جاري البدء'), 'closed': False, 'started': False}
        self['status'] = Label('')
        self['actions'] = ActionMap(['OkCancelActions'], {'cancel': self.close, 'ok': self.finish}, -2)
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.poll)
        except Exception:
            self.timer.callback.append(self.poll)
        self.onClose.append(self.cleanup)
        self.onFirstExecBegin.append(self.start)

    def start(self):
        state = getattr(self, '_state', None)
        if not state or state['closed'] or state['started']:
            return
        state['started'] = True
        worker = threading.Thread(target=_run_checks, args=(self.kind, list(self.check_accounts), state, self.cancelled))
        worker.daemon = True
        worker.start()
        self.timer.start(150, False)

    def poll(self):
        state = getattr(self, '_state', None)
        if not state or state['closed']:
            return
        count, status = state['progress']
        self['status'].setText('%d / %d\n%s\n%s' % (count, len(self.check_accounts), status, u'اكتمل الفحص — اضغط موافق للعودة' if state['done'] else u'رجوع لإيقاف الفحص بعد الاشتراك الحالي'))
        if state['done']:
            self.timer.stop()

    def finish(self):
        state = getattr(self, '_state', None)
        if state and (not state['closed']) and state['done']:
            self.close(True)

    def cleanup(self):
        state = getattr(self, '_state', None)
        if not state or state['closed']:
            return
        state['closed'] = True
        self.cancelled.set()
        try:
            self.timer.stop()
            if hasattr(self.timer, 'callback') and self.poll in self.timer.callback:
                self.timer.callback.remove(self.poll)
            connection = getattr(self, 'connection', None)
            if connection is not None and hasattr(connection, 'disconnect'):
                connection.disconnect()
            self.connection = None
        except Exception:
            pass
