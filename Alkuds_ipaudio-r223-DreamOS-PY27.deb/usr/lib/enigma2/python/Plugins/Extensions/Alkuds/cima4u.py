# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Cima4U (cimafu.cam): catalogue, grouped series, episode lists and watch-page servers.

Written from the public page structure: WordPress category and /page/N/ URLs, one
post per movie or episode, and a /watch/ page that lists direct embed servers.
Markup-dependent parts are deliberately tolerant and every step is logged to
/tmp/alkuds_cima4u.log so a layout change can be diagnosed from the receiver.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .py2compat import os
from .py2compat import threading
from .py2compat import requests
from . import arabseed as a
try:
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlparse = urllib.parse.urlparse
except ImportError:
    from urlparse import urljoin, urlparse
BASE = 'https://cimafu.cam/'
KNOWN_HOSTS = set(['cimafu.cam', 'www.cimafu.cam'])
BRAND_HOST = re.compile('(?:^|\\.)(?:cima4u|cimafu|cima-4u|cima4)[a-z0-9-]*(?:\\.[a-z]{2,24}){1,2}$')
ORIGIN_LOCK = threading.Lock()
LOG_FILE = '/tmp/alkuds_cima4u.log'
LOG_LOCK = threading.Lock()
EPISODE = re.compile(u'(?:الحلقة|حلقة)\\s*(\\d+)')
NON_POST = set(['category', 'page', 'genre', 'country', 'language', 'quality', 'series', 'tag', 'author', 'wp-content', 'wp-json', 'wp-admin', 'wp-includes', 'feed'])
EMBED_PATH = re.compile('^/(?:(?:e|v|embed)/[^/?#]+|embed-[^/?#]+\\.html)/?$')
SUPPORTED = ('mixdrop', 'streamwish', 'earnvids', 'streamtape', 'uqload')
SECTIONS = [('browse', u'تصفح الموقع', ''), ('foreign_movies', u'أفلام أجنبية', u'category/افلام-اجنبي/'), ('arabic_movies', u'أفلام عربية', u'category/افلام-عربي/'), ('turkish_movies', u'أفلام تركية', u'category/افلام-تركية/'), ('indian_movies', u'أفلام هندية', u'category/افلام-هندي/'), ('asian_movies', u'أفلام آسيوية', u'category/افلام-اسيوي/'), ('anime_movies', u'أفلام أنمي', u'category/افلام-انمي/'), ('cartoon_movies', u'أفلام كرتون', u'category/افلام-كرتون/'), ('foreign_series', u'مسلسلات أجنبية', u'category/مسلسلات-اجنبي/'), ('arabic_series', u'مسلسلات عربية', u'category/مسلسلات-عربي/'), ('turkish_series', u'مسلسلات تركية', u'category/مسلسلات-تركية/'), ('indian_series', u'مسلسلات هندية', u'category/مسلسلات-هندية/'), ('asian_series', u'مسلسلات آسيوية', u'category/مسلسلات-اسيوية/'), ('anime_series', u'مسلسلات أنمي', u'category/مسلسلات-انمي/'), ('dubbed_series', u'مسلسلات مدبلجة', u'category/مسلسلات-مدبلجة/'), ('latin_series', u'مسلسلات لاتينية', u'category/مسلسلات-لاتينية/'), ('cartoon_series', u'مسلسلات كرتون', u'category/مسلسلات-كرتون/'), ('programs', u'برامج تلفزيونية', u'category/برامج-تلفزيونية/')]
SECTION_MAP = dict(((key, (name, cat)) for key, name, cat in SECTIONS))

def _log(stage, detail):
    try:
        with LOG_LOCK:
            if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 65536:
                os.remove(LOG_FILE)
            with open(LOG_FILE, 'a') as handle:
                handle.write('%s %s\n' % (stage, detail))
    except Exception:
        pass

def _trusted_host(host):
    host = (host or '').lower().rstrip('.')
    if not host:
        return False
    if host in KNOWN_HOSTS or BRAND_HOST.search(host):
        return True
    labels = host.split('.')
    return len(labels) > 2 and any((known.split('.')[-2:] == labels[-2:] for known in KNOWN_HOSTS))

def _local(url):
    value = urljoin(BASE, url)
    parsed = urlparse(value)
    host = (parsed.hostname or '').lower()
    if parsed.scheme not in ('http', 'https') or not _trusted_host(host):
        _log('rejected_address', host or 'unknown')
        raise ValueError('Unexpected Cima4U catalogue address')
    return value.split('#', 1)[0]

def _accept(page_url, html):
    """Follow a mirror move only when the page really is Cima4U."""
    global BASE
    parsed = urlparse(page_url)
    host = (parsed.hostname or '').lower()
    if parsed.scheme not in ('http', 'https') or not _trusted_host(host):
        _log('rejected_redirect', host or 'unknown')
        raise ValueError('Unexpected Cima4U catalogue address')
    if host not in KNOWN_HOSTS and BRAND_HOST.search(host) and ('cima4u' in html.lower() or u'سيما فور يو' in html):
        with ORIGIN_LOCK:
            KNOWN_HOSTS.add(host)
            BASE = '%s://%s/' % (parsed.scheme, parsed.netloc)
        _log('origin', host)

def _get(session, url, referer=None):
    session.verify = False
    try:
        response = session.get(requests.utils.requote_uri(_local(url)), headers=a._headers(referer or BASE), timeout=(8, 35), allow_redirects=True)
        try:
            status = response.status_code
            html = response.content[:5 * 1024 * 1024].decode('utf-8', 'replace')
            if status in (403, 429, 503) or ('cf-chl-' in html and 'wp-content' not in html):
                raise RuntimeError('Cima4U requires browser verification (HTTP %d). Try again later.' % status)
            response.raise_for_status()
            page_url = response.url
        finally:
            response.close()
        _accept(page_url, html)
        _log('page', '%s bytes=%d' % (urlparse(page_url).path[:80], len(html)))
        return (html, page_url)
    except Exception as error:
        resp = getattr(error, 'response', None)
        _log('request_failed', '%s status=%s' % (type(error).__name__, getattr(resp, 'status_code', 'unknown')))
        raise

def _is_post(url):
    parsed = urlparse(url)
    if parsed.query or not _trusted_host((parsed.hostname or '').lower()):
        return False
    segments = [s for s in parsed.path.split('/') if s]
    return len(segments) == 1 and segments[0].lower() not in NON_POST and ('.' not in segments[0])

def _post_urls(node, page_url):
    result = set()
    for link in node.find('a'):
        url = urljoin(page_url, link.attrs.get('href', ''))
        if _is_post(url):
            result.add(url)
    return result

def _clean_title(text, raw=False):
    text = re.sub('\\s+', ' ', text or '').strip()
    if raw:
        text = re.sub('^\\d+\\s*', '', text)
        for marker in (u'مشاهدة ', u'برنامج ', u'عرض '):
            index = text.find(marker)
            if 0 < index <= 40:
                text = text[index:]
                break
    text = re.sub(u'^مشاهدة\\s+', '', text)
    text = re.sub(u'\\s+وتحميل\\s+', ' ', text, 1)
    text = re.sub(u'(?:\\s+(?:مترجمة|مترجم|مباشر|اون لاين|أون لاين))+\\s*$', '', text)
    return re.sub(u'^(?:فيلم|مسلسل|برنامج|انمي|أنمي|عرض)\\s+', '', text).strip()

def _card_title(link, card):
    value = (link.attrs.get('title') or '').strip()
    if len(value) > 2:
        return _clean_title(value)
    for image in card.find('img'):
        value = (image.attrs.get('alt') or '').strip()
        if len(value) > 2:
            return _clean_title(value)
    for tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6'):
        for heading in card.find(tag):
            if heading.text():
                return _clean_title(heading.text())
    return _clean_title(link.text(), True)

def _card_image(card, page_url):
    for image in card.find('img'):
        for key in ('data-src', 'data-lazy-src', 'data-original', 'data-lazy', 'src'):
            value = (image.attrs.get(key) or '').strip()
            if value and (not value.startswith('data:')):
                return urljoin(page_url, value)
    for node in [card] + card.find():
        match = re.search('url\\(\\s*[\\\'"]?([^\\\'")]+)', node.attrs.get('style', '') or '')
        if match:
            return urljoin(page_url, match.group(1))
    return ''

def _card_for(link, page_url):
    """Largest ancestor (up to 4 levels) that still holds only this post link."""
    url = urljoin(page_url, link.attrs.get('href', ''))
    card, node = (link, link.parent)
    for _ in range(4):
        if node is None or not node.tag:
            break
        if _post_urls(node, page_url) - set([url]):
            break
        card, node = (node, node.parent)
    return card

def _group(entries):
    result, seen = ([], set())
    for entry in entries:
        if not EPISODE.search(entry['name']):
            result.append(entry)
            continue
        title = a.series_name(entry['name'])
        if not title or title.lower() in seen:
            continue
        seen.add(title.lower())
        row = dict(entry)
        row.update(name=title, is_series=True, quality='')
        result.append(row)
    return result

def groups():
    return [{'name': name, 'section': key} for key, name, cat in SECTIONS]

def _list_url(section, page, query):
    name, cat = SECTION_MAP[section]
    page = max(1, int(page or 1))
    paging = 'page/%d/' % page if page > 1 else ''
    if query:
        return BASE + paging + '?s=' + requests.utils.quote(query.encode('utf-8'), safe='')
    return BASE + cat + paging

def fetch_items(section, page=1, query='', order='latest', grouped=True):
    name = SECTION_MAP[section][0]
    session = requests.Session()
    try:
        html, page_url = _get(session, _list_url(section, page, query))
    finally:
        session.close()
    root = a.Document(html).root
    entries, seen = ([], set())
    for link in root.find('a'):
        url = urljoin(page_url, link.attrs.get('href', ''))
        if url in seen or not _is_post(url):
            continue
        card = _card_for(link, page_url)
        title = _card_title(link, card)
        if not title:
            continue
        seen.add(url)
        entries.append({'url': _local(url), 'name': title, 'image': _card_image(card, page_url), 'section': section, 'category': name})
    pages = [int(page)]
    for link in root.find('a'):
        match = re.search('/page/(\\d+)/?', urlparse(link.attrs.get('href', '')).path)
        if match:
            pages.append(int(match.group(1)))
    if grouped:
        entries = _group(entries)
    _log('catalogue', '%s page=%d entries=%d grouped=%d' % (section, int(page), len(entries), bool(grouped)))
    return {'entries': entries, 'page': int(page), 'last_page': max(pages), 'total': len(entries)}

def seasons(item):
    row = dict(item)
    row.update(name=u'حلقات المسلسل', series_title=item['name'], episode_query=item['name'])
    return [row]

def episodes(item, page=1):
    series = item['series_title']
    session = requests.Session()
    try:
        html, page_url = _get(session, item['url'])
    finally:
        session.close()
    root = a.Document(html).root
    found = {}
    for link in root.find('a'):
        match = re.match(u'^(?:الحلقة|حلقة)\\s*\\*?\\s*(\\d+)\\s*\\*?$', link.text())
        url = urljoin(page_url, link.attrs.get('href', ''))
        if match and _is_post(url):
            found.setdefault(int(match.group(1)), url)
    title = re.search('<title[^>]*>(.*?)</title>', html, re.S)
    current = EPISODE.search(title.group(1)) if title else None
    if current and _is_post(page_url):
        found.setdefault(int(current.group(1)), page_url)
    entries = [{'url': _local(url), 'name': u'%s الحلقة %d' % (series, number), 'image': item.get('image', ''), 'section': item['section'], 'category': item.get('category', ''), 'is_series': False, 'series_title': series} for number, url in sorted(found.items())]
    if not entries:
        result = fetch_items('browse', page, item['episode_query'], grouped=False)
        result['entries'] = [dict(x, is_series=False, series_title=series) for x in result['entries'] if a.series_name(x['name']).lower() == item['episode_query'].lower()]
        result['entries'].sort(key=lambda x: int((EPISODE.search(x['name']) or re.search('(\\d+)', '0')).group(1)))
        _log('episodes', 'fallback_search entries=%d' % len(result['entries']))
        return result
    _log('episodes', 'list entries=%d' % len(entries))
    return {'entries': entries, 'page': 1, 'last_page': 1, 'total': len(entries)}

def _watch_url(url):
    base = url.split('?', 1)[0].split('#', 1)[0].rstrip('/')
    return base + '/' if base.endswith('/watch') else base + '/watch/'

def _embed_urls(html):
    text = html.replace('\\/', '/').replace('&amp;', '&')
    found, seen = ([], set())
    for match in re.finditer('https?://[^\\s"\'<>\\\\)\\]]+', text):
        url = match.group(0).rstrip('.,;')
        parsed = urlparse(url)
        host = (parsed.hostname or '').lower()
        if not host or _trusted_host(host) or (not EMBED_PATH.match(parsed.path)) or (url in seen):
            continue
        seen.add(url)
        found.append(url)
    return found

def servers(item):
    session = requests.Session()
    try:
        html, page_url = _get(session, _watch_url(item['url']), item['url'])
        urls = _embed_urls(html)
        if not urls:
            html, page_url = _get(session, item['url'])
            urls = _embed_urls(html)
        if not urls:
            raise RuntimeError('Cima4U did not return any players')
        rows = []
        for index, url in enumerate(urls, 1):
            host = (urlparse(url).hostname or '').lower()
            label = host.replace('www.', '').split('.')[0]
            rows.append((0 if any((s in host for s in SUPPORTED)) else 1, index, url, label))
        rows.sort()
        result = []
        for priority, index, url, label in rows:
            row = dict(item)
            row.update(name=u'سيرفر %d - %s' % (index, label), title=item['name'], server_url=url, referer=page_url)
            result.append(row)
        _log('servers', 'count=%d supported_first=%d' % (len(result), sum((1 for r in rows if r[0] == 0))))
        return result
    finally:
        session.close()

def resolve(item):
    from .freeproviders import hls_variant_streams
    session = requests.Session()
    try:
        media = a._resolve_page(session, item['server_url'], item['referer'])
        variants = []
        for stream in media:
            variants.extend(hls_variant_streams({'url': stream['url'], 'relay': True, 'mediatype': stream['mediatype'], 'subtitles': stream.get('subtitles') or [], 'quality': stream.get('quality', 'Original'), 'headers': {'User-Agent': a.UA, 'Referer': a._referer(stream['referer'])}}))
        if not variants:
            raise RuntimeError('This player is unavailable or requires browser verification. Choose another player.')
        result = dict(item)
        result.update(name=item.get('title', item['name']), streams=variants)
        return result
    finally:
        session.close()
