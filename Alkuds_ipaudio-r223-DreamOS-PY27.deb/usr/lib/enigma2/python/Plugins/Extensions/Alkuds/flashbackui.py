# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Flashback controller retained as the adopted r194 baseline."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .videodelay import VideoDelayController
from .flashbackpvr import RawPVRSession

class FlashbackController(VideoDelayController):

    def __init__(self, session):
        self.counter = None
        self.flashback = RawPVRSession(session, self._beta_error)
        super(FlashbackController, self).__init__(session)
        from .flashbackcounter import create_counter
        self.counter = create_counter(session, self.flashback)

    def _beta_error(self, message):
        self.target_ms = self.flashback.target_ms
        from .xStaticText import MessageBox
        self.session.open(MessageBox, 'Alkuds Flashback:\n' + message, MessageBox.TYPE_ERROR, timeout=10)

    def answer(self, value):
        self.dialog = None
        if self.closed or value is None:
            return
        try:
            if isinstance(value, dict):
                self.apply(value['video_ms'])
                from .backgroundaudio import configured_audio_delay_ms, apply_audio_delay
                if int(value['audio_ms']) != configured_audio_delay_ms():
                    apply_audio_delay(value['audio_ms'])
            else:
                self.apply(value)
        except Exception as error:
            self._beta_error(str(error))

    def apply(self, milliseconds):
        self.flashback.apply(milliseconds)
        self.target_ms = self.restore_ms = self.flashback.target_ms if milliseconds else 0
        if self.counter is not None:
            self.counter.reveal()

    def raw_info(self, key, flag):
        if flag == 0 and key in (352, 28, 174, 1, 158) and (not self.closed) and (self.dialog is None):
            if self.counter is not None and self.counter.is_displayed() and self.foreground():
                self.counter.dismiss()
                return 1
        return super(FlashbackController, self).raw_info(key, flag)

    def prompt(self):
        super(FlashbackController, self).prompt()
        if self.counter is not None:
            self.counter.reveal()

    def stop_timeshift(self):
        try:
            self.flashback.stop(restore=True)
            self.target_ms = 0
            self.video_applied = False
            return True
        except Exception as error:
            self._beta_error(str(error))
            return False

    def restore_delay(self):
        if not self.flashback.active:
            self._beta_error('No raw recording exists. Use OK to start the beta buffer.')
            return None
        try:
            self.flashback.apply(self.restore_ms)
            if self.counter is not None:
                self.counter.reveal()
            return self.restore_ms
        except Exception as error:
            self._beta_error(str(error))
            return None

    def same_service(self):
        if self.flashback.owns_current():
            return True
        return super(FlashbackController, self).same_service()

    def actual_delay_ms(self):
        return self.flashback.actual_delay_ms() if self.flashback.active else 0

    def telemetry(self):
        from .backgroundaudio import background_audio_ui_status
        data = background_audio_ui_status()
        measured = '--'
        if self.counter is not None:
            measured = getattr(self.counter, 'last_estimate_text', 'measuring...')
        delay = 'Target: %.1f s | Estimate: %s' % (self.flashback.target_ms / 1000.0, measured)
        return ('%s | %s' % (data.get('name', 'IP AUDIO'), str(data.get('state', 'starting')).upper()), '', delay)

    def close(self):
        from .flashbackcounter import destroy_counter
        destroy_counter(self.session, self.counter)
        self.counter = None
        self.flashback.close()
        super(FlashbackController, self).close()
