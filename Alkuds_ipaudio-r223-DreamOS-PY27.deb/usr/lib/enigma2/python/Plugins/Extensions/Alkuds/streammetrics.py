# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Small, dependency-free stream measurements for the Alkuds OSD.

The helpers intentionally read procfs/sysfs only.  They never open the IPTV
URL, run a speed test, ping a host, or create a second provider connection.
That keeps channel changes and MAC sessions unaffected.
"""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .py2compat import time

def format_bytes(value):
    value = max(0, float(value or 0))
    for unit in ('B', 'KiB', 'MiB', 'GiB', 'TiB'):
        if value < 1024 or unit == 'TiB':
            return ('%d %s' if unit == 'B' else '%.2f %s') % (value, unit)
        value /= 1024.0

class TrafficCounter(object):
    """Network receive total for a playback session, including hidden OSD time."""

    def __init__(self):
        self.reset()

    def reset(self, received=None, now=None):
        self.total = 0
        self.last = read_network_rx_bytes() if received is None else received
        self.stamp = time.time() if now is None else now

    def sample(self, received=None, now=None):
        current = read_network_rx_bytes() if received is None else received
        now = time.time() if now is None else now
        delta = max(0, current - self.last)
        self.total += delta
        elapsed = now - self.stamp
        rate = delta / elapsed if elapsed > 0 else 0
        self.last, self.stamp = (current, now)
        return (rate, self.total)

def traffic_text(rate, total):
    return 'RX: %s | Used: %s' % (format_rate(rate), format_bytes(total))
VIDEO_BITRATE_PATHS = ('/proc/stb/vmpeg/0/bitrate', '/proc/stb/vmpeg/0/bit_rate', '/proc/stb/vmpeg/0/stream_bitrate')
AUDIO_BITRATE_PATHS = ('/proc/stb/audio/0/bitrate', '/proc/stb/audio/0/bit_rate', '/proc/stb/audio/0/stream_bitrate')

def parse_network_rx_bytes(text):
    """Return received bytes summed across non-loopback interfaces."""
    total = 0
    for line in str(text or '').splitlines():
        if ':' not in line:
            continue
        name, values = line.split(':', 1)
        name = name.strip()
        if not name or name == 'lo':
            continue
        fields = values.split()
        if not fields:
            continue
        try:
            value = int(fields[0])
        except Exception:
            continue
        if value >= 0:
            total += value
    return total

def read_network_rx_bytes(path='/proc/net/dev'):
    try:
        with open(path, 'r') as handle:
            return parse_network_rx_bytes(handle.read())
    except Exception:
        return 0

def network_link_up(base='/sys/class/net'):
    """Return True/False when link state is known, otherwise None."""
    seen = False
    try:
        names = os.listdir(base)
    except Exception:
        return None
    for name in names:
        if not name or name == 'lo':
            continue
        try:
            with open(os.path.join(base, name, 'operstate'), 'r') as handle:
                state = handle.read().strip().lower()
        except Exception:
            continue
        seen = True
        if state in ('up', 'unknown', 'dormant'):
            return True
    return False if seen else None

def _parse_number(value):
    text = str(value or '').strip().lower()
    if not text:
        return 0
    token = text.split()[0]
    try:
        if token.startswith('0x'):
            return int(token, 16)
        return int(token, 10)
    except Exception:
        try:
            return int(token, 16)
        except Exception:
            return 0

def read_decoder_bitrate_bytes(paths):
    """Read receiver decoder bitrate nodes and convert bit/s to byte/s."""
    for path in paths or ():
        try:
            with open(path, 'r') as handle:
                value = _parse_number(handle.read())
        except Exception:
            continue
        if value > 0:
            return int(value / 8)
    return 0

def format_rate(value):
    try:
        value = max(0.0, float(value or 0))
    except Exception:
        value = 0.0
    if value >= 1024.0 * 1024.0:
        return '%.2f MB/s' % (value / (1024.0 * 1024.0))
    if value >= 1024.0:
        return '%.0f KB/s' % (value / 1024.0)
    return '%d B/s' % int(value)

def quality_label(width, height):
    try:
        width = int(width or 0)
        height = int(height or 0)
    except Exception:
        width, height = (0, 0)
    if width >= 3840 or height >= 2160:
        return 'UHD'
    if width >= 1920 or height >= 1080:
        return 'FHD'
    if height >= 720:
        return 'HD'
    if width > 0 or height > 0:
        return 'SD'
    return '--'

def _expected_rate(height):
    """Conservative byte/s floor used only for the coloured flow estimate."""
    try:
        height = int(height or 0)
    except Exception:
        height = 0
    if height >= 2160:
        return 1400 * 1024
    if height >= 1080:
        return 650 * 1024
    if height >= 720:
        return 300 * 1024
    return 120 * 1024

def classify_flow(rate, height=0, history=None, link_up=None):
    """Return label, percentage, colour key, and a cautious diagnosis.

    This is a stream-flow estimate, not a broadband capacity test.  A stalled
    provider and a stalled internet path can look identical at the receiver,
    so ambiguous diagnoses explicitly say ``internet/provider``.
    """
    try:
        rate = max(0.0, float(rate or 0))
    except Exception:
        rate = 0.0
    samples = []
    for item in history or []:
        try:
            samples.append(max(0.0, float(item or 0)))
        except Exception:
            pass
    if link_up is False:
        return ('VERY WEAK', 0, 'red', 'Network link is down')
    recent = samples[-4:]
    stopped = len(recent) >= 3 and max(recent) < 8 * 1024
    if stopped:
        return ('VERY WEAK', 2, 'red', 'Stream stopped: internet/provider')
    expected = float(_expected_rate(height))
    ratio = rate / expected if expected > 0 else 0.0
    if rate < 8 * 1024:
        label, percent, colour = ('VERY WEAK', 5, 'red')
    elif ratio < 0.45:
        label, percent, colour = ('WEAK', 25, 'orange')
    elif ratio < 0.9:
        label, percent, colour = ('GOOD', 50, 'yellow')
    elif ratio < 1.8:
        label, percent, colour = ('FAST', 75, 'green')
    else:
        label, percent, colour = ('VERY FAST', 100, 'green')
    unstable = False
    if len(recent) >= 4:
        average = sum(recent) / float(len(recent))
        if average > 0 and (max(recent) - min(recent)) / average > 1.35:
            unstable = True
    if unstable:
        percent = min(percent, 40)
        colour = 'orange'
        diagnosis = 'Unstable flow: internet/provider'
    elif rate < 8 * 1024:
        diagnosis = 'Waiting for stream data'
    else:
        diagnosis = 'Stream flow is stable'
    return (label, percent, colour, diagnosis)
