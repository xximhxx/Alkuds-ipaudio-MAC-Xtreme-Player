# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from enigma import getDesktop
from .freestyle import FONT
from .py2compat import ElementTree as ET

def _free_channels_skin(hint=False):
    """Violet/white list on the left and a mini TV (Pig) on the right."""
    size = getDesktop(0).size()
    width, height = (size.width(), size.height())
    margin = 24 if width >= 1920 else 16
    panel = int(width * 0.54)
    top, foot = (110, 76) if height >= 1080 else (82, 60)
    font = 42 if width >= 1920 else 32 if width >= 1280 else 25
    item = 92 if height >= 1080 else 72 if height >= 720 else 58
    row = panel - margin * 2 - 24
    icon_size = 54 if height >= 1080 else 44
    template = '{"template":[MultiContentEntryText(pos=(0,2),size=(%d,%d),font=0,text=7,backcolor=0xff000004,backcolor_sel=0x6D3FC4),MultiContentEntryPixmapAlphaBlend(pos=(14,%d),size=(%d,%d),png=6),MultiContentEntryText(pos=(%d,4),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0,color=0xff000005,color_sel=0xFFFFFF,backcolor=0xff000004,backcolor_sel=0x6D3FC4),MultiContentEntryText(pos=(%d,4),size=(42,%d),font=0,text=2,color=0xff000003,color_sel=0xff000003,flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER)],"fonts":[gFont("%s",%d)],"itemHeight":%d}' % (row, item - 4, (item - icon_size) // 2, icon_size, icon_size, icon_size + 30, row - icon_size - 90, item - 8, row - 46, item - 8, FONT, font, item)
    right = panel + margin
    pig_w = width - right - margin
    pig_h = int(pig_w * 9 / 16)
    xml = ['<screen name="AlkudsFreeTVList" position="0,0" size="%d,%d" backgroundColor="#ff12061f" flags="wfNoBorder">' % (width, height), '<eLabel position="0,0" size="%d,%d" backgroundColor="#1a0b2e" />' % (panel, height), '<eLabel position="0,0" size="7,%d" backgroundColor="#7c3aed" zPosition="2" />' % height, '<widget source="title" render="Label" position="%d,14" size="%d,%d" font="%s;%d" foregroundColor="#ffffff" backgroundColor="#1a0b2e" valign="center" noWrap="1" zPosition="2" />' % (margin + 12, panel - 2 * margin - 24, top - 22, FONT, font + 6), '<widget source="list" render="Listbox" position="%d,%d" size="%d,%d" foregroundColor="#ffffff" backgroundColor="#1a0b2e" backgroundColorSelected="#6d3fc4" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2"><convert type="TemplatedMultiContent">%s</convert></widget>' % (margin, top, panel - margin * 2, height - top - foot, template), '<eLabel position="%d,%d" size="%d,%d" backgroundColor="#ffffff" zPosition="2" />' % (right - 4, top - 4, pig_w + 8, pig_h + 8), '<widget source="session.VideoPicture" render="Pig" position="%d,%d" size="%d,%d" backgroundColor="#ff000000" transparent="0" zPosition="3" />' % (right, top, pig_w, pig_h)]
    if hint:
        hint_text = u'OK ← معاينة مصغّرة     •     INFO ← ملء الشاشة'
        xml.append(u'<eLabel position="%d,%d" size="%d,%d" text="%s" font="%s;%d" foregroundColor="#e9d5ff" backgroundColor="#12061f" transparent="1" halign="center" valign="center" zPosition="2" />' % (right, top + pig_h + 22, pig_w, 70, hint_text, FONT, max(22, font - 12)))
    key_w = (panel - margin * 2) // 4
    for index, (key, color) in enumerate([('red', '#FF9292'), ('green', '#8DE3BA'), ('yellow', '#E9D5FF'), ('blue', '#C4B5FD')]):
        xml.append('<widget source="key_%s" render="Label" position="%d,%d" size="%d,%d" font="%s;%d" foregroundColor="%s" backgroundColor="#1a0b2e" valign="center" halign="center" zPosition="2" />' % (key, margin + index * key_w, height - foot, key_w, foot, FONT, max(22, font - 9), color))
    return ''.join(xml) + '</screen>'

def subscription_list_skin(account_info=False, hint=False):
    xml = _free_channels_skin(hint)
    if not account_info:
        return xml
    screen = ET.fromstring(xml.encode('utf-8'))
    listing = next((widget for widget in screen.findall('widget') if widget.get('source') == 'list'))
    x, y = [int(v) for v in listing.get('position').split(',')]
    width, height = [int(v) for v in listing.get('size').split(',')]
    info_height = 70 if getDesktop(0).size().height() >= 1080 else 56
    listing.set('position', '%d,%d' % (x, y + info_height))
    listing.set('size', '%d,%d' % (width, height - info_height))
    ET.SubElement(screen, 'widget', {'source': 'account_info', 'render': 'Label', 'position': '%d,%d' % (x + 12, y), 'size': '%d,%d' % (width - 24, info_height), 'font': '%s;%d' % (FONT, 24 if info_height == 70 else 20), 'foregroundColor': '#E9D5FF', 'backgroundColor': '#1a0b2e', 'zPosition': '2'})
    return ET.tostring(screen, encoding='unicode')

def xtream_list_skin(original):
    """Keep Xtream row data and named widgets, with the Free TV layout."""
    screen = ET.fromstring(_free_channels_skin())
    old = ET.fromstring(original)
    for widget in screen.findall('widget'):
        if widget.get('source') == 'title':
            widget.set('source', 'main_title')
        if widget.get('source') == 'list':
            widget.set('source', 'main_list')
            width, height = [int(v) for v in widget.get('size').split(',')]
            row = 92 if getDesktop(0).size().height() >= 1080 else 72
            font = 42 if getDesktop(0).size().width() >= 1920 else 32
            widget.find('convert').text = '{"template":[MultiContentEntryPixmapAlphaBlend(pos=(14,18),size=(48,48),png=1),MultiContentEntryText(pos=(80,4),size=(%d,%d),font=0,text=0,color=0xFFFFFF,color_sel=0xFFFFFF,backcolor=0x251440,backcolor_sel=0x6D3FC4,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER)],"fonts":[gFont("%s",%d)],"itemHeight":%d}' % (width - 92, row - 8, FONT, font, row)
    for widget in old.findall('widget'):
        if widget.get('name'):
            widget.set('position', '-100,-100')
            widget.set('size', '1,1')
            screen.append(widget)
    return ET.tostring(screen, encoding='unicode')
