from __future__ import absolute_import

from Plugins.Extensions.Alkuds._vendor.future.utils import PY2

if PY2:
    from ConfigParser import *
else:
    from configparser import *
