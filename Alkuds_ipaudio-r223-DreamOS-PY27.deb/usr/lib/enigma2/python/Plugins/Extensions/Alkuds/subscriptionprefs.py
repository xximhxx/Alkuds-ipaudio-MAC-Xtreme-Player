# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Local subscription favourites and explicit removal of checked inactive accounts."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import hashlib
from .py2compat import json
from .py2compat import os
from .py2compat import shutil
import tempfile
from .py2compat import threading
from .py2compat import time
from .py2compat import urllib
urlsplit = urllib.parse.urlsplit
parse_qs = urllib.parse.parse_qs
PATH = '/etc/enigma2/alkuds/subscription_favourites.json'
LOCK = threading.RLock()

def identity(kind, item):
    info = item.get('playlist_info', {}) if kind == 'xtream' else item
    keys = ('host', 'domain', 'username', 'password') if kind == 'xtream' else ('portal', 'mac')
    return hashlib.sha256(json.dumps([kind] + [info.get(k, '') for k in keys], ensure_ascii=True).encode()).hexdigest()

def read():
    try:
        with open(PATH, encoding='utf8') as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}

def atomic(path, data):
    parent = os.path.dirname(path)
    os.makedirs(parent, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.alkuds-', dir=parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, 384)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)

def is_favourite(kind, item):
    return read().get(identity(kind, item)) is True

def toggle(kind, item):
    with LOCK:
        data = read()
        key = identity(kind, item)
        value = not data.get(key, False)
        if value:
            data[key] = True
        else:
            data.pop(key, None)
        atomic(PATH, json.dumps(data).encode())
        return value

def ordered(kind, items):
    favourites = read()
    return sorted(items, key=lambda item: not favourites.get(identity(kind, item), False))

def removable(kind, items, statuses, since=None):
    since = time.time() - 86400 if since is None else since
    return [item for item in items if statuses.get(identity(kind, item), {}).get('checked', 0) >= since and statuses.get(identity(kind, item), {}).get('status') in ('Expired', 'Inactive')]

def _xtream_key(info):
    host = str(info.get('host') or info.get('domain') or '').rstrip('/')
    parsed = urlsplit(host if '://' in host else '//' + host)
    return (parsed.netloc.lower(), str(info.get('username') or ''), str(info.get('password') or ''))

def _backup(path):
    if os.path.isfile(path):
        target = path + '.before-inactive-removal.bak'
        if not os.path.exists(target):
            shutil.copy2(path, target)
            os.chmod(target, 384)

def remove_xtream(accounts, playlist_path, json_path):
    """Comment exact saved account lines; preserve an undo copy and import tombstones."""
    targets = {_xtream_key(item.get('playlist_info') or {}) for item in accounts}
    with LOCK:
        with open(playlist_path, encoding='utf-8-sig') as handle:
            lines = handle.readlines()
        output = []
        for line in lines:
            text = line.strip()
            if text and (not text.startswith('#')):
                parsed = urlsplit(text.split()[0])
                query = parse_qs(parsed.query)
                key = (parsed.netloc.lower(), query.get('username', [''])[0], query.get('password', [''])[0])
                if key in targets:
                    line = '#' + line
            output.append(line)
        with open(json_path, encoding='utf8') as handle:
            stored = json.load(handle)
        retained = [item for item in stored if _xtream_key(item.get('playlist_info') or {}) not in targets]
        from .localimport import read_store, identity as import_identity, STORE
        imports = read_store()
        removed = set(imports.get('removed_xtream') or [])
        for item in imports.get('xtream') or []:
            if _xtream_key(item) in targets:
                removed.add(import_identity('xtream', item))
        imports['removed_xtream'] = sorted(removed)
        changes = {playlist_path: ''.join(output).encode('utf8'), json_path: json.dumps(retained, ensure_ascii=False, indent=2).encode('utf8'), STORE: json.dumps(imports, ensure_ascii=True, indent=2).encode()}
        originals = {}
        for path in changes:
            _backup(path)
            if os.path.isfile(path):
                with open(path, 'rb') as handle:
                    originals[path] = handle.read()
            else:
                originals[path] = None
        written = []
        try:
            for path, content in changes.items():
                atomic(path, content)
                written.append(path)
        except Exception:
            for path in reversed(written):
                if originals[path] is None:
                    os.unlink(path)
                else:
                    atomic(path, originals[path])
            raise
    return len(stored) - len(retained)
