# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Syria Live public matches, schedule and ordinary player sources."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import re
from .py2compat import time
from .py2compat import threading
from .py2compat import datetime
from .py2compat import urllib
urlparse = urllib.parse.urlparse
from .py2compat import requests
from .matchdata import parse_fixtures
from .plasmatv import _hls_qualities
BASE = 'syrialive'
SECTION_MAP = {'browse': (u'سيريا لايف - المباريات', '')}
API = 'https://api.syria-scores.info/api/v2/lives'
SCHEDULE = 'https://syriashdab.com/'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
_cache = (0, None)
_lock = threading.RLock()

def _get(url, headers=None, limit=2097152, bounded=True):
    with requests.get(url, headers=headers or {'User-Agent': UA}, timeout=(5, 12), stream=True) as response:
        response.raise_for_status()
        raw = response.raw.read(limit + (1 if bounded else 0), decode_content=True)
        if bounded and len(raw) > limit:
            raise RuntimeError(u'رد سيريا لايف أكبر من الحد المسموح.')
        return (raw, response.url)

def _live_rows(raw):
    text = raw.decode('utf-8-sig')
    try:
        data = json.loads(text)
        rows = data.get('lives') if isinstance(data, dict) else None
    except ValueError:
        start = re.match('\\s*\\{\\s*"lives"\\s*:\\s*\\[', text)
        if not start:
            raise RuntimeError(u'سيريا لايف أرسل بيانات غير صالحة.')
        rows, pos = ([], start.end())
        decoder = json.JSONDecoder()
        while pos < len(text):
            while pos < len(text) and text[pos] in ' \r\n\t,':
                pos += 1
            try:
                row, pos = decoder.raw_decode(text, pos)
            except ValueError:
                break
            if not isinstance(row, dict):
                break
            rows.append(row)
    if not isinstance(rows, list):
        raise RuntimeError(u'سيريا لايف أرسل قائمة غير صالحة.')
    return rows

def _team(value):
    value = re.sub('[\\u064b-\\u065f\\u0640]', '', str(value or ''))
    return re.sub('\\s+', ' ', value.translate(str.maketrans(u'أإآىة', u'ااايه'))).strip().lower()

def _kickoff(start):
    try:
        dt = datetime.fromisoformat(str(start).replace('Z', '+00:00'))
        if dt.tzinfo is None:
            return (str(start), '')
        local = dt.astimezone()
        return (local.strftime('%H:%M'), local.strftime('%d/%m/%Y %H:%M %z'))
    except (ValueError, TypeError):
        return (u'وقت غير متوفر', '')

def _quality(label, url):
    match = re.search('(?:^|\\D)(2160|1440|1080|720|576|480|360|240)(?:p|\\D|$)', str(label) + ' ' + urlparse(url).path, re.I)
    if match:
        return match.group(1) + 'p'
    match = re.search('\\b(4K|FHD|HD|SD)\\b', str(label), re.I)
    return match.group(1).upper() if match else ''

def _timestamp(value):
    try:
        dt = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return dt.timestamp() if dt.tzinfo is not None else None
    except (ValueError, TypeError, OverflowError):
        return None

def order_events(events):

    def key(event):
        stamp = event.get('start_timestamp')
        if stamp is None:
            return (3, 0, event['id'])
        state = event.get('state')
        if state == 'live':
            return (0, stamp, event['id'])
        if state in ('finished', 'ended', 'cancelled', 'postponed'):
            return (2, -stamp, event['id'])
        return (1, stamp, event['id'])
    return sorted(events, key=key)

def _event(row, fixtures):
    if not isinstance(row, dict):
        return None
    home, away = (str(row.get('home_team') or ''), str(row.get('away_team') or ''))
    if not home or not away:
        return None
    key = (_team(home), _team(away))
    matches = [x for x in fixtures if tuple((_team(n) for n in x['names'])) == key]
    fixture = matches[0] if len(matches) == 1 else {}
    start = row.get('start_time') or row.get('kickoff') or fixture.get('start')
    clock, when = _kickoff(start)
    state = fixture.get('status') or row.get('status') or 'unknown'
    status = fixture.get('label') or {'live': u'مباشر', 'not_started': u'لم تبدأ', 'finished': u'انتهت', 'ended': u'انتهت'}.get(state, '')
    scores = fixture.get('scores') or []
    result = ' - '.join((str(x) for x in scores)) if len(scores) == 2 and state in ('live', 'finished', 'ended') else u'ضد'
    links = row.get('stream_links') or {}
    header_map = row.get('stream_headers') or {}
    if not isinstance(links, dict):
        return None
    streams = []
    for label, value in links.items():
        raw = value if isinstance(value, dict) else {'url': value}
        if raw.get('drm') or raw.get('drmKey') or raw.get('license'):
            continue
        url = str(raw.get('url') or '').strip().replace('\\u0026', '&')
        if urlparse(url).scheme not in ('http', 'https') or not urlparse(url).hostname:
            continue
        headers = header_map.get(label, {}) if isinstance(header_map, dict) else {}
        headers = dict(headers) if isinstance(headers, dict) else {}
        headers.setdefault('User-Agent', UA)
        if any(('\r' in str(v) or '\n' in str(v) for v in headers.values())):
            continue
        streams.append({'name': str(label), 'url': url, 'headers': headers, 'quality': _quality(label, url), 'source': 'syrialive'})
    if not streams:
        return None
    title = home + ' ' + result + ' ' + away
    return {'id': str(row.get('match_id') or home + ' vs ' + away), 'name': clock + ' | ' + title + (' | ' + status if status else '') + u' | %d سيرفر' % len(streams), 'title': title, 'time': clock, 'when': when, 'section': 'channels', 'streams': streams, 'state': state, 'status': status, 'score': result, 'start_timestamp': _timestamp(start), 'description': ' | '.join((x for x in [when, status] + fixture.get('meta', []) if x)), 'category': fixture.get('meta', [''])[-1] if fixture.get('meta') else '', 'image': str(row.get('home_logo') or row.get('away_logo') or ''), 'source': 'syrialive'}

def catalogue(force=False):
    global _cache
    with _lock:
        if not force and _cache[1] is not None and (time.time() - _cache[0] < 25):
            return _cache[1]
        raw, final = _get(API)
        rows = _live_rows(raw)
        fixtures = []
        try:
            html, final = _get(SCHEDULE)
            fixtures = parse_fixtures(html.decode('utf-8-sig'))
        except Exception:
            pass
        events = order_events([x for x in (_event(row, fixtures) for row in rows) if x])
        if not events:
            raise RuntimeError(u'لا توجد مباريات بروابط متاحة في سيريا لايف حالياً.')
        _cache = (time.time(), events)
        return events

def refresh():
    global _cache
    with _lock:
        _cache = (0, None)

def groups():
    return [dict(x) for x in catalogue()]

def page(parent, number):
    event = next((x for x in catalogue() if x['id'] == parent.get('id')), None)
    if event is None:
        raise RuntimeError(u'المباراة لم تعد متاحة؛ حدث القائمة.')
    entries = [dict(event, name=u'سيرفر %d | %s' % (index + 1, stream['name']), server_index=index, server_key=stream['name'], server_name=stream['name'], url=stream['url'], quality=stream['quality'], action='play') for index, stream in enumerate(event['streams'])]
    start = (max(1, int(number)) - 1) * 24
    return {'entries': entries[start:start + 24], 'last_page': max(1, (len(entries) + 23) // 24)}

def resolve(item):
    events = catalogue(force=True)
    event = next((x for x in events if x['id'] == item.get('id')), None)
    index = item.get('server_index')
    if event is not None and item.get('server_name'):
        index = next((n for n, s in enumerate(event['streams']) if s['name'] == item['server_name']), None)
    if event is None or not isinstance(index, int) or (not 0 <= index < len(event['streams'])):
        raise RuntimeError(u'المباراة أو السيرفر لم يعد متاحاً؛ حدث القائمة.')
    stream = dict(event['streams'][index])
    path = urlparse(stream['url']).path.lower()
    if not path.endswith(('.m3u8', '.ts', '.mp4', '.aac', '.mp3')):
        from .livehd import resolve_livehd_server
        result = resolve_livehd_server(stream, UA)
        variants = result.get('streams') or []
        if not variants:
            raise RuntimeError(u'صفحة هذا السيرفر لم تعرض بثاً صالحاً للرسيفر.')
        for variant in variants:
            variant['quality'] = _quality(variant.get('name', ''), variant['url']) or variant.get('quality') or 'Auto'
    else:
        raw, final = _get(stream['url'], stream['headers'], 65536, bounded=False)
        stream.update(url=final, relay=True, relay_options={'livehd': True}, quality=stream['quality'] or 'Auto')
        if raw.lstrip().startswith(b'#EXTM3U'):
            text = raw.decode('utf-8-sig')
            if 'SAMPLE-AES' in text or re.search('KEYFORMAT="(?!identity")', text):
                raise RuntimeError(u'هذا السيرفر محمي ولا يدعمه مشغل الرسيفر.')
            stream['mediatype'] = 'hls'
            variants = _hls_qualities(text, stream)
        elif raw[:1] == b'G':
            stream['mediatype'] = 'ts'
            variants = [stream]
        elif b'ftyp' in raw[:32]:
            stream['mediatype'] = 'mp4'
            variants = [stream]
        else:
            raise RuntimeError(u'السيرفر لم يرجع بثاً صالحاً؛ اختر سيرفراً آخر.')
    return dict(event, name=event['title'] + ' | ' + stream['name'], url=variants[0]['url'], streams=variants)
