# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Zaflam movies/series, site filters, complete pagination and player buttons."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .py2compat import json
from .py2compat import time
from .py2compat import threading
from .py2compat import requests
from . import arabseed as a
from . import sitecatalogue as c
BASE = 'https://zaflam.com/'
HOSTS = ('zaflam.com', 'www.zaflam.com')
SECTION_MAP = {'browse': (u'تصفح الموقع', 'recent'), 'recent': (u'المضاف حديثاً', 'recent'), 'movies': (u'الأفلام', 'movies'), 'series': (u'المسلسلات', 'series')}
_search_cache = {}
_search_lock = threading.Lock()

def _local(value):
    return c.local(BASE, HOSTS, value)

def _get(session, value, params=None):
    html, final, mime = c.get(session, _local(value), BASE, params)
    _local(final)
    return (html, final)

def groups():
    return [{'name': u'البحث في كل الأقسام', 'section': 'browse', 'action': 'search'}, {'name': u'المضاف حديثاً', 'section': 'recent', 'node': 'sections'}, {'name': u'الأفلام', 'section': 'movies', 'node': 'sections'}, {'name': u'المسلسلات', 'section': 'series', 'node': 'sections'}]

def sections(section, parent):
    result = [{'name': u'البحث في هذا القسم', 'action': 'search'}, {'name': u'عرض النتائج بترتيب الموقع', 'node': 'items'}, {'name': u'ترتيب عناوين الصفحة أ–ي', 'node': 'items', 'order': 'az'}, {'name': u'ترتيب عناوين الصفحة ي–أ', 'node': 'items', 'order': 'za'}]
    if section in ('movies', 'series'):
        result += [{'name': name, 'filter': key, 'node': 'filters'} for key, name in [('genre', u'التصنيف'), ('year', u'سنة الإنتاج'), ('country', u'الدولة')]]
    if parent.get('filters'):
        result.append({'name': u'إلغاء الفلاتر', 'node': 'sections', 'filters': {}, 'filter_labels': {}})
    return result

def filters(section, parent):
    with requests.Session() as session:
        html, page = _get(session, SECTION_MAP[section][1])
    root = a.Document(html).root
    result = []
    for node in root.find('li', 'zf-drop-item'):
        if node.attrs.get('data-target') != 'input-' + parent['filter']:
            continue
        values, labels = (dict(parent.get('filters') or {}), dict(parent.get('filter_labels') or {}))
        value = node.attrs.get('data-value', '')
        if value:
            values[parent['filter']], labels[parent['filter']] = (value, node.text())
        else:
            values.pop(parent['filter'], None)
            labels.pop(parent['filter'], None)
        result.append({'name': node.text(), 'filters': values, 'filter_labels': labels, 'node': 'sections'})
    return result

def _rows(root, page, section):
    rows, seen = ([], set())
    for node in root.find():
        href = node.attrs.get('href', '')
        click = re.search('window\\.location\\s*=\\s*[\'\\"]([^\'\\"]+)[\'\\"]', node.attrs.get('onclick', ''))
        if click:
            href = click.group(1)
        path = c.urlparse(href).path
        if not (path.startswith('/titles/') or re.match('/watch/[^/]+/season/\\d+/episode/\\d+', path)):
            continue
        titles = node.find('h3') + node.find('h2')
        if not titles:
            continue
        url = _local(href)
        series = section == 'series' or path.startswith('/watch/')
        if path.startswith('/watch/'):
            slug = path.split('/')[2]
            url = _local('titles/' + slug)
        if url in seen:
            continue
        seen.add(url)
        title = titles[0].text()
        year_nodes = node.find('h1')
        year = year_nodes[0].text() if year_nodes else ''
        quality = re.search('\\b(?:\\d{3,4}[pP]|4K)(?:\\s+(?:WEB-DL|BLURAY|HDCAM|WEBRIP))?', node.text())
        rows.append({'id': url, 'url': url, 'name': title, 'title': title, 'is_series': series, 'series_key': url, 'section': section, 'image': c.image(node, page), 'quality': quality.group(0) if quality else '', 'category': (u'مسلسل' if series else u'فيلم') + (u' | ' + year if year else ''), 'search_text': node.text().lower()})
    return rows

def _catalogue(session, section, page, options):
    values = dict(options.get('filters') or {})
    url = c.page_url(_local(SECTION_MAP[section][1]), page)
    html, final = _get(session, url, values)
    root = a.Document(html).root
    rows = _rows(root, final, section)
    return (rows, c.last_page(root, page))

def _search(session, query, section):
    key = (query, section)
    with _search_lock:
        cached = _search_cache.get(key)
        if cached and time.time() - cached[0] < 120:
            return cached[1]
    html, page = _get(session, 'search/api', {'q': query})
    value = json.loads(html)
    raw = value.get('results') or []
    result = None
    if int(value.get('count') or len(raw)) < 100 and len(raw) < 100:
        result = []
        for item in raw:
            if not item.get('slug'):
                continue
            series = item.get('type') == 'series'
            if section in ('movies', 'series') and series != (section == 'series'):
                continue
            url = _local('titles/' + item['slug'])
            title = item.get('title') or item.get('original_title') or item['slug']
            original = item.get('original_title')
            if original and original != title:
                title += u' — ' + original
            result.append({'id': url, 'url': url, 'name': title, 'title': title, 'is_series': series, 'series_key': url, 'section': section, 'image': item.get('poster') or '', 'quality': '', 'category': (u'مسلسل' if series else u'فيلم') + u' | ' + str(item.get('year') or '')})
    with _search_lock:
        if len(_search_cache) > 30:
            compat_clear(_search_cache)
        _search_cache[key] = (time.time(), result)
    return result

def fetch_items(section, page=1, query='', order='latest', options=None):
    page, options = (max(1, int(page)), options or {})
    with requests.Session() as session:
        if query:
            quick = _search(session, query, section) if not options.get('filters') else None
            if quick is not None:
                rows = quick if page == 1 else []
                return {'entries': rows, 'page': page, 'last_page': 1, 'total': len(rows)}
            modes = [section] if section in ('movies', 'series') else ['movies', 'series']
            rows, lasts = ([], [])
            for mode in modes:
                values, last = _catalogue(session, mode, page, options)
                rows.extend((x for x in values if query.lower() in x['search_text']))
                lasts.append(last)
            last = max(lasts)
        else:
            rows, last = _catalogue(session, section, page, options)
    return {'entries': rows, 'page': page, 'last_page': last, 'total': len(rows)}

def seasons(item):
    with requests.Session() as session:
        html, final = _get(session, item['url'])
    root = a.Document(html).root
    rows, seen = ([], set())
    for node in root.find('a'):
        value = node.attrs.get('href', '')
        match = re.search('/watch/([^/]+)/season/(\\d+)/episode/(\\d+)', value)
        if not match or match.group(2) in seen:
            continue
        seen.add(match.group(2))
        row = dict(item)
        row.update(name=u'الموسم %d' % int(match.group(2)), season=True, season_url=_local(value), season_number=int(match.group(2)), series_title=item['name'], is_series=False)
        rows.append(row)
    if not rows:
        raise RuntimeError(u'الموقع لم يعرض مواسم هذا المسلسل حالياً.')
    rows.sort(key=lambda x: x['season_number'])
    return rows

def episodes(item, page=1):
    with requests.Session() as session:
        html, final = _get(session, item['season_url'])
    root = a.Document(html).root
    values = [n.attrs.get('href', '') for n in root.find('a', 'ep-card')]
    values.insert(0, final)
    rows, seen = ([], set())
    season_path = c.urlparse(item['season_url']).path.rsplit('/episode/', 1)[0]
    for value in values:
        target = _local(value)
        path = c.urlparse(target).path
        if not path.startswith(season_path + '/episode/'):
            continue
        match = re.search('/episode/(\\d+)', path)
        if not match or target in seen:
            continue
        seen.add(target)
        number = int(match.group(1))
        row = dict(item)
        row.update(name=u'الحلقة %d' % number, episode=number, url=target, title=item['series_title'] + u' — الحلقة %d' % number, is_series=False, season=False, episode_query=False)
        rows.append(row)
    rows.sort(key=lambda x: x['episode'])
    return {'entries': rows, 'page': 1, 'last_page': 1, 'total': len(rows)}

def servers(item):
    with requests.Session() as session:
        html, final = _get(session, item['url'])
    root = a.Document(html).root
    values = []
    for node in root.find():
        click = node.attrs.get('onclick', '')
        match = re.search('select(?:Movie)?Server\\([\'\\"]([^\'\\"]+)[\'\\"]', click)
        if match:
            values.append((node.attrs.get('data-label') or node.text(), match.group(1), ''))
    if not values:
        for frame in root.find('iframe'):
            if frame.attrs.get('id') in ('mainPlayer', 'moviePlayer') and frame.attrs.get('src'):
                values.append((u'المشغل الرئيسي', frame.attrs['src'], ''))
    return c.server_rows(values, item, final)
resolve = c.resolve
