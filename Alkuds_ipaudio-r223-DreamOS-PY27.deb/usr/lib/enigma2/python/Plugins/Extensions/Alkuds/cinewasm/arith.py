# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from ..py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import ctypes
from ..py2compat import math
import struct

class I(object):

    def __init__(self, blen):
        self.bits_length = blen * 8
        self.byte_length = blen
        self.mask = (1 << self.bits_length) - 1
        self.mask_sign = 1 << self.bits_length - 1
        self.max = (1 << self.bits_length - 1) - 1
        self.min = -1 << self.bits_length - 1

    def from_bytearray(self, data):
        if not len(data) == self.byte_length:
            raise AssertionError('Invalid WebAssembly state')
        return int.from_bytes(data, 'little', signed=True)

    def into_bytearray(self, n):
        return bytearray(to_bytes(n, self.byte_length, 'little', signed=True))

    def fit(self, n):
        n = n & self.mask
        n = n - ((n & self.mask_sign) << 1)
        return n

    def sat(self, n):
        return max(min(n, self.max), self.min)

    def add(self, a, b):
        return self.fit(a + b)

    def add_sat(self, a, b):
        return self.sat(a + b)

    def sub(self, a, b):
        return self.fit(a - b)

    def sub_sat(self, a, b):
        return self.sat(a - b)

    def mul(self, a, b):
        return self.fit(a * b)

    def div(self, a, b):
        if not (a != self.min or b != -1):
            raise AssertionError('Invalid WebAssembly state')
        return a // b if a * b > 0 else (a + -a % b) // b

    def rem(self, a, b):
        return a % b if a * b > 0 else -(-a % b)

    def shl(self, a, b):
        return self.fit(a << (b & self.bits_length - 1))

    def shr(self, a, b):
        return self.fit(a >> (b & self.bits_length - 1))

class U(object):

    def __init__(self, blen):
        self.bits_length = blen * 8
        self.byte_length = blen
        self.mask = (1 << self.bits_length) - 1
        self.mask_sign = 1 << self.bits_length - 1
        self.max = self.mask
        self.min = 0

    def from_bytearray(self, data):
        if not len(data) == self.byte_length:
            raise AssertionError('Invalid WebAssembly state')
        return int.from_bytes(data, 'little', signed=False)

    def into_bytearray(self, n):
        return bytearray(to_bytes(n, self.byte_length, 'little', signed=False))

    def fit(self, n):
        return n & self.mask

    def sat(self, n):
        return max(min(n, self.max), self.min)

    def add(self, a, b):
        return self.fit(a + b)

    def add_sat(self, a, b):
        return self.sat(a + b)

    def sub(self, a, b):
        return self.fit(a - b)

    def sub_sat(self, a, b):
        return self.sat(a - b)

    def mul(self, a, b):
        return self.fit(a * b)

    def div(self, a, b):
        return a // b

    def rem(self, a, b):
        return a % b

    def shl(self, a, b):
        return self.fit(a << (b & self.bits_length - 1))

    def shr(self, a, b):
        return self.fit(a >> (b & self.bits_length - 1))

    def rotl(self, a, b):
        b = b % self.bits_length
        return a << b & self.mask | a >> self.bits_length - b

    def rotr(self, a, b):
        b = b % self.bits_length
        return a >> b | a << self.bits_length - b & self.mask

    def clz(self, a):
        b = 0
        for _ in range(self.bits_length):
            if a & self.mask_sign != 0:
                break
            b += 1
            a = a << 1
        return b

    def ctz(self, a):
        b = 0
        for _ in range(self.bits_length):
            if a & 1 != 0:
                break
            b += 1
            a = a >> 1
        return b

    def popcnt(self, a):
        b = 0
        for _ in range(self.bits_length):
            if a & 1 != 0:
                b += 1
            a = a >> 1
        return b

class F32(object):

    def __init__(self):
        pass

    def from_bytearray(self, data):
        if not len(data) == 4:
            raise AssertionError('Invalid WebAssembly state')
        return struct.unpack('<f', data)[0]

    def into_bytearray(self, n):
        return bytearray(struct.pack('<f', ctypes.c_float(n).value))

    def fit(self, n):
        return ctypes.c_float(n).value

    def div(self, a, b):
        return self.fit(f64.div(a, b))

    def min(self, a, b):
        return self.fit(f64.min(a, b))

    def max(self, a, b):
        return self.fit(f64.max(a, b))

class F64(object):

    def __init__(self):
        pass

    def from_bytearray(self, data):
        if not len(data) == 8:
            raise AssertionError('Invalid WebAssembly state')
        return struct.unpack('<d', data)[0]

    def into_bytearray(self, n):
        return bytearray(struct.pack('<d', n))

    def fit(self, n):
        return n

    def div(self, a, b):
        _alkuds_match_value_1 = b
        if _alkuds_match_value_1 == 0:
            s = +1 if math.copysign(1, a) == math.copysign(1, b) else -1
            c = math.copysign(math.inf, s)
            if a == 0 or math.isnan(a):
                c = math.copysign(math.nan, s)
        elif True:
            c = a / b
        return c

    def min(self, a, b):
        c = min(a, b)
        if math.isnan(a):
            c = a
        if math.isnan(b):
            c = b
        return c

    def max(self, a, b):
        c = max(a, b)
        if math.isnan(a):
            c = a
        if math.isnan(b):
            c = b
        return c
i8 = I(1)
u8 = U(1)
i16 = I(2)
u16 = U(2)
i32 = I(4)
i64 = I(8)
u32 = U(4)
u64 = U(8)
f32 = F32()
f64 = F64()
