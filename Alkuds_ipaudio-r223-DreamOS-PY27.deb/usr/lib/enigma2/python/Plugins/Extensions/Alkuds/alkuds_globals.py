# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
currentPlayingServiceRef = None
currentPlayingServiceRefString = ''
newPlayingServiceRef = None
newPlayingServiceRefString = ''
current_selection = 0
active_playlist = {}
currentchannellist = None
currentchannellistindex = 0
currentepglist = []
nextlist = []
originalChannelList1 = []
originalChannelList2 = []
originalChannelList3 = []
originalChannelList4 = []
catchupdata = []
currentDownloadTotalBytes = 0
pintime = 0
adultChannel = False
categoryname = None
ChoiceBoxDialog = None
current_list = None
current_level = None
current_screen = None
previous_screen = None
current_active_playlist_selection = 0
