# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import getkoora
from .sirfbsui import Alkuds_SirTV_Browser

class Alkuds_Getkoora_Browser(Alkuds_SirTV_Browser):
    provider = getkoora
    site_name = u'جيت كورة Getkoora - بتوقيت القاهرة'

    def _poll(self):
        if self.level == 'items' and self.parent.get('_match'):
            from .generaltvui import Alkuds_GeneralTV_Browser
            Alkuds_GeneralTV_Browser._poll(self)
        else:
            Alkuds_SirTV_Browser._poll(self)
