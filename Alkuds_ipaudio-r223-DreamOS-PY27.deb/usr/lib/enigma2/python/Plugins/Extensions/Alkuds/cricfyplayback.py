# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Bounded Cricfy playback preparation. Runs in the existing browser worker."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import html
from .py2compat import json
from .py2compat import re
from .py2compat import time
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlparse = urllib.parse.urlparse
from .py2compat import requests
from .cricfy import UA, split_url, _obj
from .matchqualities import qualities

class Playback(object):

    def __init__(self):
        self.session = requests.Session()
        self.deadline = time.monotonic() + 28
        self.visited = set()
        self.requests = 0

    def fetch(self, url, headers):
        if urlparse(url).scheme not in ('http', 'https'):
            raise RuntimeError(u'عنوان المشغّل غير صالح')
        remaining = self.deadline - time.monotonic()
        self.requests += 1
        if remaining <= 0 or self.requests > 12:
            raise RuntimeError(u'انتهت مهلة تجهيز السيرفر؛ جرّب سيرفرًا آخر')
        with self.session.get(url, headers=headers, timeout=(min(4, remaining), min(8, remaining)), stream=True) as response:
            response.raise_for_status()
            data = bytearray()
            for chunk in response.iter_content(188 * 16):
                data.extend(chunk)
                if self.is_video(data):
                    break
                if len(data) > 512 * 1024:
                    raise RuntimeError(u'استجابة المشغّل أكبر من الحد المسموح')
                if time.monotonic() > self.deadline:
                    raise RuntimeError(u'انتهت مهلة تجهيز السيرفر')
            return (bytes(data), response.url)

    def stream_headers(self, url, headers):
        result = dict(headers)
        prepared = requests.Request('GET', url).prepare()
        cookie = requests.cookies.get_cookie_header(self.session.cookies, prepared)
        if cookie:
            result['Cookie'] = cookie
        return result

    def media(self, url, headers, depth=0):
        if depth > 3:
            raise RuntimeError(u'قائمة الجودات متداخلة أكثر من اللازم')
        raw, final = self.fetch(url, headers)
        if raw.startswith(b'#EXTM3U') or raw.lstrip().startswith(b'#EXTM3U'):
            text = raw.decode('utf-8-sig', 'replace')
            if re.search('#EXT-X-KEY:.*METHOD=(?!NONE)', text):
                raise RuntimeError(u'هذا السيرفر يحتاج مشغّل تشفير خاص؛ اختر سيرفرًا مباشرًا')
            links = [line.strip() for line in text.splitlines() if line.strip() and (not line.startswith('#'))]
            if not links:
                raise RuntimeError(u'السيرفر أعاد قائمة فيديو فارغة')
            if '#EXT-X-STREAM-INF:' in text:
                return self.media(urljoin(final, links[0]), headers, depth + 1)
            for segment in links[-2:]:
                data, _ = self.fetch(urljoin(final, segment), headers)
                if not self.is_video(data):
                    raise RuntimeError(u'مقاطع السيرفر ليست فيديو قابلاً للتشغيل')
            return True
        if not self.is_video(raw):
            raise RuntimeError(u'السيرفر أعاد صفحة ويب بدل الفيديو')
        return True

    @staticmethod
    def is_video(data):
        return len(data) >= 188 * 3 and data[0] == data[188] == data[376] == 71 or b'ftyp' in data[:32] or (len(data) > 8 and data[4:8] in (b'styp', b'moof'))

    def walk(self, url, headers, depth=0):
        if depth > 3 or url in self.visited:
            raise RuntimeError(u'لم يظهر رابط فيديو مباشر داخل المشغّل')
        self.visited.add(url)
        raw, final = self.fetch(url, headers)
        stream = dict(url=final, headers=self.stream_headers(final, headers), source='cricfy', quality='Auto', relay=True, relay_options={'live': True, 'livehd': True})
        if raw.lstrip().startswith(b'#EXTM3U'):
            text = raw.decode('utf-8-sig', 'replace')
            self.media(final, headers)
            stream['headers'] = self.stream_headers(final, headers)
            return qualities(text, dict(stream, mediatype='hls'))
        if self.is_video(raw):
            return [dict(stream, relay=False, mediatype='ts' if raw[:1] == b'G' else 'mp4')]
        text = raw.decode('utf-8-sig', 'replace')
        from .sirfbs import media_candidates
        candidates = media_candidates(text, final)
        candidates += re.findall('<iframe\\b[^>]*\\bsrc\\s*=\\s*["\\\']([^"\\\']+)', text, re.I)
        errors = []
        for candidate in list(dict.fromkeys(candidates))[:4]:
            target = urljoin(final, html.unescape(candidate))
            child_headers = {key: value for key, value in headers.items() if key.lower() != 'cookie'}
            child_headers['Referer'] = final
            try:
                return self.walk(target, child_headers, depth + 1)
            except Exception as error:
                errors.append(error)
        if re.search('WebAssembly\\s*\\.|["\\\'][^"\\\']+\\.wasm(?:[?"\\\'])|Wasm\\s+decryptor', text, re.I):
            raise RuntimeError(u'هذا المشغّل يحتاج تهيئة Wasm داخل المتصفح؛ مساره غير مدعوم بعد')
        if errors:
            raise errors[-1]
        raise RuntimeError(u'هذا السيرفر يحتاج تهيئة داخل تطبيقه ولم يُرجع رابط فيديو مباشرًا')

def resolve(item):
    player = Playback()
    try:
        if item.get('protected'):
            from .cricfyclearkey import prepare
            return prepare(item, player)
        url, headers = split_url(item.get('url'), item.get('headers'))
        token = _obj(item.get('tokenApi') or item.get('token_api'))
        if token:
            if not isinstance(token, dict) or token.get('request_type', 'get').lower() != 'get':
                raise RuntimeError(u'طريقة تهيئة هذا السيرفر غير مدعومة بعد')
            target = token.get('api') or token.get('url')
            raw, final = player.fetch(target, headers)
            try:
                payload = json.loads(raw.decode('utf-8-sig'))
                resolved = payload.get(token.get('link_key') or 'url') if isinstance(payload, dict) else None
            except (ValueError, UnicodeError):
                resolved = None
            if resolved:
                url, headers = split_url(resolved, headers)
            elif token.get('type') in ('embed', 'web'):
                url = final
            else:
                raise RuntimeError(u'خدمة تهيئة السيرفر لم تُرجع رابط فيديو')
        if '/promo/' in urlparse(url).path.lower():
            raise RuntimeError(u'لم يُنشر رابط المباراة بعد؛ المصدر يعرض رابطًا ترويجيًا')
        streams = player.walk(url, headers)
        return dict(item, name=item.get('match_name') or item['name'], url=streams[0]['url'], streams=streams, variants=streams)
    except requests.HTTPError as error:
        status = error.response.status_code if error.response is not None else '?'
        raise RuntimeError(u'السيرفر غير متاح الآن (HTTP %s)؛ جرّب سيرفرًا آخر' % status)
    except requests.RequestException:
        raise RuntimeError(u'تعذر الاتصال بسيرفر البث؛ جرّب سيرفرًا آخر')
    finally:
        player.session.close()
