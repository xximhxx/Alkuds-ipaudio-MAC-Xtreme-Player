from __future__ import absolute_import
from Plugins.Extensions.Alkuds._vendor.future.utils import PY3

if PY3:
    from xmlrpc.client import *
else:
    from xmlrpclib import *
