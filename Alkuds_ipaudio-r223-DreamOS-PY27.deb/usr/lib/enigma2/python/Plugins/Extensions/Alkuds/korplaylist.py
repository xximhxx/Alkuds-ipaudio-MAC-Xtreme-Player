# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Soccer Live Player's public loader: translate obfuscated segment names only."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import base64
from .py2compat import re
from .py2compat import time
from .py2compat import urllib
urljoin = urllib.parse.urljoin
from .livehd import _get_html
from .sportacity import UA
_cache = {}

def loader_options(html, final):
    script = next((urljoin(final, x) for x in re.findall('<script[^>]+src=["\\\']([^"\\\']+)', html) if '/soccer_live_player/' in x and 'playerloader.js' in x), '')
    if not script:
        raise RuntimeError(u'لم تتوفر إعدادات مشغل جيت كورة.')
    cached = _cache.get(script)
    if cached and time.time() - cached[0] < 900:
        return dict(cached[1])
    body, target = _get_html(script, UA, final)
    values = []
    for name in ('ks', 'vs'):
        match = re.search('\\b' + name + '\\s*=\\s*\\(\\s*\\[(.*?)\\]\\s*\\)\\.join', body, re.S)
        if not match:
            raise RuntimeError(u'تغيرت إعدادات مشغل جيت كورة.')
        pieces = re.findall('["\\\']([A-Za-z0-9+/=]+)["\\\']', match.group(1))
        value = base64.b64decode(''.join(pieces)).decode('ascii')
        if not re.fullmatch('[a-fA-F0-9]+', value):
            raise RuntimeError(u'إعدادات مشغل غير صحيحة.')
        values.append(value)
    options = {'kor_names': {'key': values[0], 'iv': values[1]}}
    _cache[script] = (time.time(), options)
    return options

def rewrite_names(text, settings):
    key = bytes.fromhex(settings['key'])
    iv = bytes.fromhex(settings['iv'].zfill(32)[:32])

    def decrypt(value):
        value = value.replace('-', '+').replace('_', '/')
        raw = base64.b64decode(value + '=' * (-len(value) % 4))
        try:
            from Crypto.Cipher import AES
            plain = AES.new(key, AES.MODE_CBC, iv).decrypt(raw)
        except ImportError:
            try:
                from Cryptodome.Cipher import AES
                plain = AES.new(key, AES.MODE_CBC, iv).decrypt(raw)
            except ImportError:
                from .generalaes import AESModeOfOperationCBC
                cipher = AESModeOfOperationCBC(key, iv=iv)
                plain = b''.join((cipher.decrypt(raw[i:i + 16]) for i in range(0, len(raw), 16)))
        pad = plain[-1]
        if not 1 <= pad <= 16 or plain[-pad:] != bytes([pad]) * pad:
            raise ValueError('Invalid playlist name padding')
        return plain[:-pad].decode('utf-8') + '.kor'
    lines = []
    for line in text.splitlines():
        match = re.fullmatch('(\\S+)\\.kor\\s*', line)
        lines.append(decrypt(match.group(1)) if match else line)
    return '\n'.join(lines) + '\n'
