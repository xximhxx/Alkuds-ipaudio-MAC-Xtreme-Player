# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from ..py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
import ctypes
from ..py2compat import time
from ..py2compat import io_module as io
from ..py2compat import math
from . import arith
from . import leb128
from . import log
from . import opcode
import struct

class ValType(object):

    def __init__(self, data):
        if not data in [127, 126, 125, 124, 123, 112, 111]:
            raise AssertionError('Invalid WebAssembly state')
        self.data = data

    def __eq__(self, value):
        if not isinstance(value, self.__class__):
            raise AssertionError('Invalid WebAssembly state')
        return self.data == value.data

    def __hash__(self):
        return hash(self.data)

    def __repr__(self):
        return {127: 'i32', 126: 'i64', 125: 'f32', 124: 'f64', 123: 'v128', 112: 'ref.func', 111: 'ref.extern'}[self.data]

    @classmethod
    def i32(cls):
        return cls(127)

    @classmethod
    def i64(cls):
        return cls(126)

    @classmethod
    def f32(cls):
        return cls(125)

    @classmethod
    def f64(cls):
        return cls(124)

    @classmethod
    def v128(cls):
        return cls(123)

    @classmethod
    def ref_func(cls):
        return cls(112)

    @classmethod
    def ref_extern(cls):
        return cls(111)

    @classmethod
    def from_reader(cls, r):
        return cls(ord(r.read(1)))

class ValInst(object):
    blen = 16

    def __init__(self, type, data):
        if not len(data) == self.blen:
            raise AssertionError('Invalid WebAssembly state')
        self.type = type
        self.data = data

    def __eq__(self, value):
        if not isinstance(value, self.__class__):
            raise AssertionError('Invalid WebAssembly state')
        return self.type == value.type and self.data == value.data

    def __repr__(self):
        _alkuds_match_value_1 = self.type.data
        if _alkuds_match_value_1 == 127:
            return u'{0} {1}'.format(self.type, self.into_i32())
        elif _alkuds_match_value_1 == 126:
            return u'{0} {1}'.format(self.type, self.into_i64())
        elif _alkuds_match_value_1 == 125:
            return u'{0} {1}'.format(self.type, self.into_f32())
        elif _alkuds_match_value_1 == 124:
            return u'{0} {1}'.format(self.type, self.into_f64())
        elif _alkuds_match_value_1 == 123:
            return u'{0} {1}'.format(self.type, byte_hex(self.into_v128()))
        elif _alkuds_match_value_1 == 112:
            body = repr(self.into_ref()) if self.data[4] != 0 else 'null'
            return u'{0} {1}'.format(self.type, body)
        elif _alkuds_match_value_1 == 111:
            body = repr(self.into_ref()) if self.data[4] != 0 else 'null'
            return u'{0} {1}'.format(self.type, body)
        elif True:
            raise Exception('unreachable')

    @classmethod
    def from_i32(cls, n):
        return cls(ValType.i32(), arith.i32.into_bytearray(n) + bytearray(cls.blen - 4))

    @classmethod
    def from_i64(cls, n):
        return cls(ValType.i64(), arith.i64.into_bytearray(n) + bytearray(cls.blen - 8))

    @classmethod
    def from_u32(cls, n):
        return cls(ValType.i32(), arith.u32.into_bytearray(n) + bytearray(cls.blen - 4))

    @classmethod
    def from_u64(cls, n):
        return cls(ValType.i64(), arith.u64.into_bytearray(n) + bytearray(cls.blen - 8))

    @classmethod
    def from_f32(cls, n):
        n = ctypes.c_float(n).value
        return cls(ValType.f32(), bytearray(struct.pack('<f', n)) + bytearray(cls.blen - 4))

    @classmethod
    def from_f32_u32(cls, n):
        o = cls.from_u32(n)
        o.type = ValType.f32()
        return o

    @classmethod
    def from_f64(cls, n):
        return cls(ValType.f64(), bytearray(struct.pack('<d', n)) + bytearray(cls.blen - 8))

    @classmethod
    def from_f64_u64(cls, n):
        o = cls.from_u64(n)
        o.type = ValType.f64()
        return o

    @classmethod
    def from_v128(cls, n):
        if not len(n) == 16:
            raise AssertionError('Invalid WebAssembly state')
        return cls(ValType.v128(), n + bytearray(cls.blen - 16))

    @classmethod
    def from_v128_i8(cls, n):
        if not len(n) == 16:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.i8.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_v128_u8(cls, n):
        if not len(n) == 16:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.u8.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_v128_i16(cls, n):
        if not len(n) == 8:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.i16.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_v128_u16(cls, n):
        if not len(n) == 8:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.u16.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_v128_i32(cls, n):
        if not len(n) == 4:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.i32.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_v128_u32(cls, n):
        if not len(n) == 4:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.u32.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_v128_i64(cls, n):
        if not len(n) == 2:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.i64.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_v128_u64(cls, n):
        if not len(n) == 2:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.u64.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_v128_f32(cls, n):
        if not len(n) == 4:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.f32.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_v128_f64(cls, n):
        if not len(n) == 2:
            raise AssertionError('Invalid WebAssembly state')
        data = bytearray().join([arith.f64.into_bytearray(e) for e in n]) + bytearray(cls.blen - 16)
        return cls(ValType.v128(), data)

    @classmethod
    def from_ref(cls, type, n):
        return cls(type, bytearray(struct.pack('<i', n)) + bytearray([1]) + bytearray(cls.blen - 5))

    @classmethod
    def from_all(cls, type, n):
        _alkuds_match_value_2 = type.data
        if _alkuds_match_value_2 == 127:
            return cls.from_i32(n)
        elif _alkuds_match_value_2 == 126:
            return cls.from_i64(n)
        elif _alkuds_match_value_2 == 125:
            return cls.from_f32(n)
        elif _alkuds_match_value_2 == 124:
            return cls.from_f64(n)
        elif _alkuds_match_value_2 == 123:
            return cls.from_v128(n)
        elif _alkuds_match_value_2 == 112:
            return cls.from_ref(type, n)
        elif _alkuds_match_value_2 == 111:
            return cls.from_ref(type, n)
        elif True:
            raise Exception('unreachable')

    def into_i32(self):
        return struct.unpack('<i', self.data[0:4])[0]

    def into_i64(self):
        return struct.unpack('<q', self.data[0:8])[0]

    def into_u32(self):
        return struct.unpack('<I', self.data[0:4])[0]

    def into_u64(self):
        return struct.unpack('<Q', self.data[0:8])[0]

    def into_f32(self):
        return struct.unpack('<f', self.data[0:4])[0]

    def into_f64(self):
        return struct.unpack('<d', self.data[0:8])[0]

    def into_v128(self):
        return compat_copy(self.data[:16])

    def into_v128_i8(self):
        return [arith.i8.fit(e) for e in self.data]

    def into_v128_u8(self):
        return [arith.u8.fit(e) for e in self.data]

    def into_v128_i16(self):
        return [arith.i16.from_bytearray(bytearray(self.data[i:i + 2])) for i in range(0, 16, 2)]

    def into_v128_u16(self):
        return [arith.u16.from_bytearray(bytearray(self.data[i:i + 2])) for i in range(0, 16, 2)]

    def into_v128_i32(self):
        return [arith.i32.from_bytearray(bytearray(self.data[i:i + 4])) for i in range(0, 16, 4)]

    def into_v128_u32(self):
        return [arith.u32.from_bytearray(bytearray(self.data[i:i + 4])) for i in range(0, 16, 4)]

    def into_v128_i64(self):
        return [arith.i64.from_bytearray(bytearray(self.data[i:i + 8])) for i in range(0, 16, 8)]

    def into_v128_u64(self):
        return [arith.u64.from_bytearray(bytearray(self.data[i:i + 8])) for i in range(0, 16, 8)]

    def into_v128_f32(self):
        return [arith.f32.from_bytearray(bytearray(self.data[i:i + 4])) for i in range(0, 16, 4)]

    def into_v128_f64(self):
        return [arith.f64.from_bytearray(bytearray(self.data[i:i + 8])) for i in range(0, 16, 8)]

    def into_ref(self):
        if not self.data[4] == 1:
            raise AssertionError('Invalid WebAssembly state')
        return self.into_i32()

    def into_all(self):
        _alkuds_match_value_3 = self.type.data
        if _alkuds_match_value_3 == 127:
            return self.into_i32()
        elif _alkuds_match_value_3 == 126:
            return self.into_i64()
        elif _alkuds_match_value_3 == 125:
            return self.into_f32()
        elif _alkuds_match_value_3 == 124:
            return self.into_f64()
        elif _alkuds_match_value_3 == 123:
            return self.into_v128()
        elif _alkuds_match_value_3 == 112:
            return self.into_ref()
        elif _alkuds_match_value_3 == 111:
            return self.into_ref()
        elif True:
            raise Exception('unreachable')

    @classmethod
    def zero(cls, type):
        return cls(type, bytearray(cls.blen))

class Bype(object):

    def __init__(self, kind, data):
        if not kind in [0, 1, 2]:
            raise AssertionError('Invalid WebAssembly state')
        self.kind = kind
        self.data = data

    def __eq__(self, value):
        if not isinstance(value, self.__class__):
            raise AssertionError('Invalid WebAssembly state')
        return self.kind == value.kind and self.data == value.data

    def __repr__(self):
        if self.kind == 0:
            return 'empty'
        if self.kind == 1:
            return repr(ValType(self.data))
        return repr(self.data)

    @classmethod
    def from_reader(cls, r):
        n = ord(r.read(1))
        if n == 64:
            return cls(0, 64)
        if n in [127, 126, 125, 124, 123, 112, 111]:
            return cls(1, n)
        r.seek(-1, 1)
        return cls(2, leb128.i.decode_reader(r)[0])

class Inst(object):

    def __init__(self, opcode, args):
        self.opcode = opcode
        self.args = args

    def __repr__(self):
        return self.into_single()

    def into_single(self):
        seps = [opcode.name[self.opcode]]
        if self.opcode in [opcode.block, opcode.loop, opcode.if_then]:
            seps.append(repr(self.args[0]))
            return ' '.join(seps)
        for e in self.args:
            seps.append(repr(e))
        return ' '.join(seps)

    def into_disasm(self, indent):
        prefix = ' ' * indent
        log.debugln(u'{0}{1}'.format(prefix, self.into_single()))
        if self.opcode in [opcode.block, opcode.loop, opcode.if_then]:
            for e in self.args[1]:
                e.into_disasm(indent + 4)

    @classmethod
    def from_reader(cls, r):
        b = ord(r.read(1))
        if b >= 252:
            e = leb128.u.encode(leb128.u.decode_reader(r)[0])
            b = int.from_bytes(bytearray([b]) + e, 'big')
        if not b in opcode.name:
            raise AssertionError(hex(b))
        o = cls(b, [])
        _alkuds_match_value_4 = o.opcode
        if _alkuds_match_value_4 == opcode.block:
            o.args.append(Bype.from_reader(r))
            o.args.append([])
            for _ in range(1 << 32):
                i = cls.from_reader(r)
                if i.opcode == opcode.end:
                    break
                o.args[1].append(i)
        elif _alkuds_match_value_4 == opcode.loop:
            o.args.append(Bype.from_reader(r))
            o.args.append([])
            for _ in range(1 << 32):
                i = cls.from_reader(r)
                if i.opcode == opcode.end:
                    break
                o.args[1].append(i)
        elif _alkuds_match_value_4 == opcode.if_then:
            o.args.append(Bype.from_reader(r))
            o.args.append([])
            o.args.append([])
            argidx = 1
            for _ in range(1 << 32):
                i = cls.from_reader(r)
                if i.opcode == opcode.end:
                    break
                if i.opcode == opcode.else_fi:
                    argidx = 2
                    continue
                o.args[argidx].append(i)
        elif _alkuds_match_value_4 == opcode.br:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.br_if:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.br_table:
            o.args.append([leb128.u.decode_reader(r)[0] for _ in range(leb128.u.decode_reader(r)[0])])
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.call:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.call_indirect:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.select_type:
            o.args.append([leb128.u.decode_reader(r)[0] for _ in range(leb128.u.decode_reader(r)[0])])
        elif _alkuds_match_value_4 == opcode.local_get:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.local_set:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.local_tee:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.global_get:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.global_set:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.table_get:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.table_set:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.i32_load:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 3:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_load:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.f32_load:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 3:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.f64_load:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i32_load8_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 1:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i32_load8_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 1:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i32_load16_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i32_load16_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_load8_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 1:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_load8_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 1:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_load16_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_load16_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_load32_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 3:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_load32_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 3:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i32_store:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 3:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_store:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.f32_store:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 3:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.f64_store:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i32_store8:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 1:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i32_store16:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_store8:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 1:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_store16:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64_store32:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 3:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.memory_size:
            o.args.append(ord(r.read(1)))
        elif _alkuds_match_value_4 == opcode.memory_grow:
            o.args.append(ord(r.read(1)))
        elif _alkuds_match_value_4 == opcode.i32_const:
            o.args.append(leb128.i.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.i64_const:
            o.args.append(leb128.i.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.f32_const:
            o.args.append(struct.unpack('<i', r.read(4))[0])
        elif _alkuds_match_value_4 == opcode.f64_const:
            o.args.append(struct.unpack('<q', r.read(8))[0])
        elif _alkuds_match_value_4 == opcode.ref_null:
            o.args.append(ord(r.read(1)))
        elif _alkuds_match_value_4 == opcode.ref_func:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.memory_init:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not ord(r.read(1)) == 0:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.data_drop:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.memory_copy:
            if not ord(r.read(1)) == 0:
                raise AssertionError('Invalid WebAssembly state')
            if not ord(r.read(1)) == 0:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.memory_fill:
            if not ord(r.read(1)) == 0:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.table_init:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.elem_drop:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.table_copy:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.table_grow:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.table_size:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.table_fill:
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.v128_load:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 5:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load8x8_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load8x8_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load16x4_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load16x4_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load32x2_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load32x2_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load8_splat:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 1:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load16_splat:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load32_splat:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 3:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load64_splat:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_store:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 5:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_const:
            o.args.append(bytearray(r.read(16)))
        elif _alkuds_match_value_4 == opcode.i8x16_shuffle:
            for _ in range(16):
                o.args.append(leb128.u.decode_reader(r)[0])
            for e in o.args:
                if not e < 32:
                    raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i8x16_extract_lane_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 16:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i8x16_extract_lane_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 16:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i8x16_replace_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 16:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i16x8_extract_lane_s:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 8:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i16x8_extract_lane_u:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 8:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i16x8_replace_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 8:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i32x4_extract_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i32x4_replace_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64x2_extract_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.i64x2_replace_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.f32x4_extract_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.f32x4_replace_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.f64x2_extract_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.f64x2_replace_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[0] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load8_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[2] < 16:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load16_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[2] < 8:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load32_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[2] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load64_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[2] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_store8_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[2] < 16:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_store16_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[2] < 8:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_store32_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[2] < 4:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_store64_lane:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
            if not o.args[2] < 2:
                raise AssertionError('Invalid WebAssembly state')
        elif _alkuds_match_value_4 == opcode.v128_load32_zero:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
        elif _alkuds_match_value_4 == opcode.v128_load64_zero:
            o.args.append(leb128.u.decode_reader(r)[0])
            o.args.append(leb128.u.decode_reader(r)[0])
        return o

class Expr(object):

    def __init__(self, data):
        self.data = data

    def __repr__(self):
        return repr(self.data)

    def into_disasm(self, indent):
        for e in self.data:
            e.into_disasm(indent)

    @classmethod
    def from_reader(cls, r):
        s = []
        for _ in range(1 << 32):
            i = Inst.from_reader(r)
            if i.opcode == opcode.end:
                break
            s.append(i)
        return cls(s)

class LocalsDesc(object):

    def __init__(self, n, type):
        self.n = n
        self.type = type

    def __repr__(self):
        return u'{0}x{1}'.format(self.n, self.type)

    @classmethod
    def from_reader(cls, r):
        return cls(leb128.u.decode_reader(r)[0], ValType.from_reader(r))

class LocalsInst(object):

    def __init__(self, data):
        self.data = data

    def __repr__(self):
        return repr(self.data)

class FuncType(object):

    def __init__(self, args, rets):
        self.args = args
        self.rets = rets

    def __eq__(self, value):
        if not isinstance(value, self.__class__):
            raise AssertionError('Invalid WebAssembly state')
        return self.args == value.args and self.rets == value.rets

    def __repr__(self):
        return u'{0} -> {1}'.format(self.args, self.rets)

    @classmethod
    def from_reader(cls, r):
        if not ord(r.read(1)) == 96:
            raise AssertionError('Invalid WebAssembly state')
        n = leb128.u.decode_reader(r)[0]
        args = [ValType.from_reader(r) for _ in range(n)]
        n = leb128.u.decode_reader(r)[0]
        rets = [ValType.from_reader(r) for _ in range(n)]
        return cls(args, rets)

class FuncDesc(object):

    def __init__(self, type, locals, expr):
        self.type = type
        self.locals = locals
        self.expr = expr

    def __repr__(self):
        return u'{0} {1}'.format(self.type, self.locals)

    @classmethod
    def from_reader_type(cls, r):
        return cls(leb128.u.decode_reader(r)[0], [], Expr([]))

    @classmethod
    def from_reader_code(cls, r):
        return cls(0, [LocalsDesc.from_reader(r) for _ in range(leb128.u.decode_reader(r)[0])], Expr.from_reader(r))

class Limits(object):

    def __init__(self, n, m):
        self.n = n
        self.m = m

    def __repr__(self):
        m = 'inf' if self.m == 0 else repr(self.m)
        return u'[{0}, {1}]'.format(self.n, m)

    def suit(self, value):
        c1 = self.n >= value.n
        c2 = value.m == 0
        c3 = self.m != 0 and value.m != 0 and (self.m <= value.m)
        return c1 and (c2 or c3)

    @classmethod
    def from_reader(cls, r):
        flag = ord(r.read(1))
        return cls(leb128.u.decode_reader(r)[0], leb128.u.decode_reader(r)[0] if flag else 0)

class MemType(object):

    def __init__(self, limits):
        self.limits = limits

    def __repr__(self):
        return repr(self.limits)

    @classmethod
    def from_reader(cls, r):
        return cls(Limits.from_reader(r))

class MemInst(object):

    def __init__(self, type):
        self.type = type
        self.data = bytearray()
        self.size = 0
        self.grow(type.limits.n)

    def get_i32(self, addr):
        return struct.unpack('<i', self.data[addr:addr + 4])[0]

    def get_i64(self, addr):
        return struct.unpack('<q', self.data[addr:addr + 8])[0]

    def get_u8(self, addr):
        return self.data[addr]

    def get_u16(self, addr):
        return struct.unpack('<H', self.data[addr:addr + 2])[0]

    def get_u32(self, addr):
        return struct.unpack('<I', self.data[addr:addr + 4])[0]

    def get_u64(self, addr):
        return struct.unpack('<Q', self.data[addr:addr + 8])[0]

    def get(self, addr, size):
        return compat_copy(self.data[addr:addr + size])

    def grow(self, n):
        if self.type.limits.m:
            if not self.size + n <= self.type.limits.m:
                raise AssertionError('Invalid WebAssembly state')
        if not self.size + n <= 65536:
            raise AssertionError('Invalid WebAssembly state')
        self.data.extend(bytearray(n * 64 * 1024))
        self.size += n

    def put_i32(self, addr, data):
        self.data[addr:addr + 4] = struct.pack('<i', data)

    def put_i64(self, addr, data):
        self.data[addr:addr + 8] = struct.pack('<q', data)

    def put_u8(self, addr, data):
        self.data[addr] = data

    def put_u16(self, addr, data):
        self.data[addr:addr + 2] = struct.pack('<H', data)

    def put_u32(self, addr, data):
        self.data[addr:addr + 4] = struct.pack('<I', data)

    def put_u64(self, addr, data):
        self.data[addr:addr + 8] = struct.pack('<Q', data)

    def put(self, addr, data):
        if not isinstance(data, bytearray):
            raise AssertionError('Invalid WebAssembly state')
        self.data[addr:addr + len(data)] = compat_copy(data)

    def suit(self, l):
        return Limits(self.size, self.type.limits.m).suit(l)

class TableType(object):

    def __init__(self, type, limits):
        if not type in [ValType.ref_func(), ValType.ref_extern()]:
            raise AssertionError('Invalid WebAssembly state')
        self.type = type
        self.limits = limits

    def __repr__(self):
        return u'{0} {1}'.format(self.type, self.limits)

    @classmethod
    def from_reader(cls, r):
        return cls(ValType.from_reader(r), Limits.from_reader(r))

class TableInst(object):

    def __init__(self, type):
        self.type = type
        self.elem = []
        self.size = 0
        self.grow(type.limits.n, ValInst.zero(self.type.type))

    def grow(self, n, v):
        if self.type.limits.m:
            if not self.size + n <= self.type.limits.m:
                raise AssertionError('Invalid WebAssembly state')
        if not v.type == self.type.type:
            raise AssertionError('Invalid WebAssembly state')
        self.elem.extend([v for _ in range(n)])
        self.size += n

    def suit(self, l):
        return Limits(self.size, self.type.limits.m).suit(l)

class GlobalType(object):

    def __init__(self, type, mut):
        if not mut in [0, 1]:
            raise AssertionError('Invalid WebAssembly state')
        self.type = type
        self.mut = mut

    def __repr__(self):
        prefix = ['const', 'var'][self.mut]
        return u'{0} {1}'.format(prefix, self.type)

    @classmethod
    def from_reader(cls, r):
        return cls(ValType.from_reader(r), ord(r.read(1)))

class GlobalDesc(object):

    def __init__(self, type, init):
        self.type = type
        self.init = init

    def __repr__(self):
        return repr(self.type)

    @classmethod
    def from_reader(cls, r):
        return cls(GlobalType.from_reader(r), Expr.from_reader(r))

class GlobalInst(object):

    def __init__(self, data, mut):
        if not mut in [0, 1]:
            raise AssertionError('Invalid WebAssembly state')
        self.data = data
        self.mut = mut

    def __repr__(self):
        return u'{0}'.format(self.data)

class Custom(object):

    def __init__(self, name, data):
        self.name = name
        self.data = data

    @classmethod
    def from_reader(cls, r):
        n = leb128.u.decode_reader(r)[0]
        return cls(r.read(n).decode(), bytearray(r.read(-1)))

class Import(object):

    def __init__(self, module, name, kind, desc):
        self.module = module
        self.name = name
        self.kind = kind
        self.desc = desc

    def __repr__(self):
        kind = {0: 'func', 1: 'table', 2: 'mem', 3: 'global'}[self.kind]
        return u'{0}.{1} {2} {3}'.format(self.module, self.name, kind, self.desc)

    @classmethod
    def from_reader(cls, r):
        n = leb128.u.decode_reader(r)[0]
        module = r.read(n).decode()
        n = leb128.u.decode_reader(r)[0]
        name = r.read(n).decode()
        type = ord(r.read(1))
        desc = {0: lambda r: leb128.u.decode_reader(r)[0], 1: TableType.from_reader, 2: MemType.from_reader, 3: GlobalType.from_reader}[type](r)
        return cls(module, name, type, desc)

class Extern(object):

    def __init__(self, kind, data):
        if not kind in [0, 1, 2, 3]:
            raise AssertionError('Invalid WebAssembly state')
        self.kind = kind
        self.data = data

    def __repr__(self):
        prefix = {0: 'func', 1: 'table', 2: 'mem', 3: 'global'}[self.kind]
        return u'{0} {1}'.format(prefix, self.data)

class ExportDesc(object):

    def __init__(self, name, kind, desc):
        if not kind in [0, 1, 2, 3]:
            raise AssertionError('Invalid WebAssembly state')
        self.name = name
        self.kind = kind
        self.desc = desc

    def __repr__(self):
        type_name = {0: 'func', 1: 'table', 2: 'mem', 3: 'global'}[self.kind]
        return u'{0} {1} {2}'.format(self.name, type_name, self.desc)

    @classmethod
    def from_reader(cls, r):
        name = bytearray(r.read(leb128.u.decode_reader(r)[0])).decode()
        kind = ord(r.read(1))
        desc = leb128.u.decode_reader(r)[0]
        return cls(name, kind, desc)

class ExportInst(object):

    def __init__(self, name, data):
        self.name = name
        self.data = data

    def __repr__(self):
        return u'{0} {1}'.format(self.name, self.data)

class ElemDesc(object):

    def __init__(self, kind, type, tidx, offset, init):
        if not kind >= 0:
            raise AssertionError('Invalid WebAssembly state')
        if not kind <= 7:
            raise AssertionError('Invalid WebAssembly state')
        self.kind = kind
        self.type = type
        self.tidx = tidx
        self.offset = offset
        self.init = init

    def __repr__(self):
        return u'{0}'.format(self.tidx)

    @classmethod
    def from_reader(cls, r):
        kind = leb128.u.decode_reader(r)[0]
        type = ValType.ref_func()
        tidx = 0
        offset = Expr([])
        init = []
        _alkuds_match_value_5 = kind
        if _alkuds_match_value_5 == 0:
            offset = Expr.from_reader(r)
            for _ in range(leb128.u.decode_reader(r)[0]):
                fidx = leb128.u.decode_reader(r)[0]
                expr = Expr([Inst(opcode.ref_func, [fidx])])
                init.append(expr)
        elif _alkuds_match_value_5 == 1:
            if not ord(r.read(1)) == 0:
                raise AssertionError('Invalid WebAssembly state')
            for _ in range(leb128.u.decode_reader(r)[0]):
                fidx = leb128.u.decode_reader(r)[0]
                expr = Expr([Inst(opcode.ref_func, [fidx])])
                init.append(expr)
        elif _alkuds_match_value_5 == 2:
            tidx = leb128.u.decode_reader(r)[0]
            offset = Expr.from_reader(r)
            if not ord(r.read(1)) == 0:
                raise AssertionError('Invalid WebAssembly state')
            for _ in range(leb128.u.decode_reader(r)[0]):
                fidx = leb128.u.decode_reader(r)[0]
                expr = Expr([Inst(opcode.ref_func, [fidx])])
                init.append(expr)
        elif _alkuds_match_value_5 == 3:
            if not ord(r.read(1)) == 0:
                raise AssertionError('Invalid WebAssembly state')
            for _ in range(leb128.u.decode_reader(r)[0]):
                fidx = leb128.u.decode_reader(r)[0]
                expr = Expr([Inst(opcode.ref_func, [fidx])])
                init.append(expr)
        elif _alkuds_match_value_5 == 4:
            offset = Expr.from_reader(r)
            for _ in range(leb128.u.decode_reader(r)[0]):
                expr = Expr.from_reader(r)
                init.append(expr)
        elif _alkuds_match_value_5 == 5:
            type = ValType.from_reader(r)
            for _ in range(leb128.u.decode_reader(r)[0]):
                expr = Expr.from_reader(r)
                init.append(expr)
        elif _alkuds_match_value_5 == 6:
            tidx = leb128.u.decode_reader(r)[0]
            offset = Expr.from_reader(r)
            type = ValType.from_reader(r)
            for _ in range(leb128.u.decode_reader(r)[0]):
                expr = Expr.from_reader(r)
                init.append(expr)
        elif _alkuds_match_value_5 == 7:
            type = ValType.from_reader(r)
            for _ in range(leb128.u.decode_reader(r)[0]):
                expr = Expr.from_reader(r)
                init.append(expr)
        return cls(kind, type, tidx, offset, init)

class ElemInst(object):

    def __init__(self, type, data):
        if not type in [ValType.ref_func(), ValType.ref_extern()]:
            raise AssertionError('Invalid WebAssembly state')
        self.type = type
        self.data = data

    def __repr__(self):
        return u'{0}'.format(self.type)

class DataDesc(object):

    def __init__(self, kind, midx, offset, init):
        if not kind in [0, 1, 2]:
            raise AssertionError('Invalid WebAssembly state')
        if not midx == 0:
            raise AssertionError('Invalid WebAssembly state')
        self.kind = kind
        self.midx = midx
        self.offset = offset
        self.init = init

    def __repr__(self):
        return u'{0}'.format(self.midx)

    @classmethod
    def from_reader(cls, r):
        kind = leb128.u.decode_reader(r)[0]
        _alkuds_match_value_6 = kind
        if _alkuds_match_value_6 == 0:
            midx = 0
            offset = Expr.from_reader(r)
            init = bytearray(r.read(leb128.u.decode_reader(r)[0]))
            return cls(kind, midx, offset, init)
        elif _alkuds_match_value_6 == 1:
            midx = 0
            offset = Expr([])
            init = bytearray(r.read(leb128.u.decode_reader(r)[0]))
            return cls(kind, midx, offset, init)
        elif _alkuds_match_value_6 == 2:
            midx = leb128.u.decode_reader(r)[0]
            offset = Expr.from_reader(r)
            init = bytearray(r.read(leb128.u.decode_reader(r)[0]))
            return cls(kind, midx, offset, init)
        elif True:
            raise Exception('unreachable')

class DataInst(object):

    def __init__(self, data):
        self.data = data

    def __repr__(self):
        return u'data'.format()

class ModuleDesc(object):

    def __init__(self, type, func, tabl, mems, glob, elem, data, star, imps, exps):
        self.type = type
        self.func = func
        self.tabl = tabl
        self.mems = mems
        self.glob = glob
        self.elem = elem
        self.data = data
        self.star = star
        self.imps = imps
        self.exps = exps

    @classmethod
    def from_reader(cls, r):
        if not bytearray(r.read(4)) == bytearray([0, 97, 115, 109]):
            raise AssertionError('Invalid WebAssembly state')
        if not bytearray(r.read(4)) == bytearray([1, 0, 0, 0]):
            raise AssertionError('Invalid WebAssembly state')
        type = []
        func = []
        tabl = []
        mems = []
        glob = []
        elem = []
        data = []
        star = -1
        imps = []
        exps = []
        for _ in range(32):
            section_id_byte = r.read(1)
            if not section_id_byte:
                break
            section_id = ord(section_id_byte)
            n = leb128.u.decode_reader(r)[0]
            section_data = bytearray(r.read(n))
            if not len(section_data) == n:
                raise AssertionError('Invalid WebAssembly state')
            section_reader = io.BytesIO(section_data)
            _alkuds_match_value_7 = section_id
            if _alkuds_match_value_7 == 0:
                desc = Custom.from_reader(section_reader)
                log.debugln('section custom', desc.name)
            elif _alkuds_match_value_7 == 1:
                for _ in range(leb128.u.decode_reader(section_reader)[0]):
                    desc = FuncType.from_reader(section_reader)
                    type.append(desc)
                    log.debugln('section type', desc)
            elif _alkuds_match_value_7 == 2:
                for _ in range(leb128.u.decode_reader(section_reader)[0]):
                    desc = Import.from_reader(section_reader)
                    imps.append(desc)
                    log.debugln('section import', desc)
            elif _alkuds_match_value_7 == 3:
                for _ in range(leb128.u.decode_reader(section_reader)[0]):
                    desc = FuncDesc.from_reader_type(section_reader)
                    func.append(desc)
                    log.debugln('section func', desc.type)
            elif _alkuds_match_value_7 == 4:
                for _ in range(leb128.u.decode_reader(section_reader)[0]):
                    desc = TableType.from_reader(section_reader)
                    tabl.append(desc)
                    log.debugln('section table', desc)
            elif _alkuds_match_value_7 == 5:
                for _ in range(leb128.u.decode_reader(section_reader)[0]):
                    desc = MemType.from_reader(section_reader)
                    mems.append(desc)
                    log.debugln('section memory', desc)
            elif _alkuds_match_value_7 == 6:
                for _ in range(leb128.u.decode_reader(section_reader)[0]):
                    desc = GlobalDesc.from_reader(section_reader)
                    glob.append(desc)
                    log.debugln('section global', desc)
            elif _alkuds_match_value_7 == 7:
                for _ in range(leb128.u.decode_reader(section_reader)[0]):
                    desc = ExportDesc.from_reader(section_reader)
                    exps.append(desc)
                    log.debugln('section export', desc)
            elif _alkuds_match_value_7 == 8:
                desc = leb128.u.decode_reader(section_reader)[0]
                star = desc
                log.debugln('section start', desc)
            elif _alkuds_match_value_7 == 9:
                for _ in range(leb128.u.decode_reader(section_reader)[0]):
                    desc = ElemDesc.from_reader(section_reader)
                    elem.append(desc)
                    log.debugln('section elem', desc)
            elif _alkuds_match_value_7 == 10:
                for i in range(leb128.u.decode_reader(section_reader)[0]):
                    size = leb128.u.decode_reader(section_reader)[0]
                    desc = FuncDesc.from_reader_code(io.BytesIO(section_reader.read(size)))
                    func[i].locals = desc.locals
                    func[i].expr = desc.expr
                    log.debugln('section code', desc)
                    desc.expr.into_disasm(4)
            elif _alkuds_match_value_7 == 11:
                for _ in range(leb128.u.decode_reader(section_reader)[0]):
                    desc = DataDesc.from_reader(section_reader)
                    data.append(desc)
                    log.debugln('section data', desc)
            elif _alkuds_match_value_7 == 12:
                n = leb128.u.decode_reader(section_reader)[0]
                log.debugln('section data count', n)
        return cls(type, func, tabl, mems, glob, elem, data, star, imps, exps)

class ModuleInst(object):

    def __init__(self):
        self.type = []
        self.func = []
        self.tabl = []
        self.mems = []
        self.glob = []
        self.elem = []
        self.data = []
        self.exps = []

class FuncInst(object):

    def __init__(self, type, module, code):
        self.kind = 0
        self.type = type
        self.module = module
        self.code = code

    def __repr__(self):
        return u'{0}'.format(self.type)

class FuncHost(object):

    def __init__(self, type, hostcode):
        self.kind = 1
        self.type = type
        self.hostcode = hostcode

    def __repr__(self):
        return self.hostcode.__name__

class Store(object):

    def __init__(self):
        self.func = []
        self.tabl = []
        self.mems = []
        self.glob = []
        self.elem = []
        self.data = []

    def allocate_func_wasm(self, module, func):
        addr = len(self.func)
        type = module.type[func.type]
        inst = FuncInst(type, module, func)
        self.func.append(inst)
        return addr

    def allocate_func_host(self, func):
        addr = len(self.func)
        self.func.append(func)
        return addr

    def allocate_table(self, type):
        addr = len(self.tabl)
        inst = TableInst(type)
        self.tabl.append(inst)
        return addr

    def allocate_memory(self, type):
        addr = len(self.mems)
        inst = MemInst(type)
        self.mems.append(inst)
        return addr

    def allocate_global(self, type, data):
        addr = len(self.glob)
        inst = GlobalInst(data, type.mut)
        self.glob.append(inst)
        return addr

    def allocate_elem(self, type, data):
        addr = len(self.elem)
        inst = ElemInst(type, data)
        self.elem.append(inst)
        return addr

    def allocate_data(self, data):
        addr = len(self.data)
        inst = DataInst(data)
        self.data.append(inst)
        return addr

class Label(object):

    def __init__(self, arity, frame, value, carry, instr, index):
        if not carry in [0, 1, 3]:
            raise AssertionError('Invalid WebAssembly state')
        self.arity = arity
        self.frame = frame
        self.value = value
        self.carry = carry
        self.instr = instr
        self.index = index

    def __repr__(self):
        return u'{0}'.format(self.arity)

class Frame(object):

    def __init__(self, module, locals, arity, label, value):
        self.module = module
        self.locals = locals
        self.arity = arity
        self.label = label
        self.value = value

    def __repr__(self):
        return u'{0}'.format(self.arity)

class Stack(object):

    def __init__(self):
        self.value = []
        self.label = []
        self.frame = []

class Machine(object):

    def __init__(self):
        self.store = Store()
        self.stack = Stack()

    def allocate(self, module, extern, globin, elemin):
        inst = ModuleInst()
        inst.type = module.type
        for e in extern:
            _alkuds_match_value_8 = e.kind
            if _alkuds_match_value_8 == 0:
                inst.func.append(e.data)
            elif _alkuds_match_value_8 == 1:
                inst.tabl.append(e.data)
            elif _alkuds_match_value_8 == 2:
                inst.mems.append(e.data)
            elif _alkuds_match_value_8 == 3:
                inst.glob.append(e.data)
        for _, e in enumerate(module.func):
            addr = self.store.allocate_func_wasm(inst, e)
            inst.func.append(addr)
        for _, e in enumerate(module.tabl):
            addr = self.store.allocate_table(e)
            inst.tabl.append(addr)
        for _, e in enumerate(module.mems):
            addr = self.store.allocate_memory(e)
            inst.mems.append(addr)
        for i, e in enumerate(module.glob):
            addr = self.store.allocate_global(e.type, globin[i])
            inst.glob.append(addr)
        for i, e in enumerate(module.elem):
            addr = self.store.allocate_elem(e.type, elemin[i])
            inst.elem.append(addr)
        for i, e in enumerate(module.data):
            addr = self.store.allocate_data(e.init)
            inst.data.append(addr)
        for _, e in enumerate(module.exps):
            expi = ExportInst(e.name, Extern(e.kind, 0))
            _alkuds_match_value_9 = e.kind
            if _alkuds_match_value_9 == 0:
                expi.data.data = inst.func[e.desc]
            elif _alkuds_match_value_9 == 1:
                expi.data.data = inst.tabl[e.desc]
            elif _alkuds_match_value_9 == 2:
                expi.data.data = inst.mems[e.desc]
            elif _alkuds_match_value_9 == 3:
                expi.data.data = inst.glob[e.desc]
            inst.exps.append(expi)
        return inst

    def instance(self, module, extern):
        if not len(module.imps) == len(extern):
            raise AssertionError('Invalid WebAssembly state')
        for a, b in zip(module.imps, extern):
            if not a.kind == b.kind:
                raise AssertionError('Invalid WebAssembly state')
            _alkuds_match_value_10 = a.kind
            if _alkuds_match_value_10 == 0:
                if not self.store.func[b.data].type == module.type[a.desc]:
                    raise AssertionError('Invalid WebAssembly state')
            elif _alkuds_match_value_10 == 1:
                if not self.store.tabl[b.data].type.type == a.desc.type:
                    raise AssertionError('Invalid WebAssembly state')
                if not self.store.tabl[b.data].suit(a.desc.limits):
                    raise AssertionError('Invalid WebAssembly state')
            elif _alkuds_match_value_10 == 2:
                if not self.store.mems[b.data].suit(a.desc.limits):
                    raise AssertionError('Invalid WebAssembly state')
            elif _alkuds_match_value_10 == 3:
                if not self.store.glob[b.data].data.type == a.desc.type:
                    raise AssertionError('Invalid WebAssembly state')
                if not self.store.glob[b.data].mut == a.desc.mut:
                    raise AssertionError('Invalid WebAssembly state')
        globin = []
        elemin = []
        auxmod = ModuleInst()
        auxmod.func.extend([e.data for e in extern if e.kind == 0])
        auxmod.func.extend([len(self.store.func) + i for i in range(len(module.func))])
        auxmod.glob.extend([e.data for e in extern if e.kind == 3])
        self.stack.frame.append(Frame(auxmod, LocalsInst([]), 1, 0, 0))
        for i, e in enumerate(module.glob):
            log.debugln('init global', e)
            self.stack.label.append(Label(1, 1, 0, 1, e.init.data, 0))
            self.evaluate()
            if not len(self.stack.frame) == 1:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.label) == 0:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.value) == 1:
                raise AssertionError('Invalid WebAssembly state')
            rets = self.stack.value.pop()
            globin.append(rets)
        for i, e in enumerate(module.elem):
            log.debugln('init elem', e)
            l = []
            for f in e.init:
                self.stack.label.append(Label(1, 1, 0, 1, f.data, 0))
                self.evaluate()
                if not len(self.stack.frame) == 1:
                    raise AssertionError('Invalid WebAssembly state')
                if not len(self.stack.label) == 0:
                    raise AssertionError('Invalid WebAssembly state')
                if not len(self.stack.value) == 1:
                    raise AssertionError('Invalid WebAssembly state')
                rets = self.stack.value.pop()
                l.append(rets)
            elemin.append(l)
        self.stack.frame.pop()
        newmod = self.allocate(module, extern, globin, elemin)
        if not newmod.func == auxmod.func:
            raise AssertionError('Invalid WebAssembly state')
        self.stack.frame.append(Frame(newmod, LocalsInst([]), 0, 0, 0))
        for i, e in enumerate(module.elem):
            if e.kind & 1 != 0:
                continue
            expr = []
            expr.extend(e.offset.data)
            expr.append(Inst(opcode.i32_const, [0]))
            expr.append(Inst(opcode.i32_const, [len(e.init)]))
            expr.append(Inst(opcode.table_init, [i, e.tidx]))
            expr.append(Inst(opcode.elem_drop, [i]))
            self.stack.label.append(Label(1, 1, 0, 1, expr, 0))
            self.evaluate()
            if not len(self.stack.frame) == 1:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.label) == 0:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.value) == 0:
                raise AssertionError('Invalid WebAssembly state')
        for i, e in enumerate(module.elem):
            if e.kind & 3 != 3:
                continue
            expr = []
            expr.append(Inst(opcode.elem_drop, [i]))
            self.stack.label.append(Label(1, 1, 0, 1, expr, 0))
            self.evaluate()
            if not len(self.stack.frame) == 1:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.label) == 0:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.value) == 0:
                raise AssertionError('Invalid WebAssembly state')
        for i, e in enumerate(module.data):
            log.debugln('init data', e)
            if e.kind & 1 != 0:
                continue
            expr = []
            expr.extend(e.offset.data)
            expr.append(Inst(opcode.i32_const, [0]))
            expr.append(Inst(opcode.i32_const, [len(e.init)]))
            expr.append(Inst(opcode.memory_init, [i]))
            expr.append(Inst(opcode.data_drop, [i]))
            self.stack.label.append(Label(1, 1, 0, 1, expr, 0))
            self.evaluate()
            if not len(self.stack.frame) == 1:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.label) == 0:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.value) == 0:
                raise AssertionError('Invalid WebAssembly state')
        if module.star >= 0:
            expr = []
            expr.append(Inst(opcode.call, [module.star]))
            self.stack.label.append(Label(1, 1, 0, 1, expr, 0))
            self.evaluate()
            if not len(self.stack.frame) == 1:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.label) == 0:
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.value) == 0:
                raise AssertionError('Invalid WebAssembly state')
        self.stack.frame.pop()
        return newmod

    def invocate(self, addr, args):
        func = self.store.func[addr]
        if not func.kind == 0:
            raise AssertionError('Invalid WebAssembly state')
        if not isinstance(func, FuncInst):
            raise AssertionError('Invalid WebAssembly state')
        for a, b in zip(func.type.args, args):
            if not a == b.type:
                raise AssertionError('Invalid WebAssembly state')
        self.stack.frame.append(Frame(ModuleInst(), LocalsInst([]), 0, 0, 0))
        log.debugln('invocate', addr, args)
        locals = LocalsInst(args)
        for e in func.code.locals:
            locals.data.extend([ValInst.zero(e.type) for _ in range(e.n)])
        self.stack.frame.append(Frame(func.module, locals, len(func.type.rets), 0, 0))
        self.stack.label.append(Label(len(func.type.rets), 1, 0, 3, func.code.expr.data, 0))
        self.evaluate()
        rets = [self.stack.value.pop() for _ in range(len(func.type.rets))][::-1]
        for a, b in zip(func.type.rets, rets):
            if not a == b.type:
                raise AssertionError('Invalid WebAssembly state')
        self.stack.frame.pop()
        if not len(self.stack.frame) == 0:
            raise AssertionError('Invalid WebAssembly state')
        if not len(self.stack.label) == 0:
            raise AssertionError('Invalid WebAssembly state')
        if not len(self.stack.value) == 0:
            raise AssertionError('Invalid WebAssembly state')
        return rets

    def evaluate_br(self, l):
        if not len(self.stack.label) >= l + 1:
            raise AssertionError('Invalid WebAssembly state')
        label = self.stack.label[-1 - l]
        if not len(self.stack.value) >= label.value + label.arity:
            raise AssertionError('Invalid WebAssembly state')
        rets = [self.stack.value.pop() for _ in range(label.arity)][::-1]
        self.stack.frame = self.stack.frame[:label.frame]
        self.stack.label = self.stack.label[:len(self.stack.label) - l]
        _alkuds_match_value_11 = label.carry & 1
        if _alkuds_match_value_11 == 0:
            label.index = 0
        elif _alkuds_match_value_11 == 1:
            self.stack.label.pop()
        self.stack.value = self.stack.value[:label.value]
        self.stack.value.extend(rets)

    def evaluate_bype(self, bype):
        _alkuds_match_value_12 = bype.kind
        if _alkuds_match_value_12 == 0:
            return FuncType([], [])
        elif _alkuds_match_value_12 == 1:
            return FuncType([], [ValType(bype.data)])
        elif _alkuds_match_value_12 == 2:
            return self.stack.frame[-1].module.type[bype.data]
        elif True:
            raise Exception('unreachable')

    def evaluate_call(self, addr):
        func = self.store.func[addr]
        args = [self.stack.value.pop() for _ in range(len(func.type.args))][::-1]
        nret = len(func.type.rets)
        _alkuds_match_value_13 = func.kind
        if _alkuds_match_value_13 == 0:
            if not isinstance(func, FuncInst):
                raise AssertionError('Invalid WebAssembly state')
            if not len(self.stack.frame) < 1024:
                raise AssertionError('Invalid WebAssembly state')
            locals = LocalsInst(args)
            for e in func.code.locals:
                locals.data.extend([ValInst.zero(e.type) for _ in range(e.n)])
            self.stack.frame.append(Frame(func.module, locals, nret, len(self.stack.label), len(self.stack.value)))
            self.stack.label.append(Label(nret, len(self.stack.frame) - 1, len(self.stack.value), 3, func.code.expr.data, 0))
        elif _alkuds_match_value_13 == 1:
            if not isinstance(func, FuncHost):
                raise AssertionError('Invalid WebAssembly state')
            rets = func.hostcode(self, [e.into_all() for e in args])
            rets = [ValInst.from_all(a, b) for a, b in zip(func.type.rets, rets)]
            self.stack.value.extend(rets)
        elif True:
            raise Exception('unreachable')

    def evaluate_mem_load(self, offset, size):
        mems = self.store.mems[self.stack.frame[-1].module.mems[0]]
        addr = self.stack.value.pop().into_u32()
        addr = addr + offset
        if not addr + size <= len(mems.data):
            raise AssertionError('Invalid WebAssembly state')
        return mems.data[addr:addr + size]

    def evaluate_mem_save(self, offset, size):
        mems = self.store.mems[self.stack.frame[-1].module.mems[0]]
        data = self.stack.value.pop().data
        addr = self.stack.value.pop().into_u32()
        addr = addr + offset
        if not addr + size <= len(mems.data):
            raise AssertionError('Invalid WebAssembly state')
        mems.data[addr:addr + size] = data[:size]

    def evaluate(self):
        for _ in range(2000000):
            if _ == 1999999 or (_ % 4096 == 0 and time.time() > getattr(self, 'alkuds_deadline', float('inf'))):
                raise RuntimeError('CineHD decoder instruction/time limit')
            if not self.stack.label:
                break
            label = self.stack.label[-1]
            frame = self.stack.frame[-1]
            if label.index == len(label.instr):
                self.stack.label.pop()
                if label.carry & 2:
                    if not len(self.stack.value) == frame.value + frame.arity:
                        raise AssertionError('Invalid WebAssembly state')
                    self.stack.frame.pop()
                continue
            instr = label.instr[label.index]
            label.index += 1
            log.debugln('    ', instr)
            _alkuds_match_value_14 = instr.opcode
            if _alkuds_match_value_14 == opcode.unreachable:
                if not 0:
                    raise AssertionError('Invalid WebAssembly state')
            elif _alkuds_match_value_14 == opcode.nop:
                if not 1:
                    raise AssertionError('Invalid WebAssembly state')
            elif _alkuds_match_value_14 == opcode.block:
                bype = self.evaluate_bype(instr.args[0])
                if not len(self.stack.value) >= label.value + len(bype.args):
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.label.append(Label(len(bype.rets), len(self.stack.frame), len(self.stack.value) - len(bype.args), 1, instr.args[1], 0))
            elif _alkuds_match_value_14 == opcode.loop:
                bype = self.evaluate_bype(instr.args[0])
                if not len(self.stack.value) >= label.value + len(bype.args):
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.label.append(Label(len(bype.args), len(self.stack.frame), len(self.stack.value) - len(bype.args), 0, instr.args[1], 0))
            elif _alkuds_match_value_14 == opcode.if_then:
                bype = self.evaluate_bype(instr.args[0])
                cond = self.stack.value.pop().into_i32()
                if not len(self.stack.value) >= label.value + len(bype.args):
                    raise AssertionError('Invalid WebAssembly state')
                aidx = 1 if cond != 0 else 2
                self.stack.label.append(Label(len(bype.rets), len(self.stack.frame), len(self.stack.value) - len(bype.args), 1, instr.args[aidx], 0))
            elif _alkuds_match_value_14 == opcode.else_fi:
                if not 0:
                    raise AssertionError('Invalid WebAssembly state')
            elif _alkuds_match_value_14 == opcode.end:
                if not 0:
                    raise AssertionError('Invalid WebAssembly state')
            elif _alkuds_match_value_14 == opcode.br:
                self.evaluate_br(instr.args[0])
            elif _alkuds_match_value_14 == opcode.br_if:
                if self.stack.value.pop().into_i32() != 0:
                    self.evaluate_br(instr.args[0])
            elif _alkuds_match_value_14 == opcode.br_table:
                a = self.stack.value.pop().into_u32()
                b = instr.args[1]
                if a < len(instr.args[0]):
                    b = instr.args[0][a]
                self.evaluate_br(b)
            elif _alkuds_match_value_14 == opcode.return_call:
                if not len(self.stack.value) >= frame.value + frame.arity:
                    raise AssertionError('Invalid WebAssembly state')
                rets = [self.stack.value.pop() for _ in range(frame.arity)][::-1]
                self.stack.frame.pop()
                self.stack.label = self.stack.label[:frame.label]
                self.stack.value = self.stack.value[:frame.value]
                self.stack.value.extend(rets)
            elif _alkuds_match_value_14 == opcode.call:
                addr = frame.module.func[instr.args[0]]
                self.evaluate_call(addr)
            elif _alkuds_match_value_14 == opcode.call_indirect:
                tabl = self.store.tabl[frame.module.tabl[instr.args[1]]]
                type = frame.module.type[instr.args[0]]
                addr = tabl.elem[self.stack.value.pop().into_u32()].into_ref()
                if not self.store.func[addr].type == type:
                    raise AssertionError('Invalid WebAssembly state')
                self.evaluate_call(addr)
            elif _alkuds_match_value_14 == opcode.drop:
                self.stack.value.pop()
            elif _alkuds_match_value_14 == opcode.select:
                c = self.stack.value.pop().into_i32()
                b = self.stack.value.pop()
                a = self.stack.value.pop()
                d = a if c != 0 else b
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.select_type:
                c = self.stack.value.pop().into_i32()
                b = self.stack.value.pop()
                a = self.stack.value.pop()
                if not a.type.data == instr.args[0][0]:
                    raise AssertionError('Invalid WebAssembly state')
                if not b.type.data == instr.args[0][0]:
                    raise AssertionError('Invalid WebAssembly state')
                d = a if c != 0 else b
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.local_get:
                a = self.stack.frame[-1].locals.data[instr.args[0]]
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.local_set:
                a = self.stack.value.pop()
                self.stack.frame[-1].locals.data[instr.args[0]] = a
            elif _alkuds_match_value_14 == opcode.local_tee:
                a = self.stack.value[-1]
                self.stack.frame[-1].locals.data[instr.args[0]] = a
            elif _alkuds_match_value_14 == opcode.global_get:
                glob = self.store.glob[frame.module.glob[instr.args[0]]]
                self.stack.value.append(glob.data)
            elif _alkuds_match_value_14 == opcode.global_set:
                glob = self.store.glob[frame.module.glob[instr.args[0]]]
                if not glob.mut == 1:
                    raise AssertionError('Invalid WebAssembly state')
                glob.data = self.stack.value.pop()
            elif _alkuds_match_value_14 == opcode.table_get:
                tabl = self.store.tabl[frame.module.tabl[instr.args[0]]]
                a = self.stack.value.pop().into_u32()
                b = tabl.elem[a]
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.table_set:
                tabl = self.store.tabl[frame.module.tabl[instr.args[0]]]
                a = self.stack.value.pop()
                if not a.type == tabl.type.type:
                    raise AssertionError('Invalid WebAssembly state')
                b = self.stack.value.pop().into_u32()
                tabl.elem[b] = a
            elif _alkuds_match_value_14 == opcode.i32_load:
                a = ValInst(ValType.i32(), self.evaluate_mem_load(instr.args[1], 4) + bytearray(ValInst.blen - 4))
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i64_load:
                a = ValInst(ValType.i64(), self.evaluate_mem_load(instr.args[1], 8) + bytearray(ValInst.blen - 8))
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.f32_load:
                a = ValInst(ValType.f32(), self.evaluate_mem_load(instr.args[1], 4) + bytearray(ValInst.blen - 4))
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.f64_load:
                a = ValInst(ValType.f64(), self.evaluate_mem_load(instr.args[1], 8) + bytearray(ValInst.blen - 8))
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i32_load8_s:
                a = ValInst.from_i32(struct.unpack('<b', self.evaluate_mem_load(instr.args[1], 1))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i32_load8_u:
                a = ValInst.from_i32(struct.unpack('<B', self.evaluate_mem_load(instr.args[1], 1))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i32_load16_s:
                a = ValInst.from_i32(struct.unpack('<h', self.evaluate_mem_load(instr.args[1], 2))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i32_load16_u:
                a = ValInst.from_i32(struct.unpack('<H', self.evaluate_mem_load(instr.args[1], 2))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i64_load8_s:
                a = ValInst.from_i64(struct.unpack('<b', self.evaluate_mem_load(instr.args[1], 1))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i64_load8_u:
                a = ValInst.from_i64(struct.unpack('<B', self.evaluate_mem_load(instr.args[1], 1))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i64_load16_s:
                a = ValInst.from_i64(struct.unpack('<h', self.evaluate_mem_load(instr.args[1], 2))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i64_load16_u:
                a = ValInst.from_i64(struct.unpack('<H', self.evaluate_mem_load(instr.args[1], 2))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i64_load32_s:
                a = ValInst.from_i64(struct.unpack('<i', self.evaluate_mem_load(instr.args[1], 4))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i64_load32_u:
                a = ValInst.from_i64(struct.unpack('<I', self.evaluate_mem_load(instr.args[1], 4))[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i32_store:
                self.evaluate_mem_save(instr.args[1], 4)
            elif _alkuds_match_value_14 == opcode.i64_store:
                self.evaluate_mem_save(instr.args[1], 8)
            elif _alkuds_match_value_14 == opcode.f32_store:
                self.evaluate_mem_save(instr.args[1], 4)
            elif _alkuds_match_value_14 == opcode.f64_store:
                self.evaluate_mem_save(instr.args[1], 8)
            elif _alkuds_match_value_14 == opcode.i32_store8:
                self.evaluate_mem_save(instr.args[1], 1)
            elif _alkuds_match_value_14 == opcode.i32_store16:
                self.evaluate_mem_save(instr.args[1], 2)
            elif _alkuds_match_value_14 == opcode.i64_store8:
                self.evaluate_mem_save(instr.args[1], 1)
            elif _alkuds_match_value_14 == opcode.i64_store16:
                self.evaluate_mem_save(instr.args[1], 2)
            elif _alkuds_match_value_14 == opcode.i64_store32:
                self.evaluate_mem_save(instr.args[1], 4)
            elif _alkuds_match_value_14 == opcode.memory_size:
                mems = self.store.mems[frame.module.mems[0]]
                size = mems.size
                self.stack.value.append(ValInst.from_i32(size))
            elif _alkuds_match_value_14 == opcode.memory_grow:
                mems = self.store.mems[frame.module.mems[0]]
                size = mems.size
                incr = self.stack.value.pop().into_u32()
                rets = -1
                cnda = size + incr <= 1024
                cndb = mems.type.limits.m == 0 or size + incr <= mems.type.limits.m
                if cnda and cndb:
                    rets = size
                    mems.grow(incr)
                self.stack.value.append(ValInst.from_i32(rets))
            elif _alkuds_match_value_14 == opcode.i32_const:
                a = ValInst.from_i32(instr.args[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i64_const:
                a = ValInst.from_i64(instr.args[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.f32_const:
                a = ValInst.from_i32(instr.args[0])
                a.type = ValType.f32()
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.f64_const:
                a = ValInst.from_i64(instr.args[0])
                a.type = ValType.f64()
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i32_eqz:
                a = self.stack.value.pop().into_i32()
                b = ValInst.from_i32(a == 0)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32_eq:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(a == b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_ne:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(a != b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_lt_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(a < b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_lt_u:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_u32()
                c = ValInst.from_i32(a < b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_gt_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(a > b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_gt_u:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_u32()
                c = ValInst.from_i32(a > b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_le_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(a <= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_le_u:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_u32()
                c = ValInst.from_i32(a <= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_ge_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(a >= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_ge_u:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_u32()
                c = ValInst.from_i32(a >= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_eqz:
                a = self.stack.value.pop().into_i64()
                b = ValInst.from_i32(a == 0)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64_eq:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i32(a == b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_ne:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i32(a != b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_lt_s:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i32(a < b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_lt_u:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_u64()
                c = ValInst.from_i32(a < b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_gt_s:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i32(a > b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_gt_u:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_u64()
                c = ValInst.from_i32(a > b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_le_s:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i32(a <= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_le_u:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_u64()
                c = ValInst.from_i32(a <= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_ge_s:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i32(a >= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_ge_u:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_u64()
                c = ValInst.from_i32(a >= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_eq:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_i32(a == b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_ne:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_i32(a != b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_lt:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_i32(a < b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_gt:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_i32(a > b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_le:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_i32(a <= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_ge:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_i32(a >= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_eq:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_i32(a == b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_ne:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_i32(a != b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_lt:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_i32(a < b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_gt:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_i32(a > b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_le:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_i32(a <= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_ge:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_i32(a >= b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_clz:
                a = self.stack.value.pop().into_u32()
                b = arith.u32.clz(a)
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_ctz:
                a = self.stack.value.pop().into_u32()
                b = arith.u32.ctz(a)
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_popcnt:
                a = self.stack.value.pop().into_u32()
                b = arith.u32.popcnt(a)
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_add:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(arith.i32.add(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_sub:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(arith.i32.sub(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_mul:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(arith.i32.mul(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_div_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(arith.i32.div(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_div_u:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_u32()
                c = ValInst.from_u32(arith.u32.div(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_rem_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(arith.i32.rem(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_rem_u:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_u32()
                c = ValInst.from_u32(arith.u32.rem(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_and:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(a & b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_or:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(a | b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_xor:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(a ^ b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_shl:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(arith.i32.shl(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_shr_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_i32()
                c = ValInst.from_i32(arith.i32.shr(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_shr_u:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_u32()
                c = ValInst.from_u32(arith.u32.shr(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_rotl:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_u32()
                c = ValInst.from_u32(arith.u32.rotl(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_rotr:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_u32()
                c = ValInst.from_u32(arith.u32.rotr(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_clz:
                a = self.stack.value.pop().into_u64()
                b = arith.u64.clz(a)
                c = ValInst.from_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_ctz:
                a = self.stack.value.pop().into_u64()
                b = arith.u64.ctz(a)
                c = ValInst.from_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_popcnt:
                a = self.stack.value.pop().into_u64()
                b = arith.u64.popcnt(a)
                c = ValInst.from_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_add:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(arith.i64.add(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_sub:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(arith.i64.sub(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_mul:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(arith.i64.mul(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_div_s:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(arith.i64.div(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_div_u:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_u64()
                c = ValInst.from_i64(arith.u64.div(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_rem_s:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(arith.i64.rem(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_rem_u:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_u64()
                c = ValInst.from_u64(arith.u64.rem(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_and:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(a & b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_or:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(a | b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_xor:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(a ^ b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_shl:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(arith.i64.shl(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_shr_s:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_i64()
                c = ValInst.from_i64(arith.i64.shr(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_shr_u:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_u64()
                c = ValInst.from_u64(arith.u64.shr(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_rotl:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_u64()
                c = ValInst.from_u64(arith.u64.rotl(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_rotr:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_u64()
                c = ValInst.from_u64(arith.u64.rotr(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_abs:
                a = self.stack.value.pop()
                b = ValInst(ValType.f32(), compat_copy(a.data))
                b.data[3] = b.data[3] & 127
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f32_neg:
                a = self.stack.value.pop()
                b = ValInst(ValType.f32(), compat_copy(a.data))
                b.data[3] = b.data[3] ^ 128
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f32_ceil:
                a = self.stack.value.pop().into_f32()
                b = a if math.isnan(a) or math.isinf(a) else float(math.ceil(a))
                c = ValInst.from_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_floor:
                a = self.stack.value.pop().into_f32()
                b = a if math.isnan(a) or math.isinf(a) else float(math.floor(a))
                c = ValInst.from_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_trunc:
                a = self.stack.value.pop().into_f32()
                b = a if math.isnan(a) or math.isinf(a) else float(math.trunc(a))
                c = ValInst.from_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_nearest:
                a = self.stack.value.pop().into_f32()
                b = a if math.isnan(a) or math.isinf(a) else float(round(a))
                c = ValInst.from_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_sqrt:
                a = self.stack.value.pop().into_f32()
                b = math.sqrt(a) if a >= 0 else math.nan
                c = ValInst.from_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_add:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_f32(a + b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_sub:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_f32(a - b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_mul:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_f32(a * b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_div:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = arith.f32.div(a, b)
                d = ValInst.from_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32_min:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = arith.f32.min(a, b)
                d = ValInst.from_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32_max:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = arith.f32.max(a, b)
                d = ValInst.from_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32_copysign:
                b = self.stack.value.pop().into_f32()
                a = self.stack.value.pop().into_f32()
                c = ValInst.from_f32(math.copysign(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_abs:
                a = self.stack.value.pop()
                b = ValInst(ValType.f64(), compat_copy(a.data))
                b.data[7] = b.data[7] & 127
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64_neg:
                a = self.stack.value.pop()
                b = ValInst(ValType.f64(), compat_copy(a.data))
                b.data[7] = b.data[7] ^ 128
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64_ceil:
                a = self.stack.value.pop().into_f64()
                b = a if math.isnan(a) or math.isinf(a) else float(math.ceil(a))
                c = ValInst.from_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_floor:
                a = self.stack.value.pop().into_f64()
                b = a if math.isnan(a) or math.isinf(a) else float(math.floor(a))
                c = ValInst.from_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_trunc:
                a = self.stack.value.pop().into_f64()
                b = a if math.isnan(a) or math.isinf(a) else float(math.trunc(a))
                c = ValInst.from_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_nearest:
                a = self.stack.value.pop().into_f64()
                b = a if math.isnan(a) or math.isinf(a) else float(round(a))
                c = ValInst.from_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_sqrt:
                a = self.stack.value.pop().into_f64()
                b = math.sqrt(a) if a >= 0 else math.nan
                c = ValInst.from_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_add:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_f64(a + b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_sub:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_f64(a - b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_mul:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_f64(a * b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64_div:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = arith.f64.div(a, b)
                d = ValInst.from_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64_min:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = arith.f64.min(a, b)
                d = ValInst.from_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64_max:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = arith.f64.max(a, b)
                d = ValInst.from_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64_copysign:
                b = self.stack.value.pop().into_f64()
                a = self.stack.value.pop().into_f64()
                c = ValInst.from_f64(math.copysign(a, b))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_wrap_i64:
                a = self.stack.value.pop().into_i64()
                b = ValInst.from_i32(arith.i32.fit(a))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32_trunc_f32_s:
                a = self.stack.value.pop().into_f32()
                b = int(a)
                c = ValInst.from_i32(b)
                if not c.into_i32() == b:
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_trunc_f32_u:
                a = self.stack.value.pop().into_f32()
                b = int(a)
                c = ValInst.from_u32(b)
                if not c.into_u32() == b:
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_trunc_f64_s:
                a = self.stack.value.pop().into_f64()
                b = int(a)
                c = ValInst.from_i32(b)
                if not c.into_i32() == b:
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_trunc_f64_u:
                a = self.stack.value.pop().into_f64()
                b = int(a)
                c = ValInst.from_u32(b)
                if not c.into_u32() == b:
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_extend_i32_s:
                a = self.stack.value.pop().into_i32()
                b = ValInst.from_i64(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64_extend_i32_u:
                a = self.stack.value.pop().into_u32()
                b = ValInst.from_i64(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64_trunc_f32_s:
                a = self.stack.value.pop().into_f32()
                b = int(a)
                c = ValInst.from_i64(b)
                if not c.into_i64() == b:
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_trunc_f32_u:
                a = self.stack.value.pop().into_f32()
                b = int(a)
                c = ValInst.from_u64(b)
                if not c.into_u64() == b:
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_trunc_f64_s:
                a = self.stack.value.pop().into_f64()
                b = int(a)
                c = ValInst.from_i64(b)
                if not c.into_i64() == b:
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_trunc_f64_u:
                a = self.stack.value.pop().into_f64()
                b = int(a)
                c = ValInst.from_u64(b)
                if not c.into_u64() == b:
                    raise AssertionError('Invalid WebAssembly state')
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32_convert_i32_s:
                a = self.stack.value.pop().into_i32()
                b = ValInst.from_f32(float(a))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f32_convert_i32_u:
                a = self.stack.value.pop().into_u32()
                b = ValInst.from_f32(float(a))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f32_convert_i64_s:
                a = self.stack.value.pop().into_i64()
                b = ValInst.from_f32(float(a))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f32_convert_i64_u:
                a = self.stack.value.pop().into_u64()
                b = ValInst.from_f32(float(a))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f32_demote_f64:
                a = self.stack.value.pop().into_f64()
                b = ValInst.from_f32(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64_convert_i32_s:
                a = self.stack.value.pop().into_i32()
                b = ValInst.from_f64(float(a))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64_convert_i32_u:
                a = self.stack.value.pop().into_u32()
                b = ValInst.from_f64(float(a))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64_convert_i64_s:
                a = self.stack.value.pop().into_i64()
                b = ValInst.from_f64(float(a))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64_convert_i64_u:
                a = self.stack.value.pop().into_u64()
                b = ValInst.from_f64(float(a))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64_promote_f32:
                a = self.stack.value.pop().into_f32()
                b = ValInst.from_f64(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32_reinterpret_f32:
                a = self.stack.value.pop()
                b = ValInst(ValType.i32(), compat_copy(a.data))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64_reinterpret_f64:
                a = self.stack.value.pop()
                b = ValInst(ValType.i64(), compat_copy(a.data))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f32_reinterpret_i32:
                a = self.stack.value.pop()
                b = ValInst(ValType.f32(), compat_copy(a.data))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64_reinterpret_i64:
                a = self.stack.value.pop()
                b = ValInst(ValType.f64(), compat_copy(a.data))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32_extend8_s:
                a = self.stack.value.pop().into_i32()
                b = arith.i8.fit(a)
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_extend16_s:
                a = self.stack.value.pop().into_i32()
                b = arith.i16.fit(a)
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_extend8_s:
                a = self.stack.value.pop().into_i64()
                b = arith.i8.fit(a)
                c = ValInst.from_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_extend16_s:
                a = self.stack.value.pop().into_i64()
                b = arith.i16.fit(a)
                c = ValInst.from_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_extend32_s:
                a = self.stack.value.pop().into_i64()
                b = arith.i32.fit(a)
                c = ValInst.from_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.ref_null:
                a = ValInst.zero(ValType(instr.args[0]))
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.ref_is_null:
                a = self.stack.value.pop()
                if not a.type in [ValType.ref_func(), ValType.ref_extern()]:
                    raise AssertionError('Invalid WebAssembly state')
                b = 1 if a.data[4] == 0 else 0
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.ref_func:
                a = frame.module.func[instr.args[0]]
                b = ValInst.from_ref(ValType.ref_func(), a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32_trunc_sat_f32_s:
                a = self.stack.value.pop().into_f32()
                if math.isnan(a):
                    a = 0.0
                b = int(max(arith.i32.min, min(a, arith.i32.max)))
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_trunc_sat_f32_u:
                a = self.stack.value.pop().into_f32()
                if math.isnan(a):
                    a = 0.0
                b = int(max(arith.u32.min, min(a, arith.u32.max)))
                c = ValInst.from_u32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_trunc_sat_f64_s:
                a = self.stack.value.pop().into_f64()
                if math.isnan(a):
                    a = 0.0
                b = int(max(arith.i32.min, min(a, arith.i32.max)))
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32_trunc_sat_f64_u:
                a = self.stack.value.pop().into_f64()
                if math.isnan(a):
                    a = 0.0
                b = int(max(arith.u32.min, min(a, arith.u32.max)))
                c = ValInst.from_u32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_trunc_sat_f32_s:
                a = self.stack.value.pop().into_f32()
                if math.isnan(a):
                    a = 0.0
                b = int(max(arith.i64.min, min(a, arith.i64.max)))
                c = ValInst.from_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_trunc_sat_f32_u:
                a = self.stack.value.pop().into_f32()
                if math.isnan(a):
                    a = 0.0
                b = int(max(arith.u64.min, min(a, arith.u64.max)))
                c = ValInst.from_u64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_trunc_sat_f64_s:
                a = self.stack.value.pop().into_f64()
                if math.isnan(a):
                    a = 0.0
                b = int(max(arith.i64.min, min(a, arith.i64.max)))
                c = ValInst.from_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64_trunc_sat_f64_u:
                a = self.stack.value.pop().into_f64()
                if math.isnan(a):
                    a = 0.0
                b = int(max(arith.u64.min, min(a, arith.u64.max)))
                c = ValInst.from_u64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.memory_init:
                mems = self.store.mems[frame.module.mems[0]]
                data = self.store.data[frame.module.data[instr.args[0]]]
                n = self.stack.value.pop().into_u32()
                s = self.stack.value.pop().into_u32()
                d = self.stack.value.pop().into_u32()
                if not s + n <= len(data.data):
                    raise AssertionError('Invalid WebAssembly state')
                if not d + n <= len(mems.data):
                    raise AssertionError('Invalid WebAssembly state')
                mems.data[d:d + n] = data.data[s:s + n]
            elif _alkuds_match_value_14 == opcode.data_drop:
                data = self.store.data[frame.module.data[instr.args[0]]]
                compat_clear(data.data)
            elif _alkuds_match_value_14 == opcode.memory_copy:
                mems = self.store.mems[frame.module.mems[0]]
                n = self.stack.value.pop().into_u32()
                s = self.stack.value.pop().into_u32()
                d = self.stack.value.pop().into_u32()
                if not s + n <= len(mems.data):
                    raise AssertionError('Invalid WebAssembly state')
                if not d + n <= len(mems.data):
                    raise AssertionError('Invalid WebAssembly state')
                mems.data[d:d + n] = mems.data[s:s + n]
            elif _alkuds_match_value_14 == opcode.memory_fill:
                mems = self.store.mems[frame.module.mems[0]]
                n = self.stack.value.pop().into_u32()
                s = self.stack.value.pop().data[0]
                d = self.stack.value.pop().into_u32()
                if not d + n <= len(mems.data):
                    raise AssertionError('Invalid WebAssembly state')
                for i in range(n):
                    mems.data[d + i] = s
            elif _alkuds_match_value_14 == opcode.table_init:
                tabl = self.store.tabl[frame.module.tabl[instr.args[1]]]
                elem = self.store.elem[frame.module.elem[instr.args[0]]]
                n = self.stack.value.pop().into_u32()
                s = self.stack.value.pop().into_u32()
                d = self.stack.value.pop().into_u32()
                if not s + n <= len(elem.data):
                    raise AssertionError('Invalid WebAssembly state')
                if not d + n <= len(tabl.elem):
                    raise AssertionError('Invalid WebAssembly state')
                tabl.elem[d:d + n] = elem.data[s:s + n]
            elif _alkuds_match_value_14 == opcode.elem_drop:
                elem = self.store.elem[frame.module.elem[instr.args[0]]]
                compat_clear(elem.data)
            elif _alkuds_match_value_14 == opcode.table_copy:
                tabx = self.store.tabl[frame.module.tabl[instr.args[0]]]
                taby = self.store.tabl[frame.module.tabl[instr.args[1]]]
                n = self.stack.value.pop().into_u32()
                s = self.stack.value.pop().into_u32()
                d = self.stack.value.pop().into_u32()
                if not s + n <= len(taby.elem):
                    raise AssertionError('Invalid WebAssembly state')
                if not d + n <= len(tabx.elem):
                    raise AssertionError('Invalid WebAssembly state')
                tabx.elem[d:d + n] = taby.elem[s:s + n]
            elif _alkuds_match_value_14 == opcode.table_grow:
                tabl = self.store.tabl[frame.module.tabl[instr.args[0]]]
                size = tabl.size
                incr = self.stack.value.pop().into_u32()
                init = self.stack.value.pop()
                rets = -1
                cnda = size + incr <= 1024
                cndb = tabl.type.limits.m == 0 or size + incr <= tabl.type.limits.m
                if cnda and cndb:
                    rets = size
                    tabl.grow(incr, init)
                self.stack.value.append(ValInst.from_i32(rets))
            elif _alkuds_match_value_14 == opcode.table_size:
                tabl = self.store.tabl[frame.module.tabl[instr.args[0]]]
                size = tabl.size
                self.stack.value.append(ValInst.from_i32(size))
            elif _alkuds_match_value_14 == opcode.table_fill:
                tabl = self.store.tabl[frame.module.tabl[instr.args[0]]]
                n = self.stack.value.pop().into_u32()
                s = self.stack.value.pop()
                d = self.stack.value.pop().into_u32()
                if not d + n <= len(tabl.elem):
                    raise AssertionError('Invalid WebAssembly state')
                for i in range(n):
                    tabl.elem[d + i] = s
            elif _alkuds_match_value_14 == opcode.v128_load:
                a = ValInst.from_v128(self.evaluate_mem_load(instr.args[1], 16))
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.v128_load8x8_s:
                a = self.evaluate_mem_load(instr.args[1], 8)
                b = bytearray()
                for i in range(8):
                    n = a[i]
                    n = n - ((n & 128) << 1)
                    b.extend(bytearray(to_bytes(n, 2, 'little', signed=True)))
                self.stack.value.append(ValInst.from_v128(b))
            elif _alkuds_match_value_14 == opcode.v128_load8x8_u:
                a = self.evaluate_mem_load(instr.args[1], 8)
                b = bytearray()
                for i in range(8):
                    n = a[i]
                    b.extend(bytearray(to_bytes(n, 2, 'little')))
                self.stack.value.append(ValInst.from_v128(b))
            elif _alkuds_match_value_14 == opcode.v128_load16x4_s:
                a = self.evaluate_mem_load(instr.args[1], 8)
                b = bytearray()
                for i in range(4):
                    n = int.from_bytes(a[i * 2:i * 2 + 2], 'little')
                    n = n - ((n & 32768) << 1)
                    b.extend(bytearray(to_bytes(n, 4, 'little', signed=True)))
                self.stack.value.append(ValInst.from_v128(b))
            elif _alkuds_match_value_14 == opcode.v128_load16x4_u:
                a = self.evaluate_mem_load(instr.args[1], 8)
                b = bytearray()
                for i in range(4):
                    n = int.from_bytes(a[i * 2:i * 2 + 2], 'little')
                    b.extend(bytearray(to_bytes(n, 4, 'little')))
                self.stack.value.append(ValInst.from_v128(b))
            elif _alkuds_match_value_14 == opcode.v128_load32x2_s:
                a = self.evaluate_mem_load(instr.args[1], 8)
                b = bytearray()
                for i in range(2):
                    n = int.from_bytes(a[i * 4:i * 4 + 4], 'little')
                    n = n - ((n & 2147483648) << 1)
                    b.extend(bytearray(to_bytes(n, 8, 'little', signed=True)))
                self.stack.value.append(ValInst.from_v128(b))
            elif _alkuds_match_value_14 == opcode.v128_load32x2_u:
                a = self.evaluate_mem_load(instr.args[1], 8)
                b = bytearray()
                for i in range(2):
                    n = int.from_bytes(a[i * 4:i * 4 + 4], 'little')
                    b.extend(bytearray(to_bytes(n, 8, 'little')))
                self.stack.value.append(ValInst.from_v128(b))
            elif _alkuds_match_value_14 == opcode.v128_load8_splat:
                a = self.evaluate_mem_load(instr.args[1], 1)
                self.stack.value.append(ValInst.from_v128(a * 16))
            elif _alkuds_match_value_14 == opcode.v128_load16_splat:
                a = self.evaluate_mem_load(instr.args[1], 2)
                self.stack.value.append(ValInst.from_v128(a * 8))
            elif _alkuds_match_value_14 == opcode.v128_load32_splat:
                a = self.evaluate_mem_load(instr.args[1], 4)
                self.stack.value.append(ValInst.from_v128(a * 4))
            elif _alkuds_match_value_14 == opcode.v128_load64_splat:
                a = self.evaluate_mem_load(instr.args[1], 8)
                self.stack.value.append(ValInst.from_v128(a * 2))
            elif _alkuds_match_value_14 == opcode.v128_store:
                self.evaluate_mem_save(instr.args[1], 16)
            elif _alkuds_match_value_14 == opcode.v128_const:
                a = ValInst.from_v128(instr.args[0])
                self.stack.value.append(a)
            elif _alkuds_match_value_14 == opcode.i8x16_shuffle:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = a + b
                d = [c[instr.args[i]] for i in range(16)]
                e = ValInst.from_v128_i8(d)
                self.stack.value.append(e)
            elif _alkuds_match_value_14 == opcode.i8x16_swizzle:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_i8()
                c = [a[b[i]] if b[i] < 16 else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_splat:
                a = self.stack.value.pop().into_i32()
                b = ValInst.from_v128_i8([arith.i8.fit(a)] * 16)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i16x8_splat:
                a = self.stack.value.pop().into_i32()
                b = ValInst.from_v128_i16([arith.i16.fit(a)] * 8)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32x4_splat:
                a = self.stack.value.pop().into_i32()
                b = ValInst.from_v128_i32([a] * 4)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64x2_splat:
                a = self.stack.value.pop().into_i64()
                b = ValInst.from_v128_i64([a] * 2)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f32x4_splat:
                a = self.stack.value.pop().data[0:4]
                b = ValInst.from_v128(a * 4)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64x2_splat:
                a = self.stack.value.pop().data[0:8]
                b = ValInst.from_v128(a * 2)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i8x16_extract_lane_s:
                a = self.stack.value.pop().into_v128_i8()
                b = ValInst.from_i32(a[instr.args[0]])
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i8x16_extract_lane_u:
                a = self.stack.value.pop().into_v128_u8()
                b = ValInst.from_i32(a[instr.args[0]])
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i8x16_replace_lane:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i8()
                a[instr.args[0]] = arith.i8.fit(b)
                c = ValInst.from_v128_i8(a)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_extract_lane_s:
                a = self.stack.value.pop().into_v128_i16()
                b = ValInst.from_i32(a[instr.args[0]])
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i16x8_extract_lane_u:
                a = self.stack.value.pop().into_v128_u16()
                b = ValInst.from_i32(a[instr.args[0]])
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i16x8_replace_lane:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i16()
                a[instr.args[0]] = arith.i16.fit(b)
                c = ValInst.from_v128_i16(a)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_extract_lane:
                a = self.stack.value.pop().into_v128_i32()
                b = ValInst.from_i32(a[instr.args[0]])
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32x4_replace_lane:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i32()
                a[instr.args[0]] = b
                c = ValInst.from_v128_i32(a)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64x2_extract_lane:
                a = self.stack.value.pop().into_v128_i64()
                b = ValInst.from_i64(a[instr.args[0]])
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64x2_replace_lane:
                b = self.stack.value.pop().into_i64()
                a = self.stack.value.pop().into_v128_i64()
                a[instr.args[0]] = b
                c = ValInst.from_v128_i64(a)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32x4_extract_lane:
                a = self.stack.value.pop().into_v128()
                b = instr.args[0]
                c = ValInst(ValType.f32(), a[b * 4:b * 4 + 4] + bytearray(ValInst.blen - 4))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32x4_replace_lane:
                b = self.stack.value.pop().into_u32()
                a = self.stack.value.pop().into_v128()
                c = instr.args[0]
                a[c * 4:c * 4 + 4] = arith.u32.into_bytearray(b)
                d = ValInst(ValType.v128(), a)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_extract_lane:
                a = self.stack.value.pop().into_v128()
                b = instr.args[0]
                c = ValInst(ValType.f64(), a[b * 8:b * 8 + 8] + bytearray(ValInst.blen - 8))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64x2_replace_lane:
                b = self.stack.value.pop().into_u64()
                a = self.stack.value.pop().into_v128()
                c = instr.args[0]
                a[c * 8:c * 8 + 8] = arith.u64.into_bytearray(b)
                d = ValInst(ValType.v128(), a)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_eq:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [-1 if a[i] == b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_ne:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [-1 if a[i] != b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_lt_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [-1 if a[i] < b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_lt_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [-1 if a[i] < b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_gt_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [-1 if a[i] > b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_gt_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [-1 if a[i] > b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_le_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [-1 if a[i] <= b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_le_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [-1 if a[i] <= b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_ge_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [-1 if a[i] >= b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_ge_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [-1 if a[i] >= b[i] else 0 for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_eq:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [-1 if a[i] == b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_ne:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [-1 if a[i] != b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_lt_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [-1 if a[i] < b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_lt_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [-1 if a[i] < b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_gt_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [-1 if a[i] > b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_gt_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [-1 if a[i] > b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_le_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [-1 if a[i] <= b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_le_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [-1 if a[i] <= b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_ge_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [-1 if a[i] >= b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_ge_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [-1 if a[i] >= b[i] else 0 for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_eq:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [-1 if a[i] == b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_ne:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [-1 if a[i] != b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_lt_s:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [-1 if a[i] < b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_lt_u:
                b = self.stack.value.pop().into_v128_u32()
                a = self.stack.value.pop().into_v128_u32()
                c = [-1 if a[i] < b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_gt_s:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [-1 if a[i] > b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_gt_u:
                b = self.stack.value.pop().into_v128_u32()
                a = self.stack.value.pop().into_v128_u32()
                c = [-1 if a[i] > b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_le_s:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [-1 if a[i] <= b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_le_u:
                b = self.stack.value.pop().into_v128_u32()
                a = self.stack.value.pop().into_v128_u32()
                c = [-1 if a[i] <= b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_ge_s:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [-1 if a[i] >= b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_ge_u:
                b = self.stack.value.pop().into_v128_u32()
                a = self.stack.value.pop().into_v128_u32()
                c = [-1 if a[i] >= b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_eq:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [-1 if a[i] == b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_ne:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [-1 if a[i] != b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_lt:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [-1 if a[i] < b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_gt:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [-1 if a[i] > b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_le:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [-1 if a[i] <= b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_ge:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [-1 if a[i] >= b[i] else 0 for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_eq:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [-1 if a[i] == b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_ne:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [-1 if a[i] != b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_lt:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [-1 if a[i] < b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_gt:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [-1 if a[i] > b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_le:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [-1 if a[i] <= b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_ge:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [-1 if a[i] >= b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.v128_not:
                a = self.stack.value.pop().into_v128()
                b = ValInst.from_v128(bytearray([arith.u8.fit(~e) for e in a]))
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.v128_and:
                b = self.stack.value.pop().into_v128()
                a = self.stack.value.pop().into_v128()
                c = ValInst.from_v128(bytearray([a[i] & b[i] for i in range(16)]))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.v128_andnot:
                b = self.stack.value.pop().into_v128()
                a = self.stack.value.pop().into_v128()
                c = ValInst.from_v128(bytearray([a[i] & ~b[i] for i in range(16)]))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.v128_or:
                b = self.stack.value.pop().into_v128()
                a = self.stack.value.pop().into_v128()
                c = ValInst.from_v128(bytearray([a[i] | b[i] for i in range(16)]))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.v128_xor:
                b = self.stack.value.pop().into_v128()
                a = self.stack.value.pop().into_v128()
                c = ValInst.from_v128(bytearray([a[i] ^ b[i] for i in range(16)]))
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.v128_bitselect:
                c = self.stack.value.pop().into_v128()
                b = self.stack.value.pop().into_v128()
                a = self.stack.value.pop().into_v128()
                d = ValInst.from_v128(bytearray([a[i] & c[i] | b[i] & ~c[i] for i in range(16)]))
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.v128_any_true:
                a = self.stack.value.pop().into_v128()
                b = 1 if any((e != 0 for e in a)) else 0
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.v128_load8_lane:
                a = self.stack.value.pop().into_v128()
                b = self.evaluate_mem_load(instr.args[1], 1)
                c = instr.args[2]
                a[1 * c:1 * c + 1] = b
                d = ValInst(ValType.v128(), a + bytearray(ValInst.blen - 16))
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.v128_load16_lane:
                a = self.stack.value.pop().into_v128()
                b = self.evaluate_mem_load(instr.args[1], 2)
                c = instr.args[2]
                a[2 * c:2 * c + 2] = b
                d = ValInst(ValType.v128(), a + bytearray(ValInst.blen - 16))
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.v128_load32_lane:
                a = self.stack.value.pop().into_v128()
                b = self.evaluate_mem_load(instr.args[1], 4)
                c = instr.args[2]
                a[4 * c:4 * c + 4] = b
                d = ValInst(ValType.v128(), a + bytearray(ValInst.blen - 16))
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.v128_load64_lane:
                a = self.stack.value.pop().into_v128()
                b = self.evaluate_mem_load(instr.args[1], 8)
                c = instr.args[2]
                a[8 * c:8 * c + 8] = b
                d = ValInst(ValType.v128(), a + bytearray(ValInst.blen - 16))
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.v128_store8_lane:
                a = self.stack.value.pop().into_v128()
                b = instr.args[2]
                a[:1] = a[1 * b:1 * b + 1]
                self.stack.value.append(ValInst.from_v128(a))
                self.evaluate_mem_save(instr.args[1], 1)
            elif _alkuds_match_value_14 == opcode.v128_store16_lane:
                a = self.stack.value.pop().into_v128()
                b = instr.args[2]
                a[:2] = a[2 * b:2 * b + 2]
                self.stack.value.append(ValInst.from_v128(a))
                self.evaluate_mem_save(instr.args[1], 2)
            elif _alkuds_match_value_14 == opcode.v128_store32_lane:
                a = self.stack.value.pop().into_v128()
                b = instr.args[2]
                a[:4] = a[4 * b:4 * b + 4]
                self.stack.value.append(ValInst.from_v128(a))
                self.evaluate_mem_save(instr.args[1], 4)
            elif _alkuds_match_value_14 == opcode.v128_store64_lane:
                a = self.stack.value.pop().into_v128()
                b = instr.args[2]
                a[:8] = a[8 * b:8 * b + 8]
                self.stack.value.append(ValInst.from_v128(a))
                self.evaluate_mem_save(instr.args[1], 8)
            elif _alkuds_match_value_14 == opcode.v128_load32_zero:
                a = self.evaluate_mem_load(instr.args[1], 4)
                b = a + bytearray(ValInst.blen - 4)
                c = ValInst.from_v128(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.v128_load64_zero:
                a = self.evaluate_mem_load(instr.args[1], 8)
                b = a + bytearray(ValInst.blen - 8)
                c = ValInst.from_v128(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32x4_demote_f64x2_zero:
                a = self.stack.value.pop().into_v128_f64()
                b = a + [0.0, 0.0]
                c = ValInst.from_v128_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64x2_promote_low_f32x4:
                a = self.stack.value.pop().into_v128_f32()
                b = a[:2]
                c = ValInst.from_v128_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_abs:
                a = self.stack.value.pop().into_v128_i8()
                b = [arith.i8.fit(abs(e)) for e in a]
                c = ValInst.from_v128_i8(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_neg:
                a = self.stack.value.pop().into_v128_i8()
                b = [arith.i8.fit(-e) for e in a]
                c = ValInst.from_v128_i8(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_popcnt:
                a = self.stack.value.pop().into_v128_u8()
                b = [arith.u8.popcnt(e) for e in a]
                c = ValInst.from_v128_u8(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_all_true:
                a = self.stack.value.pop().into_v128_i8()
                b = 1 if all((e != 0 for e in a)) else 0
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_bitmask:
                a = self.stack.value.pop().into_v128_i8()
                b = 0
                for i in range(16):
                    if a[i] < 0:
                        b |= 1 << i
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_narrow_i16x8_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = a + b
                d = [arith.i8.sat(e) for e in c]
                e = ValInst.from_v128_i8(d)
                self.stack.value.append(e)
            elif _alkuds_match_value_14 == opcode.i8x16_narrow_i16x8_u:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = a + b
                d = [arith.u8.sat(e) for e in c]
                e = ValInst.from_v128_u8(d)
                self.stack.value.append(e)
            elif _alkuds_match_value_14 == opcode.f32x4_ceil:
                a = self.stack.value.pop().into_v128_f32()
                b = [e if math.isnan(e) or math.isinf(e) else float(math.ceil(e)) for e in a]
                c = ValInst.from_v128_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32x4_floor:
                a = self.stack.value.pop().into_v128_f32()
                b = [e if math.isnan(e) or math.isinf(e) else float(math.floor(e)) for e in a]
                c = ValInst.from_v128_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32x4_trunc:
                a = self.stack.value.pop().into_v128_f32()
                b = [e if math.isnan(e) or math.isinf(e) else float(math.trunc(e)) for e in a]
                c = ValInst.from_v128_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32x4_nearest:
                a = self.stack.value.pop().into_v128_f32()
                b = [e if math.isnan(e) or math.isinf(e) else float(round(e)) for e in a]
                c = ValInst.from_v128_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_shl:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i8()
                c = ValInst.from_v128_i8([arith.i8.shl(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_shr_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i8()
                c = ValInst.from_v128_i8([arith.i8.shr(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_shr_u:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_u8()
                c = ValInst.from_v128_u8([arith.u8.shr(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_add:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [arith.i8.add(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_add_sat_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [arith.i8.add_sat(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_add_sat_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [arith.u8.add_sat(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_u8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_sub:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [arith.i8.sub(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_sub_sat_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [arith.i8.sub_sat(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_sub_sat_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [arith.u8.sub_sat(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_u8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_ceil:
                a = self.stack.value.pop().into_v128_f64()
                b = [e if math.isnan(e) or math.isinf(e) else float(math.ceil(e)) for e in a]
                c = ValInst.from_v128_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64x2_floor:
                a = self.stack.value.pop().into_v128_f64()
                b = [e if math.isnan(e) or math.isinf(e) else float(math.floor(e)) for e in a]
                c = ValInst.from_v128_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_min_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [min(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_min_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [min(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_u8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_max_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [max(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_i8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i8x16_max_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [max(a[i], b[i]) for i in range(16)]
                d = ValInst.from_v128_u8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_trunc:
                a = self.stack.value.pop().into_v128_f64()
                b = [e if math.isnan(e) or math.isinf(e) else float(math.trunc(e)) for e in a]
                c = ValInst.from_v128_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i8x16_avgr_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [(a[i] + b[i] + 1) // 2 for i in range(16)]
                d = ValInst.from_v128_u8(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_extadd_pairwise_i8x16_s:
                a = self.stack.value.pop().into_v128_i8()
                b = [a[i] + a[i + 1] for i in range(0, 16, 2)]
                c = ValInst.from_v128_i16(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_extadd_pairwise_i8x16_u:
                a = self.stack.value.pop().into_v128_u8()
                b = [a[i] + a[i + 1] for i in range(0, 16, 2)]
                c = ValInst.from_v128_u16(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_extadd_pairwise_i16x8_s:
                a = self.stack.value.pop().into_v128_i16()
                b = [a[i] + a[i + 1] for i in range(0, 8, 2)]
                c = ValInst.from_v128_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_extadd_pairwise_i16x8_u:
                a = self.stack.value.pop().into_v128_u16()
                b = [a[i] + a[i + 1] for i in range(0, 8, 2)]
                c = ValInst.from_v128_u32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_abs:
                a = self.stack.value.pop().into_v128_i16()
                b = [arith.i16.fit(abs(e)) for e in a]
                c = ValInst.from_v128_i16(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_neg:
                a = self.stack.value.pop().into_v128_i16()
                b = [arith.i16.fit(-e) for e in a]
                c = ValInst.from_v128_i16(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_q15mulr_sat_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [arith.i16.sat(a[i] * b[i] + 16384 >> 15) for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_all_true:
                a = self.stack.value.pop().into_v128_i16()
                b = 1 if all((e != 0 for e in a)) else 0
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_bitmask:
                a = self.stack.value.pop().into_v128_i16()
                b = 0
                for i in range(8):
                    if a[i] < 0:
                        b |= 1 << i
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_narrow_i32x4_s:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = a + b
                d = [arith.i16.sat(e) for e in c]
                e = ValInst.from_v128_i16(d)
                self.stack.value.append(e)
            elif _alkuds_match_value_14 == opcode.i16x8_narrow_i32x4_u:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = a + b
                d = [arith.u16.sat(e) for e in c]
                e = ValInst.from_v128_u16(d)
                self.stack.value.append(e)
            elif _alkuds_match_value_14 == opcode.i16x8_extend_low_i8x16_s:
                a = self.stack.value.pop().into_v128_i8()[:8]
                b = ValInst.from_v128_i16(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i16x8_extend_high_i8x16_s:
                a = self.stack.value.pop().into_v128_i8()[8:]
                b = ValInst.from_v128_i16(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i16x8_extend_low_i8x16_u:
                a = self.stack.value.pop().into_v128_u8()[:8]
                b = ValInst.from_v128_i16(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i16x8_extend_high_i8x16_u:
                a = self.stack.value.pop().into_v128_u8()[8:]
                b = ValInst.from_v128_i16(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i16x8_shl:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i16()
                c = ValInst.from_v128_i16([arith.i16.shl(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_shr_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i16()
                c = ValInst.from_v128_i16([arith.i16.shr(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_shr_u:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_u16()
                c = ValInst.from_v128_u16([arith.u16.shr(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_add:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [arith.i16.add(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_add_sat_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [arith.i16.add_sat(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_add_sat_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [arith.u16.add_sat(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_u16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_sub:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [arith.i16.sub(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_sub_sat_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [arith.i16.sub_sat(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_sub_sat_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [arith.u16.sub_sat(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_u16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_nearest:
                a = self.stack.value.pop().into_v128_f64()
                b = [e if math.isnan(e) or math.isinf(e) else float(round(e)) for e in a]
                c = ValInst.from_v128_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i16x8_mul:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [arith.i16.mul(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_min_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [min(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_min_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [min(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_u16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_max_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [max(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_max_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [max(a[i], b[i]) for i in range(8)]
                d = ValInst.from_v128_u16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_avgr_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [(a[i] + b[i] + 1) // 2 for i in range(8)]
                d = ValInst.from_v128_u16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_extmul_low_i8x16_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [a[i] * b[i] for i in range(8)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_extmul_high_i8x16_s:
                b = self.stack.value.pop().into_v128_i8()
                a = self.stack.value.pop().into_v128_i8()
                c = [a[i] * b[i] for i in range(8, 16)]
                d = ValInst.from_v128_i16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_extmul_low_i8x16_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [a[i] * b[i] for i in range(8)]
                d = ValInst.from_v128_u16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i16x8_extmul_high_i8x16_u:
                b = self.stack.value.pop().into_v128_u8()
                a = self.stack.value.pop().into_v128_u8()
                c = [a[i] * b[i] for i in range(8, 16)]
                d = ValInst.from_v128_u16(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_abs:
                a = self.stack.value.pop().into_v128_i32()
                b = [arith.i32.fit(abs(e)) for e in a]
                c = ValInst.from_v128_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_neg:
                a = self.stack.value.pop().into_v128_i32()
                b = [arith.i32.fit(-e) for e in a]
                c = ValInst.from_v128_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_all_true:
                a = self.stack.value.pop().into_v128_i32()
                b = 1 if all((e != 0 for e in a)) else 0
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_bitmask:
                a = self.stack.value.pop().into_v128_i32()
                b = 0
                for i in range(4):
                    if a[i] < 0:
                        b |= 1 << i
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_extend_low_i16x8_s:
                a = self.stack.value.pop().into_v128_i16()[:4]
                b = ValInst.from_v128_i32(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32x4_extend_high_i16x8_s:
                a = self.stack.value.pop().into_v128_i16()[4:]
                b = ValInst.from_v128_i32(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32x4_extend_low_i16x8_u:
                a = self.stack.value.pop().into_v128_u16()[:4]
                b = ValInst.from_v128_i32(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32x4_extend_high_i16x8_u:
                a = self.stack.value.pop().into_v128_u16()[4:]
                b = ValInst.from_v128_i32(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32x4_shl:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = ValInst.from_v128_i32([arith.i32.shl(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_shr_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = ValInst.from_v128_i32([arith.i32.shr(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_shr_u:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_u32()
                c = ValInst.from_v128_u32([arith.u32.shr(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i32x4_add:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [arith.i32.add(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_sub:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [arith.i32.sub(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_mul:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [arith.i32.mul(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_min_s:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [min(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_min_u:
                b = self.stack.value.pop().into_v128_u32()
                a = self.stack.value.pop().into_v128_u32()
                c = [min(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_u32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_max_s:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [max(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_max_u:
                b = self.stack.value.pop().into_v128_u32()
                a = self.stack.value.pop().into_v128_u32()
                c = [max(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_u32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_dot_i16x8_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [arith.i32.fit(a[i * 2] * b[i * 2] + a[i * 2 + 1] * b[i * 2 + 1]) for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_extmul_low_i16x8_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [a[i] * b[i] for i in range(4)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_extmul_high_i16x8_s:
                b = self.stack.value.pop().into_v128_i16()
                a = self.stack.value.pop().into_v128_i16()
                c = [a[i] * b[i] for i in range(4, 8)]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_extmul_low_i16x8_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [a[i] * b[i] for i in range(4)]
                d = ValInst.from_v128_u32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_extmul_high_i16x8_u:
                b = self.stack.value.pop().into_v128_u16()
                a = self.stack.value.pop().into_v128_u16()
                c = [a[i] * b[i] for i in range(4, 8)]
                d = ValInst.from_v128_u32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_abs:
                a = self.stack.value.pop().into_v128_i64()
                b = [arith.i64.fit(abs(e)) for e in a]
                c = ValInst.from_v128_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64x2_neg:
                a = self.stack.value.pop().into_v128_i64()
                b = [arith.i64.fit(-e) for e in a]
                c = ValInst.from_v128_i64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64x2_all_true:
                a = self.stack.value.pop().into_v128_i64()
                b = 1 if all((e != 0 for e in a)) else 0
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64x2_bitmask:
                a = self.stack.value.pop().into_v128_i64()
                b = 0
                for i in range(2):
                    if a[i] < 0:
                        b |= 1 << i
                c = ValInst.from_i32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64x2_extend_low_i32x4_s:
                a = self.stack.value.pop().into_v128_i32()[:2]
                b = ValInst.from_v128_i64(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64x2_extend_high_i32x4_s:
                a = self.stack.value.pop().into_v128_i32()[2:]
                b = ValInst.from_v128_i64(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64x2_extend_low_i32x4_u:
                a = self.stack.value.pop().into_v128_u32()[:2]
                b = ValInst.from_v128_i64(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64x2_extend_high_i32x4_u:
                a = self.stack.value.pop().into_v128_u32()[2:]
                b = ValInst.from_v128_i64(a)
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i64x2_shl:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i64()
                c = ValInst.from_v128_i64([arith.i64.shl(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64x2_shr_s:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_i64()
                c = ValInst.from_v128_i64([arith.i64.shr(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64x2_shr_u:
                b = self.stack.value.pop().into_i32()
                a = self.stack.value.pop().into_v128_u64()
                c = ValInst.from_v128_u64([arith.u64.shr(e, b) for e in a])
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.i64x2_add:
                b = self.stack.value.pop().into_v128_i64()
                a = self.stack.value.pop().into_v128_i64()
                c = [arith.i64.add(a[i], b[i]) for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_sub:
                b = self.stack.value.pop().into_v128_i64()
                a = self.stack.value.pop().into_v128_i64()
                c = [arith.i64.sub(a[i], b[i]) for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_mul:
                b = self.stack.value.pop().into_v128_i64()
                a = self.stack.value.pop().into_v128_i64()
                c = [arith.i64.mul(a[i], b[i]) for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_eq:
                b = self.stack.value.pop().into_v128_i64()
                a = self.stack.value.pop().into_v128_i64()
                c = [-1 if a[i] == b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_ne:
                b = self.stack.value.pop().into_v128_i64()
                a = self.stack.value.pop().into_v128_i64()
                c = [-1 if a[i] != b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_lt_s:
                b = self.stack.value.pop().into_v128_i64()
                a = self.stack.value.pop().into_v128_i64()
                c = [-1 if a[i] < b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_gt_s:
                b = self.stack.value.pop().into_v128_i64()
                a = self.stack.value.pop().into_v128_i64()
                c = [-1 if a[i] > b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_le_s:
                b = self.stack.value.pop().into_v128_i64()
                a = self.stack.value.pop().into_v128_i64()
                c = [-1 if a[i] <= b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_ge_s:
                b = self.stack.value.pop().into_v128_i64()
                a = self.stack.value.pop().into_v128_i64()
                c = [-1 if a[i] >= b[i] else 0 for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_extmul_low_i32x4_s:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [a[i] * b[i] for i in range(2)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_extmul_high_i32x4_s:
                b = self.stack.value.pop().into_v128_i32()
                a = self.stack.value.pop().into_v128_i32()
                c = [a[i] * b[i] for i in range(2, 4)]
                d = ValInst.from_v128_i64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_extmul_low_i32x4_u:
                b = self.stack.value.pop().into_v128_u32()
                a = self.stack.value.pop().into_v128_u32()
                c = [a[i] * b[i] for i in range(2)]
                d = ValInst.from_v128_u64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i64x2_extmul_high_i32x4_u:
                b = self.stack.value.pop().into_v128_u32()
                a = self.stack.value.pop().into_v128_u32()
                c = [a[i] * b[i] for i in range(2, 4)]
                d = ValInst.from_v128_u64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_abs:
                a = self.stack.value.pop().into_v128_f32()
                b = [abs(e) for e in a]
                c = ValInst.from_v128_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32x4_neg:
                a = self.stack.value.pop().into_v128_f32()
                b = [-e for e in a]
                c = ValInst.from_v128_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32x4_sqrt:
                a = self.stack.value.pop().into_v128_f32()
                b = [math.sqrt(e) if e >= 0 else math.nan for e in a]
                c = ValInst.from_v128_f32(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f32x4_add:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [a[i] + b[i] for i in range(4)]
                d = ValInst.from_v128_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_sub:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [a[i] - b[i] for i in range(4)]
                d = ValInst.from_v128_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_mul:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [a[i] * b[i] for i in range(4)]
                d = ValInst.from_v128_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_div:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [arith.f32.div(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_min:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [arith.f32.min(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_max:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [arith.f32.max(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_pmin:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [min(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_pmax:
                b = self.stack.value.pop().into_v128_f32()
                a = self.stack.value.pop().into_v128_f32()
                c = [max(a[i], b[i]) for i in range(4)]
                d = ValInst.from_v128_f32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_abs:
                a = self.stack.value.pop().into_v128_f64()
                b = [abs(e) for e in a]
                c = ValInst.from_v128_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64x2_neg:
                a = self.stack.value.pop().into_v128_f64()
                b = [-e for e in a]
                c = ValInst.from_v128_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64x2_sqrt:
                a = self.stack.value.pop().into_v128_f64()
                b = [math.sqrt(e) if e >= 0 else math.nan for e in a]
                c = ValInst.from_v128_f64(b)
                self.stack.value.append(c)
            elif _alkuds_match_value_14 == opcode.f64x2_add:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [a[i] + b[i] for i in range(2)]
                d = ValInst.from_v128_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_sub:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [a[i] - b[i] for i in range(2)]
                d = ValInst.from_v128_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_mul:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [a[i] * b[i] for i in range(2)]
                d = ValInst.from_v128_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_div:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [arith.f64.div(a[i], b[i]) for i in range(2)]
                d = ValInst.from_v128_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_min:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [arith.f64.min(a[i], b[i]) for i in range(2)]
                d = ValInst.from_v128_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_max:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [arith.f64.max(a[i], b[i]) for i in range(2)]
                d = ValInst.from_v128_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_pmin:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [min(a[i], b[i]) for i in range(2)]
                d = ValInst.from_v128_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_pmax:
                b = self.stack.value.pop().into_v128_f64()
                a = self.stack.value.pop().into_v128_f64()
                c = [max(a[i], b[i]) for i in range(2)]
                d = ValInst.from_v128_f64(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_trunc_sat_f32x4_s:
                a = self.stack.value.pop().into_v128_f32()
                b = [0 if math.isnan(e) else e for e in a]
                c = [int(max(arith.i32.min, min(e, arith.i32.max))) for e in b]
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_trunc_sat_f32x4_u:
                a = self.stack.value.pop().into_v128_f32()
                b = [0 if math.isnan(e) else e for e in a]
                c = [int(max(arith.u32.min, min(e, arith.u32.max))) for e in b]
                d = ValInst.from_v128_u32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f32x4_convert_i32x4_s:
                a = self.stack.value.pop().into_v128_i32()
                b = ValInst.from_v128_f32([float(e) for e in a])
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f32x4_convert_i32x4_u:
                a = self.stack.value.pop().into_v128_u32()
                b = ValInst.from_v128_f32([float(e) for e in a])
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.i32x4_trunc_sat_f64x2_s_zero:
                a = self.stack.value.pop().into_v128_f64()
                b = [0 if math.isnan(e) else e for e in a]
                c = [int(max(arith.i32.min, min(e, arith.i32.max))) for e in b]
                c.extend([0, 0])
                d = ValInst.from_v128_i32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.i32x4_trunc_sat_f64x2_u_zero:
                a = self.stack.value.pop().into_v128_f64()
                b = [0 if math.isnan(e) else e for e in a]
                c = [int(max(arith.u32.min, min(e, arith.u32.max))) for e in b]
                c.extend([0, 0])
                d = ValInst.from_v128_u32(c)
                self.stack.value.append(d)
            elif _alkuds_match_value_14 == opcode.f64x2_convert_low_i32x4_s:
                a = self.stack.value.pop().into_v128_i32()[:2]
                b = ValInst.from_v128_f64([float(e) for e in a])
                self.stack.value.append(b)
            elif _alkuds_match_value_14 == opcode.f64x2_convert_low_i32x4_u:
                a = self.stack.value.pop().into_v128_u32()[:2]
                b = ValInst.from_v128_f64([float(e) for e in a])
                self.stack.value.append(b)
            elif True:
                if not 0:
                    raise AssertionError('Invalid WebAssembly state')

class Runtime(object):

    def __init__(self):
        self.machine = Machine()
        self.imports = {}

    def allocate_func_host(self, type, func):
        return Extern(0, self.machine.store.allocate_func_host(FuncHost(type, func)))

    def allocate_table(self, type):
        return Extern(1, self.machine.store.allocate_table(type))

    def allocate_memory(self, type):
        return Extern(2, self.machine.store.allocate_memory(type))

    def allocate_global(self, type, data):
        return Extern(3, self.machine.store.allocate_global(type, data))

    def exported_memory(self, module, name):
        inst = [e for e in module.exps if e.name == name][0].data
        if not inst.kind == 2:
            raise AssertionError('Invalid WebAssembly state')
        addr = inst.data
        return self.machine.store.mems[addr]

    def exported_global(self, module, name):
        inst = [e for e in module.exps if e.name == name][0].data
        if not inst.kind == 3:
            raise AssertionError('Invalid WebAssembly state')
        addr = inst.data
        return self.machine.store.glob[addr]

    def instance(self, module):
        extern = []
        for e in module.imps:
            extern.append(self.imports[e.module][e.name])
        return self.machine.instance(module, extern)

    def instance_from_file(self, path):
        with open(path, 'rb') as f:
            return self.instance(ModuleDesc.from_reader(f))

    def invocate(self, module, func, args):
        func_addr = [e for e in module.exps if e.name == func][0].data.data
        func_inst = self.machine.store.func[func_addr]
        if not len(func_inst.type.args) == len(args):
            raise AssertionError('Invalid WebAssembly state')
        func_args = [ValInst.from_all(a, b) for a, b in zip(func_inst.type.args, args)]
        func_rets = self.machine.invocate(func_addr, func_args)
        rets = [e.into_all() for e in func_rets]
        return rets
