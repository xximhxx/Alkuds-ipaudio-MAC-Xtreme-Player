# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from ..py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from ..py2compat import datetime_module as datetime
lvl = 0

def debugln(*args):
    if lvl > 0:
        println(*args)

def println(*args):
    pre = datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
    print(pre, 'pywasm:', *args)
