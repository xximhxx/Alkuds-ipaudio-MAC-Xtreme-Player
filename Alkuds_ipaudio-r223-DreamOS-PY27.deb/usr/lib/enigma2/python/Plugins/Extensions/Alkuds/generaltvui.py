# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import threading
from . import generaltv
from .arabseedui import Alkuds_ArabSeed_Browser
from .fajershowui import Alkuds_FajerShow_Qualities
from .cataloguepages import CataloguePages

class _GeneralPages(CataloguePages):

    def _key(self, item):
        if item.get('action') == 'play':
            return ('server', item.get('server_key') or item.get('id'), item.get('url'))
        return CataloguePages._key(self, item)

class Alkuds_GeneralTV_Browser(Alkuds_ArabSeed_Browser):
    provider = generaltv
    site_name = u'جينرال تي في GENRAL TV'

    def __init__(self, session, section='browse', level='groups', parent=None, page=1):
        Alkuds_ArabSeed_Browser.__init__(self, session, section, level, parent, page)

    def _label(self):
        return self.site_name + (u' - ' + (self.parent.get('title') or self.parent.get('name', '')) if self.level != 'groups' else '')

    def _load_worker(self):
        try:
            if self.level == 'groups':
                self._result = self.provider.groups()
            else:
                self._result = self._catalogue_items(lambda number: self.provider.page(self.parent, number))
        except Exception as error:
            self._error = str(error)
        self._done = True

    def _catalogue_items(self, fetch):
        if not hasattr(self, '_catalogue_pager'):
            self._catalogue_pager = _GeneralPages(cancelled=lambda: self._closed)
        return self._catalogue_pager.get(self.page, fetch)

    def open_current(self):
        if self._loading or self._closed:
            return
        index = self._index()
        if not 0 <= index < len(self.entries):
            return
        self._selected_index = index
        item = dict(self.entries[index])
        if item.get('action') != 'play':
            self.session.open(type(self), item.get('section') or self.section, 'items', item, 1)
            return
        self._operation, self._loading, self._done = ('resolve', True, False)
        self._result, self._error = (None, '')
        self._update_title(u' - جاري تجهيز التشغيل...')
        worker = threading.Thread(target=self._resolve_worker, args=(item,))
        worker.daemon = True
        worker.start()
        self._timer.start(120, False)

    def _poll(self):
        ready = self._done and (not self._error) and (self._operation == 'load')
        Alkuds_ArabSeed_Browser._poll(self)
        if ready and (not self._closed) and (len(self.entries) == 1) and (self.entries[0].get('action') == 'play'):
            self['list'].setIndex(0)
            self.open_current()

    def next_or_refresh(self):
        if self.level == 'groups' and (not self._loading):
            self.provider.refresh()
        Alkuds_ArabSeed_Browser.next_or_refresh(self)

    def _start_resolved(self, item):
        live = self.section in ('channels', 'matches')
        category = 'Live' if live else 'Series' if self.section == 'series' else 'Movie'
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']}, item['name'], category, item.get('category', ''), item.get('image', ''), '' if live else 'generaltv:' + item['url'])
