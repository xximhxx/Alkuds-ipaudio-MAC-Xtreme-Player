# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Read publicly exposed HTML5 video sources without executing page scripts."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import re
from .py2compat import requests
try:
    from .py2compat import urllib
    urljoin = urllib.parse.urljoin
    urlsplit = urllib.parse.urlsplit
    from .py2compat import html
    unescape = html.unescape
except ImportError:
    from urlparse import urljoin, urlsplit
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape

def media_urls(text, base):
    found = []

    def add(value):
        url = urljoin(base, unescape(value.replace('\\/', '/')).strip())
        if urlsplit(url).scheme in ('http', 'https') and url not in found:
            found.append(url)
    for value in re.findall('<(?:video|source)\\b[^>]*\\bsrc=["\\\']([^"\\\']+)', text, re.I):
        add(value)
    for value in re.findall('["\\\'](https?://[^"\\\'<>\\s]+\\.(?:m3u8|mp4|webm)(?:\\?[^"\\\'<>\\s]*)?)["\\\']', text, re.I):
        add(value)
    return found

def resolve_public_page(value, user_agent):
    parts = str(value or '').split('<<R>>', 1)
    page = parts[0].strip()
    if urlsplit(page).scheme not in ('http', 'https'):
        raise RuntimeError('Unsupported web player address')
    headers = {'User-Agent': str(user_agent or 'Mozilla/5.0')}
    if len(parts) > 1 and urlsplit(parts[1].strip()).scheme in ('http', 'https'):
        headers['Referer'] = parts[1].strip()
    with requests.Session() as http:
        with http.get(page, headers=headers, timeout=(6, 15), stream=True) as response:
            response.raise_for_status()
            chunks, total = ([], 0)
            for chunk in response.iter_content(16384):
                total += len(chunk)
                if total > 1024 * 1024:
                    raise RuntimeError('Web player page is too large')
                chunks.append(chunk)
            html = b''.join(chunks).decode('utf-8', 'replace')
            final = response.url
        urls = media_urls(html, final)
        if not urls and all((token in html for token in ('/api/stream', 'filecode', 'streaming_url'))):
            parsed = urlsplit(final)
            code = parsed.path.rstrip('/').rsplit('/', 1)[-1]
            api = urljoin(final, '/api/stream')
            reply = http.post(api, json={'filecode': code, 'device': 'web'}, headers={'User-Agent': headers['User-Agent'], 'Referer': final}, timeout=(6, 15))
            reply.raise_for_status()
            payload = reply.json()
            url = payload.get('streaming_url') if isinstance(payload, dict) else None
            if isinstance(url, str) and urlsplit(url).scheme in ('http', 'https'):
                urls = [url]
        if not urls:
            raise RuntimeError('This web player does not expose a supported video link. Try another item or server.')
        return [{'url': url, 'name': 'Video %d' % (i + 1), 'headers': {'User-Agent': headers['User-Agent'], 'Referer': final}, 'mediatype': 'hls' if '.m3u8' in url.lower() else 'video', 'relay': False} for i, url in enumerate(urls)]
