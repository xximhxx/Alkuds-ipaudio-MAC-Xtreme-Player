# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import cima4u
from .arabseedui import Alkuds_ArabSeed_Browser

class Alkuds_Cima4U_Browser(Alkuds_ArabSeed_Browser):
    provider = cima4u
    site_name = u'سيما فور يو Cima4U'
