# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from Components.Sources.Source import Source
from Components.Label import Label as _Label
from .py2compat import gui_text, native
from Components.Sources.List import List as _List

class StaticText(Source):

    def __init__(self, text='', filter=lambda x: x):
        Source.__init__(self)
        self.__text = gui_text(text)
        self.filter = filter

    def handleCommand(self, cmd):
        self.text = self.filter(cmd)

    def getText(self):
        return self.__text

    def setText(self, text):
        self.__text = gui_text(text)
        self.changed((self.CHANGED_ALL,))
    text = property(getText, setText)

    def getBoolean(self):
        return bool(self.__text)
    boolean = property(getBoolean)


class Label(_Label):
    """Plugin-local adapter; system Components.Label is left unchanged."""
    def __init__(self, text='', *args, **kwargs):
        _Label.__init__(self, gui_text(text), *args, **kwargs)

    def setText(self, text):
        return _Label.setText(self, gui_text(text))

    text = property(_Label.getText, setText)


def gui_row(value):
    # Rendered strings must be native bytes; payload dictionaries/pixmaps stay intact.
    if isinstance(value, (native.str, native.unicode)):
        return gui_text(value)
    if isinstance(value, tuple):
        return tuple(gui_row(part) for part in value)
    if isinstance(value, list):
        return [gui_row(part) for part in value]
    return value


class List(_List):
    def __init__(self, rows=None, *args, **kwargs):
        _List.__init__(self, gui_row(rows or []), *args, **kwargs)

    def setList(self, rows):
        return _List.setList(self, gui_row(rows or []))

    def updateList(self, rows):
        return _List.updateList(self, gui_row(rows or []))

    def modifyEntry(self, index, entry):
        return _List.modifyEntry(self, index, gui_row(entry))

    list = property(_List.list.fget, setList)


from Screens.MessageBox import MessageBox as _MessageBox


class MessageBox(_MessageBox):
    """Only Alkuds dialogs use this adapter, never system-wide dialogs."""
    def __init__(self, session, text, *args, **kwargs):
        if 'title' in kwargs:
            kwargs['title']=gui_text(kwargs['title'])
        _MessageBox.__init__(self, session, gui_text(text), *args, **kwargs)


from Screens.ChoiceBox import ChoiceBox as _ChoiceBox


def choice_rows(rows):
    result=[]
    for row in rows or []:
        if isinstance(row, (tuple, native.list)) and row:
            label=gui_text(row[0])
            result.append((label,) + row[1:] if isinstance(row, tuple) else [label] + row[1:])
        else:
            result.append(row)
    return result


class ChoiceBox(_ChoiceBox):
    """Normalize display text only; keep callbacks and choice payloads intact."""
    def __init__(self, session, title='', list=None, *args, **kwargs):
        _ChoiceBox.__init__(self, session, gui_text(title), choice_rows(list), *args, **kwargs)
