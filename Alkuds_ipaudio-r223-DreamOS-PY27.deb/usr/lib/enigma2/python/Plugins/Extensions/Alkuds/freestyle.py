# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import os
from .xStaticText import List as SourceList
from Tools.LoadPixmap import LoadPixmap
from enigma import addFont
FONT = 'AlkudsUnicode'
try:
    addFont(os.path.join(os.path.dirname(__file__), 'fonts', 'AlkudsUnicode.ttf'), 'AlkudsUnicode', 100, 0)
    FONT = 'AlkudsUnicode'
except Exception:
    pass
_icons = {}

def icon(value):
    name = value if isinstance(value, str) and value in ('today_matches', 'watch_matches', 'ostora', 'entertainment', 'syrialive', 'oscar', 'originaltv', 'elahmad', 'alfajer', 'fajershow', 'movie', 'series', 'live', 'groups') else 'video'
    if name not in _icons:
        try:
            _icons[name] = LoadPixmap(os.path.join(os.path.dirname(__file__), 'common', 'postericons', name + '.png'))
        except Exception:
            _icons[name] = None
    return _icons[name]

def decorate(rows):
    result = []
    for index, row in enumerate(rows or []):
        row = tuple(row)
        if len(row) < 4:
            row += ('', 16777215)[max(0, len(row) - 2):]
        result.append(row[:4] + (2430016 if index % 2 == 0 else 3350618, 16777215 if index % 2 == 0 else 15985919, icon(row[1]), ''))
    return result

class StyledList(SourceList):

    def __init__(self, rows=None, *args, **kwargs):
        SourceList.__init__(self, decorate(rows), *args, **kwargs)

    def setList(self, rows):
        SourceList.setList(self, decorate(rows))
