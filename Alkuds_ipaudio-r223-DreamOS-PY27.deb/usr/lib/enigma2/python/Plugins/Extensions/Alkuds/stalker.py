# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import service_reference, gui_text
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import json
from .py2compat import os
from .py2compat import re
import hashlib
from .py2compat import threading
import glob
from .py2compat import subprocess
from .py2compat import shutil
from .py2compat import time
try:
    from .py2compat import urllib
    quote = urllib.parse.quote
except ImportError:
    from urllib import quote
from .py2compat import requests
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from .xStaticText import List as PlainList
from .freestyle import StyledList as List
from Components.config import getConfigListEntry, NoSave, ConfigText, ConfigYesNo
from .xStaticText import MessageBox
from .xStaticText import ChoiceBox
from Screens.Screen import Screen
from enigma import eServiceReference, getDesktop, eTimer
from .plugin import dir_etc
from .xStaticText import StaticText
from .uihelpers import channel_row, server_row
from .subscriptionui import move_cards, cards_skin, subscription_card, portal_card, card_row, safe_name
STALKER_FILE = os.path.join(os.path.dirname(dir_etc.rstrip('/')), 'MultiStalkerPro.json')
STALKER_FILE_FALLBACK = os.path.join(dir_etc, 'MultiStalkerPro.json')
STALKER_PREFS_FILE = os.path.join(dir_etc, 'alkuds-stalker-prefs.json')
_ACTIVE_STALKER_FILE = None

def _stalker_candidates():
    """Return lightweight candidate locations without recursively walking mounted disks."""
    candidates = ['/media/hdd/MultiStalkerPro.json', '/media/usb/MultiStalkerPro.json', '/media/mmc/MultiStalkerPro.json', '/media/cf/MultiStalkerPro.json']
    try:
        candidates.extend(sorted(glob.glob('/media/*/MultiStalkerPro.json')))
    except Exception:
        pass
    try:
        candidates.extend(sorted(glob.glob('/media/*/*/MultiStalkerPro.json')))
    except Exception:
        pass
    candidates.extend([STALKER_FILE, STALKER_FILE_FALLBACK])
    result = []
    seen = set()
    for path in candidates:
        path = os.path.normpath(path)
        if path not in seen:
            seen.add(path)
            result.append(path)
    return result

def _stalker_file_path(for_write=False):
    global _ACTIVE_STALKER_FILE
    if _ACTIVE_STALKER_FILE and os.path.isfile(_ACTIVE_STALKER_FILE):
        return _ACTIVE_STALKER_FILE
    for path in _stalker_candidates():
        if os.path.isfile(path):
            _ACTIVE_STALKER_FILE = path
            return path
    return STALKER_FILE
MAG_USER_AGENT = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG254 stbapp ver: 4 rev: 2721 Mobile Safari/533.3'
X_USER_AGENT = 'Model: MAG254; Link: Ethernet'
EXTEPLAYER3_PATHS = ('/usr/bin/exteplayer3', '/usr/bin/exteplayer3.sh')

def _has_exteplayer3():
    for path in EXTEPLAYER3_PATHS:
        try:
            if os.path.isfile(path) and os.access(path, os.X_OK):
                return True
        except Exception:
            pass
    return False

def _stalker_service_type():
    return 5002 if _has_exteplayer3() else 4097
_BG_AUDIO = {'procs': [], 'name': '', 'backend': '', 'url': ''}
_BG_AUDIO_LOCK = threading.Lock()
_BG_DEVNULL_R = None
_BG_DEVNULL_W = None

def _find_executable(names):
    for name in names:
        try:
            path = shutil.which(name)
        except Exception:
            path = None
        if path and os.path.isfile(path) and os.access(path, os.X_OK):
            return path
        for base in ('/usr/bin', '/bin', '/usr/local/bin'):
            candidate = os.path.join(base, name)
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                return candidate
    return ''

def _bg_devnull(read=False):
    global _BG_DEVNULL_R, _BG_DEVNULL_W
    if read:
        if _BG_DEVNULL_R is None or getattr(_BG_DEVNULL_R, 'closed', False):
            _BG_DEVNULL_R = open(os.devnull, 'rb')
        return _BG_DEVNULL_R
    if _BG_DEVNULL_W is None or getattr(_BG_DEVNULL_W, 'closed', False):
        _BG_DEVNULL_W = open(os.devnull, 'wb')
    return _BG_DEVNULL_W

def background_audio_status():
    with _BG_AUDIO_LOCK:
        alive = []
        for proc in _BG_AUDIO.get('procs', []):
            try:
                if proc.poll() is None:
                    alive.append(proc)
            except Exception:
                pass
        _BG_AUDIO['procs'] = alive
        if not alive:
            _BG_AUDIO['name'] = ''
            _BG_AUDIO['backend'] = ''
            _BG_AUDIO['url'] = ''
            return (False, '', '')
        return (True, _BG_AUDIO.get('name', ''), _BG_AUDIO.get('backend', ''))

def stop_background_audio():
    with _BG_AUDIO_LOCK:
        procs = list(_BG_AUDIO.get('procs', []))
        _BG_AUDIO['procs'] = []
        _BG_AUDIO['name'] = ''
        _BG_AUDIO['backend'] = ''
        _BG_AUDIO['url'] = ''
    stopped = False
    for proc in reversed(procs):
        try:
            if proc.poll() is None:
                proc.terminate()
                stopped = True
        except Exception:
            pass
    for proc in reversed(procs):
        try:
            if proc.poll() is None:
                proc.kill()
        except Exception:
            pass
    return stopped or bool(procs)

def _start_background_audio(stream_url, channel_name):
    stream_url = _clean_stream_url(stream_url)
    if not stream_url:
        raise RuntimeError('No playable stream URL')
    stop_background_audio()
    null_in = _bg_devnull(read=True)
    null_out = _bg_devnull(read=False)
    procs = []
    backend = ''
    gst = _find_executable(('gst-launch-1.0',))
    ffplay = _find_executable(('ffplay',))
    ffmpeg = _find_executable(('ffmpeg',))
    aplay = _find_executable(('aplay',))
    if gst:
        cmd = [gst, '-q', 'playbin', 'uri=' + stream_url, 'flags=2']
        procs = [subprocess.Popen(cmd, stdin=null_in, stdout=null_out, stderr=null_out, close_fds=True)]
        backend = 'GStreamer audio-only'
    elif ffplay:
        cmd = [ffplay, '-nodisp', '-vn', '-loglevel', 'error', '-nostats', stream_url]
        procs = [subprocess.Popen(cmd, stdin=null_in, stdout=null_out, stderr=null_out, close_fds=True)]
        backend = 'FFplay audio-only'
    elif ffmpeg and aplay:
        dec = subprocess.Popen([ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin', '-i', stream_url, '-vn', '-ac', '2', '-ar', '48000', '-f', 's16le', 'pipe:1'], stdin=null_in, stdout=subprocess.PIPE, stderr=null_out, close_fds=True)
        out = subprocess.Popen([aplay, '-q', '-f', 'S16_LE', '-c', '2', '-r', '48000'], stdin=dec.stdout, stdout=null_out, stderr=null_out, close_fds=True)
        try:
            dec.stdout.close()
        except Exception:
            pass
        procs = [dec, out]
        backend = 'FFmpeg + ALSA audio-only'
    else:
        raise RuntimeError('No independent audio backend found (gst-launch-1.0 / ffplay / ffmpeg+aplay)')
    time.sleep(0.35)
    alive = []
    for proc in procs:
        try:
            if proc.poll() is None:
                alive.append(proc)
        except Exception:
            pass
    if not alive:
        for proc in reversed(procs):
            try:
                if proc.poll() is None:
                    proc.kill()
            except Exception:
                pass
        raise RuntimeError('Background audio backend exited immediately; this receiver/image may not expose an independent audio output')
    with _BG_AUDIO_LOCK:
        _BG_AUDIO['procs'] = procs
        _BG_AUDIO['name'] = str(channel_name or 'IPTV')
        _BG_AUDIO['backend'] = backend
        _BG_AUDIO['url'] = stream_url
    return backend
from . import backgroundaudio as _bga

def background_audio_status():
    return _bga.background_audio_status()

def stop_background_audio():
    return _bga.stop_background_audio()

def _start_background_audio(stream_url, channel_name):
    return _bga.start_audio_backend(stream_url, channel_name)

def _clean_stream_url(command):
    """Extract a playable URL without accidentally passing ffmpeg/ffrt tokens."""
    value = str(command or '').strip()
    if not value:
        return ''
    match = re.search('(?:https?|rtsp|rtmp|rtp|udp)://[^\\s\\"\\\']+', value, re.I)
    if match:
        return match.group(0).strip()
    for prefix in ('ffmpeg ', 'ffrt ', 'auto '):
        if value.lower().startswith(prefix):
            value = value[len(prefix):].strip()
            break
    return value

def _skin(title, config=False, account_info=False):
    if not config:
        from .subscriptionliststyle import subscription_list_skin
        return subscription_list_skin(account_info)
    size = getDesktop(0).size()
    w = size.width()
    h = size.height()
    margin = max(24, int(w * 0.035))
    top = max(64, int(h * 0.1))
    bottom = max(64, int(h * 0.1))
    content_h = max(180, h - top - bottom - 18)
    content_w = w - margin * 2
    font = 28 if w >= 1920 else 22 if w > 1280 else 20
    title_font = font + 7
    key_font = max(16, font - 2)
    header_top = top
    account_body = ''
    if account_info:
        info_h = font * 2 + 16
        account_body = '<widget source="account_info" render="Label" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" foregroundColor="#c28cff" transparent="1" zPosition="3" />' % (margin + 8, top, content_w - 16, info_h, font)
        top += info_h
        content_h -= info_h
    if config:
        body = '<eLabel position="%d,%d" size="%d,%d" backgroundColor="#2d143b" zPosition="1" />\n        <widget name="config" position="%d,%d" size="%d,%d" font="AlkudsUnicode;%d" secondfont="AlkudsUnicode;%d"\n            foregroundColor="#ffffff" foregroundColorSelected="#ffffff"\n            backgroundColor="#2d143b" backgroundColorSelected="#6a249c"\n            itemHeight="%d" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2" />' % (margin, top, content_w, content_h, margin + 8, top + 6, content_w - 16, content_h - 12, font, font, font + 16)
    else:
        body = '<eLabel position="%d,%d" size="%d,%d" backgroundColor="#2d143b" zPosition="1" />\n        <widget source="list" render="Listbox" position="%d,%d" size="%d,%d"\n            foregroundColor="#ffffff" foregroundColorSelected="#ffffff"\n            backgroundColor="#2d143b" backgroundColorSelected="#6a249c"\n            scrollbarMode="showOnDemand" enableWrapAround="1" transparent="0" zPosition="2">\n            <convert type="TemplatedMultiContent">{"template":[MultiContentEntryText(pos=(14,2),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=0)],"fonts":[gFont("AlkudsUnicode",%d)],"itemHeight":%d}</convert>\n        </widget>' % (margin, top, content_w, content_h, margin + 8, top + 6, content_w - 16, content_h - 12, content_w - 46, font + 14, font, font + 18)
    footer_y = h - 54
    key_w = int((w - margin * 2) / 4.0)
    return '<screen name="AlkudsStalker" position="0,0" size="%d,%d" backgroundColor="#270b30" flags="wfNoBorder">\n        <eLabel position="0,0" size="%d,%d" backgroundColor="#270b30" zPosition="0" />\n        <eLabel position="0,0" size="%d,%d" backgroundColor="#38104a" zPosition="1" />\n        <widget source="title" render="Label" position="%d,10" size="%d,%d" font="AlkudsUnicode;%d"\n            foregroundColor="#ffffff" backgroundColor="#38104a" valign="center" transparent="0" zPosition="2" />\n        %s\n        <eLabel position="0,%d" size="%d,54" backgroundColor="#190820" zPosition="1" />\n        <widget source="key_red" render="Label" position="%d,%d" size="%d,44" font="AlkudsUnicode;%d" foregroundColor="#ff7777" backgroundColor="#190820" valign="center" transparent="0" zPosition="2" />\n        <widget source="key_green" render="Label" position="%d,%d" size="%d,44" font="AlkudsUnicode;%d" foregroundColor="#77ff88" backgroundColor="#190820" valign="center" transparent="0" zPosition="2" />\n        <widget source="key_yellow" render="Label" position="%d,%d" size="%d,44" font="AlkudsUnicode;%d" foregroundColor="#ffff77" backgroundColor="#190820" valign="center" transparent="0" zPosition="2" />\n        <widget source="key_blue" render="Label" position="%d,%d" size="%d,44" font="AlkudsUnicode;%d" foregroundColor="#c477ff" backgroundColor="#190820" valign="center" transparent="0" zPosition="2" />\n    </screen>' % (w, h, w, h, w, header_top - 8, margin, w - margin * 2, header_top - 18, title_font, account_body + body, footer_y, w, margin, footer_y + 5, key_w, key_font, margin + key_w, footer_y + 5, key_w, key_font, margin + key_w * 2, footer_y + 5, key_w, key_font, margin + key_w * 3, footer_y + 5, key_w, key_font)

def _channels_skin(account_info=False):
    from .subscriptionliststyle import subscription_list_skin
    return subscription_list_skin(account_info, True)

def _decode_multistalker_text(text):
    """Decode MultiStalkerPro exports, including a few common hand-edit/export defects."""
    if text.startswith(u'\ufeff'):
        text = text.lstrip(u'\ufeff')
    first = text.find('[')
    last = text.rfind(']')
    if first >= 0 and last > first:
        text = text[first:last + 1]
    try:
        data = json.loads(text)
        return data if isinstance(data, list) else []
    except Exception:
        pass
    repaired = text
    repaired = re.sub('("host"\\s*:\\s*")([^"\\r\\n]*?)(\\s*,\\s*"mac"\\s*:)', '\\1\\2"\\3', repaired, flags=re.I)
    repaired = re.sub(',\\s*]', ']', repaired)
    try:
        data = json.loads(repaired)
        return data if isinstance(data, list) else []
    except Exception:
        pass
    items = []
    pair = re.compile('"host"\\s*:\\s*"(?P<host>https?://.*?)(?:"?\\s*,\\s*)"mac"\\s*:\\s*"(?P<mac>[0-9A-Fa-f:.-]+)"', re.I | re.S)
    matches = list(pair.finditer(repaired))
    for i, match in enumerate(matches):
        host = (match.group('host') or '').strip().rstrip(',').strip().rstrip('"').strip()
        mac = (match.group('mac') or '').strip()
        seg_end = matches[i + 1].start() if i + 1 < len(matches) else min(len(repaired), match.end() + 1000)
        segment = repaired[match.end():seg_end]
        item = {'host': host, 'mac': mac, 'type': 1, 'entryPoint': 'portal.php'}
        mtype = re.search('"type"\\s*:\\s*(\\d+)', segment, re.I)
        if mtype:
            try:
                item['type'] = int(mtype.group(1))
            except Exception:
                pass
        mentry = re.search('"entryPoint"\\s*:\\s*"([^"]+)"', segment, re.I)
        if mentry:
            item['entryPoint'] = mentry.group(1).strip()
        items.append(item)
    return items

def _read_existing_multistalker_raw():
    """Read the first usable MultiStalkerPro.json from HDD/USB or /etc/enigma2."""
    global _ACTIVE_STALKER_FILE
    first_existing = None
    for path in _stalker_candidates():
        if not os.path.isfile(path):
            continue
        if first_existing is None:
            first_existing = path
        try:
            with open(path, 'r') as f:
                text = f.read()
            data = _decode_multistalker_text(text)
            usable = any((isinstance(x, dict) and x.get('host') and x.get('mac') for x in data))
            if usable:
                _ACTIVE_STALKER_FILE = path
                return data
        except Exception as e:
            print('[Alkuds Stalker] load MultiStalkerPro %s: %s' % (path, e))
    if first_existing:
        _ACTIVE_STALKER_FILE = first_existing
        try:
            with open(first_existing, 'r') as f:
                return _decode_multistalker_text(f.read())
        except Exception:
            pass
    return []

def _read_multistalker_raw():
    raw = _read_existing_multistalker_raw()
    try:
        from .localimport import read_store, identity
        store = read_store()
        hidden = set(store.get('removed_stalker') or [])
        seen = set((identity('stalker', row) for row in raw if isinstance(row, dict) and row.get('mac')))
        for row in store.get('stalker') or []:
            marker = identity('stalker', row)
            if marker not in seen and marker not in hidden:
                raw.append(dict(row))
                seen.add(marker)
    except Exception:
        pass
    return raw

def _portal_name(host, item=None):
    if isinstance(item, dict) and item.get('name'):
        return str(item.get('name'))
    value = str(host or '').strip()
    value = re.sub('^https?://', '', value, flags=re.I)
    value = value.split('/')[0]
    return value or 'Stalker'

def _load_prefs():
    try:
        if os.path.isfile(STALKER_PREFS_FILE):
            with open(STALKER_PREFS_FILE, 'r') as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}

def _save_prefs(data):
    try:
        if not os.path.isdir(dir_etc):
            os.makedirs(dir_etc)
        tmp = STALKER_PREFS_FILE + '.tmp'
        with open(tmp, 'w') as f:
            json.dump(data, f, indent=2, sort_keys=True)
        try:
            os.rename(tmp, STALKER_PREFS_FILE)
        except OSError:
            if os.path.exists(STALKER_PREFS_FILE):
                os.remove(STALKER_PREFS_FILE)
            os.rename(tmp, STALKER_PREFS_FILE)
    except Exception as e:
        print('[Alkuds Stalker] save prefs:', e)

def _portal_pref_key(portal):
    base = _normalise_portal(portal.get('portal', portal.get('host', '')))
    mac = _normalise_mac(portal.get('mac', ''))
    raw = (base + '|' + mac).encode('utf-8')
    return hashlib.sha1(raw).hexdigest()

def _load_portals():
    raw = _read_multistalker_raw()
    prefs = _load_prefs()
    portals = []
    for raw_index, item in enumerate(raw):
        if not isinstance(item, dict):
            continue
        host = str(item.get('host', '') or '').strip()
        mac = _normalise_mac(item.get('mac', ''))
        if not host or not mac:
            continue
        try:
            item_type = int(item.get('type', 1) or 1)
        except Exception:
            item_type = 1
        entry = str(item.get('entryPoint', '') or '').strip().lstrip('/')
        portal = {'name': _portal_name(host, item), 'portal': _normalise_portal(host), 'host': host, 'mac': mac, 'type': item_type, 'entryPoint': entry, 'insecure': bool(item.get('insecure', False)), 'timeout': int(item.get('timeout', 10) or 10), '_raw': dict(item), '_raw_index': raw_index}
        pref = prefs.get(_portal_pref_key(portal), {})
        if isinstance(pref, dict):
            if pref.get('channel_sort') in ('az', 'za', 'server'):
                portal['channel_sort'] = pref.get('channel_sort')
        portals.append(portal)
    return portals

def _portal_to_multistalker(item):
    raw = dict(item.get('_raw', {})) if isinstance(item.get('_raw'), dict) else {}
    portal = _normalise_portal(item.get('portal', item.get('host', '')))
    old_host = str(raw.get('host', item.get('host', '')) or '').strip()
    if old_host and _normalise_portal(old_host) == portal:
        host = old_host
    else:
        host = portal.rstrip('/') + '/c' if portal else ''
    raw['host'] = host
    raw['mac'] = _normalise_mac(item.get('mac', raw.get('mac', '')))
    try:
        raw['type'] = int(item.get('type', raw.get('type', 1)) or 1)
    except Exception:
        raw['type'] = 1
    entry = str(item.get('entryPoint', raw.get('entryPoint', 'portal.php')) or 'portal.php').strip().lstrip('/')
    raw['entryPoint'] = entry
    raw.pop('channel_sort', None)
    raw.pop('_raw', None)
    raw.pop('_raw_index', None)
    if item.get('name') and raw.get('name'):
        raw['name'] = str(item.get('name'))
    return raw

def _save_portals(data):
    """Write portal records back while preserving tmdb_key/subdl_key records."""
    if not os.path.isdir(dir_etc):
        try:
            os.makedirs(dir_etc)
        except Exception:
            pass
    existing = _read_multistalker_raw()
    metadata = []
    for item in existing:
        if not isinstance(item, dict) or not (item.get('host') and item.get('mac')):
            metadata.append(item)
    output = metadata + [_portal_to_multistalker(item) for item in data or []]
    path = _stalker_file_path(for_write=True)
    parent = os.path.dirname(path)
    if parent and (not os.path.isdir(parent)):
        try:
            os.makedirs(parent)
        except Exception:
            pass
    tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(output, f, indent=4, ensure_ascii=False)
    try:
        os.rename(tmp, path)
    except OSError:
        try:
            if os.path.exists(path):
                os.remove(path)
            os.rename(tmp, path)
        except Exception:
            pass
    try:
        from .localimport import STORE, read_store, identity, atomic_write
        store = read_store()
        retained = set((identity('stalker', row) for row in output if isinstance(row, dict) and row.get('mac')))
        store['removed_stalker'] = [identity('stalker', row) for row in store.get('stalker') or [] if identity('stalker', row) not in retained]
        atomic_write(STORE, json.dumps(store, ensure_ascii=True, indent=2))
    except Exception:
        pass

def _normalise_mac(value):
    raw = re.sub('[^0-9A-Fa-f]', '', value or '').upper()
    if len(raw) != 12:
        return ''
    return ':'.join((raw[i:i + 2] for i in range(0, 12, 2)))

def _privacy_mac(value, reveal=False):
    """Return a UI-safe MAC; underlying portal data is never modified."""
    mac = _normalise_mac(value)
    if reveal or not mac:
        return mac
    parts = mac.split(':')
    if len(parts) == 6:
        return '%s:%s:%s:**:**:%s' % (parts[0], parts[1], parts[2], parts[5])
    if len(mac) > 5:
        return '******' + mac[-5:]
    return '******'

def _normalise_portal(value):
    value = (value or '').strip()
    if not value:
        return ''
    if not value.startswith(('http://', 'https://')):
        value = 'http://' + value
    value = value.rstrip('/')
    value = re.sub('/(c|c/index\\.html?|index\\.html?)$', '', value, flags=re.I)
    return value.rstrip('/')

def _channel_sort_key(item):
    name = str(item[0] if item else '')
    parts = re.split('(\\d+)', name.lower())
    key = []
    for part in parts:
        if part.isdigit():
            try:
                key.append((0, int(part)))
            except Exception:
                key.append((1, part))
        else:
            key.append((1, part))
    return key

def _persist_portal_option(portal, key, value):
    """Persist Alkuds-only UI options separately from MultiStalkerPro.json."""
    prefs = _load_prefs()
    pkey = _portal_pref_key(portal)
    record = prefs.get(pkey, {})
    if not isinstance(record, dict):
        record = {}
    record[key] = value
    prefs[pkey] = record
    portal[key] = value
    _save_prefs(prefs)

class StalkerClient(object):

    def __init__(self, portal):
        self.saved_portal = dict(portal)
        self.portal = _normalise_portal(portal.get('portal', ''))
        self.mac = _normalise_mac(portal.get('mac', ''))
        self.verify = not bool(portal.get('insecure', False))
        self.timeout = int(portal.get('timeout', 10) or 10)
        self.entry_point = str(portal.get('entryPoint', '') or '').strip().lstrip('/')
        self.session = requests.Session()
        self.token = ''
        self.endpoint = ''
        self.account_info = {}
        self.headers = {'User-Agent': MAG_USER_AGENT, 'X-User-Agent': X_USER_AGENT, 'Accept': '*/*', 'Connection': 'keep-alive', 'Cookie': 'mac=%s; stb_lang=en; timezone=GMT' % quote(self.mac, safe='')}

    def _candidate_endpoints(self):
        p = self.portal.rstrip('/')
        candidates = []
        if self.entry_point:
            ep = self.entry_point.lstrip('/')
            if p.endswith(ep):
                candidates.append(p)
            else:
                candidates.append(p + '/' + ep)
        if p.endswith('portal.php') or p.endswith('server/load.php'):
            candidates.append(p)
        else:
            candidates.extend([p + '/portal.php', p + '/server/load.php'])
        seen = []
        for url in candidates:
            if url and url not in seen:
                seen.append(url)
        return seen

    def _extract_js(self, payload):
        if isinstance(payload, dict):
            return payload.get('js', payload)
        return payload

    def _request(self, params, endpoint=None):
        url = endpoint or self.endpoint
        if not url:
            raise RuntimeError('Portal endpoint is not set')
        headers = dict(self.headers)
        if self.token:
            headers['Authorization'] = 'Bearer ' + self.token
        r = self.session.get(url, params=params, headers=headers, timeout=self.timeout, verify=self.verify)
        r.raise_for_status()
        try:
            return r.json()
        except ValueError:
            text = (r.text or '').strip()
            if text.startswith(u'\ufeff'):
                text = text.lstrip(u'\ufeff')
            return json.loads(text)

    def connect(self):
        last_error = None
        for endpoint in self._candidate_endpoints():
            try:
                payload = self._request({'type': 'stb', 'action': 'handshake', 'token': '', 'JsHttpRequest': '1-xml'}, endpoint=endpoint)
                js = self._extract_js(payload)
                token = js.get('token', '') if isinstance(js, dict) else ''
                if token:
                    self.endpoint = endpoint
                    self.token = str(token)
                    try:
                        profile = self._request({'type': 'stb', 'action': 'get_profile', 'hd': '1', 'JsHttpRequest': '1-xml'})
                        from .accountinfo import account_fields
                        self.account_info.update(account_fields(profile))
                    except Exception:
                        pass
                    return True
            except Exception as e:
                last_error = e
        if last_error:
            raise last_error
        raise RuntimeError('Handshake failed')

    def get_account_info(self):
        from .accountinfo import account_fields, _expiry_timestamp
        try:
            payload = self._request({'type': 'account_info', 'action': 'get_main_info', 'JsHttpRequest': '1-xml'})
            self.account_info.update(account_fields(payload))
            data = self._extract_js(payload)
            if isinstance(data, dict) and (not self.account_info.get('expiry')):
                value = data.get('phone')
                if value and (not str(value).strip().isdigit()) and (_expiry_timestamp(value) is not None):
                    self.account_info['expiry'] = value
            if self.token and isinstance(data, dict) and self.account_info and (not data.get('error')):
                from .subscriptioncheck import record
                from .remote_backup import backup_stalker_connected
                expiry = _expiry_timestamp(self.account_info.get('expiry'))
                status = 'Expired' if expiry and expiry < time.time() else 'Active'
                record('mac', self.saved_portal, status, self.account_info)
                if status == 'Active' and (not getattr(self, 'suppress_backup', False)):
                    backup_stalker_connected(self.saved_portal)
        except Exception:
            pass
        return self.account_info

    def get_genres(self):
        if not self.token:
            self.connect()
        payload = self._request({'type': 'itv', 'action': 'get_genres', 'JsHttpRequest': '1-xml'})
        js = self._extract_js(payload)
        if isinstance(js, dict):
            js = js.get('data', js.get('genres', []))
        from .adultfilter import categories
        return categories('mac', self.saved_portal, 'live', js)

    def get_channels(self):
        if not self.token:
            self.connect()
        payload = self._request({'type': 'itv', 'action': 'get_all_channels', 'JsHttpRequest': '1-xml'})
        js = self._extract_js(payload)
        if isinstance(js, dict):
            js = js.get('data', js.get('channels', []))
        from .adultfilter import items, enabled
        if enabled('mac', self.saved_portal):
            self.get_genres()
        return items('mac', self.saved_portal, 'live', js if isinstance(js, list) else [])

    def create_link(self, command, content_type='itv', series='0'):
        last_error = None
        for attempt in range(2):
            try:
                if not self.token:
                    self.connect()
                payload = self._request({'type': content_type, 'action': 'create_link', 'cmd': command or '', 'series': str(series), 'forced_storage': '0', 'disable_ad': '0', 'download': '0', 'JsHttpRequest': '1-xml'})
                js = self._extract_js(payload)
                cmd = ''
                if isinstance(js, dict):
                    cmd = js.get('cmd', '') or js.get('url', '')
                elif isinstance(js, str):
                    cmd = js
                if not cmd:
                    raise RuntimeError('Portal did not return a stream link')
                stream_url = _clean_stream_url(cmd)
                if not stream_url:
                    raise RuntimeError('Portal returned an empty stream URL')
                return stream_url
            except Exception as e:
                last_error = e
                if attempt == 0:
                    self.token = ''
                    self.endpoint = ''
                    continue
                raise
        if last_error:
            raise last_error
        raise RuntimeError('Unable to create stream link')

class Alkuds_Stalker_Add(ConfigListScreen, Screen):

    def __init__(self, session, edit_index=None):
        Screen.__init__(self, session)
        self.skin = _skin('Stalker / MAC', config=True)
        self.session = session
        self.edit_index = edit_index
        self.portals = _load_portals()
        current = self.portals[edit_index] if edit_index is not None and edit_index < len(self.portals) else {}
        self.nameCfg = NoSave(ConfigText(default=str(current.get('name', 'Stalker')), fixed_size=False))
        self.portalCfg = NoSave(ConfigText(default=str(current.get('portal', '')), fixed_size=False))
        self.macCfg = NoSave(ConfigText(default=str(current.get('mac', '00:1A:79:')), fixed_size=False))
        self.entryCfg = NoSave(ConfigText(default=str(current.get('entryPoint', 'portal.php') or 'portal.php'), fixed_size=False))
        self.insecureCfg = NoSave(ConfigYesNo(default=bool(current.get('insecure', False))))
        entries = [getConfigListEntry('Name:', self.nameCfg), getConfigListEntry('Portal URL:', self.portalCfg), getConfigListEntry('MAC:', self.macCfg), getConfigListEntry('Entry point:', self.entryCfg), getConfigListEntry('Allow invalid HTTPS certificate:', self.insecureCfg)]
        ConfigListScreen.__init__(self, entries, session=self.session)
        self['title'] = StaticText('Stalker / MAC')
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('Save')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'cancel': self.close, 'red': self.close, 'green': self.save, 'ok': self.save}, -2)

    def save(self):
        portal = _normalise_portal(self.portalCfg.value)
        mac = _normalise_mac(self.macCfg.value)
        name = (self.nameCfg.value or 'Stalker').strip()
        if not portal:
            self.session.open(MessageBox, 'Portal URL is required.', MessageBox.TYPE_ERROR, timeout=5)
            return
        if not mac:
            self.session.open(MessageBox, 'Invalid MAC address.', MessageBox.TYPE_ERROR, timeout=5)
            return
        item = {'name': name, 'portal': portal, 'host': portal.rstrip('/') + '/c', 'mac': mac, 'type': 1, 'entryPoint': (self.entryCfg.value or 'portal.php').strip().lstrip('/'), 'insecure': bool(self.insecureCfg.value)}
        is_new = self.edit_index is None
        if is_new:
            for old in self.portals:
                if _normalise_portal(old.get('portal')) == portal and _normalise_mac(old.get('mac')) == mac:
                    self.session.open(MessageBox, 'This Portal/MAC already exists.', MessageBox.TYPE_INFO, timeout=5)
                    return
            self.portals.append(item)
        else:
            self.portals[self.edit_index] = item
        _save_portals(self.portals)
        self.close(True)

class Alkuds_Stalker_Manager(Screen):

    def __init__(self, session, audio_only=False):
        Screen.__init__(self, session)
        self.skin = cards_skin()
        self.session = session
        self.audio_only = bool(audio_only)
        self['title'] = StaticText('Alkuds ipaudio - MAC IPAUDIO' if self.audio_only else 'Alkuds ipaudio - MAC Portals')
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('Open')
        self['key_yellow'] = StaticText('Delete')
        self['key_blue'] = StaticText('Add')
        self['list'] = PlainList([], enableWrapAround=True)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'AlkudsActions', 'MenuActions'], {'menu': self.check_subscriptions, 'cancel': self.close, 'red': self.close, 'green': self.open_portal, 'ok': self.open_portal, 'yellow': self.delete_portal, 'blue': self.add_portal, 'up': lambda: move_cards(self, 'moveUp'), 'down': lambda: move_cards(self, 'moveDown'), 'left': lambda: move_cards(self, 'pageUp'), 'right': lambda: move_cards(self, 'pageDown')}, -2)
        self.onLayoutFinish.append(self.reload)

    def check_subscriptions(self):
        from .subscriptioncheck import show_menu
        show_menu(self, 'mac', self.portals)

    def reload(self, *args):
        from .subscriptionprefs import ordered
        self.portals = ordered('mac', _load_portals())
        label = 'MAC audio subscriptions' if self.audio_only else 'MAC subscriptions'
        self['title'].setText('%s  /  %d' % (label, len(self.portals)))
        rows = [portal_card(item, index) for index, item in enumerate(self.portals)]
        if not rows:
            rows = [card_row('No MAC subscriptions yet', -1, 'Press BLUE to add a portal', kind='mac')]
        self['list'].setList(rows)

    def delete_checked_accounts(self, accounts):
        from .subscriptionprefs import identity, _backup, atomic
        from .localimport import STORE, read_store, identity as import_identity
        targets = {identity('mac', item) for item in accounts}
        current = _load_portals()
        retained = [item for item in current if identity('mac', item) not in targets]
        path = _stalker_file_path(for_write=True)
        raw = _read_multistalker_raw()
        metadata = [item for item in raw if not isinstance(item, dict) or not (item.get('host') and item.get('mac'))]
        output = metadata + [_portal_to_multistalker(item) for item in retained]
        store = read_store()
        keep = {import_identity('stalker', row) for row in output if isinstance(row, dict) and row.get('mac')}
        store['removed_stalker'] = [import_identity('stalker', row) for row in store.get('stalker') or [] if import_identity('stalker', row) not in keep]
        originals = {}
        for target in (path, STORE):
            _backup(target)
            if os.path.isfile(target):
                with open(target, 'rb') as handle:
                    originals[target] = handle.read()
            else:
                originals[target] = None
        atomic(path, json.dumps(output, ensure_ascii=False, indent=2).encode('utf8'))
        try:
            atomic(STORE, json.dumps(store).encode())
        except Exception:
            if originals[path] is None:
                os.unlink(path)
            else:
                atomic(path, originals[path])
            raise
        self.reload()
        return len(current) - len(retained)

    def _current_index(self):
        cur = self['list'].getCurrent()
        return cur[1] if cur and len(cur) > 1 else -1

    def add_portal(self):
        self.session.openWithCallback(self.reload, Alkuds_Stalker_Add)

    def delete_portal(self):
        idx = self._current_index()
        if idx < 0 or idx >= len(self.portals):
            return
        name = self.portals[idx].get('name', 'Stalker')
        self.session.openWithCallback(lambda answer: self._delete_confirmed(answer, idx), MessageBox, 'Delete %s?' % name, MessageBox.TYPE_YESNO)

    def _delete_confirmed(self, answer, idx):
        if answer and idx < len(self.portals):
            del self.portals[idx]
            _save_portals(self.portals)
            self.reload()

    def open_portal(self):
        idx = self._current_index()
        if idx < 0 or idx >= len(self.portals):
            self.add_portal()
            return
        if self.audio_only:
            self.session.openWithCallback(self._child_closed, Alkuds_Stalker_Genres, self.portals[idx], True)
        else:
            from .stalkervod import Alkuds_MAC_Content
            self.session.open(Alkuds_MAC_Content, self.portals[idx])

    def _child_closed(self, result=None):
        if result == 'ipaudio-started':
            self.close(result)

class Alkuds_Stalker_Genres(Screen):

    def __init__(self, session, portal, audio_only=False):
        Screen.__init__(self, session)
        self.skin = _skin('Stalker categories', account_info=True)
        self['account_info'] = StaticText('Connecting account...')
        self.session = session
        self.portal = portal
        self.audio_only = bool(audio_only)
        self.client = StalkerClient(portal)
        self['title'] = StaticText(('%s - MAC IPAUDIO Categories' if self.audio_only else '%s - Categories') % portal.get('name', 'Stalker'))
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('Open')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('Reload')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'cancel': self.back, 'red': self.back, 'green': self.open_genre, 'ok': self.open_genre, 'blue': self.load}, -2)
        self.genres = []
        self._loading = False
        self._load_done = False
        self._load_result = None
        self._load_error = ''
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll_load)
        except Exception:
            self._timer.callback.append(self._poll_load)
        self.onFirstExecBegin.append(self.load)

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._load_done = False
        self._load_result = None
        self._load_error = ''
        self['list'].setList([('Connecting selected portal...', '')])
        t = threading.Thread(target=self._load_worker)
        t.daemon = True
        t.start()
        self._timer.start(100, False)

    def _load_worker(self):
        try:
            self._load_result = self.client.get_genres()
            self.client.get_account_info()
        except Exception as e:
            self._load_error = str(e)
        self._load_done = True

    def _poll_load(self):
        if not self._load_done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._load_error:
            self['list'].setList([('Connection failed - press BLUE to retry', '')])
            self.session.open(MessageBox, 'Stalker connection failed:\n%s' % self._load_error, MessageBox.TYPE_ERROR, timeout=8)
            return
        self.genres = self._load_result if isinstance(self._load_result, list) else []
        from .accountinfo import account_text
        self['account_info'].setText(account_text(self.client.account_info))
        try:
            from .remote_backup import backup_stalker_connected
            backup_stalker_connected(self.portal)
        except Exception:
            pass
        rows = [('All channels', '*')]
        for item in self.genres:
            if not isinstance(item, dict):
                continue
            gid = str(item.get('id', item.get('genre_id', '')))
            title = str(item.get('title', item.get('name', '')))
            if gid and title:
                rows.append((title, gid))
        self['list'].setList(rows)

    def back(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass
        self.close()

    def open_genre(self):
        if self._loading:
            return
        cur = self['list'].getCurrent()
        if not cur or not cur[1]:
            return
        if self.audio_only:
            self.session.openWithCallback(self._child_closed, Alkuds_Stalker_Channels, self.portal, cur[1], cur[0], True)
        else:
            self.session.open(Alkuds_Stalker_Channels, self.portal, cur[1], cur[0])

    def _child_closed(self, result=None):
        if result == 'ipaudio-started':
            self.close(result)

class Alkuds_Stalker_Player(Screen):
    """Stalker live player with one-link reuse and a lightweight InfoBar."""
    skin = '<screen name="AlkudsStalkerPlayer" position="0,0" size="1,1" flags="wfNoBorder"></screen>'

    def __init__(self, session, client, channels, index, play_on_open=True, initial_url='', initial_service_type=None):
        Screen.__init__(self, session)
        self.session = session
        from .listpreview import install_fullscreen_video
        install_fullscreen_video(self)
        self.client = client
        self.channels = channels or []
        self.index = int(index or 0)
        self.play_on_open = bool(play_on_open)
        self.stream_url = str(initial_url or '')
        self.service_type = int(initial_service_type or _stalker_service_type())
        self.info_dialog = None
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'DirectionActions', 'MenuActions'], {'cancel': self.back, 'stop': self.stop_and_back, 'red': self.back, 'channelUp': self.next_channel, 'up': self.next_channel, 'right': self.next_channel, 'channelDown': self.prev_channel, 'down': self.prev_channel, 'left': self.prev_channel, 'ok': self.toggle_info, 'info': self.toggle_info, 'menu': self.player_menu, '0': self.restart_stream}, -2)
        self.onClose.append(self._cleanup_info)
        if self.play_on_open:
            self.onFirstExecBegin.append(self.play_current)
        else:
            self.onFirstExecBegin.append(self.show_current_info)
        from .transportcontrol import install as install_transport
        install_transport(self, True)

    def _current(self):
        if not self.channels:
            return None
        self.index %= len(self.channels)
        return self.channels[self.index]

    def _play(self, reuse_url=False):
        current = self._current()
        if not current:
            return
        channel_name, channel_cmd = (current[0], current[1])
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
            if reuse_url and self.stream_url:
                stream_url = self.stream_url
            else:
                stream_url = self.client.create_link(channel_cmd)
                self.stream_url = str(stream_url or '')
            ref = service_reference(int(self.service_type), 0, stream_url)
            ref.setName(gui_text(str(channel_name)))
            result = self.session.nav.playService(ref)
            if result is False and int(self.service_type) != 4097:
                self.service_type = 4097
                fallback = service_reference(4097, 0, stream_url)
                fallback.setName(gui_text(str(channel_name)))
                self.session.nav.playService(fallback)
            self.show_current_info()
        except Exception as e:
            self.session.open(MessageBox, 'Unable to play channel:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=6)

    def play_current(self):
        self._play()

    def next_channel(self):
        if self.channels:
            self.index = (self.index + 1) % len(self.channels)
            self.stream_url = ''
            self._play()

    def prev_channel(self):
        if self.channels:
            self.index = (self.index - 1) % len(self.channels)
            self.stream_url = ''
            self._play()

    def restart_stream(self):
        self._play(reuse_url=True)

    def show_current_info(self):
        if hasattr(self, '_transport_control'):
            self._transport_control.present()

    def toggle_info(self):
        if hasattr(self, '_transport_control'):
            self._transport_control.toggle_bar()

    def player_menu(self):
        self._transport_control.suspend()
        try:
            from .streammonitor import available_player_types
            choices = []
            for value, label in available_player_types():
                prefix = '[Current] ' if int(value) == int(self.service_type) else ''
                choices.append((prefix + '%s (%s)' % (label, value), int(value)))
            if self.info_dialog:
                self.info_dialog.hide()
            self.session.openWithCallback(self._player_selected, ChoiceBox, title='Choose player for this stream', list=choices)
        except Exception as e:
            self.session.open(MessageBox, 'Player menu unavailable:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=5)

    def _player_selected(self, answer=None):
        if answer and len(answer) > 1:
            try:
                self.service_type = int(answer[1])
                self._play(reuse_url=True)
                return
            except Exception:
                pass
        self.show_current_info()

    def _cleanup_info(self):
        try:
            from .streammonitor import destroy_stream_info_dialog
            destroy_stream_info_dialog(self.session, self.info_dialog)
        except Exception:
            pass
        self.info_dialog = None

    def back(self):
        self.close(self.index)

    def stop_and_back(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.close(self.index)

class Alkuds_Stalker_Channels(Screen):

    def __init__(self, session, portal, genre_id='*', genre_name='Channels', audio_only=False):
        Screen.__init__(self, session)
        self.skin = _channels_skin()
        self.session = session
        self.portal = portal
        self.audio_only = bool(audio_only)
        self.genre_id = str(genre_id)
        self.genre_name = str(genre_name)
        self.client = StalkerClient(portal)
        self.original_channels = []
        self.channels = []
        self.sort_mode = str(portal.get('channel_sort', 'az') or 'az')
        self.player_name = 'ExtePlayer3 5002' if _has_exteplayer3() else 'IPTV 4097 fallback'
        self.playing_index = None
        self.playing_url = ''
        self.playing_service_type = _stalker_service_type()
        self._loading = False
        self._load_done = False
        self._load_result = None
        self._load_error = ''
        self._closed = False
        self._timer = eTimer()
        try:
            self._timer_conn = self._timer.timeout.connect(self._poll_channels)
        except Exception:
            self._timer.callback.append(self._poll_channels)
        self._bg_loading = False
        self._bg_done = False
        self._bg_error = ''
        self._bg_backend = ''
        self._bg_name = ''
        self._bg_url = ''
        self._bg_mode = 'dual'
        self._bg_target = 'remux'
        self._bg_index = 0
        self._bg_timer = eTimer()
        try:
            self._bg_timer_conn = self._bg_timer.timeout.connect(self._poll_background_audio)
        except Exception:
            self._bg_timer.callback.append(self._poll_background_audio)
        self['title'] = StaticText('')
        self['key_red'] = StaticText('Back')
        self['key_green'] = StaticText('IP Audio' if self.audio_only else 'Play')
        self['key_yellow'] = StaticText('Sort')
        self['key_blue'] = StaticText('Reload')
        self['list'] = List([], enableWrapAround=True)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions'], {'cancel': self.back, 'red': self.back, 'green': self.play, 'ok': self.play, 'yellow': self.sort_menu, 'blue': self.load, 'menu': self.options_menu, 'stop': self.stop_stream}, -2)
        self.onFirstExecBegin.append(self.load)
        self._update_title()
        from .postergrid import install as install_posters
        install_posters(self, self.play, self.options_menu, 'list')
        from .uihelpers import install_channel_guide
        install_channel_guide(self)

    def _sort_label(self):
        return {'az': 'A-Z', 'za': 'Z-A', 'server': 'Portal'}.get(self.sort_mode, 'A-Z')

    def _update_title(self):
        player = 'MAC IPAUDIO' if self.audio_only else self.player_name
        self['title'].setText('%s - %s  [%s]  [Sort: %s]' % (self.portal.get('name', 'Stalker'), self.genre_name, player, self._sort_label()))

    def _apply_sort(self, keep_name=None):
        self.channels = list(self.original_channels)
        if self.sort_mode == 'az':
            self.channels.sort(key=_channel_sort_key)
        elif self.sort_mode == 'za':
            self.channels.sort(key=_channel_sort_key, reverse=True)
        rows = []
        selected = 0
        for idx, item in enumerate(self.channels):
            name = item[0]
            rows.append((channel_row(idx, name, idx == self.playing_index), idx))
            if keep_name is not None and name == keep_name:
                selected = idx
        if not rows:
            rows = [('No channels in this category.', -1)]
        self['list'].setList(rows)
        if rows and rows[0][1] >= 0:
            try:
                self['list'].setIndex(selected)
            except Exception:
                pass
        self._update_title()

    def load(self):
        if self._loading:
            return
        self._loading = True
        self._load_done = False
        self._load_result = None
        self._load_error = ''
        self['list'].setList([('Loading selected category...', -1)])
        t = threading.Thread(target=self._channels_worker)
        t.daemon = True
        t.start()
        self._timer.start(100, False)

    def _channels_worker(self):
        try:
            all_channels = self.client.get_channels()
            result = []
            self._poster_images = {}
            for item in all_channels:
                if not isinstance(item, dict):
                    continue
                gid = str(item.get('tv_genre_id', item.get('genre_id', '')))
                if self.genre_id != '*' and gid != self.genre_id:
                    continue
                name = str(item.get('name', item.get('title', 'Channel')))
                cmd = item.get('cmd', '') or item.get('url', '')
                if cmd:
                    result.append((name, cmd))
                    self._poster_images[cmd] = item.get('stream_icon') or item.get('logo') or item.get('screenshot_uri') or item.get('cover') or ''
            self._load_result = result
        except Exception as e:
            self._load_error = str(e)
        self._load_done = True

    def _poll_channels(self):
        if not self._load_done:
            return
        try:
            self._timer.stop()
        except Exception:
            pass
        self._loading = False
        if self._closed:
            return
        if self._load_error:
            self['list'].setList([('Load failed - press BLUE to retry', -1)])
            self.session.open(MessageBox, 'Unable to load channels:\n%s' % self._load_error, MessageBox.TYPE_ERROR, timeout=8)
            return
        self.original_channels = self._load_result if isinstance(self._load_result, list) else []
        self._apply_sort()

    def back(self):
        self._closed = True
        try:
            self._timer.stop()
        except Exception:
            pass
        try:
            self._bg_timer.stop()
        except Exception:
            pass
        controller = getattr(self, '_list_preview', None)
        if controller:
            controller.close()
        self.close()

    def stop_stream(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.playing_index = None
        self.playing_url = ''

    def _set_sort(self, mode):
        cur = self['list'].getCurrent()
        keep_name = None
        if cur and cur[1] >= 0 and (cur[1] < len(self.channels)):
            keep_name = self.channels[cur[1]][0]
        self.sort_mode = mode
        _persist_portal_option(self.portal, 'channel_sort', mode)
        self._apply_sort(keep_name=keep_name)

    def sort_menu(self):
        self.session.openWithCallback(self._sort_selected, ChoiceBox, title='Channel sorting', list=[('Alphabetical A - Z', 'az'), ('Alphabetical Z - A', 'za'), ('Original portal order', 'server')])

    def _sort_selected(self, answer=None):
        if answer and len(answer) > 1:
            self._set_sort(answer[1])

    def options_menu(self):
        self.session.openWithCallback(self._option_selected, ChoiceBox, title='Stalker channel options', list=[('Sort: A - Z', 'az'), ('Sort: Z - A', 'za'), ('Sort: original portal order', 'server'), ('Reload channel list', 'reload'), (u'جدول beIN — توقيت الرسيفر', 'sports_schedule'), ('Reconnect portal', 'reconnect'), ('Add to IPAudio Pro', 'add_pro'), ('Add to IPAudio', 'add_old'), ('Local Remux: IPTV + Satellite audio tracks', 'rmx_dual'), ('R14 Timeshift KeyGate: IPTV audio only', 'rmx_iptv'), ('Local Remux: stop and restore satellite', 'rmx_stop'), ('Local Remux: status', 'rmx_status'), ('Player: %s' % self.player_name, 'player_info'), ('Cancel', 'cancel')])

    def _option_selected(self, answer=None):
        if not answer or len(answer) < 2:
            return
        action = answer[1]
        if action in ('az', 'za', 'server'):
            self._set_sort(action)
        elif action == 'reload':
            self.load()
        elif action == 'sports_schedule':
            from .audioepg import open_iptv_schedule
            open_iptv_schedule(self)
        elif action == 'reconnect':
            self.client.token = ''
            self.client.endpoint = ''
            self.load()
        elif action == 'add_pro':
            self.export_ipaudio('pro')
        elif action == 'add_old':
            self.export_ipaudio('legacy')
        elif action == 'rmx_dual':
            self.start_local_remux('dual')
        elif action == 'rmx_iptv':
            self.start_local_remux('iptv')
        elif action == 'rmx_stop':
            try:
                from .remux import stop_local_remux
                stopped = stop_local_remux(restore=True)
                msg = 'Local Remux stopped. Satellite service restored.' if stopped else 'Local Remux is not running.'
            except Exception as e:
                msg = 'Unable to stop Local Remux: %s' % str(e)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)
        elif action == 'rmx_status':
            try:
                from .remux import local_remux_status
                active, name, backend = local_remux_status()
                msg = 'Local Remux is running:\n%s\n%s' % (name, backend) if active else 'Local Remux is not running.'
            except Exception as e:
                msg = 'Unable to read Local Remux status: %s' % str(e)
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
        elif action == 'player_info':
            self.session.open(MessageBox, 'Stalker uses %s automatically.\nBACK returns to the loaded channel list.\nCH+/CH- or UP/DOWN changes channel while watching.' % self.player_name, MessageBox.TYPE_INFO, timeout=7)

    def export_ipaudio(self, kind='pro'):
        if self._bg_loading:
            return
        cur = self['list'].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            self.session.open(MessageBox, 'Select a channel first.', MessageBox.TYPE_INFO, timeout=4)
            return
        index = int(cur[1])
        self._bg_index = index
        self._bg_name, channel_cmd = self.channels[index]
        self._bg_cmd = channel_cmd
        self._bg_target = 'export_pro' if str(kind) == 'pro' else 'export_legacy'
        self._bg_loading = True
        self._bg_done = False
        self._bg_error = ''
        self._bg_url = ''
        t = threading.Thread(target=self._local_remux_resolve_worker, args=(channel_cmd,))
        t.daemon = True
        t.start()
        self._bg_timer.start(120, False)

    def start_local_remux(self, mode='dual'):
        if self._bg_loading:
            return
        cur = self['list'].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            self.session.open(MessageBox, 'Select a channel first.', MessageBox.TYPE_INFO, timeout=4)
            return
        index = cur[1]
        self._bg_index = int(index)
        self._bg_name, channel_cmd = self.channels[index]
        self._bg_cmd = channel_cmd
        self._bg_mode = mode if mode in ('dual', 'iptv') else 'dual'
        self._bg_target = 'remux'
        self._bg_loading = True
        self._bg_done = False
        self._bg_error = ''
        self._bg_backend = ''
        self._bg_url = ''
        t = threading.Thread(target=self._local_remux_resolve_worker, args=(channel_cmd,))
        t.daemon = True
        t.start()
        self._bg_timer.start(120, False)

    def start_ipaudio(self):
        if self._bg_loading:
            return
        cur = self['list'].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            return
        index = int(cur[1])
        self._bg_index = index
        self._bg_name, channel_cmd = self.channels[index]
        self._bg_cmd = channel_cmd
        self._bg_target = 'ipaudio'
        self._bg_loading = True
        self._bg_done = False
        self._bg_error = ''
        self._bg_url = ''
        t = threading.Thread(target=self._local_remux_resolve_worker, args=(channel_cmd,))
        t.daemon = True
        t.start()
        self._bg_timer.start(120, False)

    def _local_remux_resolve_worker(self, channel_cmd):
        try:
            self._bg_url = self.client.create_link(channel_cmd)
            if not self._bg_url:
                raise RuntimeError('Portal did not return a playable stream URL')
        except Exception as e:
            self._bg_error = str(e)
        self._bg_done = True

    def _poll_background_audio(self):
        if not self._bg_done:
            return
        try:
            self._bg_timer.stop()
        except Exception:
            pass
        self._bg_loading = False
        if self._closed:
            return
        if self._bg_error:
            label = 'IPAudio export' if str(self._bg_target).startswith('export_') else 'IPAudio' if self._bg_target == 'ipaudio' else 'Local Remux'
            self.session.open(MessageBox, 'Unable to resolve Stalker stream for %s:\n%s' % (label, self._bg_error), MessageBox.TYPE_ERROR, timeout=8)
            return
        try:
            if str(self._bg_target).startswith('export_'):
                from .ipaudioexport import export_channel
                kind = 'pro' if self._bg_target == 'export_pro' else 'legacy'
                path, added = export_channel(kind, str(self._bg_name), str(self._bg_url))
                target = 'IPAudio Pro' if kind == 'pro' else 'IPAudio'
                msg = ('Added %s to %s.\n%s' if added else '%s already exists in %s.\n%s') % (str(self._bg_name), target, path)
                msg += '\n\nFresh MAC link saved; some portals may expire resolved links later.'
                self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=8)
                return
            if self._bg_target == 'ipaudio':
                from .backgroundaudio import start_background_audio_direct
                context = {'source': 'stalker', 'portal': dict(self.portal or {}), 'genre_id': self.genre_id, 'genre_name': self.genre_name, 'channels': list(self.channels or []), 'selected_index': int(self._bg_index), 'channel_name': str(self._bg_name or ''), 'mode': 'iptv'}
                retry_resolver = lambda client=self.client, command=self._bg_cmd: client.create_link(command)
                start_background_audio_direct(self.session, self._bg_url, self._bg_name, headers=dict(self.client.headers), resume_context=context, retry_resolver=retry_resolver)
                self.close('ipaudio-started')
                return
            from .remux import start_local_remux
            resume_context = {'source': 'stalker', 'portal': dict(self.portal or {}), 'genre_id': self.genre_id, 'genre_name': self.genre_name, 'channels': list(self.channels or []), 'selected_index': int(self._bg_index), 'channel_name': str(self._bg_name or ''), 'mode': self._bg_mode}
            retry_resolver = lambda client=self.client, command=self._bg_cmd: client.create_link(command)
            start_local_remux(self.session, self._bg_url, self._bg_name, self._bg_mode, iptv_headers=dict(self.client.headers), resume_context=resume_context, retry_resolver=retry_resolver)
            if self._bg_mode == 'dual':
                msg = 'Starting Local Remux: %s\n\nVideo is copied from the original satellite service. IPTV audio becomes the default track and satellite audio is kept as a second track. After playback starts, press AUDIO to try switching tracks.' % self._bg_name
                self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=7)
        except Exception as e:
            self.session.open(MessageBox, 'Unable to start Local Remux:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=8)

    def _play_index(self, index):
        if not self.channels or index < 0 or index >= len(self.channels):
            return False
        channel_name, channel_cmd = self.channels[index]
        try:
            from .backgroundaudio import prepare_foreground_playback
            prepare_foreground_playback()
            previous_service = self.session.nav.getCurrentlyPlayingServiceReference()
            had_preview = bool(getattr(self, '_list_preview', None))
            stream_url = self.client.create_link(channel_cmd)
            servicetype = _stalker_service_type()
            ref = service_reference(servicetype, 0, stream_url)
            ref.setName(gui_text(str(channel_name)))
            result = self.session.nav.playService(ref)
            if result is False and servicetype == 5002:
                fallback = service_reference(4097, 0, stream_url)
                fallback.setName(gui_text(str(channel_name)))
                self.session.nav.playService(fallback)
                servicetype = 4097
            self.playing_index = index
            self.playing_url = stream_url
            self.playing_service_type = int(servicetype)
            from .listpreview import preview
            preview(self, [stream_url], servicetype, channel_name, play=False)
            if not had_preview:
                self._list_preview.previous = previous_service
            self._list_preview.keep_playing = True
            self._list_preview.full_call = (self._player_closed, Alkuds_Stalker_Player, (self.client, self.channels, index, False, stream_url, servicetype), {})
            return True
        except Exception as e:
            self.session.open(MessageBox, 'Unable to play channel:\n%s' % str(e), MessageBox.TYPE_ERROR, timeout=6)
            return False

    def play(self):
        cur = self['list'].getCurrent()
        if not cur or cur[1] < 0 or cur[1] >= len(self.channels):
            return
        index = cur[1]
        if self.audio_only:
            self.start_ipaudio()
            return
        if self.playing_index != index:
            self._play_index(index)
        else:
            controller = getattr(self, '_list_preview', None)
            if controller:
                controller.fullscreen()

    def _player_closed(self, index=None):
        try:
            self.show()
        except Exception:
            pass
        try:
            if index is not None and self.channels:
                self.playing_index = int(index) % len(self.channels)
                self['list'].setIndex(self.playing_index)
        except Exception:
            pass
        if self.playing_index is not None and self.channels:
            from .listpreview import preview, reference_type
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if ref:
                preview(self, [ref.getPath()], reference_type(ref), self.channels[self.playing_index][0], play=False)
                self._list_preview.full_call = (self._player_closed, Alkuds_Stalker_Player, (self.client, self.channels, self.playing_index, False, ref.getPath(), reference_type(ref)), {})
