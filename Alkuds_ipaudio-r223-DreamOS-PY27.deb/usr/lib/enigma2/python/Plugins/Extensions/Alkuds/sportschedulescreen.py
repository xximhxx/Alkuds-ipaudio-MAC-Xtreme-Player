# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import time
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from enigma import eTimer
from .freestyle import StyledList as List
from .xStaticText import StaticText
from . import sportsguide

class AudioSchedule(Screen):

    def __init__(self, session, name, key):
        Screen.__init__(self, session)
        from .stalker import _channels_skin
        self.skin = _channels_skin()
        self.name, self.key, self.day = (name, key, 0)
        self['title'] = StaticText('')
        self['list'] = List([], enableWrapAround=True)
        for key_name, text in (('red', u'رجوع'), ('green', u'اليوم'), ('yellow', u'الأمس'), ('blue', u'الغد')):
            self['key_' + key_name] = StaticText(text)
        self['actions'] = ActionMap(['AlkudsActions', 'OkCancelActions', 'ColorActions', 'DirectionActions', 'MenuActions'], {'cancel': self.close, 'red': self.close, 'green': lambda: self.set_day(0), 'yellow': lambda: self.set_day(-1), 'blue': lambda: self.set_day(1), 'left': lambda: self.set_day(max(-1, self.day - 1)), 'right': lambda: self.set_day(min(1, self.day + 1)), 'menu': self.reload, 'ok': self.show_program, 'info': self.show_program}, -10)
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.refresh)
        except Exception:
            self.timer.callback.append(self.refresh)
        self.onShown.append(self.shown)
        self.onHide.append(self.timer.stop)
        self.onClose.append(self.timer.stop)
        self.last = None
        self.rows = []

    def show_program(self):
        current = self['list'].getCurrent()
        index = current[1] if current else -1
        if 0 <= index < len(self.rows):
            from .xStaticText import MessageBox
            self.session.open(MessageBox, sportsguide.caption(self.rows[index]), MessageBox.TYPE_INFO, timeout=0)

    def shown(self):
        sportsguide.ensure_async()
        self.refresh()
        self.timer.start(1000, False)

    def set_day(self, day):
        self.day = day
        self.last = None
        self.refresh()

    def reload(self):
        sportsguide.ensure_async(force=True)
        self.last = None
        self.refresh()

    def refresh(self):
        stamp = (self.day, sportsguide.revision(), sportsguide.loading())
        if stamp == self.last:
            return
        self.last = stamp
        start, _ = sportsguide.day_bounds(self.day)
        self['title'].setText(self.name + ' | ' + time.strftime('%d/%m/%Y', time.localtime(start)) + u' | توقيت الرسيفر')
        rows = sportsguide.programs(self.key, self.day) if self.key.startswith('bein') else []
        self.rows = rows
        if rows:
            self['list'].setList([(sportsguide.caption(row), index) for index, row in enumerate(rows)])
            now = time.time()
            current = next((i for i, row in enumerate(rows) if row['start'] <= now < row['stop']), 0)
            self['list'].setIndex(current)
        else:
            text = u'جاري جلب جدول beIN...' if sportsguide.loading() else u'لا يوجد جدول منشور لهذه القناة في المصدر حالياً'
            if not sportsguide.loading() and sportsguide.error_caption():
                text = sportsguide.error_caption()
            if not self.key.startswith('bein'):
                text = u'الجدول عبر الإنترنت متاح لقنوات beIN؛ باقي القنوات تستخدم EPG الرسيفر'
            self['list'].setList([(text, -1)])
