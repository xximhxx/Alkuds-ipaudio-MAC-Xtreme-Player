# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from . import egyapp
from .arabseedui import Alkuds_ArabSeed_Browser

class Alkuds_EgyApp_Browser(Alkuds_ArabSeed_Browser):
    provider = egyapp
    site_name = u'إيجي بيست — التطبيق'

    def open_current(self):
        index = self._index()
        if self.level == 'groups' and (not self._loading) and (not self._closed) and (0 <= index < len(self.entries)):
            section = self.entries[index].get('section')
            if section in ('live', 'live_sports'):
                self.session.open(type(self), section, 'items', {}, 1)
                return
        return Alkuds_ArabSeed_Browser.open_current(self)

    def _start_resolved(self, item):
        if item.get('kind') != 'live':
            return Alkuds_ArabSeed_Browser._start_resolved(self, item)
        from .fajershowui import Alkuds_FajerShow_Qualities
        self.session.open(Alkuds_FajerShow_Qualities, {'variants': item['streams']}, item['name'], 'Live', item.get('description', ''), item.get('image', ''), '')

    def _load_worker(self):
        if self.level != 'sections':
            return Alkuds_ArabSeed_Browser._load_worker(self)
        try:
            self._result = egyapp.sections(self.section)
        except Exception as error:
            self._error = str(error)
        self._done = True
