# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
"""Getkoora public schedules and Soccer Live Player configuration."""
from __future__ import absolute_import, division, print_function
from .py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from .py2compat import urllib
urljoin = urllib.parse.urljoin
urlparse = urllib.parse.urlparse
from .py2compat import time
from .py2compat import threading
from . import sportacity
from .sportacity import UA, _Document, _text, player_config
from .livehd import _get_html, _iframe_urls
from .matchstreams import prepare
BASE = 'https://www.getkoora.org/'
SECTION_MAP = {'matches': (u'جيت كورة - المباريات', '')}
groups = sportacity.groups
_schedule_cache = {}
_schedule_lock = threading.RLock()

def refresh():
    with _schedule_lock:
        compat_clear(_schedule_cache)

def fetch_day(day):
    if day not in ('today', 'tomorrow', 'yesterday'):
        raise RuntimeError(u'جدول غير صحيح.')
    key = (day, time.strftime('%Y-%m-%d'))
    with _schedule_lock:
        cached = _schedule_cache.get(key)
        if cached and time.time() - cached[0] < 30:
            return [dict(x) for x in cached[1]]
    from .py2compat import requests
    path = 'kora-live/' if day == 'today' else 'matches-' + day + '/'
    with requests.get(urljoin(BASE, path), headers={'User-Agent': UA, 'Referer': BASE}, timeout=(4, 10), stream=True) as response:
        response.raise_for_status()
        raw = response.raw.read(2097153, decode_content=True)
        if len(raw) > 2097152:
            raise RuntimeError(u'جدول أكبر من الحد المسموح.')
        html, final = (raw.decode('utf-8-sig', 'replace'), response.url)
    entries = sportacity.parse_matches(html, day, final)
    for item in entries:
        parsed = urlparse(item['url'])
        if parsed.netloc == urlparse(BASE).netloc and parsed.path in ('', '/', '/kora-live/'):
            item['url'] = ''
        item.update(action='servers', _match=True, section='matches', source='getkoora')
    with _schedule_lock:
        _schedule_cache[key] = (time.time(), entries)
    return [dict(x) for x in entries]

def _server_rows(html, final, match):
    servers = player_config(html).get('servers') or []
    rows = []
    for index, server in enumerate(servers):
        if not isinstance(server, dict) or server.get('clappr_license_key') or server.get('clappr_license_type'):
            continue
        if server.get('source_mode', 'direct') not in ('direct', 'api') or not server.get('code_url'):
            continue
        label = server.get('name') or u'سيرفر %d' % (index + 1)
        quality = server.get('quality') or ''
        rows.append(dict(match, name=label + (' | ' + quality if quality else ''), match_name=match['name'], url=final, referer=final, server_index=index, action='play', _server=server))
    return rows

def servers(match):
    if not match.get('url'):
        raise RuntimeError(u'هذه المباراة للجدول فقط؛ لا يوجد بث معلن الآن.')
    html, final = _get_html(match['url'], UA, BASE)
    rows = _server_rows(html, final, match)
    if rows:
        return rows
    for frame in _iframe_urls(html, final)[:8]:
        try:
            inner, target = _get_html(frame, UA, final)
            rows = _server_rows(inner, target, match)
            if rows:
                return rows
        except Exception:
            continue
    raise RuntimeError(u'لم يظهر مشغل لهذه المباراة حالياً؛ حدّث الجدول.')

def page(parent, number):
    entries = servers(parent) if parent.get('_match') else fetch_day(parent.get('day', 'today'))
    start = (max(1, int(number)) - 1) * 24
    return {'entries': entries[start:start + 24], 'last_page': max(1, (len(entries) + 23) // 24)}

def resolve(item):
    from .py2compat import json
    html, final = _get_html(item['url'], UA, item.get('referer') or BASE)
    servers = player_config(html).get('servers') or []
    index = item.get('server_index', 0)
    if not isinstance(index, int) or not 0 <= index < len(servers):
        raise RuntimeError(u'السيرفر تغير؛ افتح المباراة مجدداً.')
    server = servers[index]
    if server.get('clappr_license_key') or server.get('clappr_license_type'):
        raise RuntimeError(u'هذا المشغل محمي ولا يدعمه الرسيفر.')
    target = urljoin(final, server.get('code_url') or '')
    if server.get('source_mode') == 'api':
        body, target_base = _get_html(target, UA, final)
        value = json.loads(body)
        for key in str(server.get('api_json_key') or '').split('.'):
            if key:
                value = value.get(key) if isinstance(value, dict) else None
        if not isinstance(value, str) or not value:
            raise RuntimeError(u'السيرفر لم يرجع رابط البث.')
        target = urljoin(target_base, value)
    elif server.get('source_mode', 'direct') != 'direct':
        raise RuntimeError(u'صيغة مشغل غير مدعومة.')
    if server.get('type') == 'iframe_url':
        candidates = sportacity._players(target, final)
    else:
        candidates = [dict(url=target, name=item['name'], quality=server.get('quality') or 'Auto', headers={'User-Agent': UA, 'Referer': final}, source='getkoora')]
        if server.get('encryption_hls'):
            from .korplaylist import loader_options
            candidates[0]['relay_options'] = loader_options(html, final)
    return prepare(item, candidates)
