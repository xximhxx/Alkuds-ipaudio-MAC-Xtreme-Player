# -*- coding: utf-8 -*-
# DreamOS Python 2.7 branch of r223.
from __future__ import absolute_import, division, print_function
from ..py2compat import str, bytes, int, range, open, OSError, FileNotFoundError, PermissionError, ConnectionError, BrokenPipeError, BlockingIOError, TimeoutError, byte_hex, to_bytes, clear as compat_clear, copy as compat_copy
from ..py2compat import io_module as io

class _U(object):

    @staticmethod
    def encode(i):
        if not i >= 0:
            raise AssertionError('Invalid WebAssembly state')
        r = bytearray()
        while True:
            b = i & 127
            i = i >> 7
            if i == 0:
                r.append(b)
                return r
            r.append(128 | b)

    @staticmethod
    def decode(b):
        if not len(b) > 0:
            raise AssertionError('Invalid WebAssembly state')
        r = 0
        for i, e in enumerate(b):
            r = r + ((e & 127) << i * 7)
        return r

    @staticmethod
    def decode_reader(r):
        a = bytearray()
        while True:
            b = r.read(1)
            if len(b) != 1:
                raise EOFError
            b = ord(b)
            a.append(b)
            if b & 128 == 0:
                break
        return (_U.decode(a), len(a))

class _I(object):

    @staticmethod
    def encode(i):
        r = bytearray()
        while True:
            b = i & 127
            i = i >> 7
            if i == 0 and b & 64 == 0 or (i == -1 and b & 64 != 0):
                r.append(b)
                return r
            r.append(128 | b)

    @staticmethod
    def decode(b):
        if not len(b) > 0:
            raise AssertionError('Invalid WebAssembly state')
        r = 0
        for i, e in enumerate(b):
            r = r + ((e & 127) << i * 7)
        i = len(b) - 1
        e = b[i]
        if e & 64 != 0:
            r |= -(1 << i * 7 + 7)
        return r

    @staticmethod
    def decode_reader(r):
        a = bytearray()
        while True:
            b = r.read(1)
            if len(b) != 1:
                raise EOFError
            b = ord(b)
            a.append(b)
            if b & 128 == 0:
                break
        return (_I.decode(a), len(a))
u = _U()
i = _I()
